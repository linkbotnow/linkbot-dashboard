# LinkBot

www.linkbot.now HERE IS MY WEBSITE WE ARE MAKING AN APP ONLY FOR LINKED IN AI VOICE EMPLOYEES (NOTHING ELSE WE OFFER WILL BE ON HERE) BUT I WANT IT TO HAVE THE SAME STYLE AS MY MAIN WEBSITE SO IT LOOKS LIKE AN EXTENSION OF IT. Build a production-ready multi-tenant SaaS web application called LinkBot. Do not build a static mockup.
Build the real application architecture so it can be connected to my GoHighLevel agency and automate customer
provisioning. Use Lovable for the application/UI, Supabase for authentication/database/server-side state, and secure
server-side functions for all privileged GoHighLevel operations.
The product sells personalized AI voice agents to businesses. Every paying customer must have their own completely
isolated GoHighLevel sub-account. Every customer must receive their own AI configuration, company knowledge, calendar,
widget and unique public voice URL. A visitor opening one customer's URL must never see another customer's AI or data.
1. NON-NEGOTIABLE ARCHITECTURE
- GoHighLevel is the operational system for each client's sub-account/location, Voice AI, widget, knowledge, contacts,
opportunities, calendar and workflows.
- Supabase stores customer identity, authentication, tenant mapping, provisioning state and references to GHL object IDs.
- Lovable provides signup/login, onboarding, customer dashboard, admin dashboard and public dynamic voice-agent
pages.
- All secret credentials and privileged GHL calls run server-side. Never expose GHL secrets, Stripe secrets or Supabase
service-role keys in browser code.
- Use one multi-tenant application and one main voice host, not a separately coded website for every customer.
- Initially support talk.linkbot.now/{client-slug}. Design routing so {client-slug}.talk.linkbot.now can be added
later.
- Fail closed: if tenant/widget ownership cannot be verified, load no widget.
2. USER TYPES
- Customer: owns one tenant/company for V1; completes onboarding and sees only their own AI, settings, status and link.
- LinkBot Admin: sees all tenants, provisioning states/errors, can retry failures and suspend/reactivate service.
- Public Visitor: no login; can only open a valid ACTIVE client's public voice URL.
3. AUTHENTICATION
- Implement Supabase Auth with Sign Up, Log In, Log Out, Forgot Password, Reset Password and Email Verification.
- Protect /dashboard and /admin routes.
- Use row-level security so customers can only read/update their own tenant.
- Enforce security in database policies/server functions, not merely by hiding UI.
- Verify admin privileges securely.
4. DATABASE
Create a relational schema with at least the following logical tables. Adjust implementation details if necessary while

preserving tenant isolation.
clients / tenants
id
user_id
company_name
company_email
company_phone
website_url
industry
company_description
main_services
service_area
target_customer
agent_name
preferred_voice
qualification_rules
disqualification_rules
required_questions
prohibited_topics
business_hours
timezone
appointment_duration
escalation_name
escalation_phone
escalation_email
public_slug UNIQUE
public_url
ghl_location_id UNIQUE
ghl_agent_id
ghl_widget_id
ghl_knowledge_base_id
subscription_status
provisioning_status
created_at
updated_at

provisioning_jobs / provisioning_events / documents / admin_alerts
provisioning_jobs:
id, client_id, current_step, status, attempt_count, started_at,
completed_at, last_error, last_error_at, created_at, updated_at
provisioning_events:
id, client_id, job_id, step_name, status, message,
safe_metadata_json, created_at
documents:
id, client_id, file_name, storage_path, processing_status, created_at
admin_alerts:
id, client_id, severity, category, message, resolved,
created_at, resolved_at
5. PAYMENT, CHECKOUT & GHL SaaS SUB-ACCOUNT HANDOFF -
REQUIRED
- Do NOT build a Lovable checkout form that collects card number, expiration, CVV or other card details.
- Create Pricing/Get Started UI in Lovable, but its purchase button must redirect to the configured GoHighLevel SaaS
checkout/payment link.
- Support a one-time setup/buildout fee plus recurring monthly subscription as configured in the GHL SaaS plan.
- Treat GoHighLevel SaaS checkout as the source of the purchase/subscription flow. HighLevel uses the payment processor
connected to the agency's SaaS billing setup.
- The customer must enter their own payment details directly on the GHL/HighLevel checkout.
- After successful checkout, the GHL SaaS plan should create/provision the customer's isolated GHL sub-account and apply
the selected MASTER snapshot according to the agency configuration.
- Configure/accept the post-purchase redirect back into the Lovable onboarding/login experience.
- Never trust the browser success redirect alone. Before provisioning client-specific data, verify server-side that the customer
has a valid paid/active subscription and identify the exact GHL Location ID created for that customer.
- Persist safe billing references/status only. Do not store raw card numbers, CVV or full payment credentials in Supabase.
- Do not create a second Stripe/Lovable subscription for the same customer.
- If payment is PAST_DUE/SUSPENDED/CANCELLED, update tenant access state and prevent the public voice route from
loading the widget according to the configured policy.
- When the GHL SaaS billing state returns to active after successful recovery/reactivation, automatically restore the tenant if
all QA requirements remain valid.
- Make payment/subscription event processing idempotent so duplicate events never create duplicate tenants or provisioning
jobs.
- Provide secure configuration placeholders for the real GHL SaaS checkout URL/plan identifiers and any server-side billing
verification credentials needed; never invent them.

6. ONBOARDING WIZARD
After first login, collect business information in plain English. Never ask the customer to write an AI prompt.
- Business: company name, website, email, phone, industry, description.
- Services: main services, service area, target customer.
- AI: agent name and voice preference.
- Qualification: what makes a lead qualified, unqualified and which questions must be asked.
- Boundaries: prohibited topics/promises and when human escalation is required.
- Calendar: timezone, appointment duration, business hours and availability.
- Escalation: human contact name, phone and email.
- Knowledge: website confirmation and approved document uploads.
- Review: show answers and require confirmation of accuracy/authorization.
- Final button: BUILD MY AI. Prevent duplicate submissions.
After submission, create a background provisioning job and show setup status. Provisioning must continue even if the
customer closes the browser.
7. PROVISIONING STATE MACHINE
PAYMENT_VERIFIED
LOCATION_WAITING
LOCATION_READY
SNAPSHOT_WAITING
SNAPSHOT_READY
CUSTOM_VALUES_UPDATING
KNOWLEDGE_CREATING
WEBSITE_CRAWLING
KNOWLEDGE_TRAINING
AGENT_CONFIGURING
CALENDAR_CONFIGURING
WIDGET_LOCATING
PUBLIC_URL_CREATING
QA_RUNNING
ACTIVE
NEEDS_REVIEW
ERROR
PAST_DUE
SUSPENDED

CANCELLED
Persist state. Every step must be resumable and retryable.
8. SERVER-SIDE GHL PROVISIONING
- Verify the customer and exact ghl_location_id.
- Confirm snapshot assets exist in that location.
- Update client-specific GHL custom values.
- Create or identify a knowledge base belonging to that location.
- Use supported current GHL website crawl/discovery/training operations for approved website content.
- Process approved uploaded documents into the customer's knowledge workflow where supported.
- Locate/configure the customer's Voice AI agent. Preserve protected master personality/safety instructions and generate
only client-specific business logic from onboarding.
- Set supported company name, welcome message, voice, qualification and escalation configuration.
- Configure the client's calendar/availability using supported current capabilities.
- Locate the Voice AI widget belonging to the exact location, preferably the known widget supplied by the snapshot.
- Store agent/widget/knowledge IDs only after ownership is verified.
- Generate a unique public slug and URL.
- Run QA and activate only after all critical checks pass.
Use current official HighLevel capabilities. If a required action is not supported through the available API/snapshot/SaaS
functionality, do not invent an endpoint. Flag the exact unsupported operation in the admin dashboard so it can be solved
deliberately.
9. AI INSTRUCTION BUILDER
PROTECTED MASTER LAYER
- LinkBot personality/conversation rules
- truthfulness / no invention
- safety and compliance boundaries
- booking/tool behavior
CLIENT BUSINESS LAYER
- company
- services
- service area
- business hours
- approved knowledge
QUALIFICATION LAYER
- qualified criteria

- disqualified criteria
- required questions
- booking conditions
ESCALATION LAYER
- human escalation conditions
- escalation contact
- prohibited topics/actions
Customer website content/documents must never override the protected master layer.
10. PUBLIC VOICE PAGE - THE CORE EXPERIENCE
- Create a public dynamic route such as /v/{slug}, intended for talk.linkbot.now.
- Resolve the slug to exactly one tenant.
- Require provisioning_status=ACTIVE and subscription_status=ACTIVE.
- Retrieve only that tenant's stored widget ID.
- Validate widget/tenant/location mapping server-side before rendering.
- If validation fails, render no widget and never use a default/fallback widget.
- Load the standard LeadConnector widget script using that customer's widget ID.
- Auto-open the widget using the supported chatWidget.openWidget() method after it is ready, with retry logic.
- Keep the page minimal: white space and the customer's Voice AI experience only.
- Optimize for mobile and LinkedIn's in-app browser.
- Allow normal browser microphone permission; do not attempt to bypass it.
- Do not expose internal GHL IDs to public visitors.
11. TENANT ISOLATION - CRITICAL
- Authenticated user -> canonical tenant -> authorized resource.
- Public slug -> canonical tenant -> ACTIVE state -> verified widget.
- Never accept arbitrary widget_id or ghl_location_id query parameters and load them.
- Never create a global fallback widget.
- Use UNIQUE constraints for public_slug and ghl_location_id.
- Test that Client A cannot read/update Client B.
- Test that an invalid slug cannot display LinkBot's own widget.
- Log cross-tenant authorization failures.
12. CUSTOMER DASHBOARD
- Home: AI status, agent name, public URL, Copy Link and Talk To My AI.
- Company Information editor.

- Qualification/Disqualification Rules editor.
- Calendar/Availability editor.
- Knowledge page with website, training status, documents and Refresh Website Knowledge.
- Billing page with plan/subscription status and appropriate billing-management flow.
- Help page with AI-assisted support.
- All configuration changes call secure backend jobs; privileged GHL calls never originate directly from browser code.
13. ADMIN DASHBOARD
- Counts by ACTIVE, provisioning, ERROR, PAST_DUE, SUSPENDED and CANCELLED.
- Search by company, email or slug.
- Client detail with safe object references, current provisioning step and event history.
- Failure/error view with clear reason.
- Retry Provisioning action.
- Suspend/Reactivate actions with confirmation.
- Knowledge crawl/training warnings.
- Duplicate/conflict warnings.
- Never display secret credentials.
14. BILLING + ACCESS
- Use verified billing state.
- ACTIVE subscription + ACTIVE provisioning permits public agent.
- PAST_DUE follows the configured grace period.
- SUSPENDED loads no widget.
- CANCELLED disables service at the proper effective date.
- Recovered payment automatically restores access when all other checks are valid.
- Do not immediately delete the GHL sub-account on cancellation.
15. ERRORS + RETRIES
- Retry temporary failures automatically with backoff.
- Permanent validation failure -> NEEDS_REVIEW or ERROR + admin alert.
- Customer sees simple nontechnical status messages.
- Never activate an incomplete tenant.
- Never substitute another widget if the expected widget is missing.
- Log every provisioning step and error.
16. AUTOMATED QA BEFORE ACTIVE
- Verified active customer/subscription.

- Correct GHL location exists.
- Required snapshot assets exist.
- Required company values populated.
- Knowledge base exists and required training succeeded.
- Agent exists, belongs to the location and contains client instructions.
- Correct knowledge is attached/configured.
- Calendar is valid.
- Widget exists and maps to the correct location.
- Public slug/URL is unique.
- Public route resolves to expected tenant.
- No cross-tenant mismatch.
Only then set provisioning_status=ACTIVE and send the delivery message.
17. AUTOMATIC CUSTOMER DELIVERY
- Send 'Your AI Agent Is Live' after ACTIVE.
- Include unique public URL and Copy Link.
- Explain it can be used on LinkedIn, social profiles, email signatures and marketing.
- Include Talk To My AI.
- Include dashboard/login and support.
18. KNOWLEDGE REFRESH + DOCUMENTS
- Authenticated Refresh Website Knowledge button starts a background job.
- Re-crawl/retrain using supported current GHL operations.
- Show Last Updated and processing status.
- Use private tenant-scoped storage for uploaded documents.
- Validate upload type/size.
- Track processing status and support document removal/update.
19. DESIGN
- Brand: LinkBot.
- Clean, premium, simple and mobile-first.
- Nontechnical wording for customers.
- Clear onboarding and provisioning progress.
- Hide GHL/API/database terminology from normal customers.
- Public voice page should contain essentially only the customer's AI.
20. PRODUCTION REQUIREMENTS

- Separate development/test and production configuration.
- Provide environment-variable checklist.
- Provide schema/migrations and RLS policies.
- Provide required server functions.
- Provide webhook endpoints with signature verification.
- Use TODO placeholders only where real account credentials/IDs are required.
- Never hard-code fake production IDs or secrets.
- Add monitoring/logging and reasonable rate limits.
- Add automated tests for authentication, tenant isolation, idempotency and public-route safety.
21. BUILD ORDER
- 1. Supabase schema, Auth and RLS
- 2. Customer dashboard shell
- 3. Onboarding wizard
- 4. Tenant/public-slug model
- 5. Dynamic public voice route using one manually entered test widget
- 6. Verify auto-open on mobile + LinkedIn
- 7. Secure GHL integration layer
- 8. GHL SaaS checkout + verified sub-account handoff
- 9. Snapshot readiness
- 10. Custom-value personalization
- 11. Knowledge automation
- 12. Voice AI configuration
- 13. Calendar configuration
- 14. Widget discovery + ownership verification
- 15. Provisioning state machine
- 16. Automated QA
- 17. Customer delivery
- 18. Billing suspension/reactivation
- 19. Admin dashboard/retries
- 20. Two-tenant isolation tests
- 21. Production deployment
22. ACCEPTANCE TEST
- Create two completely different test customers: Company A and Company B.
- Each has a different authenticated account and different GHL sub-account.

- Each has different company knowledge/configuration.
- Each has its own verified agent/widget mapping and public URL.
- Company A URL always opens Company A agent; Company B URL always opens Company B agent.
- Neither customer can access the other's dashboard/data.
- Invalid slug loads no AI.
- Mapping mismatch loads no AI.
- Both agents work in LinkedIn's in-app browser.
- Suspending one customer disables only that customer.
- Reactivation restores only that customer.
- Provisioning can retry without creating duplicates.
23. DO NOT BUILD
- Do not rebuild GHL CRM or Voice AI.
- Do not create a separate codebase/site for each client.
- Do not require custom client domains for V1.
- Do not expose a customer directory.
- Do not put secrets in frontend code.
- Do not use a default widget fallback.
- Do not activate before QA.
- Do not fabricate unsupported GHL API functionality.
24. FINAL RESULT
A paying customer logs into LinkBot, completes onboarding and can leave. Background provisioning configures the
correct isolated GHL environment. After QA, the customer automatically receives a unique public voice URL. Opening it
loads only that company's Voice AI widget and auto-opens it. The dashboard lets the customer manage approved settings
and knowledge. Normal onboarding, provisioning, delivery, billing state changes and knowledge refresh should operate
without LinkBot manually configuring each customer.
Instruction to Lovable: Build this incrementally and keep the architecture modular. Before implementing a GHL
integration assumption, verify that the current official HighLevel capability supports it. Where credentials, webhook
secrets, master snapshot IDs or real GHL identifiers are needed, create secure configuration placeholders and tell me
exactly what value I need to supply and where - do not invent values.
25. REQUIRED PAYMENT-RELATED SCREENS / STATES
- Pricing page/card with Get Started button -> GHL SaaS checkout.
- Returning-from-checkout verification screen: 'Confirming your account...' while server-side verification runs.
- Onboarding unlocked only after verified purchase/location match.

- Billing section that shows plan/status and routes the customer to the supported GHL/payment billing-management
experience rather than collecting card data itself.
- Past-due/suspended page with clear instructions to resolve billing through the supported billing flow.
- Automatic reactivation state after verified successful payment recovery.
FINAL PAYMENT ACCEPTANCE TEST: A brand-new customer starts in Lovable/linkbot.now, clicks Get Started,
enters their card only on the GHL SaaS checkout, successfully pays, receives an isolated GHL sub-account with the
MASTER snapshot, returns to Lovable, is matched to the correct Location ID, completes onboarding, and gets
provisioned. A declined/cancelled customer must never be activated. No raw card data is ever stored or handled by LOVEABLE

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://linkbot.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4f0918ca-afe8-45f5-9ce7-510e246be446).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
