DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'provisioning-worker-retry') THEN
    PERFORM cron.unschedule('provisioning-worker-retry');
  END IF;
END $$;

DROP TRIGGER IF EXISTS provisioning_jobs_wake ON public.provisioning_jobs;
DROP FUNCTION IF EXISTS public.provisioning_jobs_wake_trigger();
DROP FUNCTION IF EXISTS public.provisioning_retry_tick();
DROP FUNCTION IF EXISTS public.arm_provisioning_retry();
DROP FUNCTION IF EXISTS public.wake_provisioning_worker();

DROP POLICY IF EXISTS "client_docs_select_own" ON storage.objects;
DROP POLICY IF EXISTS "client_docs_insert_own" ON storage.objects;
DROP POLICY IF EXISTS "client_docs_update_own" ON storage.objects;
DROP POLICY IF EXISTS "client_docs_delete_own" ON storage.objects;

DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.provisioning_events;
DROP TABLE IF EXISTS public.provisioning_jobs;
DROP TABLE IF EXISTS public.admin_alerts;
DROP TABLE IF EXISTS public.checkout_intents;

ALTER TABLE public.billing_events DROP CONSTRAINT IF EXISTS billing_events_client_id_fkey;
UPDATE public.billing_events SET client_id = NULL;
ALTER TABLE public.billing_events ADD CONSTRAINT billing_events_client_id_fkey
  FOREIGN KEY (client_id) REFERENCES public.client_slugs(id) ON DELETE SET NULL;

DROP TABLE IF EXISTS public.clients;
DROP FUNCTION IF EXISTS public.owns_client(uuid);
DROP FUNCTION IF EXISTS public.protect_client_columns();
DROP FUNCTION IF EXISTS public.sanitize_client_insert();

DROP TABLE IF EXISTS public.internal_settings;
DROP TABLE IF EXISTS public.profiles;

DROP POLICY IF EXISTS "Admins can view demo requests" ON public.demo_requests;
DROP POLICY IF EXISTS billing_events_admin_select ON public.billing_events;
DROP POLICY IF EXISTS client_slugs_admin_select ON public.client_slugs;
DROP POLICY IF EXISTS audit_admin_select ON public.security_audit_log;
DROP TABLE IF EXISTS public.user_roles;
DROP FUNCTION IF EXISTS public.is_admin();
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
DROP TYPE IF EXISTS public.app_role;

CREATE POLICY demo_requests_server_only ON public.demo_requests FOR SELECT TO authenticated USING (false);
CREATE POLICY billing_events_server_only ON public.billing_events FOR SELECT TO authenticated USING (false);
CREATE POLICY client_slugs_server_only ON public.client_slugs FOR SELECT TO authenticated USING (false);
CREATE POLICY security_audit_log_server_only ON public.security_audit_log FOR SELECT TO authenticated USING (false);

DROP FUNCTION IF EXISTS public.reserve_client_slug(text, text, text, text, text, text, text[]);

DROP TYPE IF EXISTS public.alert_severity;
DROP TYPE IF EXISTS public.document_status;
DROP TYPE IF EXISTS public.event_status;
DROP TYPE IF EXISTS public.job_status;
DROP TYPE IF EXISTS public.provisioning_status;
DROP TYPE IF EXISTS public.subscription_status;