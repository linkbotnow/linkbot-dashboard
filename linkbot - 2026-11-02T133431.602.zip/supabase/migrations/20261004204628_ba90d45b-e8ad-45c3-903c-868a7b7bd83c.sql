ALTER TABLE public.client_slugs DROP CONSTRAINT IF EXISTS client_slugs_slug_format;
ALTER TABLE public.client_slugs ADD CONSTRAINT client_slugs_slug_format
  CHECK (slug ~ '^[a-z0-9_-]+(\.[a-z0-9_-]+)*$' AND length(slug) BETWEEN 3 AND 30);

CREATE OR REPLACE FUNCTION public.reserve_client_slug(p_email text, p_slug text, p_full_name text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_company text DEFAULT NULL::text, p_website text DEFAULT NULL::text, p_domains text[] DEFAULT '{}'::text[], p_last_name text DEFAULT NULL::text, p_owner_account_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_email text := lower(btrim(p_email));
  v_slug text := lower(btrim(p_slug));
  v_existing public.client_slugs;
BEGIN
  IF v_slug !~ '^[a-z0-9_-]+(\.[a-z0-9_-]+)*$' OR length(v_slug) < 3 OR length(v_slug) > 30 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid');
  END IF;
  IF length(v_slug) = 12 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
  END IF;

  SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
  IF FOUND AND lower(v_existing.email) <> v_email THEN
    IF v_existing.status NOT IN ('active','paused') AND v_existing.activated_at IS NULL
       AND v_existing.hold_expires_at IS NOT NULL AND v_existing.hold_expires_at < now() THEN
      PERFORM public.release_expired_holds(v_slug);
    ELSE
      RETURN jsonb_build_object('ok', false, 'reason', 'taken');
    END IF;
  END IF;

  INSERT INTO public.client_slugs (email, slug, full_name, last_name, phone, company_name, website, owner_account_id, allowed_domains, status, link_code, hold_expires_at)
  VALUES (v_email, v_slug, p_full_name, p_last_name, p_phone, p_company, p_website, p_owner_account_id, COALESCE(p_domains, '{}'), 'reserved', public.generate_link_code(), now() + interval '30 minutes')
  ON CONFLICT (lower(email)) DO UPDATE
    SET slug = EXCLUDED.slug,
        full_name = COALESCE(EXCLUDED.full_name, public.client_slugs.full_name),
        last_name = COALESCE(EXCLUDED.last_name, public.client_slugs.last_name),
        phone = COALESCE(EXCLUDED.phone, public.client_slugs.phone),
        company_name = COALESCE(EXCLUDED.company_name, public.client_slugs.company_name),
        website = COALESCE(EXCLUDED.website, public.client_slugs.website),
        owner_account_id = COALESCE(EXCLUDED.owner_account_id, public.client_slugs.owner_account_id),
        allowed_domains = CASE WHEN array_length(EXCLUDED.allowed_domains, 1) IS NULL
                               THEN public.client_slugs.allowed_domains
                               ELSE EXCLUDED.allowed_domains END,
        link_code = COALESCE(public.client_slugs.link_code, EXCLUDED.link_code),
        hold_expires_at = now() + interval '30 minutes'
    WHERE public.client_slugs.status NOT IN ('active','paused');

  IF NOT EXISTS (SELECT 1 FROM public.client_slugs WHERE lower(email) = v_email AND slug = v_slug) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'locked');
  END IF;

  RETURN jsonb_build_object('ok', true, 'slug', v_slug);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
END;
$function$;

-- GoHighLevel link change: rename a paid, active bot's name link.
CREATE OR REPLACE FUNCTION public.rename_bot_slug(p_bot_id uuid, p_new_slug text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_slug text := lower(btrim(p_new_slug));
  v_bot public.client_slugs;
  v_existing public.client_slugs;
BEGIN
  SELECT * INTO v_bot FROM public.client_slugs WHERE id = p_bot_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'reason', 'bot_not_found'); END IF;
  IF v_bot.status <> 'active' OR v_bot.activated_at IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_active');
  END IF;
  IF v_slug !~ '^[a-z0-9_-]+(\.[a-z0-9_-]+)*$' OR length(v_slug) < 3 OR length(v_slug) > 30 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_name');
  END IF;
  IF length(v_slug) = 12 THEN RETURN jsonb_build_object('ok', false, 'reason', 'name_taken'); END IF;
  IF v_slug = v_bot.slug THEN
    RETURN jsonb_build_object('ok', true, 'slug', v_bot.slug, 'link_code', v_bot.link_code, 'changed', false);
  END IF;

  SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
  IF FOUND THEN
    IF v_existing.status NOT IN ('active','paused') AND v_existing.activated_at IS NULL
       AND v_existing.hold_expires_at IS NOT NULL AND v_existing.hold_expires_at < now() THEN
      PERFORM public.release_expired_holds(v_slug);
    ELSE
      RETURN jsonb_build_object('ok', false, 'reason', 'name_taken');
    END IF;
  END IF;

  UPDATE public.client_slugs SET slug = v_slug, links_sent_at = NULL WHERE id = p_bot_id;
  RETURN jsonb_build_object('ok', true, 'slug', v_slug, 'link_code', v_bot.link_code, 'changed', true);
EXCEPTION
  WHEN unique_violation THEN RETURN jsonb_build_object('ok', false, 'reason', 'name_taken');
END;
$function$;

-- GoHighLevel link change: new private link; the old code is retired forever.
CREATE OR REPLACE FUNCTION public.new_bot_link_code(p_bot_id uuid)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_bot public.client_slugs;
  v_code text;
BEGIN
  SELECT * INTO v_bot FROM public.client_slugs WHERE id = p_bot_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'reason', 'bot_not_found'); END IF;
  IF v_bot.status <> 'active' OR v_bot.activated_at IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'not_active');
  END IF;
  IF v_bot.link_code IS NOT NULL THEN
    INSERT INTO public.retired_link_codes (link_code) VALUES (v_bot.link_code) ON CONFLICT (link_code) DO NOTHING;
  END IF;
  v_code := public.generate_link_code();
  UPDATE public.client_slugs SET link_code = v_code, links_sent_at = NULL WHERE id = p_bot_id;
  RETURN jsonb_build_object('ok', true, 'slug', v_bot.slug, 'link_code', v_code, 'changed', true);
END;
$function$;

REVOKE ALL ON FUNCTION public.rename_bot_slug(uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.new_bot_link_code(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.rename_bot_slug(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.new_bot_link_code(uuid) TO service_role;