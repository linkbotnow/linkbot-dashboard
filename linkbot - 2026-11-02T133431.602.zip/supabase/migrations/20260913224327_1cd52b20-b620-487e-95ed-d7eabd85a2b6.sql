ALTER TABLE public.client_slugs
  DROP CONSTRAINT IF EXISTS client_slugs_slug_format;

ALTER TABLE public.client_slugs
  ADD CONSTRAINT client_slugs_slug_format
  CHECK (slug ~ '^[a-z0-9]{3,30}$');

CREATE OR REPLACE FUNCTION public.reserve_client_slug(
  p_email text,
  p_slug text,
  p_full_name text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_company text DEFAULT NULL,
  p_website text DEFAULT NULL,
  p_domains text[] DEFAULT '{}'
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text := lower(btrim(p_email));
  v_slug text := lower(btrim(p_slug));
  v_existing public.client_slugs;
BEGIN
  IF v_slug !~ '^[a-z0-9]{3,30}$' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid');
  END IF;

  SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
  IF FOUND AND lower(v_existing.email) <> v_email THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
  END IF;

  INSERT INTO public.client_slugs (email, slug, full_name, phone, company_name, website, allowed_domains, status)
  VALUES (v_email, v_slug, p_full_name, p_phone, p_company, p_website, COALESCE(p_domains, '{}'), 'reserved')
  ON CONFLICT (lower(email)) DO UPDATE
    SET slug = EXCLUDED.slug,
        full_name = COALESCE(EXCLUDED.full_name, public.client_slugs.full_name),
        phone = COALESCE(EXCLUDED.phone, public.client_slugs.phone),
        company_name = COALESCE(EXCLUDED.company_name, public.client_slugs.company_name),
        website = COALESCE(EXCLUDED.website, public.client_slugs.website),
        allowed_domains = CASE WHEN array_length(EXCLUDED.allowed_domains, 1) IS NULL
                               THEN public.client_slugs.allowed_domains
                               ELSE EXCLUDED.allowed_domains END
    WHERE public.client_slugs.status <> 'active';

  IF NOT EXISTS (SELECT 1 FROM public.client_slugs WHERE lower(email) = v_email AND slug = v_slug) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'locked');
  END IF;

  RETURN jsonb_build_object('ok', true, 'slug', v_slug);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
END;
$$;