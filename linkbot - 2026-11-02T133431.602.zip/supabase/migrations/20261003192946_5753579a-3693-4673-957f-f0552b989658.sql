-- lovable-cron-fallback-reviewed: 24 runs/day; availability is derived from hold_expires_at at query time, this hourly job only tidies expired rows.
ALTER TABLE public.client_slugs ADD COLUMN IF NOT EXISTS link_code text, ADD COLUMN IF NOT EXISTS hold_expires_at timestamptz;

CREATE OR REPLACE FUNCTION public.generate_link_code()
RETURNS text LANGUAGE plpgsql VOLATILE SET search_path = public, extensions AS $$
DECLARE
  alphabet constant text := 'abcdefghijklmnopqrstuvwxyz0123456789';
  v_code text; v_bytes bytea; i int;
BEGIN
  LOOP
    v_bytes := extensions.gen_random_bytes(12);
    v_code := '';
    FOR i IN 0..11 LOOP
      -- 252 = 7*36: reject-free mapping is not exact; use rejection sampling
      WHILE get_byte(v_bytes, i) >= 252 LOOP
        v_bytes := set_byte(v_bytes, i, get_byte(extensions.gen_random_bytes(1), 0));
      END LOOP;
      v_code := v_code || substr(alphabet, (get_byte(v_bytes, i) % 36) + 1, 1);
    END LOOP;
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.client_slugs WHERE link_code = v_code);
  END LOOP;
  RETURN v_code;
END; $$;
REVOKE ALL ON FUNCTION public.generate_link_code() FROM PUBLIC, anon, authenticated;

UPDATE public.client_slugs SET link_code = public.generate_link_code() WHERE link_code IS NULL;
UPDATE public.client_slugs SET hold_expires_at = now() + interval '30 minutes' WHERE hold_expires_at IS NULL AND status <> 'active';
CREATE UNIQUE INDEX IF NOT EXISTS client_slugs_link_code_key ON public.client_slugs (link_code);

-- Remove expired, never-activated holds; archive each so a late payment can be matched.
CREATE OR REPLACE FUNCTION public.release_expired_holds(p_slug text DEFAULT NULL)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_count integer;
BEGIN
  WITH gone AS (
    DELETE FROM public.client_slugs
    WHERE status <> 'active' AND activated_at IS NULL
      AND hold_expires_at IS NOT NULL AND hold_expires_at < now()
      AND (p_slug IS NULL OR slug = p_slug)
    RETURNING *
  )
  INSERT INTO public.security_audit_log (event_type, details)
  SELECT 'hold_expired', to_jsonb(gone) FROM gone;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END; $$;
REVOKE ALL ON FUNCTION public.release_expired_holds(text) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.reserve_client_slug(p_email text, p_slug text, p_full_name text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_company text DEFAULT NULL::text, p_website text DEFAULT NULL::text, p_domains text[] DEFAULT '{}'::text[], p_last_name text DEFAULT NULL::text, p_password_hash text DEFAULT NULL::text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  v_email text := lower(btrim(p_email));
  v_slug text := lower(btrim(p_slug));
  v_existing public.client_slugs;
BEGIN
  IF v_slug !~ '^[a-z0-9][a-z0-9-]{1,29}$' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid');
  END IF;
  IF length(v_slug) = 12 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
  END IF;

  SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
  IF FOUND AND lower(v_existing.email) <> v_email THEN
    IF v_existing.status <> 'active' AND v_existing.activated_at IS NULL
       AND v_existing.hold_expires_at IS NOT NULL AND v_existing.hold_expires_at < now() THEN
      PERFORM public.release_expired_holds(v_slug);
    ELSE
      RETURN jsonb_build_object('ok', false, 'reason', 'taken');
    END IF;
  END IF;

  INSERT INTO public.client_slugs (email, slug, full_name, last_name, phone, company_name, website, login_password_hash, allowed_domains, status, link_code, hold_expires_at)
  VALUES (v_email, v_slug, p_full_name, p_last_name, p_phone, p_company, p_website, p_password_hash, COALESCE(p_domains, '{}'), 'reserved', public.generate_link_code(), now() + interval '30 minutes')
  ON CONFLICT (lower(email)) DO UPDATE
    SET slug = EXCLUDED.slug,
        full_name = COALESCE(EXCLUDED.full_name, public.client_slugs.full_name),
        last_name = COALESCE(EXCLUDED.last_name, public.client_slugs.last_name),
        phone = COALESCE(EXCLUDED.phone, public.client_slugs.phone),
        company_name = COALESCE(EXCLUDED.company_name, public.client_slugs.company_name),
        website = COALESCE(EXCLUDED.website, public.client_slugs.website),
        login_password_hash = COALESCE(EXCLUDED.login_password_hash, public.client_slugs.login_password_hash),
        allowed_domains = CASE WHEN array_length(EXCLUDED.allowed_domains, 1) IS NULL
                               THEN public.client_slugs.allowed_domains
                               ELSE EXCLUDED.allowed_domains END,
        link_code = COALESCE(public.client_slugs.link_code, EXCLUDED.link_code),
        hold_expires_at = now() + interval '30 minutes'
    WHERE public.client_slugs.status <> 'active';

  IF NOT EXISTS (SELECT 1 FROM public.client_slugs WHERE lower(email) = v_email AND slug = v_slug) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'locked');
  END IF;

  RETURN jsonb_build_object('ok', true, 'slug', v_slug);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
END;
$function$;

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'release-expired-link-holds') THEN
    PERFORM cron.unschedule('release-expired-link-holds');
  END IF;
  PERFORM cron.schedule('release-expired-link-holds', '0 * * * *', 'SELECT public.release_expired_holds();');
END $$;