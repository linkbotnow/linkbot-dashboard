INSERT INTO public.customer_accounts (email, password_hash)
VALUES ('test@test.com', 'scrypt$dcf021ad747c25323701d17dfa27dce6$cc83e158bcf184f7c7deb6e98a203238272e5a26ceb62b7b34003b2cdfb954c4dfc2fed734b0e839f3f56fe240b09a455b1dd467417b2092e1f68ec84d936338')
ON CONFLICT (lower(email)) DO NOTHING;