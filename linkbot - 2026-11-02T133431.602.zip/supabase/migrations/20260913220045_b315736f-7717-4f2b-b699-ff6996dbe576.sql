CREATE TABLE public.widget_page_hits (
  ip_hash text NOT NULL,
  window_start timestamp with time zone NOT NULL,
  hits integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (ip_hash, window_start)
);

GRANT ALL ON public.widget_page_hits TO service_role;

ALTER TABLE public.widget_page_hits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "widget_page_hits_no_client_access" ON public.widget_page_hits FOR SELECT TO authenticated USING (false);

CREATE TRIGGER update_widget_page_hits_updated_at BEFORE UPDATE ON public.widget_page_hits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.register_widget_page_hit(p_ip_hash text, p_limit integer DEFAULT 10)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_window timestamp with time zone := date_trunc('hour', now());
  v_hits integer;
BEGIN
  IF p_ip_hash IS NULL OR length(p_ip_hash) = 0 THEN
    RETURN jsonb_build_object('allowed', true, 'hits', 0);
  END IF;

  INSERT INTO public.widget_page_hits (ip_hash, window_start, hits)
  VALUES (p_ip_hash, v_window, 1)
  ON CONFLICT (ip_hash, window_start)
  DO UPDATE SET hits = public.widget_page_hits.hits + 1, updated_at = now()
  RETURNING hits INTO v_hits;

  DELETE FROM public.widget_page_hits WHERE window_start < now() - interval '6 hours';

  RETURN jsonb_build_object('allowed', v_hits <= p_limit, 'hits', v_hits);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.register_widget_page_hit(text, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.register_widget_page_hit(text, integer) TO service_role;