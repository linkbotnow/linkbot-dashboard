ALTER TABLE public.demo_requests ADD COLUMN repeat_of uuid REFERENCES public.demo_requests(id) ON DELETE SET NULL;
CREATE INDEX demo_requests_email_website_created_idx ON public.demo_requests (lower(email), lower(website), created_at DESC);
CREATE INDEX demo_requests_created_idx ON public.demo_requests (created_at DESC);

CREATE TABLE public.demo_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code_hash text NOT NULL,
  payload jsonb NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.demo_codes TO service_role;
ALTER TABLE public.demo_codes ENABLE ROW LEVEL SECURITY;
CREATE POLICY demo_codes_server_only ON public.demo_codes FOR SELECT TO authenticated USING (false);