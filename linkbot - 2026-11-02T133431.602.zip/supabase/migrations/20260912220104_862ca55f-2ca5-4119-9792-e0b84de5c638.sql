CREATE POLICY "client_docs_select_own" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'client-documents' AND (public.owns_client(((storage.foldername(name))[1])::uuid) OR public.is_admin()));
CREATE POLICY "client_docs_insert_own" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'client-documents' AND public.owns_client(((storage.foldername(name))[1])::uuid));
CREATE POLICY "client_docs_delete_own" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'client-documents' AND public.owns_client(((storage.foldername(name))[1])::uuid));