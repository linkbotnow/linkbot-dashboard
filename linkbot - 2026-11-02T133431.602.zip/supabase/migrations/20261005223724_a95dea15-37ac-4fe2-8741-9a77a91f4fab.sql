CREATE OR REPLACE FUNCTION public.daily_auth_cleanup()
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE s int; r int; p int; d int;
BEGIN
  DELETE FROM public.customer_sessions WHERE expires_at < now();
  GET DIAGNOSTICS s = ROW_COUNT;
  DELETE FROM public.password_resets WHERE used_at IS NOT NULL OR created_at < now() - interval '1 hour';
  GET DIAGNOSTICS r = ROW_COUNT;
  DELETE FROM public.checkout_passes cp
  WHERE cp.disabled_at IS NOT NULL
     OR (cp.created_at < now() - interval '30 minutes'
         AND EXISTS (SELECT 1 FROM public.client_slugs c
                     WHERE c.id = cp.bot_id AND c.status <> 'active' AND c.activated_at IS NULL));
  GET DIAGNOSTICS p = ROW_COUNT;
  DELETE FROM public.demo_codes WHERE used_at IS NOT NULL OR expires_at < now();
  GET DIAGNOSTICS d = ROW_COUNT;
  RETURN jsonb_build_object('sessions', s, 'reset_codes', r, 'checkout_passes', p, 'demo_codes', d);
END; $$;
REVOKE ALL ON FUNCTION public.daily_auth_cleanup() FROM PUBLIC, anon, authenticated;

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'daily-auth-cleanup') THEN
    PERFORM cron.unschedule('daily-auth-cleanup');
  END IF;
  PERFORM cron.schedule('daily-auth-cleanup', '0 3 * * *', 'SELECT public.daily_auth_cleanup();');
END $$;