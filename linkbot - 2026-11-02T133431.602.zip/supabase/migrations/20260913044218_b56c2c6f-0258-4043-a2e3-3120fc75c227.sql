CREATE TABLE public.demo_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  first_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  company_name TEXT NOT NULL,
  website TEXT NOT NULL,
  sms_consent BOOLEAN NOT NULL DEFAULT false,
  source TEXT NOT NULL DEFAULT 'landing_hero',
  delivered_at TIMESTAMP WITH TIME ZONE,
  delivery_error TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT ALL ON public.demo_requests TO service_role;
GRANT SELECT ON public.demo_requests TO authenticated;

ALTER TABLE public.demo_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view demo requests"
ON public.demo_requests
FOR SELECT
TO authenticated
USING (public.is_admin());

CREATE INDEX demo_requests_created_at_idx ON public.demo_requests (created_at DESC);