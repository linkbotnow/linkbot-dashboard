CREATE TABLE public.legal_signatures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid REFERENCES public.customer_accounts(id) ON DELETE SET NULL,
  email text NOT NULL,
  full_name text NOT NULL,
  agreed_sensitive_use boolean NOT NULL,
  agreed_terms boolean NOT NULL,
  signed_at timestamptz NOT NULL DEFAULT now(),
  ip_address text,
  user_agent text,
  terms_version text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.legal_signatures TO service_role;
ALTER TABLE public.legal_signatures ENABLE ROW LEVEL SECURITY;
CREATE POLICY legal_signatures_server_only ON public.legal_signatures FOR SELECT TO authenticated USING (false);