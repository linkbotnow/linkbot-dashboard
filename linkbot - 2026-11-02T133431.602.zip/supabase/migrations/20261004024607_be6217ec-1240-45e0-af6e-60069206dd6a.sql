ALTER TABLE public.client_slugs ADD COLUMN linkedin_url text;
CREATE OR REPLACE FUNCTION public.normalize_linkedin_url() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE v text;
BEGIN
  IF NEW.linkedin_url IS NULL OR btrim(NEW.linkedin_url) = '' THEN NEW.linkedin_url := NULL; RETURN NEW; END IF;
  v := btrim(NEW.linkedin_url);
  v := regexp_replace(v, '^https?://', '', 'i');
  v := regexp_replace(v, '^www\.', '', 'i');
  IF v !~* '^linkedin\.com/in/[A-Za-z0-9_%-]+/?$' THEN
    RAISE EXCEPTION 'linkedin_url must be a LinkedIn profile address (linkedin.com/in/...)';
  END IF;
  NEW.linkedin_url := 'https://www.linkedin.com/in/' || substring(v from '(?i)^linkedin\.com/in/(.*)$');
  RETURN NEW;
END $$;
CREATE TRIGGER client_slugs_normalize_linkedin BEFORE INSERT OR UPDATE OF linkedin_url ON public.client_slugs FOR EACH ROW EXECUTE FUNCTION public.normalize_linkedin_url();
ALTER TABLE public.client_slugs ADD CONSTRAINT client_slugs_linkedin_url_format CHECK (linkedin_url IS NULL OR linkedin_url ~ '^https://www\.linkedin\.com/in/[A-Za-z0-9_%-]+/?$');