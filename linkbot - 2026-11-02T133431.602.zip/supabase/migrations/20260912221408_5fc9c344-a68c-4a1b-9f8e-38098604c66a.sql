REVOKE ALL ON FUNCTION public.provisioning_jobs_wake_trigger() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.protect_client_columns() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.sanitize_client_insert() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;