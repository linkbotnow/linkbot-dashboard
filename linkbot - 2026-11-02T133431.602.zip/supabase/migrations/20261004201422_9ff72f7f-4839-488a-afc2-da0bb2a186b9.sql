CREATE TABLE public.checkout_passes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bot_id uuid NOT NULL REFERENCES public.client_slugs(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  disabled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX checkout_passes_bot_idx ON public.checkout_passes (bot_id);
GRANT ALL ON public.checkout_passes TO service_role;
ALTER TABLE public.checkout_passes ENABLE ROW LEVEL SECURITY;
CREATE POLICY checkout_passes_server_only ON public.checkout_passes FOR SELECT TO authenticated USING (false);