CREATE TABLE public.customer_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  password_hash text NOT NULL,
  failed_attempts integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX customer_accounts_email_lower_idx ON public.customer_accounts (lower(email));
GRANT ALL ON public.customer_accounts TO service_role;
ALTER TABLE public.customer_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY customer_accounts_server_only ON public.customer_accounts FOR SELECT TO authenticated USING (false);
CREATE TRIGGER customer_accounts_updated_at BEFORE UPDATE ON public.customer_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.customer_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES public.customer_accounts(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.customer_sessions TO service_role;
ALTER TABLE public.customer_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY customer_sessions_server_only ON public.customer_sessions FOR SELECT TO authenticated USING (false);

CREATE TABLE public.password_resets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid NOT NULL REFERENCES public.customer_accounts(id) ON DELETE CASCADE,
  code_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.password_resets TO service_role;
ALTER TABLE public.password_resets ENABLE ROW LEVEL SECURITY;
CREATE POLICY password_resets_server_only ON public.password_resets FOR SELECT TO authenticated USING (false);

ALTER TABLE public.client_slugs ADD COLUMN owner_account_id uuid REFERENCES public.customer_accounts(id) ON DELETE SET NULL;

INSERT INTO public.customer_accounts (email, password_hash)
SELECT DISTINCT ON (lower(email)) lower(email), login_password_hash
FROM public.client_slugs
WHERE login_password_hash IS NOT NULL
ORDER BY lower(email), updated_at DESC;

UPDATE public.client_slugs s SET owner_account_id = a.id
FROM public.customer_accounts a WHERE lower(s.email) = lower(a.email);

DROP FUNCTION public.reserve_client_slug(text, text, text, text, text, text, text[], text, text);
ALTER TABLE public.client_slugs DROP COLUMN login_password_hash;

CREATE OR REPLACE FUNCTION public.reserve_client_slug(p_email text, p_slug text, p_full_name text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_company text DEFAULT NULL::text, p_website text DEFAULT NULL::text, p_domains text[] DEFAULT '{}'::text[], p_last_name text DEFAULT NULL::text, p_owner_account_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_email text := lower(btrim(p_email));
  v_slug text := lower(btrim(p_slug));
  v_existing public.client_slugs;
BEGIN
  IF v_slug !~ '^[a-z0-9][a-z0-9-]{1,29}$' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid');
  END IF;
  IF length(v_slug) = 12 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
  END IF;

  SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
  IF FOUND AND lower(v_existing.email) <> v_email THEN
    IF v_existing.status <> 'active' AND v_existing.activated_at IS NULL
       AND v_existing.hold_expires_at IS NOT NULL AND v_existing.hold_expires_at < now() THEN
      PERFORM public.release_expired_holds(v_slug);
    ELSE
      RETURN jsonb_build_object('ok', false, 'reason', 'taken');
    END IF;
  END IF;

  INSERT INTO public.client_slugs (email, slug, full_name, last_name, phone, company_name, website, owner_account_id, allowed_domains, status, link_code, hold_expires_at)
  VALUES (v_email, v_slug, p_full_name, p_last_name, p_phone, p_company, p_website, p_owner_account_id, COALESCE(p_domains, '{}'), 'reserved', public.generate_link_code(), now() + interval '30 minutes')
  ON CONFLICT (lower(email)) DO UPDATE
    SET slug = EXCLUDED.slug,
        full_name = COALESCE(EXCLUDED.full_name, public.client_slugs.full_name),
        last_name = COALESCE(EXCLUDED.last_name, public.client_slugs.last_name),
        phone = COALESCE(EXCLUDED.phone, public.client_slugs.phone),
        company_name = COALESCE(EXCLUDED.company_name, public.client_slugs.company_name),
        website = COALESCE(EXCLUDED.website, public.client_slugs.website),
        owner_account_id = COALESCE(EXCLUDED.owner_account_id, public.client_slugs.owner_account_id),
        allowed_domains = CASE WHEN array_length(EXCLUDED.allowed_domains, 1) IS NULL
                               THEN public.client_slugs.allowed_domains
                               ELSE EXCLUDED.allowed_domains END,
        link_code = COALESCE(public.client_slugs.link_code, EXCLUDED.link_code),
        hold_expires_at = now() + interval '30 minutes'
    WHERE public.client_slugs.status <> 'active';

  IF NOT EXISTS (SELECT 1 FROM public.client_slugs WHERE lower(email) = v_email AND slug = v_slug) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'locked');
  END IF;

  RETURN jsonb_build_object('ok', true, 'slug', v_slug);
EXCEPTION
  WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'taken');
END;
$function$;
REVOKE EXECUTE ON FUNCTION public.reserve_client_slug(text, text, text, text, text, text, text[], text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_client_slug(text, text, text, text, text, text, text[], text, uuid) TO service_role;