REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_admin() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.owns_client(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.protect_client_columns() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.sanitize_client_insert() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.owns_client(uuid) TO authenticated, service_role;
-- checkout_intents is server-only by design: add an explicit deny-all policy so the intent is documented.
CREATE POLICY "checkout_intents_no_client_access" ON public.checkout_intents FOR SELECT TO authenticated USING (false);