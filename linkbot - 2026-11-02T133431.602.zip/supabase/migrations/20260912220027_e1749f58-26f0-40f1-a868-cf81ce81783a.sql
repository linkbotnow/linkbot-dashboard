-- ===== Enums =====
CREATE TYPE public.app_role AS ENUM ('admin', 'customer');

CREATE TYPE public.provisioning_status AS ENUM (
  'PAYMENT_PENDING',
  'PAYMENT_VERIFIED',
  'LOCATION_WAITING',
  'LOCATION_READY',
  'SNAPSHOT_WAITING',
  'SNAPSHOT_READY',
  'CUSTOM_VALUES_UPDATING',
  'KNOWLEDGE_CREATING',
  'WEBSITE_CRAWLING',
  'KNOWLEDGE_TRAINING',
  'AGENT_CONFIGURING',
  'CALENDAR_CONFIGURING',
  'WIDGET_LOCATING',
  'PUBLIC_URL_CREATING',
  'QA_RUNNING',
  'ACTIVE',
  'NEEDS_REVIEW',
  'ERROR',
  'PAST_DUE',
  'SUSPENDED',
  'CANCELLED'
);

CREATE TYPE public.subscription_status AS ENUM (
  'PENDING', 'ACTIVE', 'PAST_DUE', 'SUSPENDED', 'CANCELLED'
);

CREATE TYPE public.job_status AS ENUM ('QUEUED', 'RUNNING', 'WAITING', 'SUCCEEDED', 'FAILED', 'NEEDS_REVIEW', 'CANCELLED');
CREATE TYPE public.event_status AS ENUM ('STARTED', 'SUCCEEDED', 'FAILED', 'SKIPPED', 'WAITING', 'INFO');
CREATE TYPE public.document_status AS ENUM ('UPLOADED', 'APPROVED', 'PROCESSING', 'TRAINED', 'FAILED', 'UNSUPPORTED', 'REMOVED');
CREATE TYPE public.alert_severity AS ENUM ('info', 'warning', 'error', 'critical');

-- ===== Helpers =====
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ===== profiles =====
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  email text,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ===== user_roles =====
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(auth.uid(), 'admin')
$$;

CREATE POLICY "profiles_select_own_or_admin" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_admin());
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "user_roles_select_own_or_admin" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

-- ===== clients (tenants) =====
CREATE TABLE public.clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  company_name text NOT NULL,
  company_email text NOT NULL,
  company_phone text,
  website_url text,
  industry text,
  company_description text,
  main_services text,
  service_area text,
  target_customer text,
  agent_name text NOT NULL DEFAULT 'Ava',
  preferred_voice text,
  qualification_rules text,
  disqualification_rules text,
  required_questions text,
  prohibited_topics text,
  escalation_conditions text,
  business_hours jsonb NOT NULL DEFAULT '{}'::jsonb,
  timezone text NOT NULL DEFAULT 'America/New_York',
  appointment_duration integer NOT NULL DEFAULT 30,
  escalation_name text,
  escalation_phone text,
  escalation_email text,
  website_knowledge_approved boolean NOT NULL DEFAULT false,
  accuracy_confirmed_at timestamptz,
  onboarding_completed_at timestamptz,
  public_slug text UNIQUE,
  public_url text,
  ghl_location_id text UNIQUE,
  ghl_agent_id text,
  ghl_widget_id text,
  ghl_knowledge_base_id text,
  ghl_calendar_id text,
  widget_verified_at timestamptz,
  subscription_status public.subscription_status NOT NULL DEFAULT 'PENDING',
  provisioning_status public.provisioning_status NOT NULL DEFAULT 'PAYMENT_PENDING',
  billing_customer_ref text,
  billing_subscription_ref text,
  billing_plan_ref text,
  billing_last_event_at timestamptz,
  grace_period_until timestamptz,
  cancelled_effective_at timestamptz,
  suspended_at timestamptz,
  suspended_reason text,
  activated_at timestamptz,
  delivered_at timestamptz,
  knowledge_status text NOT NULL DEFAULT 'NOT_STARTED',
  knowledge_last_updated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX clients_provisioning_status_idx ON public.clients (provisioning_status);
CREATE INDEX clients_subscription_status_idx ON public.clients (subscription_status);
CREATE INDEX clients_company_email_idx ON public.clients (lower(company_email));

GRANT SELECT, INSERT, UPDATE ON public.clients TO authenticated;
GRANT ALL ON public.clients TO service_role;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "clients_select_own_or_admin" ON public.clients FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());
CREATE POLICY "clients_insert_own" ON public.clients FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "clients_update_own_or_admin" ON public.clients FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_admin());

CREATE TRIGGER clients_updated_at BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Customers may never change protected/server-controlled columns.
CREATE OR REPLACE FUNCTION public.protect_client_columns()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  jwt_role text := current_setting('request.jwt.claim.role', true);
BEGIN
  -- service_role (server code) is trusted.
  IF jwt_role IS NULL OR jwt_role = 'service_role' THEN
    RETURN NEW;
  END IF;
  -- Admins may change status/reference columns; regular customers may not.
  IF public.is_admin() THEN
    NEW.user_id := OLD.user_id;
    RETURN NEW;
  END IF;
  IF NEW.user_id IS DISTINCT FROM OLD.user_id
     OR NEW.public_slug IS DISTINCT FROM OLD.public_slug
     OR NEW.public_url IS DISTINCT FROM OLD.public_url
     OR NEW.ghl_location_id IS DISTINCT FROM OLD.ghl_location_id
     OR NEW.ghl_agent_id IS DISTINCT FROM OLD.ghl_agent_id
     OR NEW.ghl_widget_id IS DISTINCT FROM OLD.ghl_widget_id
     OR NEW.ghl_knowledge_base_id IS DISTINCT FROM OLD.ghl_knowledge_base_id
     OR NEW.ghl_calendar_id IS DISTINCT FROM OLD.ghl_calendar_id
     OR NEW.widget_verified_at IS DISTINCT FROM OLD.widget_verified_at
     OR NEW.subscription_status IS DISTINCT FROM OLD.subscription_status
     OR NEW.provisioning_status IS DISTINCT FROM OLD.provisioning_status
     OR NEW.billing_customer_ref IS DISTINCT FROM OLD.billing_customer_ref
     OR NEW.billing_subscription_ref IS DISTINCT FROM OLD.billing_subscription_ref
     OR NEW.billing_plan_ref IS DISTINCT FROM OLD.billing_plan_ref
     OR NEW.billing_last_event_at IS DISTINCT FROM OLD.billing_last_event_at
     OR NEW.grace_period_until IS DISTINCT FROM OLD.grace_period_until
     OR NEW.cancelled_effective_at IS DISTINCT FROM OLD.cancelled_effective_at
     OR NEW.suspended_at IS DISTINCT FROM OLD.suspended_at
     OR NEW.suspended_reason IS DISTINCT FROM OLD.suspended_reason
     OR NEW.activated_at IS DISTINCT FROM OLD.activated_at
     OR NEW.delivered_at IS DISTINCT FROM OLD.delivered_at
     OR NEW.knowledge_status IS DISTINCT FROM OLD.knowledge_status
     OR NEW.knowledge_last_updated_at IS DISTINCT FROM OLD.knowledge_last_updated_at
  THEN
    RAISE EXCEPTION 'Protected client columns can only be changed by the server' USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER clients_protect_columns BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.protect_client_columns();

-- Customers inserting their own tenant row cannot pre-set protected columns.
CREATE OR REPLACE FUNCTION public.sanitize_client_insert()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  jwt_role text := current_setting('request.jwt.claim.role', true);
BEGIN
  IF jwt_role IS NULL OR jwt_role = 'service_role' OR public.is_admin() THEN
    RETURN NEW;
  END IF;
  NEW.public_slug := NULL; NEW.public_url := NULL;
  NEW.ghl_location_id := NULL; NEW.ghl_agent_id := NULL; NEW.ghl_widget_id := NULL;
  NEW.ghl_knowledge_base_id := NULL; NEW.ghl_calendar_id := NULL; NEW.widget_verified_at := NULL;
  NEW.subscription_status := 'PENDING'; NEW.provisioning_status := 'PAYMENT_PENDING';
  NEW.billing_customer_ref := NULL; NEW.billing_subscription_ref := NULL; NEW.billing_plan_ref := NULL;
  NEW.billing_last_event_at := NULL; NEW.grace_period_until := NULL; NEW.cancelled_effective_at := NULL;
  NEW.suspended_at := NULL; NEW.suspended_reason := NULL; NEW.activated_at := NULL; NEW.delivered_at := NULL;
  NEW.knowledge_status := 'NOT_STARTED'; NEW.knowledge_last_updated_at := NULL;
  RETURN NEW;
END; $$;
CREATE TRIGGER clients_sanitize_insert BEFORE INSERT ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.sanitize_client_insert();

-- Ownership helper used by child-table policies (avoids recursive RLS).
CREATE OR REPLACE FUNCTION public.owns_client(_client_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.clients WHERE id = _client_id AND user_id = auth.uid())
$$;

-- ===== provisioning_jobs =====
CREATE TABLE public.provisioning_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  current_step public.provisioning_status NOT NULL DEFAULT 'PAYMENT_VERIFIED',
  status public.job_status NOT NULL DEFAULT 'QUEUED',
  attempt_count integer NOT NULL DEFAULT 0,
  next_run_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  last_error text,
  last_error_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- Only one non-terminal job per client (idempotency).
CREATE UNIQUE INDEX provisioning_jobs_one_active_per_client
  ON public.provisioning_jobs (client_id)
  WHERE status IN ('QUEUED','RUNNING','WAITING','NEEDS_REVIEW');
CREATE INDEX provisioning_jobs_due_idx ON public.provisioning_jobs (status, next_run_at);

GRANT SELECT ON public.provisioning_jobs TO authenticated;
GRANT ALL ON public.provisioning_jobs TO service_role;
ALTER TABLE public.provisioning_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "jobs_select_own_or_admin" ON public.provisioning_jobs FOR SELECT TO authenticated
  USING (public.owns_client(client_id) OR public.is_admin());
CREATE TRIGGER provisioning_jobs_updated_at BEFORE UPDATE ON public.provisioning_jobs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ===== provisioning_events =====
CREATE TABLE public.provisioning_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.provisioning_jobs(id) ON DELETE SET NULL,
  step_name text NOT NULL,
  status public.event_status NOT NULL,
  message text,
  safe_metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX provisioning_events_client_idx ON public.provisioning_events (client_id, created_at DESC);
GRANT SELECT ON public.provisioning_events TO authenticated;
GRANT ALL ON public.provisioning_events TO service_role;
ALTER TABLE public.provisioning_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "events_select_own_or_admin" ON public.provisioning_events FOR SELECT TO authenticated
  USING (public.owns_client(client_id) OR public.is_admin());

-- ===== documents =====
CREATE TABLE public.documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  storage_path text NOT NULL,
  mime_type text,
  size_bytes bigint,
  processing_status public.document_status NOT NULL DEFAULT 'UPLOADED',
  processing_message text,
  ghl_document_ref text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX documents_client_idx ON public.documents (client_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.documents TO authenticated;
GRANT ALL ON public.documents TO service_role;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "documents_select_own_or_admin" ON public.documents FOR SELECT TO authenticated
  USING (public.owns_client(client_id) OR public.is_admin());
CREATE POLICY "documents_insert_own" ON public.documents FOR INSERT TO authenticated
  WITH CHECK (public.owns_client(client_id));
CREATE POLICY "documents_update_own" ON public.documents FOR UPDATE TO authenticated
  USING (public.owns_client(client_id)) WITH CHECK (public.owns_client(client_id));
CREATE POLICY "documents_delete_own" ON public.documents FOR DELETE TO authenticated
  USING (public.owns_client(client_id));
CREATE TRIGGER documents_updated_at BEFORE UPDATE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ===== admin_alerts =====
CREATE TABLE public.admin_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES public.clients(id) ON DELETE CASCADE,
  severity public.alert_severity NOT NULL DEFAULT 'warning',
  category text NOT NULL,
  message text NOT NULL,
  resolved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX admin_alerts_open_idx ON public.admin_alerts (resolved, created_at DESC);
GRANT SELECT, UPDATE ON public.admin_alerts TO authenticated;
GRANT ALL ON public.admin_alerts TO service_role;
ALTER TABLE public.admin_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alerts_admin_select" ON public.admin_alerts FOR SELECT TO authenticated USING (public.is_admin());
CREATE POLICY "alerts_admin_update" ON public.admin_alerts FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ===== billing_events (idempotent webhook ledger) =====
CREATE TABLE public.billing_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL DEFAULT 'ghl',
  external_event_id text NOT NULL,
  event_type text NOT NULL,
  ghl_location_id text,
  ghl_company_id text,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  safe_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  processing_status text NOT NULL DEFAULT 'RECEIVED',
  processing_error text,
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  UNIQUE (provider, external_event_id)
);
CREATE INDEX billing_events_location_idx ON public.billing_events (ghl_location_id);
GRANT SELECT ON public.billing_events TO authenticated;
GRANT ALL ON public.billing_events TO service_role;
ALTER TABLE public.billing_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "billing_events_admin_select" ON public.billing_events FOR SELECT TO authenticated USING (public.is_admin());

-- ===== checkout_intents =====
CREATE TABLE public.checkout_intents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  email text NOT NULL,
  status text NOT NULL DEFAULT 'STARTED',
  ghl_location_id text,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  verified_at timestamptz,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days')
);
CREATE INDEX checkout_intents_email_idx ON public.checkout_intents (lower(email));
GRANT ALL ON public.checkout_intents TO service_role;
ALTER TABLE public.checkout_intents ENABLE ROW LEVEL SECURITY;

-- ===== security_audit_log =====
CREATE TABLE public.security_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  event_type text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.security_audit_log TO authenticated;
GRANT ALL ON public.security_audit_log TO service_role;
ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit_admin_select" ON public.security_audit_log FOR SELECT TO authenticated USING (public.is_admin());

-- ===== Realtime for live provisioning status =====
ALTER PUBLICATION supabase_realtime ADD TABLE public.clients;
ALTER PUBLICATION supabase_realtime ADD TABLE public.provisioning_events;