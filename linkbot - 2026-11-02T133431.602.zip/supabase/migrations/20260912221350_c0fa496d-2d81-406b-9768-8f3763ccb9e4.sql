-- lovable-cron-fallback-reviewed: 1440 runs/day; armed only while provisioning jobs are pending (wake-on-enqueue trigger, self-unschedules after drain). HighLevel snapshot installs and website crawls expose no completion webhook and must be polled.
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;

ALTER TABLE public.provisioning_jobs
  ADD COLUMN IF NOT EXISTS context_json jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS last_qa_json jsonb,
  ADD COLUMN IF NOT EXISTS checkout_email text,
  ADD COLUMN IF NOT EXISTS agent_prompt_version text;

CREATE TABLE IF NOT EXISTS public.internal_settings (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.internal_settings ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.internal_settings FROM anon, authenticated;
GRANT ALL ON public.internal_settings TO service_role;
CREATE POLICY "internal_settings_no_client_access" ON public.internal_settings
  FOR SELECT TO authenticated USING (false);

INSERT INTO public.internal_settings(key, value)
VALUES ('worker_token', encode(gen_random_bytes(32), 'hex'))
ON CONFLICT (key) DO NOTHING;

CREATE OR REPLACE FUNCTION public.wake_provisioning_worker()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, extensions AS $$
DECLARE
  v_url text;
  v_token text;
BEGIN
  SELECT value INTO v_url FROM public.internal_settings WHERE key = 'worker_url';
  SELECT value INTO v_token FROM public.internal_settings WHERE key = 'worker_token';
  IF v_url IS NULL OR v_token IS NULL THEN
    RETURN;
  END IF;
  PERFORM net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-worker-token', v_token),
    body := '{"source":"db"}'::jsonb,
    timeout_milliseconds := 5000
  );
END; $$;
REVOKE ALL ON FUNCTION public.wake_provisioning_worker() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.arm_provisioning_retry()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_catalog AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'provisioning-worker-retry') THEN
    PERFORM cron.schedule('provisioning-worker-retry', '* * * * *', 'SELECT public.provisioning_retry_tick();');
  END IF;
END; $$;
REVOKE ALL ON FUNCTION public.arm_provisioning_retry() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.provisioning_retry_tick()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_catalog AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.provisioning_jobs
    WHERE status IN ('QUEUED','WAITING','RUNNING')
  ) THEN
    IF EXISTS (
      SELECT 1 FROM public.provisioning_jobs
      WHERE status IN ('QUEUED','WAITING','RUNNING')
        AND next_run_at <= now()
        AND (locked_at IS NULL OR locked_at < now() - interval '10 minutes')
    ) THEN
      PERFORM public.wake_provisioning_worker();
    END IF;
  ELSE
    IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'provisioning-worker-retry') THEN
      PERFORM cron.unschedule('provisioning-worker-retry');
    END IF;
  END IF;
END; $$;
REVOKE ALL ON FUNCTION public.provisioning_retry_tick() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.provisioning_jobs_wake_trigger()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.status IN ('QUEUED','WAITING','RUNNING') THEN
    PERFORM public.arm_provisioning_retry();
    IF NEW.status IN ('QUEUED','WAITING') AND NEW.next_run_at <= now() + interval '5 seconds' THEN
      PERFORM public.wake_provisioning_worker();
    END IF;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS provisioning_jobs_wake ON public.provisioning_jobs;
CREATE TRIGGER provisioning_jobs_wake AFTER INSERT OR UPDATE OF status, next_run_at ON public.provisioning_jobs
  FOR EACH ROW EXECUTE FUNCTION public.provisioning_jobs_wake_trigger();