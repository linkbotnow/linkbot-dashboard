/* Follow-up access and draft live only in this page's memory. */
(() => {
  'use strict';
  const query = new URL(location.href).searchParams;
  const account = query.get('account') || '', contact = query.get('contact') || '';
  const canvas = document.getElementById('canvas'), spacer = document.getElementById('spacer');
  let token = '', busy = false, lockedUntil = 0, recipient = null;
  function esc(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
  function fit() {
    if (document.body.classList.contains('follow-form')) { spacer.style.height = ''; return; }
    const phone = document.documentElement.clientWidth < 700;
    const scale = document.documentElement.clientWidth / (phone ? 390 : 1440);
    document.documentElement.classList.toggle('phone', phone);
    canvas.style.width = `${phone ? 390 : 1440}px`;
    canvas.style.transform = `scale(${scale})`;
    canvas.style.setProperty('--canvas-height', `${innerHeight / scale}px`);
    spacer.style.height = `${canvas.offsetHeight * scale}px`;
    canvas.style.visibility = 'visible';
  }
  async function api(action, data = {}) {
    const response = await fetch('/app/follow-up', { method: 'POST', credentials: 'omit', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, account, contact, token, ...data }) });
    const result = await response.json();
    if (result.invalid) { confirmation("This link isn't valid."); return null; }
    if (response.status === 401) { token = ''; loginScreen(); throw new Error(result.error); }
    return result;
  }
  function passwordError(message) {
    const box = document.getElementById('password-error');
    if (!box) return;
    if (lockedUntil > Date.now()) {
      const n = Math.max(1, Math.ceil((lockedUntil - Date.now()) / 60000));
      box.innerHTML = `Your Account Is Locked. Try again in ${n === 1 ? '1 minute' : n + ' minutes'}, or <button type="button" class="plain" data-forgot>reset your password</button> to unlock it now.`;
    } else box.textContent = message;
    fit();
  }
  const EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22"/></svg>';
  function passwordProblem(value) {
    if (value.length < 8) return 'Password must be at least 8 characters.';
    if (!/[A-Z]/.test(value)) return 'Password must include an uppercase letter.';
    if (!/[0-9]/.test(value)) return 'Password must include a number.';
    if (!/[^A-Za-z0-9]/.test(value)) return 'Password must include a special character.';
    return '';
  }
  function passwordField(id, label) { return `<label for="${id}">${label}</label><div class="password-wrap"><input id="${id}" type="password" autocomplete="new-password" maxlength="128" required><button type="button" class="password-eye" data-eye aria-label="Show password">${EYE}</button></div>`; }
  function resetEmailScreen() {
    document.body.classList.remove('follow-form');
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="top"><h1>Reset Password</h1></div><div class="password-area"><form class="password-box" id="reset-form" autocomplete="off"><p class="reset-text">Enter your account email and we'll send you a 6-digit code.</p><label for="reset-email">Email</label><input id="reset-email" name="email" type="email" placeholder="you@yourcompany.com" autocomplete="off" maxlength="255" required><div class="password-error" role="alert" id="reset-error"></div><button class="linkbot-button" type="submit"><span>Send Code</span></button><button type="button" class="plain" data-back><span>Back</span></button></form></div></section></main>`;
    window.scrollTo(0, 0); fit();
    document.getElementById('reset-form').addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return; busy = true;
      const email = document.getElementById('reset-email').value, submit = event.currentTarget.querySelector('[type=submit]');
      submit.disabled = true;
      try { await api('request_reset_code', { email }); resetCodeScreen(email); }
      catch { const box = document.getElementById('reset-error'); if (box) box.textContent = 'Something went wrong. Please try again.'; }
      finally { busy = false; submit.disabled = false; }
    });
  }
  function resetCodeScreen(email) {
    document.body.classList.remove('follow-form');
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="top"><h1>Reset Password</h1></div><div class="password-area"><form class="password-box" id="reset-form" data-email="${esc(email)}" autocomplete="off"><p class="reset-text">Enter the 6-digit code we sent to your email, then choose a new password.</p><label for="reset-code">6-Digit Code</label><input id="reset-code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]*" maxlength="6" required>${passwordField('reset-new', 'New Password')}${passwordField('reset-confirm', 'Confirm New Password')}<div class="password-error" role="alert" id="reset-error"></div><div class="password-notice" role="status" id="reset-notice"></div><button class="linkbot-button" type="submit"><span>Save Password</span></button><button type="button" class="plain" data-resend><span>Resend Code</span></button><button type="button" class="plain" data-back><span>Back</span></button></form></div></section></main>`;
    window.scrollTo(0, 0); fit();
    const form = document.getElementById('reset-form');
    form.addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return;
      const code = document.getElementById('reset-code').value.trim();
      const password = document.getElementById('reset-new').value, confirm = document.getElementById('reset-confirm').value;
      const error = document.getElementById('reset-error');
      if (!/^\d{6}$/.test(code)) { error.textContent = 'Enter the 6-digit code from your email.'; return; }
      const problem = passwordProblem(password); if (problem) { error.textContent = problem; return; }
      if (password !== confirm) { error.textContent = "Passwords don't match."; return; }
      busy = true; error.textContent = ''; const submit = form.querySelector('[type=submit]'); submit.disabled = true;
      try {
        const result = await api('reset_with_code', { code, new_password: password });
        if (result?.ok) loginScreen('Password updated. Enter your new password.');
        else if (result) error.textContent = result.error || 'Something went wrong. Please try again.';
      } catch { error.textContent = 'Something went wrong. Please try again.'; }
      finally { busy = false; submit.disabled = false; }
    });
  }
  function loginScreen(notice = '') {
    document.body.classList.remove('follow-form');
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="top"><h1>My Links</h1></div><div class="password-area"><form class="password-box" id="password-form" autocomplete="off"><label for="password">Password</label><input id="password" name="password" type="password" placeholder="LinkBot Login Password" autocomplete="off" maxlength="128" required><div class="password-error" role="alert" id="password-error"></div><div class="password-notice" role="status">${esc(notice)}</div><button class="linkbot-button" type="submit"><span>Manage My Links</span></button><button type="button" class="plain" data-forgot><span>Forgot Password?</span></button></form></div></section></main>`;
    window.scrollTo(0, 0); fit();
    document.getElementById('password-form').addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return; busy = true;
      const input = document.getElementById('password'), submit = event.currentTarget.querySelector('[type=submit]');
      submit.disabled = true;
      try {
        const result = await api('login', { password: input.value });
        if (result?.ok) { input.value = ''; token = result.token; lockedUntil = 0; await load(); }
        else if (result) { if (result.locked) lockedUntil = Date.now() + (result.lockedMinutes || 15) * 60000; passwordError(result.error || 'That password is incorrect.'); }
      } catch { passwordError('Something went wrong. Please try again.'); }
      finally { input.value = ''; busy = false; submit.disabled = false; }
    });
  }
  function shell(content) {
    document.body.classList.add('follow-form');
    document.documentElement.classList.remove('phone');
    canvas.style.width = ''; canvas.style.transform = ''; canvas.style.visibility = 'visible';
    canvas.innerHTML = `<main class="follow-shell"><section class="follow-card">${content}</section></main>`;
    fit(); window.scrollTo(0, 0);
  }
  function confirmation(text) { shell(`<p class="follow-confirm" role="status">${esc(text)}</p>`); }
  async function load() {
    const result = await api('load');
    if (!result) return;
    if (result.error) { passwordError(result.error); return; }
    recipient = result.recipient;
    if (result.alreadySent) { confirmation(`You already sent a follow-up to ${recipient.firstName}.`); return; }
    const name = `${recipient.firstName} ${recipient.lastName}`.trim();
    shell(`<h1>Send Follow-Up Email</h1><p class="follow-subtitle">Your AI wrote this based on the conversation. Edit anything you like, then send it or skip it.</p><div class="follow-to"><span>To:</span><div class="follow-recipient"><span>${esc(name)}</span><span class="follow-email">${esc(recipient.email)}</span></div></div><form id="follow-form" novalidate><label class="follow-field">Subject<input id="subject" maxlength="1000" value="${esc(result.subject)}"></label><label class="follow-field">Message<textarea id="message" maxlength="100000">${esc(result.message)}</textarea></label><div class="follow-error" id="follow-error" role="alert"></div><div class="follow-actions"><button type="button" class="follow-skip" id="skip">Don't Send</button><button type="submit" class="linkbot-button"><span>Send Email</span></button></div><p class="follow-note">Nothing is sent until you click Send Email.</p></form>`);
    document.getElementById('skip').addEventListener('click', () => { if (!busy) confirmation('No problem. Nothing was sent.'); });
    document.getElementById('follow-form').addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return;
      const subject = document.getElementById('subject').value, message = document.getElementById('message').value;
      const error = document.getElementById('follow-error');
      if (!subject.trim() || !message.trim()) { error.textContent = 'Please add a subject and message.'; return; }
      busy = true; error.textContent = '';
      const buttons = [...event.currentTarget.querySelectorAll('button')]; buttons.forEach(button => { button.disabled = true; });
      try {
        const result = await api('send', { subject, message });
        if (result?.sent) confirmation(`Sent. Your follow-up is on its way to ${recipient.firstName}.`);
        else if (result?.alreadySent) confirmation(`You already sent a follow-up to ${recipient.firstName}.`);
        else if (result) error.textContent = result.error || "Couldn't send your email. Please try again.";
      } catch { error.textContent = "Couldn't send your email. Please try again."; }
      finally { busy = false; buttons.forEach(button => { button.disabled = false; }); }
    });
  }
  document.addEventListener('click', async event => {
    if (event.target.closest('[data-forgot]')) { resetEmailScreen(); return; }
    if (event.target.closest('[data-back]')) { loginScreen(); return; }
    const resend = event.target.closest('[data-resend]');
    if (resend) {
      if (busy) return; busy = true; resend.disabled = true;
      const email = document.getElementById('reset-form')?.dataset.email || '';
      try { await api('request_reset_code', { email }); const note = document.getElementById('reset-notice'); if (note) note.textContent = 'If that email matches this account, a code is on its way.'; }
      catch { const box = document.getElementById('reset-error'); if (box) box.textContent = 'Something went wrong. Please try again.'; }
      finally { busy = false; resend.disabled = false; }
      return;
    }
    const eye = event.target.closest('[data-eye]');
    if (eye) {
      const input = eye.parentElement.querySelector('input'), show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      eye.innerHTML = show ? EYE_OFF : EYE;
      eye.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    }
  });
  setInterval(() => { if (!token && lockedUntil > Date.now()) passwordError('That password is incorrect.'); }, 1000);
  window.addEventListener('resize', fit);
  window.addEventListener('pagehide', () => { token = ''; recipient = null; const input = document.getElementById('password'); if (input) input.value = ''; });
  window.addEventListener('pageshow', event => { if (event.persisted) { token = ''; recipient = null; loginScreen(); } });
  if (document.fonts) document.fonts.ready.then(fit);
  loginScreen();
})();