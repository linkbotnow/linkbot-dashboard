(() => {
  // LinkBot phone page mock-up, running over this tab only. Refresh to remove.
  const CSS_URL = document.getElementById("lb-app-css")?.href || document.querySelector('link[rel="stylesheet"][href*="/assets/styles-"]')?.href || "https://linkbot.now/assets/styles-DlDkgGEX.css"; // this page's own current styles
  const HEAD = "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Manrope:wght@400;500;600;700;800&display=swap\">\n<style id=\"lb-css\">\nhtml,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#000 !important;font-family:var(--font-sans);}\n#lb-stage{position:fixed;inset:0;background:#000;overflow:hidden;display:flex;align-items:center;justify-content:center;}\n#lb-fit{position:relative;flex:none;width:316px;height:650px;}\n#lb-mobile{display:none;position:fixed;left:0;top:0;transform-origin:0 0;background:var(--surface);}\nhtml.lb-phone #lb-stage{display:none;}\nhtml.lb-phone #lb-mobile{display:block;}\n</style>";
  const BODY = "<div id=\"lb-stage\"><div id=\"lb-fit\"><div id=\"lb-phone\" class=\"relative h-[650px] w-[316px] overflow-hidden rounded-[42px] shadow-elev-3\" style=\"background:#020304;\">\n<div class=\"absolute inset-0 rounded-[42px]\" style=\"background:linear-gradient(115deg,rgba(255,255,255,0) 0%,rgba(255,255,255,0) 8.5%,rgba(255,255,255,0.38) 10.5%,rgba(255,255,255,0) 12.5%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.32) 88.5%,rgba(255,255,255,0) 91%),linear-gradient(180deg,rgba(255,255,255,0.55) 0%,rgba(255,255,255,0.10) 1.5px,rgba(255,255,255,0) 3px),linear-gradient(0deg,rgba(255,255,255,0.45) 0%,rgba(255,255,255,0.08) 1.5px,rgba(255,255,255,0) 3px),linear-gradient(90deg,rgba(255,255,255,0.35) 0%,rgba(255,255,255,0) 2px),linear-gradient(270deg,rgba(255,255,255,0.35) 0%,rgba(255,255,255,0) 2px);box-shadow:inset 0 0 0 1px rgba(255,255,255,0.24),inset 0 0 0 3px rgba(0,0,0,0.85);\"></div>\n<div class=\"absolute inset-[4px] rounded-[38px]\" style=\"background:#000;box-shadow:inset 0 0 0 1px rgba(255,255,255,0.06),inset 0 0 3px 1px rgba(255,255,255,0.05);\"></div>\n<div class=\"absolute inset-[9px] z-10 overflow-hidden rounded-[33px] bg-surface\">\n<div class=\"absolute left-1/2 top-2 z-30 h-6 w-24 -translate-x-1/2 rounded-full bg-night\"></div>\n<div class=\"absolute inset-x-0 top-0 z-20 flex h-11 items-center justify-between bg-surface px-6 text-[10px] font-bold text-ink\"><span id=\"lb-time\">9:41</span><span>\u25cf \u25cf \u25cf</span></div>\n<div class=\"absolute inset-0 z-10 bg-surface\"><div class=\"relative flex h-full flex-col bg-surface px-6 pb-6 pt-16 text-center text-ink\">\n<div class=\"text-center\">\n<p class=\"eyebrow mt-7\">LIVE RECEPTIONIST</p>\n<span class=\"lbm-mic relative mx-auto flex h-24 w-24 items-center justify-center\">\n<span class=\"absolute h-24 w-24 rounded-full bg-brand/20 animate-pulse-ring\"></span>\n<span class=\"relative grid h-20 w-20 place-items-center rounded-full bg-brand text-brand-foreground shadow-brand\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"h-8 w-8\" aria-hidden=\"true\"><path d=\"M12 19v3\"/><path d=\"M19 10v2a7 7 0 0 1-14 0v-2\"/><rect x=\"9\" y=\"2\" width=\"6\" height=\"13\" rx=\"3\"/></svg></span>\n</span>\n</div>\n<h3 class=\"mt-6 text-3xl font-black text-ink\">Hi, let's chat.</h3>\n<p class=\"mt-3 text-base font-medium leading-relaxed text-muted-foreground\">I can answer your questions and help with anything you need.</p>\n<div class=\"demo-audio-lines mt-8\" aria-hidden=\"true\"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>\n<div class=\"relative mt-auto w-full\">\n<button type=\"button\" class=\"linkbot-button w-full\"><span class=\"flex items-center gap-2\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"h-4 w-4\" aria-hidden=\"true\"><path d=\"M12 19v3\"/><path d=\"M19 10v2a7 7 0 0 1-14 0v-2\"/><rect x=\"9\" y=\"2\" width=\"6\" height=\"13\" rx=\"3\"/></svg> Start Call</span></button>\n</div>\n</div></div>\n</div>\n</div></div></div>\n<div id=\"lb-mobile\"><div class=\"relative flex h-full flex-col bg-surface px-6 pb-6 pt-16 text-center text-ink\">\n<div class=\"text-center\">\n<p class=\"eyebrow mt-7\">LIVE RECEPTIONIST</p>\n<span class=\"lbm-mic relative mx-auto flex h-24 w-24 items-center justify-center\">\n<span class=\"absolute h-24 w-24 rounded-full bg-brand/20 animate-pulse-ring\"></span>\n<span class=\"relative grid h-20 w-20 place-items-center rounded-full bg-brand text-brand-foreground shadow-brand\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"h-8 w-8\" aria-hidden=\"true\"><path d=\"M12 19v3\"/><path d=\"M19 10v2a7 7 0 0 1-14 0v-2\"/><rect x=\"9\" y=\"2\" width=\"6\" height=\"13\" rx=\"3\"/></svg></span>\n</span>\n</div>\n<h3 class=\"mt-6 text-3xl font-black text-ink\">Hi, let's chat.</h3>\n<p class=\"mt-3 text-base font-medium leading-relaxed text-muted-foreground\">I can answer your questions and help with anything you need.</p>\n<div class=\"demo-audio-lines mt-8\" aria-hidden=\"true\"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>\n<div class=\"relative mt-auto w-full\">\n<button type=\"button\" class=\"linkbot-button w-full\"><span class=\"flex items-center gap-2\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"h-4 w-4\" aria-hidden=\"true\"><path d=\"M12 19v3\"/><path d=\"M19 10v2a7 7 0 0 1-14 0v-2\"/><rect x=\"9\" y=\"2\" width=\"6\" height=\"13\" rx=\"3\"/></svg> Start Call</span></button>\n</div>\n</div></div>\n<script>(function(){\nvar d=document.documentElement,fit=document.getElementById(\"lb-fit\"),mob=document.getElementById(\"lb-mobile\");\nfunction isPhone(){var s=Math.min(screen.width,screen.height);var c=window.matchMedia&&matchMedia(\"(pointer: coarse)\").matches;return c&&s<600;}\nfunction lay(){var w=window.innerWidth,h=window.innerHeight;\nif(isPhone()){d.classList.add(\"lb-phone\");var k=Math.min(w/298,h/560);mob.style.width=(w/k)+\"px\";mob.style.height=(h/k)+\"px\";mob.style.zoom=k;}\nelse{d.classList.remove(\"lb-phone\");var m=16,s=Math.min((w-2*m)/316,(h-2*m)/650);fit.style.zoom=s;}}\nlay();window.addEventListener(\"resize\",lay);window.addEventListener(\"orientationchange\",function(){setTimeout(lay,250);});\nvar t=document.getElementById(\"lb-time\");function tick(){var n=new Date();t.textContent=(n.getHours()%12||12)+\":\"+String(n.getMinutes()).padStart(2,\"0\");}tick();setInterval(tick,1000);\n})();</script>";
  // Cover phrases: when the AI says one of these, its button appears. Sample links for tonight.
  const COVER = [
    // Only links that really exist get a button, and only when the assistant actually gives the address.
    // TEST ONLY: the assistant doesn't know this document yet, so saying "test document" on the call brings up its button.
    { re: /test\s*doc(ument)?/i, label: "View Our Test Document", url: "https://docs.google.com/document/d/1eR7eYyk1rQ4rm7lhK3WivSjZIGNXSGmhUdP0_ch2pRA/edit?tab=t.0", caller: true },
  ];
  const URL_RE = /\b(?:https?:\/\/)?(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|net|org|io|co|ai|now|us|biz|info|app|me)(?:\/[^\s,)"]*)?/gi;
  const MIC = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4" aria-hidden="true"><path d="M12 19v3"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><rect x="9" y="2" width="6" height="13" rx="3"/></svg>';
  const PHONE_OFF = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4" aria-hidden="true"><path d="M10.1 13.9a14 14 0 0 0 3.732 2.668 1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2 18 18 0 0 1-12.728-5.272"/><path d="M22 2 2 22"/><path d="M4.76 13.582A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 .244.473"/></svg>';
  const ARROW = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7"/><path d="M8 7h9v9"/></svg>';
  const GLOBE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
  const CAL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>';
  const LINK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';
  const CHEV = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  const iconFor = (l) => /book|meeting|calendar|schedule|appointment/i.test(l.label) ? CAL : /website|site/i.test(l.label) ? GLOBE : LINK;
  const CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';
  const EXTRA_CSS = `
    .lbm-captions{display:none;flex:1 1 auto;min-height:0;margin:14px -6px 14px;overflow:hidden;position:relative;
      -webkit-mask-image:linear-gradient(to bottom,transparent 0,#000 22px);mask-image:linear-gradient(to bottom,transparent 0,#000 22px);}
    .lbm-captions-inner{position:absolute;left:0;right:0;bottom:0;display:flex;flex-direction:column;gap:5px;padding:0 6px 2px;}
    .lbm-bubble{position:relative;max-width:78%;margin:0;padding:7px 12px;border-radius:18px;text-align:left;
      font-family:"Inter",-apple-system,BlinkMacSystemFont,ui-sans-serif,system-ui,sans-serif;font-size:13.5px;font-weight:400;line-height:1.35;letter-spacing:-0.005em;
      overflow-wrap:anywhere;animation:lbm-pop .22s cubic-bezier(.2,.8,.2,1);}
    .lbm-ai{align-self:flex-start;background:#e9e9eb;color:#0b0b0d;border-bottom-left-radius:5px;}
    .lbm-you{align-self:flex-end;background:var(--linkbot-blue-exact,oklch(0.52 0.24 264));color:#fff;border-bottom-right-radius:5px;}
    .lbm-ai + .lbm-ai{border-top-left-radius:5px;} .lbm-you + .lbm-you{border-top-right-radius:5px;}
    @keyframes lbm-pop{from{opacity:0;transform:translateY(6px) scale(.98);}to{opacity:1;transform:none;}}
    @media (prefers-reduced-motion:reduce){.lbm-bubble{animation:none;}}
    .lbm-links{display:none;flex-direction:column;width:100%;margin-bottom:8px;min-height:0;}
    .lbm-links-head{display:none;text-align:center;}
    .lbm-links-label{margin:0;font:900 10px/1 "Inter",ui-sans-serif,system-ui,sans-serif;letter-spacing:.26em;color:var(--linkbot-blue-exact,oklch(0.52 0.24 264));}
    .lbm-links-hint{margin:8px 0 10px;font:500 12.5px/1.4 "Inter",ui-sans-serif,system-ui,sans-serif;color:oklch(0.46 0.03 260);white-space:nowrap;}
    .lbm-links-wrap{position:relative;display:flex;flex-direction:column;min-height:0;}
    .lbm-links-scroll{display:flex;flex-direction:column;gap:9px;min-height:0;overflow-y:auto;padding:4px 22px 46px;margin:0 -22px -37px;scrollbar-width:none;}
    .lbm-more-pill{display:none;position:absolute;left:50%;top:0;transform:translateX(-50%);z-index:3;align-items:center;gap:4px;height:27px;padding:0 13px;border:0;border-radius:999px;background:#fff;color:oklch(0.46 0.03 260);font:600 11.5px/1 "Inter",ui-sans-serif,system-ui,sans-serif;white-space:nowrap;cursor:pointer;opacity:1;transition:opacity .25s ease;box-shadow:0 2px 8px rgba(15,23,42,.14),inset 0 0 0 1px rgba(15,23,42,.10);}
    .lbm-more-pill svg{width:13px;height:13px;animation:lbm-bob 1.2s ease-in-out infinite;}
    @keyframes lbm-bob{0%,100%{transform:translateY(-1.5px);}50%{transform:translateY(1.5px);}}
    @media (prefers-reduced-motion:reduce){.lbm-more-pill svg{animation:none;}}
    .lbm-links-scroll::-webkit-scrollbar{display:none;}
    .lbm-links .linkbot-button.lbm-lbtn{display:grid !important;grid-template-columns:28px 1fr 28px;align-items:center;padding:0 10px !important;flex:none;}
    .lbm-lbtn .lbm-ic,.lbm-lbtn .lbm-ar{display:grid;place-items:center;}
    .lbm-lbtn .lbm-ic svg{width:16px;height:16px;} .lbm-lbtn .lbm-ar svg{width:13px;height:13px;}
    .lbm-lbtn .lbm-tx{min-width:0;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:clip;}
    .lbm-links .linkbot-button{width:100%;color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background-color:#ffffff !important;
      background-image:linear-gradient(180deg,#ffffff 0%,#f3f5fb 100%) !important;background-blend-mode:normal !important;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.16),0 1px 1px rgba(15,23,42,.06),0 8px 18px -10px rgba(37,71,208,.35),0 18px 36px -18px rgba(15,23,42,.18) !important;}
    .lbm-links .linkbot-button::before{inset:1px 1px 50% 1px !important;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(255,255,255,0)) !important;}
    .lbm-links .linkbot-button::after{background:linear-gradient(115deg,transparent 30%,rgba(37,71,208,.10) 50%,transparent 70%) !important;}
    /* Tighter text at the top (same in every state, with or without links) so the link box gets more room. */
    .flex-col.bg-surface.pt-16{padding-top:56px !important;}
    .flex-col.bg-surface.pt-16 .eyebrow{margin-top:32px !important;line-height:14px !important;}
    .flex-col.bg-surface.pt-16 > h3{margin-top:14px;font-size:31.5px !important;line-height:35px !important;}
    .flex-col.bg-surface.pt-16 > p.mt-3{margin-top:6px !important;font-size:15px !important;line-height:25px !important;}
        .lbm-screen h3{transition:opacity .35s ease,max-height .45s cubic-bezier(.2,.8,.2,1) .2s,margin .45s cubic-bezier(.2,.8,.2,1) .2s;max-height:120px;}
    .lbm-on h3{opacity:0;max-height:0;overflow:hidden;margin-top:0 !important;margin-bottom:0 !important;}
    .lbm-ended .lbm-links{flex:1 1 auto;justify-content:flex-start;margin:18px 0 0;}
    .lbm-ended .lbm-links-wrap{flex:1 1 auto;}
    .lbm-ended .lbm-links-scroll{flex:1 1 auto;}
    .lbm-ended .demo-audio-lines{display:none !important;}
    .flex-col.bg-surface.pt-16:not(.lbm-on) .demo-audio-lines{display:none !important;transition:none !important;animation:none !important;}
    .lbm-ended .lbm-links-wrap.lbm-has-more .lbm-more-pill{display:flex;}
    .lbm-ended .lbm-links-wrap.lbm-scrolled .lbm-more-pill{opacity:0;pointer-events:none;}
    .lbm-ended .lbm-links-wrap.lbm-has-more .lbm-links-scroll{-webkit-mask-image:linear-gradient(to bottom,#000 0,#000 var(--lbm-fade,60%),rgba(0,0,0,.25) calc(var(--lbm-fade,60%) + 19px),transparent 100%);mask-image:linear-gradient(to bottom,#000 0,#000 var(--lbm-fade,60%),rgba(0,0,0,.25) calc(var(--lbm-fade,60%) + 19px),transparent 100%);}
    .lbm-ended .lbm-links-wrap.lbm-has-more.lbm-scrolled .lbm-links-scroll{-webkit-mask-image:linear-gradient(to bottom,#000 calc(100% - 9px),transparent calc(100% - 9px));mask-image:linear-gradient(to bottom,#000 calc(100% - 9px),transparent calc(100% - 9px));}
    .lbm-ended .lbm-links-head{display:block;}
    /* Link section box (after the call): faint brand-blue tint, pure white buttons, same size no matter how many links. */
    .lbm-ended .lbm-links{box-sizing:border-box;margin:13px 0 18px;padding:13px 11px 0;border-radius:var(--radius-lg,10px);background:color-mix(in oklab,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 6%,#fff);}
    .lbm-ended .lbm-links-hint{margin:7px 0 6px;}
    .lbm-ended .lbm-links-scroll{padding:4px 11px 9px;margin:0 -11px;}
    .lbm-ended .lbm-links .linkbot-button{background-image:none !important;}
    .lbm-ended .lbm-links .linkbot-button{animation:none !important;}
    .linkbot-button.lbm-call[aria-disabled="true"],.linkbot-button.lbm-call[aria-disabled="true"]:hover,.linkbot-button.lbm-call[aria-disabled="true"]:active{background-color:#B9C8F7 !important;background-image:none !important;color:#ffffff !important;box-shadow:none !important;cursor:not-allowed !important;pointer-events:none !important;transform:none !important;filter:none !important;transition:none !important;}
    .linkbot-button.lbm-call[aria-disabled="true"]::before,.linkbot-button.lbm-call[aria-disabled="true"]::after{display:none !important;}
    /* Shorter link box: 2 full buttons, then the bubble in the blank space with the 3rd button faint behind it. Equal blank space above and below the box. */
    .lbm-ended .lbm-links{flex:none !important;margin:auto 0 !important;}
    .lbm-ended .lbm-links-wrap{flex:none !important;height:146px;}
    .lbm-ended > .relative.mt-auto{margin-top:8px !important;}
    /* Box top is 8px higher (bottom stays put) so the blank space above the box matches the space below it. */
    .lbm-ended .lbm-links{padding-top:17px !important;}
    .lbm-ended .lbm-links-hint{margin-bottom:10px !important;}
    /* Link buttons: on hover they raise smoothly (no shine flash). */
    /* Smooth raise on hover. The phone is now sized with zoom instead of stretching, so text and outlines stay sharp. */
    .lbm-links .linkbot-button.lbm-lbtn{position:relative;transform:translateY(0) !important;filter:none !important;transition:transform 260ms cubic-bezier(.25,.8,.25,1),box-shadow 260ms cubic-bezier(.25,.8,.25,1) !important;}
    .lbm-links .linkbot-button.lbm-lbtn::after{display:none !important;}
    .lbm-links .linkbot-button.lbm-lbtn:hover{transform:translateY(-2px) !important;filter:none !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.22),0 1px 1px rgba(15,23,42,.06),0 12px 22px -10px rgba(37,71,208,.45),0 22px 40px -18px rgba(15,23,42,.22) !important;}
    .lbm-links .linkbot-button.lbm-lbtn:active{transform:translateY(0) !important;}
    .lbm-on .lbm-captions{display:block;} .lbm-on .lbm-sub{display:none;} .lbm-has-links .lbm-links{display:flex;}
    .lbm-on .demo-audio-lines{margin-top:18px;}
    .lbm-connecting{animation:lbm-breathe 1.4s ease-in-out infinite;}
    @keyframes lbm-breathe{0%,100%{opacity:.35;}50%{opacity:1;}}
    .lbm-dots i{font-style:normal;animation:lbm-dot 1.2s infinite;opacity:.2;}
    .lbm-dots i:nth-child(2){animation-delay:.2s;} .lbm-dots i:nth-child(3){animation-delay:.4s;}
    @keyframes lbm-dot{0%,80%,100%{opacity:.2;}40%{opacity:1;}}
    @media (prefers-reduced-motion:reduce){.lbm-connecting,.lbm-dots i{animation:none;opacity:1;}}
    /* Save-a-copy popup for Google document links */
    .lbm-doc-ov{position:absolute;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;padding:0 20px;background:rgba(11,16,32,.38);animation:lbm-fade .18s ease both;}
    @keyframes lbm-fade{from{opacity:0;}to{opacity:1;}}
    .lbm-doc-sheet{width:100%;box-sizing:border-box;background:#fff;border-radius:var(--radius-lg,10px);padding:22px 20px 18px;display:flex;flex-direction:column;align-items:center;text-align:center;box-shadow:0 24px 48px -16px rgba(11,16,32,.45);animation:lbm-pop .22s cubic-bezier(.2,.8,.2,1) both;}
    .lbm-doc-ic{width:52px;height:52px;border-radius:50%;display:grid;place-items:center;color:var(--linkbot-blue-exact,oklch(0.52 0.24 264));background:color-mix(in oklab,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 10%,#fff);}
    .lbm-doc-ic svg{width:24px;height:24px;}
    .lbm-unav .lbm-doc-ic svg{width:22px;height:22px;}
    .lbm-doc-title{margin:14px 0 0;width:100%;font:800 18px/1.25 var(--font-display,"Manrope"),ui-sans-serif,system-ui,sans-serif;letter-spacing:-.01em;color:var(--ink,#0b1020);white-space:nowrap;}
    .lbm-doc-text{margin:7px 0 18px;width:100%;font:500 13px/1.5 "Inter",ui-sans-serif,system-ui,sans-serif;color:oklch(0.46 0.03 260);}
    .lbm-doc-sheet .linkbot-button{width:100%;}
    .lbm-doc-sheet .lbm-doc-just{margin-top:10px;}
    .lbm-doc-row{margin-top:15px;width:100%;box-sizing:border-box;padding:0 5px;display:flex;align-items:center;gap:8px;cursor:pointer;font:500 12.5px "Inter",ui-sans-serif,system-ui,sans-serif;color:oklch(0.46 0.03 260);white-space:nowrap;-webkit-tap-highlight-color:transparent;}
    .lbm-doc-box{flex:none;width:18px;height:18px;border-radius:5px;box-sizing:border-box;border:1.5px solid rgba(15,23,42,.28);display:grid;place-items:center;background:#fff;color:#fff;}
    .lbm-doc-box svg{width:11px;height:11px;display:none;}
    .lbm-doc-row.on .lbm-doc-box{background:var(--linkbot-blue-exact,oklch(0.52 0.24 264));border-color:var(--linkbot-blue-exact,oklch(0.52 0.24 264));}
    .lbm-doc-row.on .lbm-doc-box svg{display:block;}
    .lbm-doc-words{flex:none;text-align:left;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-just{color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background-color:#ffffff !important;
      background-image:linear-gradient(180deg,#ffffff 0%,#f3f5fb 100%) !important;background-blend-mode:normal !important;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.16),0 1px 1px rgba(15,23,42,.06),0 8px 18px -10px rgba(37,71,208,.35),0 18px 36px -18px rgba(15,23,42,.18) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-just::before{inset:1px 1px 50% 1px !important;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(255,255,255,0)) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-just::after{background:linear-gradient(115deg,transparent 30%,rgba(37,71,208,.10) 50%,transparent 70%) !important;}
    /* Popup buttons (Save & Open, Just Open): the website button's lift, shine sweep and press, built in so they always work. Call buttons and link buttons are not touched. */
    .lbm-doc-sheet .linkbot-button{position:relative !important;isolation:isolate;overflow:hidden !important;cursor:pointer;transform:none;filter:none;transition:transform 450ms cubic-bezier(.2,.8,.2,1),box-shadow 450ms cubic-bezier(.2,.8,.2,1),filter 300ms ease !important;}
    .lbm-doc-sheet .linkbot-button > span{position:relative;z-index:1;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-save{color:#fff !important;background-color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background-image:linear-gradient(180deg,rgba(255,255,255,.16) 0%,rgba(255,255,255,0) 45%,rgba(0,0,0,.18) 100%) !important;background-blend-mode:overlay !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.28),inset 0 -1px 0 rgba(0,0,0,.35),inset 0 0 0 1px rgba(255,255,255,.06),0 1px 0 rgba(0,0,0,.18),0 10px 22px -8px rgba(15,23,42,.35),0 22px 48px -16px rgba(15,23,42,.28) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-save::before{content:"";position:absolute;inset:0 0 50% 0;z-index:-1;pointer-events:none;border-radius:inherit;background:linear-gradient(180deg,rgba(255,255,255,.22),rgba(255,255,255,0));}
    .lbm-doc-sheet .linkbot-button.lbm-doc-just::before{content:"";position:absolute;z-index:-1;pointer-events:none;border-radius:inherit;}
    .lbm-doc-sheet .linkbot-button::after{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;border-radius:inherit;transform:translateX(-120%) !important;transition:transform 900ms cubic-bezier(.2,.8,.2,1) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-save::after{background:linear-gradient(115deg,transparent 30%,rgba(255,255,255,.28) 50%,transparent 70%) !important;}
    .lbm-doc-sheet .linkbot-button:hover{transform:translateY(-3px) scale(1.015) !important;filter:brightness(1.06) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-save:hover{box-shadow:inset 0 1px 0 rgba(255,255,255,.4),inset 0 -1px 0 rgba(0,0,0,.4),inset 0 0 0 1px rgba(255,255,255,.1),0 2px 0 rgba(0,0,0,.18),0 18px 34px -10px rgba(15,23,42,.4),0 36px 70px -22px rgba(26,84,240,.55) !important;}
    .lbm-doc-sheet .linkbot-button:hover::after{transform:translateX(120%) !important;}
    .lbm-doc-sheet .linkbot-button:active{transform:translateY(0) scale(.99) !important;filter:brightness(.98) !important;}
    .lbm-doc-sheet .linkbot-button.lbm-doc-save:active{box-shadow:inset 0 2px 4px rgba(0,0,0,.35),inset 0 -1px 0 rgba(255,255,255,.08),0 6px 14px -8px rgba(15,23,42,.35) !important;}
    /* Business hasn't paid: Start Call greyed out. */
    .lbm-paused .lbm-call{filter:grayscale(1) !important;opacity:.45 !important;}
    /* All lines busy: the page turns into a typing chat. Same look, just no voice. */
    .lbm-chat{display:none;flex:1 1 auto;min-height:0;flex-direction:column;align-items:center;width:100%;margin-top:14px;}
    .lbm-busy .lbm-chat{display:flex;}
    .lbm-busy > h3,.lbm-busy > p.mt-3,.lbm-busy .lbm-links,.lbm-busy .demo-audio-lines,.lbm-busy .lbm-captions,.lbm-busy > .relative.mt-auto{display:none !important;}
    .lbm-chat-note{flex:none;padding:6px 12px;border-radius:999px;background:color-mix(in oklab,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 8%,#fff);color:var(--linkbot-blue-exact,oklch(0.52 0.24 264));font:600 11.5px/1.2 "Inter",ui-sans-serif,system-ui,sans-serif;white-space:nowrap;}
    .lbm-chat-msgs{flex:1 1 auto;min-height:0;width:100%;overflow-y:auto;scrollbar-width:none;display:flex;flex-direction:column;gap:5px;padding:12px 0 6px;}
    .lbm-chat-msgs::-webkit-scrollbar{display:none;}
    .lbm-chat-msgs > :first-child{margin-top:auto;}
    .lbm-chat-msgs .lbm-lbtn{flex:none;margin:4px 0 2px;}
    .lbm-chat-msgs .linkbot-button.lbm-lbtn{display:grid !important;grid-template-columns:28px 1fr 28px;align-items:center;width:100%;box-sizing:border-box;padding:0 10px !important;color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background:#fff !important;background-blend-mode:normal !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.16),0 1px 1px rgba(15,23,42,.06),0 8px 18px -10px rgba(37,71,208,.35),0 18px 36px -18px rgba(15,23,42,.18) !important;}
    .lbm-chat-msgs .linkbot-button.lbm-lbtn::before{inset:1px 1px 50% 1px !important;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(255,255,255,0)) !important;}
    .lbm-chat-msgs .linkbot-button.lbm-lbtn::after{display:none !important;}
    .lbm-chat-form{flex:none;width:100%;box-sizing:border-box;margin:8px 0 0;height:44px;border-radius:999px;display:flex;align-items:center;gap:6px;padding:0 5px 0 16px;background:#fff;box-shadow:inset 0 0 0 1px oklch(0.88 0.015 250);}
    .lbm-chat-in{flex:1 1 auto;min-width:0;border:0;outline:0;background:transparent;font:500 14px "Inter",ui-sans-serif,system-ui,sans-serif;color:var(--ink,#0b1020);}
    .lbm-chat-send{flex:none;width:34px;height:34px;border:0;border-radius:50%;display:grid;place-items:center;color:#fff;background:var(--linkbot-blue-exact,oklch(0.52 0.24 264));cursor:pointer;}
    .lbm-chat-send svg{width:16px;height:16px;}
    .lbm-busy .lbm-mic{display:none !important;}
    .lbm-busy-pop .lbm-doc-save{margin-top:14px;}
    .lbm-chat-dbg{flex:none;width:100%;margin-top:6px;text-align:center;font:500 10px/1.3 ui-monospace,Menlo,monospace;color:#9ca3af;}
    /* Approved link buttons (same as the mock-ups and PDF): pure white, raised, blue gem icons. Size and shape stay the same. */
    .lbm-screen .linkbot-button.lbm-lbtn{color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background-color:#ffffff !important;background-image:linear-gradient(180deg,#ffffff 0%,#ffffff 55%,#fafafa 100%) !important;background-blend-mode:normal !important;
      box-shadow:inset 0 1px 0 #fff,inset 0 -1.5px 1.5px rgba(0,0,0,.04),0 0 0 .5px rgba(0,0,0,.05),0 1px 1px rgba(0,0,0,.08),0 3px 5px -1px rgba(0,0,0,.10),0 8px 14px -4px rgba(0,0,0,.16),0 14px 20px -12px rgba(0,0,0,.18) !important;}
    .lbm-screen .linkbot-button.lbm-lbtn::before{display:none !important;}
    .lbm-screen .lbm-links .linkbot-button.lbm-lbtn:hover{box-shadow:inset 0 1px 0 #fff,inset 0 -1.5px 1.5px rgba(0,0,0,.04),0 0 0 .5px rgba(0,0,0,.05),0 2px 2px rgba(0,0,0,.08),0 6px 9px -2px rgba(0,0,0,.12),0 13px 20px -5px rgba(0,0,0,.18),0 20px 28px -14px rgba(0,0,0,.2) !important;}
    .lbm-screen .lbm-lbtn .lbm-tx{font-weight:700 !important;letter-spacing:-.3px;text-shadow:none !important;}
    .lbm-screen .lbm-lbtn .lbm-ic{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;justify-self:start;color:#fff;
      background:radial-gradient(ellipse 62% 38% at 50% 20%,rgba(255,255,255,.9),rgba(255,255,255,0) 72%),radial-gradient(circle at 50% 115%,rgba(150,200,255,.95) 0%,rgba(150,200,255,0) 55%),linear-gradient(180deg,color-mix(in oklab,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 60%,#fff) 0%,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 55%,color-mix(in oklab,var(--linkbot-blue-exact,oklch(0.52 0.24 264)) 68%,#000) 100%);
      box-shadow:inset 0 -2px 3px rgba(0,0,30,.3),0 2px 3px -1px rgba(0,0,0,.25);}
    .lbm-screen .lbm-lbtn .lbm-ic svg{width:14px !important;height:14px !important;margin:0 !important;filter:drop-shadow(0 1px 0 rgba(0,0,40,.35));}
    /* Calling screen (like an iPhone call): from Start Call until the AI starts talking. */
    .lbm-callname,.lbm-callstate{display:none;}
    .lbm-calling > h3,.lbm-calling > p.mt-3,.lbm-calling .demo-audio-lines,.lbm-calling .lbm-links,.lbm-calling .lbm-captions{display:none !important;}
    .lbm-calling .lbm-callname{display:block;margin:14px 0 0;font:600 26px/1.2 -apple-system,BlinkMacSystemFont,"SF Pro Display","Inter",ui-sans-serif,system-ui,sans-serif;letter-spacing:-.01em;color:var(--ink,#0b1020);}
    .lbm-calling .lbm-callstate{display:block;margin:6px 0 0;font:400 16px/1.3 -apple-system,BlinkMacSystemFont,"SF Pro Text","Inter",ui-sans-serif,system-ui,sans-serif;color:#8a8a8e;}
    /* Start Call / End Call button: pinned to the same spot at the bottom of the phone screen in every state. The space it uses is reserved so nothing else moves. */
    .flex-col.bg-surface.pt-16 > .relative.mt-auto{position:absolute !important;left:24px;right:24px;bottom:24px;width:auto !important;margin:0 !important;}
    .flex-col.bg-surface.pt-16{padding-bottom:68px !important;}
    .flex-col.bg-surface.pt-16.lbm-ended{padding-bottom:76px !important;}
    .flex-col.bg-surface.pt-16.lbm-busy{padding-bottom:24px !important;}
    /* REAL PHONES ONLY (#lb-mobile; the desktop phone picture is untouched): less empty space at the top, taller Start/End Call button, and the blue links box stretches to fill the screen. */
    #lb-mobile .flex-col.bg-surface.pt-16{padding-top:18px !important;padding-bottom:74px !important;}
    #lb-mobile .flex-col.bg-surface.pt-16.lbm-ended{padding-bottom:82px !important;}
    #lb-mobile .flex-col.bg-surface.pt-16.lbm-busy{padding-bottom:24px !important;}
    #lb-mobile .flex-col.bg-surface.pt-16 > .relative.mt-auto .linkbot-button{height:50px !important;}
    #lb-mobile .lbm-ended .lbm-links{flex:1 1 auto !important;margin:10px 0 !important;min-height:0;}
    #lb-mobile .lbm-ended .lbm-links-wrap{flex:1 1 auto !important;height:auto !important;min-height:96px;}
    /* 225: real phones: tighter space above "LIVE RECEPTIONIST", and the subtitle always stays on one line. */
    #lb-mobile .flex-col.bg-surface.pt-16 .eyebrow{margin-top:18px !important;}
    #lb-mobile .flex-col.bg-surface.pt-16 > p.mt-3{white-space:nowrap;overflow:hidden;}
    /* 231: blue top line on top with no gap; the mic takes the gap the blue line used, so everything below stays put from the first frame. The mic only animates when it folds away for a call; it comes back instantly. */
    .flex-col.bg-surface.pt-16 .text-center > .eyebrow{margin-top:0 !important;}
    #lb-mobile .flex-col.bg-surface.pt-16 .text-center > .eyebrow{margin-top:0 !important;}
    .lbm-mic{margin-top:32px;max-height:140px;}
    #lb-mobile .lbm-mic{margin-top:18px;}
    .lbm-calling .lbm-mic,.lbm-on .lbm-mic{opacity:0;max-height:0;overflow:hidden;margin-top:0 !important;transition:opacity .35s ease,max-height .45s cubic-bezier(.2,.8,.2,1) .2s,margin .45s cubic-bezier(.2,.8,.2,1) .2s;}
    /* 231: mic pulse stops a little sooner (1.4x instead of 1.6x) so it doesn't run into the words. */
    .lbm-mic > span.absolute{animation-name:lbm-pulse-ring-short !important;}
    @keyframes lbm-pulse-ring-short{0%{transform:scale(.9);opacity:.8;}70%{transform:scale(1.4);opacity:0;}100%{transform:scale(1.4);opacity:0;}}
    /* 233: nothing slides: hidden until ready, and no collapse/expand animation when a call starts or ends. */
    body{transition:none !important;}
    html.lbm-loading body{opacity:0 !important;}
    @media (pointer: coarse) and (max-width: 599px), (pointer: coarse) and (max-height: 599px){html,body{background:#fff !important;}}
    .lbm-screen h3,.lbm-calling .lbm-mic,.lbm-on .lbm-mic{transition:none !important;}
    /* 233: desktop/iPad phone only: one-line sentence, mic gap matches the real-phone layout, roomier links box. */
    #lb-stage .flex-col.bg-surface.pt-16 > p.mt-3{white-space:nowrap;overflow:hidden;}
    #lb-stage .lbm-mic{margin-top:18px;}
    #lb-stage .lbm-ended .lbm-links{padding-top:22px !important;}
    #lb-stage .lbm-ended .lbm-links-hint{margin-bottom:14px !important;}
    #lb-stage .lbm-ended .lbm-links-scroll{gap:12px;}
    #lb-stage .lbm-ended .lbm-links{flex:none !important;margin:auto 0 !important;}
    #lb-stage .lbm-ended .lbm-links-wrap{flex:none !important;height:166px !important;}
    /* 231: Start/End Call buttons are flat like an iPhone call button: no gray outer drop shadow (inner edge shine kept). */
    .flex-col.bg-surface.pt-16 > .relative.mt-auto .linkbot-button,.flex-col.bg-surface.pt-16 > .relative.mt-auto .linkbot-button:hover,.flex-col.bg-surface.pt-16 > .relative.mt-auto .linkbot-button:active{box-shadow:inset 0 1px 0 rgba(255,255,255,.28),inset 0 -1px 0 rgba(0,0,0,.35),inset 0 0 0 1px rgba(255,255,255,.06) !important;}
    /* Dead end page: someone typed the name link straight into the address bar. */
    .lbm-dead-pg{display:none;position:absolute;inset:0;z-index:25;background:#fff;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:0 16px;box-sizing:border-box;text-align:center;color:#6b7280;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}
    .lbm-dead .lbm-dead-pg{display:flex;}
    .lbm-dead-msg{margin:0;width:206px;line-height:1.5;}
    .lbm-dead-btns{display:flex;flex-direction:column;gap:10px;width:206px;}
    .lbm-dead-btns .linkbot-button{width:100%;box-sizing:border-box;height:44px;text-decoration:none;}
    .lbm-dead-btns .linkbot-button.lbm-white{color:var(--linkbot-blue-exact,oklch(0.52 0.24 264)) !important;background-color:#ffffff !important;background-image:linear-gradient(180deg,#ffffff 0%,#f3f5fb 100%) !important;background-blend-mode:normal !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.16),0 1px 1px rgba(15,23,42,.06),0 8px 18px -10px rgba(37,71,208,.35),0 18px 36px -18px rgba(15,23,42,.18) !important;}
    .lbm-dead-btns .linkbot-button.lbm-white::before{inset:1px 1px 50% 1px !important;background:linear-gradient(180deg,rgba(255,255,255,.9),rgba(255,255,255,0)) !important;}
    .lbm-dead-btns .linkbot-button.lbm-white::after{background:linear-gradient(115deg,transparent 30%,rgba(37,71,208,.10) 50%,transparent 70%) !important;}
  `;

  document.getElementById("lbm-frame")?.remove();
  const frame = document.createElement("iframe");
  frame.id = "lbm-frame";
  frame.setAttribute("allow", "microphone");
  frame.style.cssText = "position:fixed;inset:0;width:100%;height:100vh;height:100dvh;border:0;z-index:2147483647;background:#000;"; // fit the visible screen, even when the phone's browser bars are showing
  frame.srcdoc = `<!doctype html><html class="lbm-loading"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="${CSS_URL}">${HEAD}<style>${EXTRA_CSS}</style></head><body>${BODY}</body></html>`;
  document.body.appendChild(frame);
  // 233: show the phone screen only once it is fully built and its fonts are loaded, so nothing shifts after it appears.
  frame.addEventListener("load", () => {
    const d = frame.contentDocument;
    if (!d) return;
    const reveal = () => d.documentElement.classList.remove("lbm-loading");
    // 256: wait until the folders settings have attached to every phone screen, so nothing is added or rebuilt after it shows.
    const foldersReady = new Promise((r) => {
      const chk = () => {
        const ss = d.querySelectorAll(".lbm-screen");
        if (ss.length && Array.from(ss).every((s) => s.getAttribute("data-lbf") === "1")) return r();
        setTimeout(chk, 30);
      };
      chk();
    });
    Promise.race([Promise.all([d.fonts?.ready ?? Promise.resolve(), foldersReady]), new Promise((r) => setTimeout(r, 2000))])
      .then(() => requestAnimationFrame(() => requestAnimationFrame(reveal)));
  });
  // Real phones: the page behind the call screen is white, so Safari's address bar and toolbar turn white and blend in.
  // (Chrome on iPhone always keeps its own gray bars; no website can change them.)
  if (window.matchMedia && matchMedia("(pointer: coarse)").matches && Math.min(screen.width, screen.height) < 600) {
    frame.style.background = "#fff";
    document.documentElement.style.setProperty("background", "#fff", "important");
    document.body.style.setProperty("background", "#fff", "important");
    let tc = document.querySelector('meta[name="theme-color"]');
    if (!tc) { tc = document.createElement("meta"); tc.setAttribute("name", "theme-color"); document.head.appendChild(tc); }
    tc.setAttribute("content", "#ffffff");
  }

  // ---- The assistant's widget on this page (hidden behind the mock-up) ----
  // 278: the call widget runs in its own hidden frame, reloaded brand new after every call.
  const pageWidgetId = (document.querySelector("script[data-widget-id]")?.getAttribute("data-widget-id") || "").replace(/[^A-Za-z0-9_-]/g, "");
  let wf = null;
  const loadWidgetFrame = () => {
    if (!pageWidgetId) return;
    if (!wf) {
      wf = document.createElement("iframe");
      wf.id = "lb-widget-frame";
      wf.setAttribute("allow", "microphone; autoplay");
      wf.setAttribute("aria-hidden", "true");
      wf.tabIndex = -1;
      wf.style.cssText = "position:fixed;left:0;top:0;width:420px;height:640px;border:0;opacity:0;pointer-events:none;transform:translateX(-300vw);z-index:0;";
      document.body.appendChild(wf);
    }
    wf.src = "/lb-widget-chat.html?w=" + encodeURIComponent(pageWidgetId) + "&r=" + Date.now();
  };
  if (pageWidgetId) {
    loadWidgetFrame();
    // the page's own copy of the widget is never used: remove it whenever it appears
    setInterval(() => { document.querySelectorAll("chat-widget").forEach((el) => el.remove()); }, 300);
    document.querySelectorAll("chat-widget").forEach((el) => el.remove());
  }
  const widget = () => pageWidgetId ? (wf?.contentDocument?.querySelector("chat-widget:not([data-pr-ghost])") || null) : document.querySelector("chat-widget:not([data-pr-ghost])");
  let reloadTimer = 0;
  const freshWidget = () => { if (!pageWidgetId) return; clearTimeout(reloadTimer); reloadTimer = setTimeout(() => { if (live || connecting || callOn) return; loadWidgetFrame(); }, 800); }; // 278: brand-new widget for the next call
  // Works with the widget already on this page: the round orb style or the bar style.
  const ctrl = () => { try { return widget()?.__stencil__getHostRef?.()?.t || null; } catch { return null; } };
  const press = () => {
    const root = widget()?.shadowRoot;
    const stage = root?.querySelector(".voice-orb-stage");
    if (stage) {
      stage.focus();
      const KE = wf?.contentWindow?.KeyboardEvent || KeyboardEvent; // 278: event made in the widget's own frame
      stage.dispatchEvent(new KE("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      stage.blur(); // 273: the keyboard can never reach the hidden widget
      return true;
    }
    const bar = root?.querySelector(".lc_text-widget--horizontal");
    if (!bar) return false;
    const c = ctrl();
    if ((live || connecting) && c && typeof c.handleEndVoiceCall === "function") { c.handleEndVoiceCall(); return true; } // bar style: End Call hangs up
    bar.click();
    return true;
  };
  const isLive = () => {
    const cls = widget()?.shadowRoot?.querySelector(".voice-orb-widget")?.className || "";
    if (cls) return !/is-idle/.test(cls) && !/is-(ended|complete|completed|success|finished)/.test(cls);
    return !!ctrl()?.isVoiceCallActive;
  };

  // ---- Live words from the call ----
  const lines = []; // {who:"ai"|"you", text, open}
  const links = new Map(); // key -> {label,url}
  const raw = [];
  const roleOf = (j) => {
    const r = String(j.role || j.speaker || j.source || j.participant || j.from || (j.data && (j.data.role || j.data.speaker || j.data.source)) || "").toLowerCase();
    if (/user|caller|human|customer|visitor|client/.test(r)) return "you";
    if (/agent|assistant|ai|bot|model/.test(r)) return "ai";
    return "";
  };
  const textOf = (j, depth = 0) => {
    if (!j || typeof j !== "object" || depth > 4) return "";
    for (const k of ["text", "transcript", "delta", "content", "caption"]) if (typeof j[k] === "string" && j[k].trim()) return j[k];
    for (const v of Object.values(j)) if (v && typeof v === "object") { const t = textOf(v, depth + 1); if (t) return t; }
    return "";
  };
  // Saved links: kept in this browser, separately for each business page, with no end date.
  const STORE = "linkbot-links:" + location.hostname + location.pathname;
  const norm = (x) => String(x).toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/+$/, "");
  const callLinks = new Set(); // labels given during the current call
  const saveLinks = () => { try { localStorage.setItem(STORE, JSON.stringify([...links.values()])); } catch {} };
  const loadLinks = () => {
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem(STORE) || "[]"); } catch {}
    if (!Array.isArray(saved)) saved = [];
    // Only links the business still has set up are kept; a changed address under the same name is updated.
    saved.forEach((l) => {
      const c = COVER.find((k) => k.label === (l && l.label));
      if (c && !links.has(c.label) && ![...links.values()].some((x) => norm(x.url) === norm(c.url))) links.set(c.label, { label: c.label, url: c.url });
    });
    saveLinks();
  };
  const addLink = (label, url) => {
    callLinks.add(label);
    // The same link only ever shows once (matched by its name or its address); giving it again moves it to the top.
    [...links.values()].forEach((x) => { if (x.label === label || norm(x.url) === norm(url)) links.delete(x.label); });
    links.set(label, { label, url });
    saveLinks();
    render();
  };
  // Only links the business has set up get a button; any other address the assistant says is ignored.
  const scanLinks = (text, who) => {
    COVER.forEach((c) => { if ((who === "ai" || c.caller) && c.re.test(text)) addLink(c.label, c.url); });
  };
  const byItem = new Map(); // itemId -> line
  // Spoken web addresses are rewritten only for the links this page knows (no guessing).
  const KNOWN = [];
  const spoken = KNOWN.map((d) => {
    const [name, ...rest] = d.split(".");
    const letters = name.split("").map((ch) => ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("[\\s.]*");
    const tld = rest.join("\\s*(?:dot|\\.)\\s*");
    return { d, re: new RegExp("(?:\\bw\\s*w\\s*w\\s*(?:dot|\\.)\\s*)?\\b" + letters + "[\\s.]*(?:dot|\\.)\\s*" + tld + "\\b", "gi") };
  });
  const pretty = (s) => spoken.reduce((acc, k) => acc.replace(k.re, (m) => (/^w\s*w\s*w/i.test(m) ? "www." : "") + k.d), s);
  // On screen only: a question the assistant ends with "!" (for her voice) shows with "?" instead.
  const QWORDS = /^(?:what|how|why|when|where|who|which|can|could|would|will|do|does|did|is|are|may)\b/i;
  // Caller's phone numbers and emails show the way they're written: 555-123-4567 and name@example.com (on screen only).
  const PHONE_RE = /(?:\+?\b1[\s,.-]*)?\(?\b(\d{3})\)?[\s,.-]*(\d{3})[\s,.-]*(\d{4})\b/g;
  const EMAIL_RE = /^(.*?)\s+(?:at|@)\s+([a-z0-9][a-z0-9 .-]*?)\s*(?:dot|\.)\s*(com|net|org|io|co|us|edu|gov|me|ai|biz|info|ca|uk)\b\.?$/i;
  const fmtYou = (l, t) => {
    t = t.replace(PHONE_RE, (m, a, b, c) => (/^\s*\+?1\b/.test(m) ? "1-" : "") + a + "-" + b + "-" + c);
    const i = lines.indexOf(l);
    let prev = null;
    for (let k = i - 1; k >= 0; k--) if (lines[k].who !== "you") { prev = lines[k]; break; }
    if (!prev || !/e-?mail/i.test(prev.text)) return t; // only when the assistant just asked for their email
    const m = t.replace(/\s*@\s*/g, " at ").match(EMAIL_RE);
    if (!m) return t;
    let name = m[1].replace(/^.*\b(?:is|it's|its|it is)\b\s*/i, "");
    while (/^(yeah|yes|sure|ok|okay|um|uh|so)\b[,.]?\s*/i.test(name)) name = name.replace(/^(yeah|yes|sure|ok|okay|um|uh|so)\b[,.]?\s*/i, "");
    const tidy = (x) => x.toLowerCase().replace(/\s+dot\s+/g, ".").replace(/\s+(underscore)\s+/g, "_").replace(/\s+(dash|hyphen)\s+/g, "-").replace(/[^a-z0-9._+-]/g, "");
    const user = tidy(name), dom = tidy(m[2]);
    return user && dom ? user + "@" + dom + "." + m[3].toLowerCase() : t;
  };
  const asks = (s) => s.replace(/[^.!?]+[.!?]*/g, (seg) => { const lead = seg.match(/^\s*/)[0]; const body = seg.slice(lead.length); return QWORDS.test(body) ? lead + body.replace(/!+(\s*)$/, "?$1") : seg; });
  const clean = (s) => s.replace(/\[[^\]]*(\]|$)/g, "").replace(/[\[\]]/g, "").replace(/\s{2,}/g, " ").replace(/^[\s.,;:!?-]+/, "").trim();
  // Smart link matching for ANY button the business has set up, using only the button's own name (no word lists per link).
  // "Visit Our Website" -> website, "View Our Pricing Guide" -> pricing + guide. A button shows when the assistant names it while sharing it,
  // or when the caller asked for it and the assistant says it's on their screen without naming it.
  const STOP = /^(visit|view|see|read|open|get|check|out|download|watch|our|the|your|my|a|an|to|for|and|of|this|that|here|click|tap|now|link|links|page)$/;
  const words = (t) => clean(String(t)).toLowerCase().replace(/web\s+site/g, "website").match(/[a-z0-9]+/g) || [];
  const keysOf = (c) => c.keys || (c.keys = words(c.label).filter((w) => !STOP.test(w)));
  const hits = (w, k) => w === k || w === k + "s" || (k.length >= 4 && w.includes(k)) || (w.length >= 4 && k.includes(w));
  const named = (ws, c) => keysOf(c).length > 0 && keysOf(c).every((k) => ws.some((w) => w === k || w === k + "s" || (k.length >= 4 && w.includes(k)))); // the assistant must say the whole name word ("site" alone isn't "website")
  const partly = (ws, c) => keysOf(c).filter((k) => ws.some((w, i) => hits(w, k) && !/^(my|our)$/.test(ws[i - 1] || ""))).length; // "my website" is the caller's own, not ours
  const HANDED = /\b(bottom of|on) (your|the) screen\b|\b(sent|sending|dropped|dropping) (it|that|this)\b|\b(shared|sharing) it\b|got it for you|here it is|here you go|\btap (it|on it)\b|\bclick (it|on it)\b/i;
  const SHARE = /\bdropp(ing|ed)\b|\b(i'?m|i am|i'?ve|i have|just|i)\s+(sent|sending|shared|sharing)\b|\bhere it is\b|\bhere you go\b|\b(on|bottom of) (your|the) screen\b/i; // the assistant sharing it, not just talking about it
  const ASK = /\b(send|share|drop|text|email|give|get|see|look|show|link|pull|where|what.?s|have|book|schedule|need|want)\b/i;
  const NOPE = /\b(don.?t|can.?t|cannot|unable|isn.?t|not available)\b/i;
  let asked = null;
  const smartLinks = (cur, who) => {
    if (who === "you") { // remember which button the caller just asked for (cleared by their next words)
      const ws = words(cur.text);
      let best = null, n = 0;
      if (ASK.test(clean(cur.text))) COVER.forEach((c) => { const m = partly(ws, c); if (m > n) { n = m; best = c; } });
      asked = best;
      return;
    }
    clean(cur.text).split(/(?<=[.!?])\s+/).forEach((sen) => {
      if (NOPE.test(sen)) return; // "I don't have that one" never shows a button
      const ws = words(sen);
      COVER.forEach((c) => { if (!cur.seen.has(c.label) && named(ws, c) && (SHARE.test(sen) || HANDED.test(sen))) { cur.seen.add(c.label); addLink(c.label, c.url); } });
      if (asked && !cur.seen.has(asked.label) && HANDED.test(sen)) { cur.seen.add(asked.label); addLink(asked.label, asked.url); }
    });
  };
  const onMessage = (data) => {
    if (typeof data !== "string") return;
    let j; try { j = JSON.parse(data); } catch { return; }
    const type = String(j.type || j.event || "");
    if (resetting) return; // 272: messages from reopening the old call never reach the screen
    if (/call[-_ ]?end/i.test(type)) { if (!live) return; const seq = callSeq; setTimeout(() => { if (seq === callSeq && live && !isLive()) endNow(); }, 1200); return; } // 259/270/279: only ends a call that was already live and really has ended; never while ringing or connecting
    if (!/transcript/i.test(type)) return;
    if (raw.length < 40 && /final/i.test(type)) { raw.push(j); console.log("LinkBot mock-up, final call message", j); }
    const text = textOf(j); if (!text) return;
    freshStart();
    const who = roleOf(j) || "ai";
    if (who === "ai") aiSpoke = true; // 4K2
    if (!talking) talking = true;
    clearUnavailable(); // 240: words are coming through, so the call works
    if (connecting) { connecting = false; console.log("LinkBot mock-up: The assistant's first words arrived " + Math.round(performance.now() - tapAt) + " ms after tapping Start Call."); }
    const final = /final/i.test(type);
    const key = j.itemId || j.item_id || j.id || (who + ":" + lines.length);
    let cur = byItem.get(key);
    if (!cur) { cur = { who, text: "", open: true }; byItem.set(key, cur); lines.push(cur); }
    cur.text = final ? text : cur.text + text;
    if (final) cur.open = false;
    // 238: the AI said goodbye as the last thing in its line: hang up immediately, exactly like tapping End Call.
    if (final && who === "ai" && /\b(good\s*-?\s*bye|bye(\s+(now|for now))?)\s*[.!]*\s*$/i.test(clean(cur.text)) && (live || connecting || callOn)) {
      cancelUntil = performance.now() + 15000; sawOff = false; hangUp(); endNow();
    }
    cur.seen = cur.seen || new Set();
    COVER.forEach((c) => { if (!cur.seen.has(c.label) && (who === "ai" || c.caller) && c.re.test(clean(cur.text))) { cur.seen.add(c.label); addLink(c.label, c.url); } }); // checked while the words come in, so the button shows the moment the link is mentioned
    smartLinks(cur, who);
    render();
  };
  const proto = WebSocket.prototype;
  if (!window.__lbmHooked) {
    window.__lbmHooked = true;
    const origAdd = proto.addEventListener;
    const hooked = new WeakSet();
    const hook = (ws) => { if (hooked.has(ws)) return; hooked.add(ws); origAdd.call(ws, "message", (e) => window.__lbmOnMessage && window.__lbmOnMessage(e.data)); };
    proto.addEventListener = function (type, fn, opts) { if (type === "message") hook(this); return origAdd.call(this, type, fn, opts); };
    const desc = Object.getOwnPropertyDescriptor(proto, "onmessage");
    Object.defineProperty(proto, "onmessage", { configurable: true, get() { return desc.get.call(this); }, set(v) { hook(this); desc.set.call(this, v); } });
  }
  window.__lbmOnMessage = onMessage;
  // TEST ONLY: the links test snippet adds its sample buttons here, so they stay put when the list redraws.
  window.__lbmAddLinks = (list) => { list.forEach((l) => addLink(l.label, l.url)); };

  // ---- Google document links: offer to save a PDF copy to the device first ----
  const FILE_IC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/></svg>';
  const DL_IC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/></svg>';
  const SAVE_IC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M12 11v6"/><path d="m9 14 3 3 3-3"/></svg>';
  // Docs, Sheets and Slides save as PDF; a file stored in Google Drive saves as whatever it already is.
  const docDownload = (url) => {
    let m = String(url).match(/docs\.google\.com\/(document|spreadsheets|presentation)\/d\/([\w-]+)/);
    if (m) return m[1] === "presentation" ? `https://docs.google.com/presentation/d/${m[2]}/export/pdf` : `https://docs.google.com/${m[1]}/d/${m[2]}/export?format=pdf`;
    m = String(url).match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:[^#]*&)?id=)([\w-]+)/);
    if (m) return `https://drive.google.com/uc?export=download&id=${m[1]}`;
    return "";
  };
  const isDoc = (l) => !!docDownload(l.url);
  // The name shown in the popup comes from the button name the business set (never made up): "View Our Price Guide" becomes "Price Guide".
  const docName = (label) => label.replace(/^(view|see|read|download|open|get|check out)\s+(our|the|your|this)?\s*/i, "").trim() || label;
  const ALWAYS = "linkbot-docs-always:" + location.hostname + location.pathname;
  const alwaysSave = () => { try { return localStorage.getItem(ALWAYS) === "1"; } catch { return false; } };
  // The download runs in a hidden frame, so if Google sends a page instead of a file, this screen is never replaced.
  const saveFile = (url) => {
    const f = docRef.createElement("iframe");
    f.style.cssText = "position:absolute;width:0;height:0;border:0;visibility:hidden;";
    f.src = docDownload(url);
    docRef.body.appendChild(f);
    setTimeout(() => f.remove(), 60000);
  };
  // 222: On phones and iPads, links open in a full-screen panel over the call so the call keeps going. Computers still open a new tab.
  const PANEL_APP = /LinkedInApp|FBAN|FBAV|FB_IAB|Instagram|Twitter|TikTok|musical_ly|Snapchat/i.test(navigator.userAgent);
  const touchDevice = () => matchMedia("(pointer: coarse)").matches || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
  const usePanel = () => PANEL_APP || touchDevice();
  const uaIOSMajor = () => { const m = navigator.userAgent.match(/OS (\d+)_/); return m ? parseInt(m[1], 10) : 0; };
  const embedUrl = (url) => {
    const u = String(url);
    let m = u.match(/docs\.google\.com\/(document|spreadsheets|presentation)\/d\/([\w-]+)/);
    if (m) return `https://docs.google.com/${m[1]}/d/${m[2]}/preview`;
    m = u.match(/drive\.google\.com\/(?:file\/d\/|open\?id=)([\w-]+)/);
    if (m) return `https://drive.google.com/file/d/${m[1]}/preview`;
    m = u.match(/(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/);
    if (m) return `https://www.youtube.com/embed/${m[1]}?playsinline=1&rel=0`;
    m = u.match(/vimeo\.com\/(\d+)/);
    if (m) return `https://player.vimeo.com/video/${m[1]}`;
    if (/\.pdf(?:[?#]|$)/i.test(u)) return "https://docs.google.com/viewer?embedded=true&url=" + encodeURIComponent(u);
    return u;
  };
  const FRAME_OK = new Map();   // embed address -> check in progress
  const FRAME_DONE = new Map(); // embed address -> finished answer (true = panel, false = new tab)
  const checkFrame = (url) => {
    if (!/^https:/i.test(String(url))) return Promise.resolve(false);
    const e = embedUrl(url);
    if (!FRAME_OK.has(e)) {
      FRAME_OK.set(e, fetch("/api/public/frame-check?url=" + encodeURIComponent(e))
        .then((r) => (r.ok ? r.json() : { ok: false }))
        .then((j) => j.ok === true)
        .catch(() => false)
        .then((v) => { FRAME_DONE.set(e, v); return v; }));
    }
    return FRAME_OK.get(e);
  };
  // Opens a link outside our page: from LinkedIn/in-app browsers, in the phone's real browser; everywhere else, in a new tab.
  const openOutside = (url) => {
    const ua = navigator.userAgent;
    if (PANEL_APP && /iPhone|iPod/.test(ua) && uaIOSMajor() >= 17) { window.location.href = "x-safari-" + url; return; }
    if (PANEL_APP && /Android/i.test(ua)) {
      try {
        const u = new URL(url);
        window.location.href = `intent://${u.host}${u.pathname}${u.search}#Intent;scheme=${u.protocol.replace(":", "")};S.browser_fallback_url=${encodeURIComponent(url)};end`;
        return;
      } catch {}
    }
    window.open(url, "_blank", "noopener,noreferrer");
  };
  const WEB_CSS = ".lbm-web{position:fixed;inset:0;z-index:2147483647;background:rgba(15,23,42,0);transition:background .26s ease;}"
    + ".lbm-web.lbm-web-in{background:rgba(15,23,42,.38);}"
    + ".lbm-web-card{position:absolute;top:12px;right:12px;bottom:12px;left:12px;display:flex;flex-direction:column;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 20px 50px -12px rgba(15,23,42,.45);transform:translateY(calc(100% + 24px));transition:transform .26s ease;}"
    + ".lbm-web.lbm-web-in .lbm-web-card{transform:none;}"
    + ".lbm-web-bar{flex:0 0 auto;display:flex;align-items:center;gap:8px;height:48px;padding:0 8px 0 16px;background:#fff;border-bottom:1px solid #e5e7eb;font-family:Inter,-apple-system,BlinkMacSystemFont,sans-serif;}"
    + ".lbm-web-name{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:15px;font-weight:600;color:#111827;}"
    + ".lbm-web-btn{flex:0 0 auto;width:36px;height:36px;border:0;border-radius:50%;background:#f3f4f6;display:grid;place-items:center;cursor:pointer;padding:0;}"
    + ".lbm-web-frame{flex:1 1 auto;width:100%;border:0;background:#fff;}"
    + ".lbm-web-open #lb-stage *,.lbm-web-open #lb-mobile *{animation-play-state:paused !important;}";
  const showSheet = (url, label) => {
    const d = docRef;
    if (!d || !d.body) return openOutside(url);
    if (!d.getElementById("lbm-web-css")) { const st = d.createElement("style"); st.id = "lbm-web-css"; d.head.appendChild(st); }
    d.getElementById("lbm-web-css").textContent = WEB_CSS;
    d.querySelectorAll(".lbm-web").forEach((o) => o.remove());
    const w = d.createElement("div");
    w.className = "lbm-web";
    w.innerHTML = '<div class="lbm-web-card"><div class="lbm-web-bar"><span class="lbm-web-name"></span>'
      + '<button type="button" class="lbm-web-btn lbm-web-x" aria-label="Close"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 3l10 10M13 3L3 13" stroke="#111827" stroke-width="2.2" stroke-linecap="round"/></svg></button></div>'
      + '<iframe class="lbm-web-frame" sandbox="allow-scripts allow-same-origin allow-forms allow-presentation" allow="fullscreen; encrypted-media; picture-in-picture" referrerpolicy="no-referrer"></iframe></div>';
    w.querySelector(".lbm-web-name").textContent = label || "";
    w.querySelector(".lbm-web-frame").src = embedUrl(url);
    const close = () => { w.classList.remove("lbm-web-in"); setTimeout(() => { w.remove(); d.documentElement.classList.remove("lbm-web-open"); }, 260); };
    w.querySelector(".lbm-web-x").onclick = close;
    d.body.appendChild(w);
    d.documentElement.classList.add("lbm-web-open");
    requestAnimationFrame(() => requestAnimationFrame(() => w.classList.add("lbm-web-in")));
  };
  const openLink = (url, label) => {
    const u = String(url);
    if (!/^https?:/i.test(u)) { window.location.href = u; return; } // email, phone and other non-web links open normally
    if (!usePanel() || !(live || connecting || callOn)) { openOutside(u); return; } // computers, and whenever no call is running: new tab (from LinkedIn: the real browser)
    const e = embedUrl(u);
    if (FRAME_DONE.has(e)) { if (FRAME_DONE.get(e)) showSheet(u, label); else openOutside(u); return; }
    openOutside(u); checkFrame(u); // check not finished yet: open right away so the tap always works
  };
  // Title stays on one line; the grey text stays on two lines; past the smallest size the name is cut short at a whole word with "…".
  const fitDoc = (sheet, name) => {
    const t = sheet.querySelector(".lbm-doc-title"), d = sheet.querySelector(".lbm-doc-text"), w = sheet.querySelector(".lbm-doc-words"), row = sheet.querySelector(".lbm-doc-row");
    let f = 18; t.style.fontSize = f + "px";
    while (t.scrollWidth > t.clientWidth + 0.5 && f > 12) { f -= 0.25; t.style.fontSize = f + "px"; }
    const twoLines = () => d.scrollHeight <= parseFloat(getComputedStyle(d).lineHeight) * 2 + 1;
    let words = name.split(/\s+/), cut = false;
    const say = () => { d.textContent = words.join(" ") + (cut ? "…" : "") + " will save to your device as a PDF, then open."; };
    let g = 13; d.style.fontSize = g + "px"; say();
    while (!twoLines() && g > 11) { g -= 0.25; d.style.fontSize = g + "px"; }
    const trim = () => { while (words.length > 1 && /^(and|or|of|the|for|to|with|a|an|&|-|–)$/i.test(words[words.length - 1])) words = words.slice(0, -1); };
    while (!twoLines() && words.length > 1) { words = words.slice(0, -1); trim(); cut = true; say(); }
    // Checkbox line: the box keeps its size; the words grow or shrink so the line fits the buttons, a few pixels in from each edge.
    const cs = getComputedStyle(row);
    const room = row.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight) - row.querySelector(".lbm-doc-box").offsetWidth - parseFloat(cs.columnGap || 8);
    let h = 12.5; w.style.fontSize = h + "px"; h = h * room / w.scrollWidth; w.style.fontSize = h + "px";
    while (w.scrollWidth > room + 0.3 && h > 8) { h -= 0.05; w.style.fontSize = h + "px"; }
  };
  const docPopup = (s, l) => {
    s.querySelector(".lbm-doc-ov")?.remove();
    const ov = docRef.createElement("div"); ov.className = "lbm-doc-ov";
    ov.innerHTML = `<div class="lbm-doc-sheet" role="dialog" aria-modal="true" aria-label="Save a copy to your device?">
      <span class="lbm-doc-ic">${SAVE_IC}</span>
      <p class="lbm-doc-title">Save a copy to your device?</p>
      <p class="lbm-doc-text"></p>
      <button type="button" class="linkbot-button lbm-doc-save"><span>Save &amp; Open</span></button>
      <button type="button" class="linkbot-button lbm-doc-just"><span>Just Open</span></button>
      <div class="lbm-doc-row" role="checkbox" aria-checked="false" tabindex="0"><span class="lbm-doc-box">${CHECK}</span><span class="lbm-doc-words">Always do this. Never ask again.</span></div>
    </div>`;
    s.appendChild(ov);
    const row = ov.querySelector(".lbm-doc-row");
    const flip = () => { const on = !row.classList.contains("on"); row.classList.toggle("on", on); row.setAttribute("aria-checked", String(on)); };
    row.onclick = flip; row.onkeydown = (e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); flip(); } };
    const close = () => ov.remove();
    ov.onclick = (e) => { if (e.target === ov) close(); };
    ov.querySelector(".lbm-doc-save").onclick = () => {
      if (row.classList.contains("on")) { try { localStorage.setItem(ALWAYS, "1"); } catch {} }
      saveFile(l.url); openLink(l.url, l.label); close();
    };
    ov.querySelector(".lbm-doc-just").onclick = () => { openLink(l.url, l.label); close(); };
    fitDoc(ov.querySelector(".lbm-doc-sheet"), docName(l.label));
    docRef.fonts?.ready?.then(() => { if (ov.isConnected) fitDoc(ov.querySelector(".lbm-doc-sheet"), docName(l.label)); });
  };
  // "Temporarily Unavailable" popup: shown whenever a call can't start or connect. Replaces the plain browser warning, which never shows.
  // When the business hasn't paid, it says "Currently Unavailable" and that the business paused its assistant, so nobody thinks LinkBot has a bad connection.
  const unavailable = (forcePaused = false) => {
    const paused = forcePaused === true || view === "paused";
    const title = paused ? "Currently Unavailable" : "Temporarily Unavailable";
    for (const s of screens()) {
      s.querySelector(".lbm-doc-ov")?.remove();
      const ov = docRef.createElement("div"); ov.className = "lbm-doc-ov lbm-unav";
      ov.innerHTML = `<div class="lbm-doc-sheet" role="alertdialog" aria-modal="true" aria-label="${title}">
        <span class="lbm-doc-ic">${PHONE_OFF}</span>
        <p class="lbm-doc-title">${title}</p>
        <p class="lbm-doc-text"></p>
        <button type="button" class="linkbot-button lbm-doc-save"><span>OK</span></button>
      </div>`;
      ov.querySelector(".lbm-doc-text").textContent = paused
        ? (links.size > 0 ? "This business has paused its AI assistant, but your saved links still work below." : "This business has paused its AI assistant. Please check back later.")
        : (links.size > 0 ? "Calls can’t connect right now, but your saved links still work below." : "Calls can’t connect right now. Please try again later.");
      s.appendChild(ov);
      ov.querySelector(".lbm-doc-save").onclick = () => ov.remove();
      // Title on one line, message on two lines at most.
      const fit = () => {
        const t = ov.querySelector(".lbm-doc-title"), d = ov.querySelector(".lbm-doc-text");
        let f = 18; t.style.fontSize = f + "px";
        while (t.scrollWidth > t.clientWidth + 0.5 && f > 12) { f -= 0.25; t.style.fontSize = f + "px"; }
        let g = 13; d.style.fontSize = g + "px";
        while (d.scrollHeight > parseFloat(getComputedStyle(d).lineHeight) * 2 + 1 && g > 10) { g -= 0.25; d.style.fontSize = g + "px"; }
      };
      fit(); docRef.fonts?.ready?.then(() => { if (ov.isConnected) fit(); });
    }
  };
  // ---- Test views (for looking at every screen): normal, paused (hasn't paid), busy (all lines busy), dead-li / dead-none (dead end page) ----
  const CHAT_IC = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-8 w-8" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
  const SEND_IC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>';
  let view = "normal";
  const orbOf = (s) => s.querySelector(".text-center .grid.rounded-full");
  // 283: backup text chat (used when all live calls are busy). Runs the GoHighLevel text chat widget in its own hidden frame.
  const TEXT_WIDGET_ID = "6ad96ea9f56fd8562e7fd7ef";
  const BUSY_TEST = true; // TEST PAGE ONLY: every Start Call shows the "all live calls are busy" choice
  let tf = null, tBox = null, tSeen = new Set(), tLastSent = "", tTimer = 0, tObs = null;
  const chatDbg = (m) => { console.log("LinkBot chat: " + m); for (const s of screens()) { const d = s.querySelector(".lbm-chat-dbg"); if (d) d.textContent = m; } };
  const tVisible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const tRoot = () => tf?.contentDocument?.querySelector("chat-widget")?.shadowRoot || null;
  const T_JUNK = /^(\d{1,2}:\d{2}\s?(am|pm)?|just now|now|today|yesterday|sent|delivered|read|seen|typing\.*|\.\.\.)$/i;
  // 290: GoHighLevel's own notices and date/time stamps are never shown as messages.
  const T_SYS = /give us a minute to assign|chat closed due to|user inactivity|your chat has ended|please rate your experience|to start a new chat|^click here\.?$|^feedback$|powered by|^type a message/i;
  const T_DATE = /^(?:[a-z]{3,9}\.? \d{1,2}(?:, ?\d{4})?,? )?\d{1,2}:\d{2}(?::\d{2})?\s?(?:am|pm)?$/i;
  const tSent = new Set();
  const tSkip = (x) => T_JUNK.test(x) || T_SYS.test(x) || T_DATE.test(x) || tSent.has(x);
  const loadTextFrame = () => {
    if (tf) return;
    tf = document.createElement("iframe");
    tf.id = "lb-text-frame";
    tf.setAttribute("aria-hidden", "true");
    tf.tabIndex = -1;
    tf.style.cssText = "position:fixed;left:0;top:0;width:420px;height:700px;border:0;opacity:0;pointer-events:none;transform:translateX(-300vw);z-index:0;";
    tf.src = "/lb-widget-chat.html?t=1&w=" + TEXT_WIDGET_ID + "&r=" + Date.now();
    document.body.appendChild(tf);
  };
  // 287: GoHighLevel's text widget is built from nested parts, each with its own hidden inside, so every search goes through all of them.
  const deepAll = (root, sel) => { const out = []; const walk = (r) => { r.querySelectorAll(sel).forEach((e) => out.push(e)); r.querySelectorAll("*").forEach((e) => { if (e.shadowRoot) walk(e.shadowRoot); }); }; if (root) walk(root); return out; };
  const tLines = (root) => {
    const out = [];
    const walk = (node) => {
      for (const n of node.childNodes) {
        if (n.nodeType === 3) { const x = n.textContent.replace(/\s+/g, " ").trim(); if (x) out.push(x); }
        else if (n.nodeType === 1 && !/^(STYLE|SCRIPT|TEMPLATE)$/.test(n.tagName)) { if (n.shadowRoot) walk(n.shadowRoot); walk(n); }
      }
    };
    if (root) walk(root);
    return out;
  };
  const findTextBox = () => new Promise((done) => {
    const t0 = performance.now();
    const step = () => {
      const root = tRoot();
      if (root) {
        const box = deepAll(root, "textarea, input[type=text], input:not([type]), [contenteditable=true]").find(tVisible);
        if (box) return done(box);
        const form = deepAll(root, "input[type=email], input[type=tel]").find(tVisible);
        if (form) { chatDbg("Text widget is asking for contact details before chatting."); return done(null); }
        const opener = deepAll(root, "button, [role=button], [class*=launcher], [class*=bubble]").find((el) => tVisible(el) && !el.__lbOpened);
        if (opener) { opener.__lbOpened = true; opener.click(); chatDbg("Opening the text widget…"); }
      }
      if (performance.now() - t0 > 15000) {
        const r = tRoot();
        chatDbg("Not connected. inputs:" + deepAll(r, "textarea,input,[contenteditable=true]").length + " buttons:" + deepAll(r, "button,[role=button]").length + " words:" + (tLines(r).join(" ").slice(0, 80) || "none"));
        return done(null);
      }
      setTimeout(step, 250);
    };
    step();
  });
  // 287: AI messages type out word by word.
  const showAi = (text) => {
    for (const t of screens()) {
      const msgs = t.querySelector(".lbm-chat-msgs");
      const ai = docRef.createElement("p"); ai.className = "lbm-bubble lbm-ai"; msgs.appendChild(ai);
      const words = text.split(/(\s+)/);
      let i = 0;
      const tick = () => {
        ai.textContent += words.slice(i, i + 2).join(""); i += 2;
        msgs.scrollTop = msgs.scrollHeight;
        if (i < words.length) { setTimeout(tick, 70); return; }
        // 290: link buttons work like the call: a link the AI names (same list as the call) or a web address it writes out.
        const found = COVER.filter((c) => c.re.test(text)).map((c) => ({ label: c.label, url: c.url }));
        (text.match(/https?:\/\/[^\s)]+/g) || []).forEach((url) => { if (!found.some((f) => f.url === url)) found.push({ label: "Open Link", url }); });
        found.forEach((l) => {
          const b = docRef.createElement("button"); b.type = "button"; b.className = "linkbot-button w-full lbm-lbtn";
          b.innerHTML = `<span class="lbm-ic">${iconFor(l)}</span><span class="lbm-tx"></span><span class="lbm-ar">${ARROW}</span>`;
          b.querySelector(".lbm-tx").textContent = l.label; b.onclick = () => openLink(l.url, l.label);
          msgs.appendChild(b);
          requestAnimationFrame(() => fitLinkLabel(b.querySelector('.lbm-tx')));
          addLink(l.label, l.url);
        });
        msgs.scrollTop = msgs.scrollHeight;
      };
      tick();
    }
  };
  // 287: new words in the widget (its greeting and every reply) are checked every 0.7 seconds and shown once they stop changing.
  let tLastSig = "", tStable = 0;
  const watchTextReplies = () => {
    const root = tRoot(); if (!root || tObs) return;
    tLines(root).forEach((x) => tSeen.add(x));
    tObs = setInterval(() => {
      const fresh = tLines(root).filter((x) => !tSeen.has(x) && !tSkip(x));
      const sig = fresh.join("|");
      if (!fresh.length) { tLastSig = ""; tStable = 0; return; }
      if (sig !== tLastSig) { tLastSig = sig; tStable = 0; return; }
      if (++tStable < 1) return;
      fresh.forEach((x) => tSeen.add(x));
      tLastSig = ""; tStable = 0;
      chatDbg("Reply received.");
      showAi(fresh.join(" "));
    }, 500);
  };
  const startChat = () => {
    view = "busy";
    for (const s of screens()) {
      s.classList.add("lbm-busy");
      const o = orbOf(s); if (o) { o.__orig = o.__orig || o.innerHTML; o.innerHTML = CHAT_IC; }
      const msgs = s.querySelector(".lbm-chat-msgs"); msgs.textContent = "";
    }
    render();
    showAi("Hi. I can answer any question, guide you to the best option, send you links for anything you need, and get you connected. What can I help you with today?"); // 291: the AI greets first, typed out like every reply
    loadTextFrame();
    chatDbg("Connecting to the text chat…");
    findTextBox().then((box) => { tBox = box; if (box) { watchTextReplies(); chatDbg("Text chat ready."); startListening(); } });
  };
  // 289: send the way a person would. If the widget shows "To start a new chat, CLICK HERE", click it first.
  const tLabel = (b) => (b.getAttribute("aria-label") || "") + " " + (b.getAttribute("title") || "") + " " + String(b.className?.baseVal ?? b.className) + " " + (b.getAttribute("type") || "");
  const tEnter = (box, win) => ["keydown", "keypress", "keyup"].forEach((k) => box.dispatchEvent(new win.KeyboardEvent(k, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, composed: true, cancelable: true })));
  const tDoSend = (text) => {
    const root = tRoot(); const win = tf.contentWindow;
    const box = deepAll(root, "textarea, input[type=text], input:not([type]), [contenteditable=true]").find(tVisible) || tBox;
    if (!box) { chatDbg("Text chat is not ready yet."); return; }
    tBox = box; tLastSent = text; tSent.add(text.trim()); // 290
    box.focus();
    if (box.isContentEditable) box.textContent = text;
    else Object.getOwnPropertyDescriptor(box.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype, "value").set.call(box, text);
    box.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
    box.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
    // the send button is the right-most button on the same row as the box (never the microphone or attach buttons)
    const br = box.getBoundingClientRect();
    const row = deepAll(root, "button, [role=button]").filter((b) => { if (!tVisible(b)) return false; const r = b.getBoundingClientRect(); return r.bottom > br.top - 30 && r.top < br.bottom + 30; });
    const named = row.find((b) => /send|submit/i.test(tLabel(b)));
    const right = row.filter((b) => !/attach|file|clip|upload|mic|voice|record|emoji/i.test(tLabel(b))).sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0];
    let how = "";
    setTimeout(() => {
      if (named) { named.click(); how = "send button"; }
      else if (right) { right.click(); how = "right-most button"; }
      else { tEnter(box, win); how = "Enter key"; }
      setTimeout(() => {
        const left = box.isContentEditable ? box.textContent.trim() : String(box.value || "").trim();
        if (left && how === "Enter key") tEnter(box, win); // 292: never send twice
        const names = row.map((b) => (b.getAttribute("aria-label") || b.getAttribute("title") || (b.innerText || "").trim() || String(b.className?.baseVal ?? b.className) || "?").replace(/\s+/g, " ").trim().slice(0, 18)).join("|");
        const says = tLines(tRoot()).slice(-6).join(" | ").replace(/\s+/g, " ").slice(-140); // 291: what the widget itself is showing
        const dis = row.filter((b) => b.disabled || b.getAttribute("aria-disabled") === "true").length;
        chatDbg("Sent by " + how + ". Box emptied:" + (left ? "no (tried Enter)" : "yes") + " Box type:" + box.tagName.toLowerCase() + (box.disabled ? "(disabled)" : "") + " Disabled buttons:" + dis + " Widget says: " + (says || "nothing"));
      }, 1500);
      box.blur();
    }, 150);
  };
  const chatSend = (s, text) => {
    for (const t of screens()) {
      const msgs = t.querySelector(".lbm-chat-msgs");
      const me = docRef.createElement("p"); me.className = "lbm-bubble lbm-you"; me.textContent = text; msgs.appendChild(me);
      msgs.scrollTop = msgs.scrollHeight;
    }
    if (!tf || !tRoot()) { chatDbg("Text chat is not ready yet."); return; }
    const again = deepAll(tRoot(), "a, button, [role=button], span").find((el) => tVisible(el) && /^click here$/i.test((el.innerText || el.textContent || "").trim()));
    if (again) { again.click(); chatDbg("Starting a new chat…"); setTimeout(() => tDoSend(text), 1500); }
    else tDoSend(text);
    setTimeout(() => { // 288: report what the widget did with the message
      const r = tRoot();
      const all = tLines(r);
      const form = deepAll(r, "input[type=email], input[type=tel]").filter(tVisible).length;
      const extra = all.filter((x) => !tSeen.has(x) && x !== text).join(" ").replace(/\s+/g, " ").slice(0, 90);
      chatDbg("After send: in widget:" + (all.includes(text) ? "yes" : "no") + " contact form:" + (form ? "yes" : "no") + " new words:" + (extra || "none"));
    }, 9000);
  };
  // 290: talk instead of type, wherever the browser allows speech-to-text. Words show in the box while talking and send when they pause.
  let rec = null, recOn = false;
  const setChatInput = (t) => { for (const sc of screens()) { const i = sc.querySelector(".lbm-chat-in"); if (i) i.value = t; } };
  const startListening = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR || recOn) { if (!SR) chatDbg("Text chat ready. (Talking is not available in this browser.)"); return; }
    try {
      rec = new SR(); rec.continuous = true; rec.interimResults = true; rec.lang = navigator.language || "en-US";
      recOn = true;
      rec.onresult = (e) => {
        let interim = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) { const t = r[0].transcript.trim(); setChatInput(""); if (t) chatSend(null, t); }
          else interim += r[0].transcript;
        }
        if (interim) setChatInput(interim);
      };
      rec.onerror = (e) => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { recOn = false; chatDbg("Text chat ready. (Talking was not allowed.)"); } };
      rec.onend = () => { if (recOn && view === "busy") { try { rec.start(); } catch {} } };
      rec.start();
      for (const sc of screens()) { const i = sc.querySelector(".lbm-chat-in"); if (i) i.placeholder = "Talk or type your message…"; }
      chatDbg("Text chat ready. Listening.");
    } catch { recOn = false; }
  };
  // 283: "All live calls are busy" choice.
  const busyPrompt = () => {
    for (const s of screens()) {
      s.querySelector(".lbm-doc-ov")?.remove();
      const ov = docRef.createElement("div"); ov.className = "lbm-doc-ov lbm-unav lbm-busy-pop";
      ov.innerHTML = `<div class="lbm-doc-sheet" role="alertdialog" aria-modal="true" aria-label="Sorry, all live calls are busy.">
        <span class="lbm-doc-ic">${PHONE_OFF}</span>
        <p class="lbm-doc-title">Sorry, all live calls are busy.</p>
        <button type="button" class="linkbot-button lbm-doc-save"><span>Continue Chat With Text Only</span></button>
        <button type="button" class="linkbot-button lbm-doc-just"><span>Try Again Later</span></button>
      </div>`;
      s.appendChild(ov);
      const bt = ov.querySelector(".lbm-doc-title"); // 285: title always on one line, shrinks to fit
      const fitBusy = () => { let f = 18; bt.style.fontSize = f + "px"; while (bt.scrollWidth > bt.clientWidth + 0.5 && f > 10) { f -= 0.25; bt.style.fontSize = f + "px"; } };
      fitBusy(); docRef.fonts?.ready?.then(() => { if (ov.isConnected) fitBusy(); });
      ov.querySelector(".lbm-doc-save").onclick = () => { docRef.querySelectorAll(".lbm-doc-ov").forEach((o) => o.remove()); startChat(); };
      ov.querySelector(".lbm-doc-just").onclick = () => { docRef.querySelectorAll(".lbm-doc-ov").forEach((o) => o.remove()); };
    }
  };

  const DEAD_MSG = "This AI assistant opens only from Sarah’s LinkedIn. Please click the link in their profile to start a live call now.";
  const fitDead = (s) => {
    const e = s.querySelector(".lbm-dead-msg"); if (!e || !e.offsetParent) return;
    const lh = () => parseFloat(getComputedStyle(e).lineHeight);
    let lo = 10, hi = 14.01;
    for (let i = 0; i < 30; i++) { const m = (lo + hi) / 2; e.style.fontSize = m + "px"; if (Math.round(e.offsetHeight / lh()) <= 3) lo = m; else hi = m; }
    e.style.fontSize = Math.floor(lo * 10) / 10 + "px";
  };
  window.__lbmView = (v) => {
    view = v;
    for (const s of screens()) {
      s.querySelectorAll(".lbm-doc-ov").forEach((o) => o.remove());
      s.classList.remove("lbm-paused", "lbm-busy", "lbm-dead");
      const o = orbOf(s); if (o && o.__orig) o.innerHTML = o.__orig;
      if (v === "paused") s.classList.add("lbm-paused");
      if (v === "dead-li" || v === "dead-none" || v === "cancelled") {
        s.classList.add("lbm-dead");
        const btns = s.querySelector(".lbm-dead-btns");
        btns.innerHTML = v === "cancelled"
          ? '<a class="linkbot-button" href="https://linkbot.now"><span>Get Your Own LinkBot</span></a>'
          : v === "dead-li"
          ? '<a class="linkbot-button" href="https://www.linkedin.com/"><span>Go to Sarah’s LinkedIn</span></a><a class="linkbot-button lbm-white" href="https://linkbot.now"><span>Get Your Own LinkBot</span></a>'
          : '<a class="linkbot-button" href="https://linkbot.now"><span>Get Your Own LinkBot</span></a>';
        btns.querySelectorAll("a").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); window.top.location.href = a.href; }));
        // Text size is set from the dead end message, so the cancelled line matches it.
        const sizeText = () => { const m = s.querySelector(".lbm-dead-msg"); m.textContent = DEAD_MSG; fitDead(s); if (v === "cancelled") m.textContent = "This assistant is no longer available."; };
        sizeText(); docRef.fonts?.ready?.then(sizeText);
      }
    }
    if (v === "paused") unavailable();
    render();
    console.log("LinkBot mock-up: showing the " + ({ normal: "normal", paused: "hasn't paid", busy: "all lines busy (tap Start Call)", "dead-li": "dead end page with LinkedIn saved", "dead-none": "dead end page with no LinkedIn", cancelled: "account cancelled" }[v] || v) + " screen.");
  };
  // 222: Videos only play after the call. Tapping a video button during a call fades its title to "End Call To Play Video" for 2 seconds, then back.
  const isVideo = (l) => /(?:youtube\.com\/(?:watch|shorts\/|live\/|embed\/)|youtu\.be\/|vimeo\.com\/|loom\.com\/(?:share|embed)\/|wistia\.(?:com|net)\/|\.(?:mp4|mov|m4v|webm)(?:[?#]|$))/i.test(String(l.url));
  // 229: During a call, only safe links open (in the panel). Videos fade to "End Call To Play Video"; risky links fade to "Open Link After Call". Both open normally after the call.
  const RISKY_RE = /(?:\/(?:log-?in|sign-?in|sign-?up|register|account|my-account|checkout|cart|pay|payment|payments|billing|portal|dashboard|auth|oauth)(?:[\/?#.]|$))|payment-link|buy\.stripe|checkout\.|^https?:\/\/(?:[^\/]*\.)?(?:linkedin\.com|lnkd\.in|facebook\.com|fb\.com|instagram\.com|twitter\.com|x\.com|tiktok\.com|threads\.net|pinterest\.com|reddit\.com|snapchat\.com|paypal\.com|paypal\.me|stripe\.com|squareup\.com|square\.link|venmo\.com|cash\.app|amazon\.com|amzn\.to|apps\.apple\.com|play\.google\.com|bit\.ly|tinyurl\.com)(?:[\/?#:]|$)/i;
  const holdLink = (s, b, l) => {
    if (!s.classList.contains("lbm-on")) return false;
    const u = String(l.url);
    let msg = "";
    if (isVideo(l)) msg = "End Call To Play Video";
    else if (usePanel() && (!/^https:/i.test(u) || RISKY_RE.test(u) || FRAME_DONE.get(embedUrl(u)) !== true)) msg = "Open Link After Call";
    if (!msg) return false;
    const tx = b.querySelector(".lbm-tx");
    if (!tx || b.__lbHold) return true;
    b.__lbHold = true;
    tx.style.transition = "opacity .25s ease";
    const swap = (text, then) => {
      tx.style.opacity = "0";
      setTimeout(() => { tx.textContent = text; tx.style.opacity = "1"; if (then) then(); }, 250);
    };
    swap(msg, () => setTimeout(() => swap(l.label, () => setTimeout(() => {
      b.__lbHold = false; tx.style.transition = ""; tx.style.opacity = "";
    }, 250)), 2000));
    return true;
  };
  const tapLink = (s, l) => {
    if (!isDoc(l)) return openLink(l.url, l.label);
    if (alwaysSave()) { saveFile(l.url); openLink(l.url, l.label); return; }
    docPopup(s, l);
  };

  try { if (navigator.audioSession) navigator.audioSession.type = "play-and-record"; } catch {} // 280: iPhone plays the AI through the loud speaker
  // ---- Ringing sound while the call connects (stops the moment the AI starts talking) ----
  let ringCtx = null, ringGain = null, ringTimer = 0, ringing = false;
  const ringOnce = () => {
    if (!ringing || !ringCtx) return;
    const t = ringCtx.currentTime;
    const g = ringCtx.createGain(); g.connect(ringCtx.destination);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.0336, t + 0.03); g.gain.setValueAtTime(0.0336, t + 1.97); g.gain.linearRampToValueAtTime(0, t + 2);
    [440, 480].forEach((f) => { const o = ringCtx.createOscillator(); o.frequency.value = f; o.connect(g); o.start(t); o.stop(t + 2); });
    ringGain = g;
    ringTimer = setTimeout(ringOnce, 6000);
  };
  const startRing = () => { try { ringCtx = ringCtx || new (window.AudioContext || window.webkitAudioContext)(); ringCtx.resume(); ringing = true; clearTimeout(ringTimer); ringOnce(); } catch {} };
  const stopRing = () => { if (!ringing) return; ringing = false; clearTimeout(ringTimer); try { ringGain.gain.cancelScheduledValues(ringCtx.currentTime); ringGain.gain.setValueAtTime(0, ringCtx.currentTime); } catch {} const ctx = ringCtx; ringCtx = null; ringGain = null; setTimeout(() => { try { ctx && ctx.close(); } catch {} }, 60); }; // 223: shut the ring player off completely so the AI's voice plays at full volume
  // Hang up the widget's call (used when End Call is tapped while it is still ringing).
  let cancelUntil = 0;
  let sawOff = true; // 271: true once the widget has been seen with no live call after a hang-up
  let resetting = false; // 272: true while the widget is being taken out of its "call ended" state
  const orbCls = () => widget()?.shadowRoot?.querySelector(".voice-orb-widget")?.className || "";
  const ENDED_RE = /is-(ended|complete|completed|success|finished)/;
  let callSeq = 0; // 259: each call gets its own number so an old call's end signal can never end a new call
  let endedAt = 0; // 263: when the last call ended
  // 266: Start Call is not ready until the previous call is fully off (never longer than 10 seconds) plus 1 second.
  const startBlocked = () => !live && !connecting && ((isLive() && performance.now() - endedAt < 10000) || (endedAt && performance.now() - endedAt < 1000));
  setInterval(() => {
    const d = document.getElementById("lbm-frame")?.contentDocument;
    if (!d) return;
    const off = startBlocked();
    d.querySelectorAll(".lbm-call").forEach((b) => { if (off) b.setAttribute("aria-disabled", "true"); else b.removeAttribute("aria-disabled"); });
  }, 150);
  // 240: "Temporarily Unavailable" only when the call truly never connected. A connected call (AI just slow to talk) never shows it; the page keeps waiting quietly.
  const connectTimeout = () => {
    if (!connecting) return;
    if (live || isLive()) { connectTimer = setTimeout(connectTimeout, 5000); return; }
    connecting = false; callOn = false; render(); unavailable();
  };
  // 240: close the "Temporarily Unavailable" popup the moment the call comes through.
  const clearUnavailable = () => { try { docRef?.querySelectorAll(".lbm-unav").forEach((o) => o.remove()); } catch {} };
  const hangUp = () => { try { const c = ctrl(); if (c && typeof c.handleEndVoiceCall === "function") c.handleEndVoiceCall(); else press(); } catch {} };
  // 234: first name only, possessive: names ending in S get only an apostrophe (JAMES’), all others get ’S (JENNIFER’S).
  const possessive = (name) => { const n = String(name).trim(); return /s$/i.test(n) ? n + "’" : n + "’S"; };
  const CALLER_NAME = possessive("JENNIFER"); // shown in blue on the calling screen (reads "Jennifer’s Live Receptionist")

  // ---- Drawing into the phone screen ----
  let suppress = false, talking = false, fresh = false;
  const freshStart = () => { if (!fresh) return; fresh = false; lines.length = 0; byItem.clear(); callLinks.clear(); }; // saved links stay; new ones are added to them
  // 268: Start Call clears the previous conversation from the screen right away; pieces of the previous call's lines never show on the new call.
  let oldKeys = new Set();
  const clearForNewCall = () => { oldKeys = new Set(byItem.keys()); lines.length = 0; byItem.clear(); callLinks.clear(); };
  let docRef = null, live = false, wanted = false, connecting = false, tapAt = 0, connectTimer = 0;
  let aiSpoke = false; // 4K2: the AI has said something during this call
  const droppedEarly = () => !aiSpoke && !(cancelUntil && performance.now() < cancelUntil); // 4K2: ended before the AI spoke and not by End Call
  let callOn = false; // 281: a call is on screen from Start Call until it really ends
  function screens() {
    if (!docRef) return [];
    return [...docRef.querySelectorAll("#lb-stage .flex-col.bg-surface.pt-16, #lb-mobile .flex-col.bg-surface.pt-16")];
  }
  // "Scroll for N more links": shown before they scroll, counting buttons not fully in view; fades out once they scroll.
  function updateMore(s) {
    const w = s.querySelector(".lbm-links-wrap"); const sc = s.querySelector(".lbm-links-scroll");
    if (!w || !sc || !s.classList.contains("lbm-ended")) { w?.classList.remove("lbm-has-more"); return; }
    const wr = w.getBoundingClientRect(); const zoneTop = wr.bottom - 44; // room for the pill under the last full button
    let lastFull = wr.top; let hidden = 0; let peekTop = null;
    [...sc.children].forEach((b) => {
      const r = b.getBoundingClientRect();
      if (r.bottom <= zoneTop + 1 && r.top >= wr.top - 1) lastFull = Math.max(lastFull, r.bottom);
      else if (r.bottom > zoneTop + 1) { hidden++; if (peekTop === null && r.top < wr.bottom) peekTop = r.top; }
    });
    const more = sc.scrollHeight - sc.clientHeight - sc.scrollTop > 2 && hidden > 0;
    w.classList.toggle("lbm-has-more", more);
    if (!more) return;
    const pill = w.querySelector(".lbm-more-pill");
    pill.querySelector("span").textContent = "Scroll for " + hidden + " more link" + (hidden === 1 ? "" : "s");
    // The pill sits centered in the space between the last full button and the bottom of the box.
    // Screen measurements are divided by the phone's zoom so the pill and fade land in the right spot at any window size.
    const k = wr.height / w.offsetHeight || 1;
    const top = (lastFull - wr.top) / k + ((wr.bottom - lastFull) / k - pill.offsetHeight) / 2;
    pill.style.top = Math.round(Math.min(top, w.offsetHeight - pill.offsetHeight - 4)) + "px";
    sc.style.setProperty("--lbm-fade", Math.max(0, (lastFull - sc.getBoundingClientRect().top) / k) + "px");
  }
  const linkLabelFits = new WeakMap();
  function fitLinkLabel(tx) {
    if (!tx) return;
    const b = tx.closest('button');
    const view = tx.ownerDocument.defaultView;
    if (!b || !view || b.__lbHold || b.hasAttribute('data-hold')) return;
    let state = linkLabelFits.get(tx);
    if (!state) {
      state = { pending: false, observer: null };
      linkLabelFits.set(tx, state);
      // Watch authored layout widths, not the phone's visual zoom/transform.
      if (view.ResizeObserver) {
        state.observer = new view.ResizeObserver(() => {
          if (!tx.isConnected) { state.observer.disconnect(); return; }
          fitLinkLabel(tx);
        });
        state.observer.observe(b);
        state.observer.observe(tx);
      }
      tx.ownerDocument.fonts?.ready?.then(() => fitLinkLabel(tx));
    }
    if (state.pending) return;
    state.pending = true;
    const normal = () => { tx.style.fontSize = ''; };
    const width = () => {
      if (!tx.isConnected || !tx.getClientRects().length) return 0;
      const style = view.getComputedStyle(tx);
      if (style.visibility !== 'visible' || Number(style.opacity) === 0) return 0;
      return tx.clientWidth;
    };
    view.requestAnimationFrame(() => {
      const first = width(), buttonWidth = b.clientWidth;
      view.requestAnimationFrame(() => {
        state.pending = false;
        if (!tx.isConnected) { state.observer?.disconnect(); return; }
        if (b.__lbHold || b.hasAttribute('data-hold')) return;
        const available = width();
        const entering = b.getAnimations?.().some(a => a.playState === 'running' && Number.isFinite(a.effect?.getComputedTiming().endTime));
        if (!available || !buttonWidth) { normal(); return; }
        if (available !== first || buttonWidth !== b.clientWidth || entering) {
          normal(); fitLinkLabel(tx); return;
        }
        normal();
        const base = parseFloat(view.getComputedStyle(tx).fontSize);
        if (!Number.isFinite(base) || base <= 0) return;
        const range = tx.ownerDocument.createRange();
        range.selectNodeContents(tx);
        // Both rectangles share the same phone zoom; their ratio cancels it.
        const measured = () => {
          const box = tx.getBoundingClientRect().width;
          const text = range.getBoundingClientRect().width;
          return box > 0 && text > 0 ? text * available / box : NaN;
        };
        const textWidth = measured();
        if (!Number.isFinite(textWidth) || textWidth <= available) return;
        let low = base * 0.75, high = base;
        for (let i = 0; i < 16; i++) {
          tx.style.fontSize = ((low + high) / 2) + 'px';
          const text = measured();
          if (!Number.isFinite(text)) { normal(); return; }
          if (text > available) high = (low + high) / 2; else low = (low + high) / 2;
        }
        tx.style.fontSize = Math.max(base * 0.75, low) + 'px';
      });
    });
  }
  window.addEventListener('resize', () => requestAnimationFrame(() => docRef?.querySelectorAll('.lbm-lbtn .lbm-tx').forEach(fitLinkLabel)));
  function render() {
    if (!connecting) stopRing();
    // "In the call" only once the assistant is actually talking; until then the home screen stays exactly as it was.
    const inCall = callOn && talking; // 281
    const calling = connecting && !talking;
    for (const s of screens()) {
      s.classList.toggle("lbm-calling", calling);
      const eb = s.querySelector(".eyebrow");
      if (eb) { eb.__orig = eb.__orig || eb.textContent; const want = calling ? CALLER_NAME : eb.__orig; if (eb.textContent !== want) eb.textContent = want; }
      const inner = s.querySelector(".lbm-captions-inner");
      if (inner) {
        // Update in place: one element per spoken turn; only new turns animate in.
        const shown = lines.filter((l) => clean(l.text)).slice(-12);
        const keep = new Set(shown);
        [...inner.children].forEach((el) => { if (!keep.has(el.__line)) el.remove(); });
        shown.forEach((l) => {
          let el = [...inner.children].find((c) => c.__line === l);
          if (!el) {
            el = docRef.createElement("p");
            el.__line = l;
            el.className = "lbm-bubble " + (l.who === "you" ? "lbm-you" : "lbm-ai");
            inner.appendChild(el);
          }
          const txt = l.who === "you" ? fmtYou(l, asks(pretty(clean(l.text)))) : asks(pretty(clean(l.text))); // caller phone numbers and emails written properly
          if (el.textContent !== txt) el.textContent = txt;
        });
      }
      const box = s.querySelector(".lbm-links");
      const all = [...links.values()].reverse(); // newest links at the top
      const shownLinks = inCall ? all.filter((l) => callLinks.has(l.label)).slice(0, 1) : all; // during a call: the newest link the assistant gave on this call, even if it was saved before
      const sig = shownLinks.map((l) => l.label).join("|");
      if (box && box.dataset.sig !== sig) {
        box.dataset.sig = sig;
        const sc = box.querySelector(".lbm-links-scroll");
        sc.textContent = "";
        sc.scrollTop = 0; box.querySelector(".lbm-links-wrap")?.classList.remove("lbm-scrolled"); // new list: show the count again
        shownLinks.forEach((l) => {
          const b = docRef.createElement("button");
          b.type = "button"; b.className = "linkbot-button w-full lbm-lbtn";
          b.innerHTML = isDoc(l) ? `<span class="lbm-ic">${FILE_IC}</span><span class="lbm-tx"></span><span class="lbm-ar">${DL_IC}</span>` // document links: file icon + download arrow
            : `<span class="lbm-ic">${iconFor(l)}</span><span class="lbm-tx"></span><span class="lbm-ar">${ARROW}</span>`;
          b.querySelector(".lbm-tx").textContent = l.label;
          if (usePanel()) checkFrame(l.url); // checks the link the moment its button appears, so a tap opens it instantly
          b.onclick = () => { if (holdLink(s, b, l)) return; tapLink(s, l); };
          sc.appendChild(b);
        });
      }
      s.classList.toggle("lbm-on", inCall);
      s.classList.toggle("lbm-ended", !inCall && links.size > 0);
      s.classList.toggle("lbm-has-links", links.size > 0);
      s.classList.toggle("lbm-has-links", links.size > 0);
      const btn = s.querySelector(".lbm-call");
      if (btn) {
        const mode = connecting ? "connecting" : (live || callOn) ? "live" : "idle"; // 281
        if (btn.dataset.mode !== mode) {
          btn.dataset.mode = mode;
          btn.classList.toggle("end-call-button", mode !== "idle");
          btn.innerHTML = mode !== "idle" ? `<span class="flex items-center gap-2">${PHONE_OFF} End Call</span>`
            : `<span class="flex items-center gap-2">${MIC} Start Call</span>`;
        }
      }
      requestAnimationFrame(() => { s.querySelectorAll('.lbm-lbtn .lbm-tx').forEach(tx => { if (!tx.closest('button').__lbHold) fitLinkLabel(tx); }); updateMore(s); requestAnimationFrame(() => updateMore(s)); });
      const al = s.querySelector(".demo-audio-lines");
      al?.classList.toggle("demo-audio-lines-active", talking && callOn); // 281
      // After the call the audio lines row is removed completely, so the links sit right under the subtitle.
      if (al) al.style.setProperty("display", s.classList.contains("lbm-ended") ? "none" : "", s.classList.contains("lbm-ended") ? "important" : "");
    }
  }
  loadLinks();
  frame.addEventListener("load", () => {
    docRef = frame.contentDocument;
    for (const s of screens()) {
      s.classList.add("lbm-screen");
      s.querySelector("p.mt-3")?.classList.add("lbm-sub");
      const cn = docRef.createElement("p"); cn.className = "lbm-callname"; cn.textContent = "Live Receptionist";
      const cs = docRef.createElement("p"); cs.className = "lbm-callstate"; cs.textContent = "calling…";
      s.querySelector("h3")?.after(cn, cs);
      const audio = s.querySelector(".demo-audio-lines");
      const cap = docRef.createElement("div"); cap.className = "lbm-captions";
      const inner = docRef.createElement("div"); inner.className = "lbm-captions-inner"; cap.appendChild(inner);
      audio?.after(cap);
      const wrap = s.querySelector(".relative.mt-auto");
      const lk = docRef.createElement("div"); lk.className = "lbm-links";
      const touch = !(docRef.defaultView.matchMedia && docRef.defaultView.matchMedia("(hover: hover) and (pointer: fine)").matches);
      lk.innerHTML = '<div class="lbm-links-head"><p class="lbm-links-label">LINKS SHARED WITH YOU</p><p class="lbm-links-hint"></p></div><div class="lbm-links-wrap"><div class="lbm-links-scroll"></div><button type="button" class="lbm-more-pill"><span></span>' + CHEV + '</button></div>';
      lk.querySelector(".lbm-links-hint").textContent = (touch ? "Tap" : "Click") + " to open and view each link.";
      wrap?.before(lk);
      const scr = lk.querySelector(".lbm-links-scroll");
      scr.addEventListener("scroll", () => {
        // The count shows at the top; once they scroll down, the pill and the bottom fade go away, and they come back when they scroll back to the top.
        lk.querySelector(".lbm-links-wrap").classList.toggle("lbm-scrolled", scr.scrollTop > 2);
        updateMore(s);
      }, { passive: true });
      lk.querySelector(".lbm-more-pill").onclick = () => scr.scrollBy({ top: 53, behavior: "smooth" });
      // After the call, scrolling anywhere on the phone screen scrolls the links, not only when the finger or mouse is on them.
      const fwd = (dy) => {
        if (!s.classList.contains("lbm-ended") || s.querySelector(".lbm-doc-ov") || s.classList.contains("lbm-busy") || s.classList.contains("lbm-dead")) return false;
        const k = s.getBoundingClientRect().height / s.offsetHeight || 1;
        scr.scrollTop += dy / k;
        return true;
      };
      // Scrolling is slowed down so the links move at a calm, even speed, inside the box or anywhere else on the phone.
      s.addEventListener("wheel", (e) => {
        if (fwd((e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY) * 0.5)) e.preventDefault();
      }, { passive: false });
      let touchY = null;
      s.addEventListener("touchstart", (e) => { touchY = scr.contains(e.target) ? null : e.touches[0].clientY; }, { passive: true });
      s.addEventListener("touchmove", (e) => {
        if (touchY === null) return;
        const y = e.touches[0].clientY;
        if (fwd(touchY - y)) { touchY = y; e.preventDefault(); }
      }, { passive: false });
      docRef.defaultView.addEventListener("resize", () => updateMore(s));
      // 225: real phones only: shorter subtitle that always stays on one line (never bigger than now; shrinks only if a phone is too narrow).
      if (s.closest("#lb-mobile, #lb-stage")) {
        const sub = s.querySelector(":scope > p.mt-3");
        if (sub) {
          sub.textContent = "I can help with anything you need.";
          const fitSub = () => {
            sub.style.fontSize = "";
            let f = parseFloat(getComputedStyle(sub).fontSize) || 15;
            while (sub.scrollWidth > sub.clientWidth + 0.5 && f > 9) { f -= 0.25; sub.style.fontSize = f + "px"; }
          };
          fitSub();
          docRef.defaultView.addEventListener("resize", fitSub);
          docRef.fonts?.ready?.then(fitSub);
        }
      }
      const chat = docRef.createElement("div"); chat.className = "lbm-chat";
      chat.innerHTML = '<div class="lbm-chat-note">All lines are busy, so let’s chat here instead.</div><div class="lbm-chat-msgs"></div><form class="lbm-chat-form"><input class="lbm-chat-in" type="text" placeholder="Type your message…" aria-label="Type your message"><button class="lbm-chat-send" type="submit" aria-label="Send">' + SEND_IC + '</button></form><div class="lbm-chat-dbg"></div>';
      wrap?.before(chat);
      chat.querySelector("form").addEventListener("submit", (e) => { e.preventDefault(); const i = chat.querySelector(".lbm-chat-in"); const t = i.value.trim(); if (!t) return; i.value = ""; chatSend(s, t); });
      const dead = docRef.createElement("div"); dead.className = "lbm-dead-pg";
      dead.innerHTML = '<p class="lbm-dead-msg">This AI assistant opens only from Sarah’s LinkedIn. Please click the link in their profile to start a live call now.</p><div class="lbm-dead-btns"></div>';
      s.appendChild(dead);
      const btn = wrap?.querySelector("button");
      if (btn) {
        btn.classList.add("lbm-call");
        btn.onclick = () => {
          if (view === "paused") { unavailable(); return; } // business hasn't paid: popup, no call
          if (view === "busy") { startChat(); return; } // all lines busy: switch to the typing chat
          if (BUSY_TEST && !live && !connecting && !callOn) { busyPrompt(); return; } // 283: test page: every Start Call shows the busy choice
          if (connecting && performance.now() - tapAt < 1000) return; // 234: ignore a second click in the first second after Start Call (double click never hangs up)
          if (startBlocked()) return; // 263/265/266: previous call not fully off yet: ignore the tap
          if (connecting) { clearTimeout(connectTimer); cancelUntil = performance.now() + 15000; sawOff = false; hangUp(); endNow(); return; } // End Call while still ringing: hang up right away
          if (live || callOn) { cancelUntil = performance.now() + 15000; sawOff = false; hangUp(); endNow(); return; } // 237: End Call during a live call always hangs up and always ends the call on screen
          aiSpoke = false; // 4K2: new call, the AI has not spoken yet
          if (!live && !connecting && ENDED_RE.test(orbCls())) {
            // 272: the widget is still in its "call ended" state: reset it to idle, then start a real new call.
            talking = false; fresh = true; wanted = true;
            clearForNewCall();
            connecting = true; tapAt = performance.now(); callOn = true; // 281
            clearTimeout(connectTimer);
            cancelUntil = 0;
            callSeq++; suppress = false;
            resetting = true;
            startRing();
            render();
            press(); // leaves the ended state
            const t0 = performance.now();
            const waitIdle = () => {
              if (!connecting) { resetting = false; return; } // End Call was tapped while waiting
              const c = orbCls();
              const ready = /is-idle/.test(c) || (!ENDED_RE.test(c) && !isLive());
              if (!ready && performance.now() - t0 < 15000) { setTimeout(waitIdle, 150); return; }
              setTimeout(() => {
                if (!connecting) { resetting = false; return; }
                resetting = false;
                connecting = false; press(); connecting = true; // same as 224: this always STARTS the call
                clearTimeout(connectTimer);
                connectTimer = setTimeout(connectTimeout, 45000);
              }, 400);
            };
            setTimeout(waitIdle, 300);
            return;
          }
          if (!live && !connecting && !widget()?.shadowRoot?.querySelector(".voice-orb-stage, .lc_text-widget--horizontal")) {
            // 224: the call widget is still loading (common right after the page opens): ring now and start the call the moment it is ready
            talking = false; fresh = true; wanted = true;
            clearForNewCall(); // 268
            connecting = true; tapAt = performance.now(); callOn = true; // 281
            clearTimeout(connectTimer);
            cancelUntil = 0;
            callSeq++; suppress = false; // 259: new call: forget the previous call's end signal and suppress flag
            startRing();
            render();
            const t0 = performance.now();
            const waitForWidget = () => {
              if (!connecting) return; // End Call was tapped while waiting
              connecting = false; const started = press(); connecting = true; // 234: the wait always STARTS the call (never read as End Call)
              if (started) {
                clearTimeout(connectTimer);
                connectTimer = setTimeout(connectTimeout, 45000);
                return;
              }
              if (performance.now() - t0 > 12000) { connecting = false; callOn = false; stopRing(); render(); unavailable(); return; }
              setTimeout(waitForWidget, 250);
            };
            waitForWidget();
            return;
          }
          if (!press()) { unavailable(); return; }
          wanted = !live && !connecting;
          if (wanted) {
            talking = false; fresh = true;
            clearForNewCall(); // 268
            connecting = true; tapAt = performance.now(); callOn = true; // 281
            clearTimeout(connectTimer);
            connectTimer = setTimeout(connectTimeout, 45000);
            cancelUntil = 0;
            callSeq++; suppress = false; // 259: new call: forget the previous call's end signal and suppress flag
            startRing();
          } else { connecting = false; }
          render();
        };
      }
    }
    render();
  });
  // 227: AI voice at double volume through a booster with a limiter. The original audio keeps playing until the booster is confirmed working.
  let boostCtx = null, boostTimer = 0;
  let boostedEls = [];
  const boostSeen = new WeakSet();
  const allAudio = () => {
    const out = [...document.querySelectorAll("audio")];
    const walk = (root) => { if (!root) return; root.querySelectorAll("*").forEach((el) => { if (el.tagName === "AUDIO") out.push(el); if (el.shadowRoot) walk(el.shadowRoot); }); };
    document.querySelectorAll("chat-widget").forEach((w) => walk(w.shadowRoot));
    return out;
  };
  const boostOne = (a) => {
    const stream = a.srcObject;
    if (!boostCtx || boostSeen.has(a) || !(stream instanceof MediaStream) || !stream.getAudioTracks().length) return;
    boostSeen.add(a);
    try {
      const src = boostCtx.createMediaStreamSource(stream);
      const gain = boostCtx.createGain(); gain.gain.value = 4;
      const limiter = boostCtx.createDynamicsCompressor();
      limiter.threshold.value = -3; limiter.knee.value = 0; limiter.ratio.value = 20; limiter.attack.value = 0.003; limiter.release.value = 0.1;
      const probe = boostCtx.createAnalyser(); probe.fftSize = 512;
      src.connect(probe);
      const buf = new Uint8Array(probe.fftSize);
      let tries = 0;
      const confirm = () => {
        if (!boostCtx) return;
        probe.getByteTimeDomainData(buf);
        if (buf.some((v) => Math.abs(v - 128) > 2)) {
          src.connect(gain); gain.connect(limiter); limiter.connect(boostCtx.destination);
          a.muted = true; boostedEls.push(a);
          return;
        }
        if (++tries < 300) setTimeout(confirm, 100); // waits up to 30 seconds for the AI's voice
      };
      confirm();
    } catch {}
  };
  const stopBoost = () => {
    clearInterval(boostTimer); boostTimer = 0;
    boostedEls.forEach((a) => { try { a.muted = false; } catch {} });
    boostedEls = [];
    const ctx = boostCtx; boostCtx = null;
    try { ctx && ctx.close(); } catch {}
  };
  const startBoost = () => {
    try {
      stopBoost();
      boostCtx = new (window.AudioContext || window.webkitAudioContext)();
      boostCtx.resume();
      boostTimer = setInterval(() => {
        if (!live && !connecting) { stopBoost(); return; }
        if (!boostedEls.length) allAudio().forEach(boostOne); // stop scanning once the AI's audio is boosted
      }, 400);
    } catch {}
  };
  function endNow() {
    if (!live && !connecting && !callOn) return; // 281
    const early = droppedEarly(); // 4K2
    callOn = false; // 281
    suppress = true; live = false; connecting = false; talking = false; endedAt = performance.now(); // 263
    freshWidget(); // 278
    console.log("LinkBot mock-up: The assistant hung up.", new Date().toLocaleTimeString());
    render();
    if (early) unavailable(true); // 4K2
  }
  window.addEventListener("linkbot:agent-call-ended", endNow);
  let liveWidget = null;
  let endSeen = 0; // 235: when the call system first looked ended
  setInterval(() => {
    if (resetting) return; // 272: the widget is being reset; the screen keeps ringing
    let now = isLive();
    if (!now) sawOff = true; // 271
    if (now && sawOff && cancelUntil && performance.now() < cancelUntil) { cancelUntil = 0; hangUp(); suppress = true; } // the call they ended came through late (after it was fully off): hang it up
    if (suppress) { if (!now || widget() !== liveWidget) suppress = false; now = false; }
    if (!now && connecting && callOn && ENDED_RE.test(orbCls()) && droppedEarly()) { endNow(); return; }
    if (now === live) { endSeen = 0; return; }
    // 235: a call only counts as ended after the call system has looked ended for 1.5 seconds in a row (a split-second blip never ends the call on screen).
    if (!now && live && !suppress) { if (!endSeen) endSeen = performance.now(); if (performance.now() - endSeen < 1500) return; }
    endSeen = 0;
    if (now) clearUnavailable(); // 240: the call is live, so close any "Temporarily Unavailable" popup
    if (now) { liveWidget = widget(); if (tapAt) console.log("LinkBot mock-up: call connected " + Math.round(performance.now() - tapAt) + " ms after tapping Start Call."); }
    else { const early = (live || callOn) && droppedEarly(); /* 4K2 */ connecting = false; talking = false; callOn = false; freshWidget(); /* 278 */ endedAt = performance.now(); /* 263 */ console.log("LinkBot mock-up: call ended.", widget() === liveWidget ? "Same assistant widget (the call itself was ended)." : "The assistant's widget was replaced by the LinkBot page.", new Date().toLocaleTimeString()); if (early) { live = now; render(); unavailable(true); return; } /* 4K2 */ }
    live = now; render();
  }, 200);
  console.log("LinkBot mock-up loaded (version 44: runs the widget already on this page)."); 
})();