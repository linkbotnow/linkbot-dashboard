(() => {
  // LinkBot saved links settings: folders, rename, delete and rearrange for the links saved on the phone's home screen.
  // Runs on top of /livedemo-overlay.js and never changes it. Everything is kept in this browser only, per business page.
  if (window.__lbFolders) return;
  window.__lbFolders = true;

  const ORG = "linkbot-org:" + location.hostname + location.pathname;
  const load = () => {
    let o = null;
    try { o = JSON.parse(localStorage.getItem(ORG) || "null"); } catch {}
    o = o && typeof o === "object" ? o : {};
    return {
      folders: Array.isArray(o.folders) ? o.folders.filter((f) => f && f.id && Array.isArray(f.links)) : [],
      names: o.names && typeof o.names === "object" ? o.names : {},
      deleted: Array.isArray(o.deleted) ? o.deleted : [],
      order: Array.isArray(o.order) ? o.order : [],
    };
  };
  const org = load();
  const save = () => { try { localStorage.setItem(ORG, JSON.stringify(org)); } catch {} };

  const SV = (p, w) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w || 2}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  const GEAR = SV('<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>', 1.9);
  const HOME = SV('<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>', 1.9);
  const CHECK = SV('<path d="M20 6 9 17l-5-5"/>', 2.2);
  const BUB = SV('<path d="M20 6 9 17l-5-5"/>', 3.2);
  const FOLDER = SV('<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>');
  const FOLDER_PLUS = SV('<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/><path d="M12 10v6M9 13h6"/>');
  const REARR = SV('<path d="M3 6h11"/><path d="M3 12h11"/><path d="M3 18h11"/><path d="m17 15 3 3 3-3"/><path d="M20 6v12"/>');
  const LEFT = SV('<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>');
  const CHEV_R = SV('<path d="m9 18 6-6-6-6"/>', 2.4);
  const GRIP = SV('<path d="M5 9h14M5 15h14"/>', 2.2);
  const PENCIL = SV('<path d="M21.17 6.81a1 1 0 0 0-3.99-3.99L3.84 16.17a2 2 0 0 0-.5.83l-1.32 4.350a.5.5 0 0 0 .62.62l4.35-1.32a2 2 0 0 0 .83-.5z"/>');
  const TRASH = SV('<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>');

  const BLUE = "var(--linkbot-blue-exact,oklch(0.52 0.24 264))";
  const MUTED = "oklch(0.46 0.03 260)";
  const CSS = `
    .lbm-links-head{position:relative;}
    .lbm-links-scroll{touch-action:pan-y;}
    .lbf-corner{position:absolute;top:-9px;width:24px;height:24px;display:none;place-items:center;border:0;padding:0;margin:0;background:none;color:#a9b4d6;cursor:pointer;border-radius:50%;-webkit-tap-highlight-color:transparent;}
    .lbf-corner svg{width:14px;height:14px;}
    .lbf-done svg{width:15px;height:15px;}
    .lbf-corner:hover,.lbf-corner.lbf-on{color:${BLUE};}
    .lbf-corner.lbf-on{background:#fff;}
    .lbf-gear,.lbf-done{right:-6px;} .lbf-home{left:-6px;}
    .lbf-show-gear .lbf-gear,.lbf-show-home .lbf-home,.lbf-show-done .lbf-done{display:grid;}
    .lbf-row{position:relative;flex:none;border-radius:8px;}
    .lbf-row.lbf-clip{overflow:hidden;}
    .lbf-row > .lbm-lbtn{position:relative;z-index:1;transition:transform .22s cubic-bezier(.2,.8,.2,1) !important;}
    .lbf-row.lbf-swiping > .lbm-lbtn{transition:none !important;}
    .lbf-acts{position:absolute;top:0;right:0;bottom:0;display:flex;gap:4px;visibility:hidden;}
    .lbf-row.lbf-clip .lbf-acts{visibility:visible;}
    .lbf-act{width:55px;border:0;border-radius:8px;color:#fff;font:700 10px/1 "Inter",ui-sans-serif,system-ui,sans-serif;white-space:nowrap;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:0;margin:0;cursor:pointer;-webkit-tap-highlight-color:transparent;}
    .lbf-act svg{width:15px;height:15px;}
    .lbf-blue{background:${BLUE};} .lbf-red{background:#d92d2d;}
    .lbm-links .linkbot-button.lbm-lbtn.lbf-fold{grid-template-columns:28px 1fr 40px !important;}
    .lbf-fold .lbf-cnt{display:flex !important;align-items:center;justify-content:flex-end;gap:3px;font:700 11.5px/1 "Inter",ui-sans-serif,system-ui,sans-serif;color:#7b86a0;white-space:nowrap;}
    .lbf-fold .lbf-cnt svg{width:14px !important;height:14px !important;}
    .lbf-arr .lbm-ar{color:#a3abb9;}
    .lbf-arr .lbm-ar svg{width:16px !important;height:16px !important;}
    .lbf-arrange .lbm-links-scroll{touch-action:none;}
    .lbf-arrange .lbf-row{cursor:grab;}
    .lbf-row.lbf-lift{z-index:5;cursor:grabbing;}
    .lbf-row.lbf-lift > .lbm-lbtn{box-shadow:0 0 0 1.5px ${BLUE},0 0 0 5.5px rgba(37,82,232,.12) !important;border-radius:10px !important;transition:none !important;}
    .lbf-veil{position:absolute;inset:0;z-index:44;background:rgba(11,15,30,.18);animation:lbm-fade .15s ease both;}
    .lbf-menu{position:absolute;top:22px;left:50%;margin-left:-125px;z-index:45;width:250px;box-sizing:border-box;background:#fff;border-radius:14px;padding:6px;text-align:left;box-shadow:0 18px 36px -10px rgba(0,0,0,.35),0 0 0 .5px rgba(0,0,0,.08);animation:lbm-pop .18s cubic-bezier(.2,.8,.2,1) both;}
    .lbf-mi{display:flex;align-items:center;gap:11px;width:100%;height:46px;padding:0 12px;margin:0;border:0;border-radius:9px;background:none;font:600 14.5px/1 "Inter",ui-sans-serif,system-ui,sans-serif;letter-spacing:normal;color:#0b0b0d;white-space:nowrap;cursor:pointer;text-align:left;}
    .lbf-mi:hover{background:#f3f5fb;}
    .lbf-mi svg{width:19px;height:19px;color:${BLUE};flex:none;}
    .lbf-tip{display:flex;gap:11px;margin:2px 6px 8px;padding:10px 6px 2px;border-top:1px solid #eef0f4;font:400 12.5px/1.45 "Inter",ui-sans-serif,system-ui,sans-serif;letter-spacing:normal;color:#4b5563;white-space:nowrap;}
    .lbf-tip svg{width:19px;height:19px;color:#8a94a6;flex:none;margin-top:1px;}
    .lbf-topdim{position:absolute;inset:0;pointer-events:none;animation:lbm-fade .15s ease both;}
    .lbm-doc-ov.lbf-ov{background:rgba(11,15,30,.5);padding:0 22px;}
    .lbm-doc-ov.lbf-ov.lbf-wide{padding:0 18px;}
    .lbf-sheet{align-items:stretch !important;border-radius:18px !important;padding:22px 20px 20px !important;box-shadow:0 24px 48px -12px rgba(0,0,0,.4) !important;}
    .lbf-wide .lbf-sheet{padding:20px 16px 18px !important;}
    .lbf-sheet .lbm-doc-ic{align-self:center;width:44px;height:44px;margin:0 0 12px;}
    .lbf-sheet .lbm-doc-ic svg{width:20px;height:20px;}
    .lbf-sheet .lbf-blue-ic{color:#fff;background:radial-gradient(ellipse 62% 38% at 50% 20%,rgba(255,255,255,.85),rgba(255,255,255,0) 72%),linear-gradient(180deg,#7f9bf3 0%,#2552e8 55%,#1a3aa8 100%);}
    .lbf-sheet .lbf-red-ic{color:#d92d2d;background:#fde8e8;}
    .lbf-sheet .lbm-doc-title{margin:0;font:800 18px/1.25 "Inter",ui-sans-serif,system-ui,sans-serif;letter-spacing:normal;color:#0b0b0d;white-space:nowrap;}
    .lbf-sheet .lbm-doc-text{margin:6px 0 0;text-align:center;font:400 13.5px/1.45 "Inter",ui-sans-serif,system-ui,sans-serif;color:#4b5563;}
    .lbf-sheet .lbm-doc-text b{font-weight:700;color:#0b0b0d;}
    .lbf-fl{display:block;margin:14px 0 6px;text-align:left;font:700 11.5px/1.2 "Inter",ui-sans-serif,system-ui,sans-serif;color:#4b5563;white-space:nowrap;}
    .lbf-sheet .lbm-doc-text + .lbf-fl{margin-top:16px;}
    .lbf-in{display:block;width:100%;box-sizing:border-box;height:46px;margin:0;border:1.5px solid ${BLUE};border-radius:10px;padding:0 12px;font:600 15px "Inter",ui-sans-serif,system-ui,sans-serif;color:#0b0b0d;background:#fff;box-shadow:0 0 0 4px rgba(37,82,232,.12);outline:none;}
    .lbf-was{margin:8px 0 0;text-align:left;font:400 12px/1.4 "Inter",ui-sans-serif,system-ui,sans-serif;color:#6b7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .lbf-pick{max-height:196px;overflow-y:auto;border-top:1px solid #eef0f4;scrollbar-width:none;}
    .lbf-pick.lbf-more{-webkit-mask-image:linear-gradient(to bottom,#000 0,#000 150px,transparent 100%);mask-image:linear-gradient(to bottom,#000 0,#000 150px,transparent 100%);}
    .lbf-pick::-webkit-scrollbar{display:none;}
    .lbf-pr{display:flex;align-items:center;gap:12px;width:100%;height:47px;padding:0 6px;margin:0;border:0;border-bottom:1px solid #eef0f4;background:none;font:600 14.5px/1 "Inter",ui-sans-serif,system-ui,sans-serif;color:#0b0b0d;text-align:left;cursor:pointer;-webkit-tap-highlight-color:transparent;}
    .lbf-pr > span:last-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .lbf-bub{flex:none;width:22px;height:22px;box-sizing:border-box;border-radius:50%;border:2px solid #c3cbe0;display:grid;place-items:center;color:#fff;}
    .lbf-bub svg{width:12px;height:12px;display:none;}
    .lbf-pr.on .lbf-bub{border-color:${BLUE};background:${BLUE};}
    .lbf-pr.on .lbf-bub svg{display:block;}
    .lbf-none{margin:12px 0 0;font:400 12.5px/1.4 "Inter",ui-sans-serif,system-ui,sans-serif;color:#4b5563;}
    .lbf-btns{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:18px;}
    .lbf-wide .lbf-btns{margin-top:14px;}
    .lbf-b{height:46px;margin:0;border:0;border-radius:10px;font:700 14.5px/1 "Inter",ui-sans-serif,system-ui,sans-serif;white-space:nowrap;cursor:pointer;}
    .lbf-cancel{background:#eef1f6;color:#374151;} .lbf-save{background:${BLUE};color:#fff;} .lbf-del{background:#d92d2d;color:#fff;}
  `;


  let uid = 0;
  const el = (doc, tag, cls, html) => { const e = doc.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const zoomOf = (s) => (s.getBoundingClientRect().width / s.offsetWidth) || 1;
  const nameOf = (lbl) => org.names[lbl] || lbl;
  const folderOf = (lbl) => org.folders.find((f) => f.links.includes(lbl));
  const rank = (key) => { const i = org.order.indexOf(key); return i < 0 ? -1 : i; };
  const screensOf = (doc) => [...doc.querySelectorAll(".lbm-screen")].filter((s) => s.__lbf);
  const buildAll = (doc) => screensOf(doc).forEach((s) => build(s, true));

  // The overlay's own link buttons, newest first. A fresh set appears each time the overlay redraws the list.
  const rawOf = (s) => {
    const st = s.__lbf;
    const btns = [...s.querySelectorAll(".lbm-links-scroll .lbm-lbtn:not(.lbf-fold)")];
    if (btns.some((b) => !b.dataset.lbl)) {
      btns.forEach((b) => {
        b.dataset.lbl = b.querySelector(".lbm-tx")?.textContent || "";
        b.__ar = b.querySelector(".lbm-ar")?.innerHTML || "";
      });
      st.raw = btns;
    }
    return st.raw || [];
  };

  function closeRow(s) {
    const st = s.__lbf;
    if (!st.open) return;
    const row = st.open; st.open = null;
    const b = row.querySelector(":scope > .lbm-lbtn");
    b?.style.setProperty("transform", "translateX(0px)", "important");
    setTimeout(() => { if (st.open !== row) row.classList.remove("lbf-clip"); }, 240);
  }
  // The phone's top bar (time and dots) sits above the screen, so it gets its own matching shade while a menu or popup is open.
  function topDim(s, alpha) {
    const bar = s.parentElement?.parentElement?.querySelector(":scope > .z-20");
    if (!bar || !bar.querySelector("#lb-time")) return null;
    const d = el(s.ownerDocument, "div", "lbf-topdim");
    d.style.background = "rgba(11,15,30," + alpha + ")";
    bar.appendChild(d);
    return d;
  }
  function closeMenus(s) {
    s.querySelectorAll(".lbf-menu,.lbf-veil").forEach((x) => x.remove());
    s.parentElement?.parentElement?.querySelectorAll(".lbf-topdim").forEach((x) => x.remove());
    s.querySelector(".lbf-gear")?.classList.remove("lbf-on");
  }

  function build(s, reset) {
    const st = s.__lbf;
    if (!st || st.dragging) return;
    const doc = s.ownerDocument;
    const sc = s.querySelector(".lbm-links-scroll");
    const head = s.querySelector(".lbm-links-head");
    const label = head.querySelector(".lbm-links-label");
    const hint = head.querySelector(".lbm-links-hint");
    st.busy = true;
    try {
      const raw = rawOf(s);
      const ended = s.classList.contains("lbm-ended");
      if (!ended) {
        // During a call the overlay's own list shows untouched. A deleted link that is shared again comes back.
        if (s.classList.contains("lbm-on")) {
          let changed = false;
          raw.forEach((b) => { const i = org.deleted.indexOf(b.dataset.lbl); if (i > -1 && b.isConnected) { org.deleted.splice(i, 1); changed = true; } });
          if (changed) save();
        }
        if (sc.querySelector(".lbf-row")) {
          sc.textContent = "";
          raw.forEach((b) => {
            b.removeAttribute("style"); b.classList.remove("lbf-arr");
            const tx = b.querySelector(".lbm-tx"); if (tx) tx.textContent = b.dataset.lbl;
            const ar = b.querySelector(".lbm-ar"); if (ar && b.__ar) ar.innerHTML = b.__ar;
            sc.appendChild(b);
          });
        }
        st.view = "home"; st.mode = "list"; st.open = null;
        closeMenus(s);
        if (s.classList.contains("lbf-arrange")) s.classList.remove("lbf-arrange"); // only touch the class when it is there, or the page keeps redrawing itself
        head.classList.remove("lbf-show-gear", "lbf-show-home", "lbf-show-done");
        if (label.textContent !== st.lab0) label.textContent = st.lab0;
        if (hint.textContent !== st.hint0) hint.textContent = st.hint0;
        return;
      }

      const present = raw.filter((b) => b.dataset.lbl && !org.deleted.includes(b.dataset.lbl));
      const byLbl = new Map(present.map((b) => [b.dataset.lbl, b]));
      if (st.view !== "home" && !org.folders.some((f) => f.id === st.view)) st.view = "home";
      const folder = st.view === "home" ? null : org.folders.find((f) => f.id === st.view);
      const arrange = st.mode === "arrange";
      st.open = null;
      sc.textContent = "";

      const linkRow = (b) => {
        const lbl = b.dataset.lbl;
        const row = el(doc, "div", "lbf-row"); row.dataset.kind = "l"; row.dataset.key = "l:" + lbl;
        b.removeAttribute("style");
        const tx = b.querySelector(".lbm-tx"); if (tx) tx.textContent = nameOf(lbl);
        const ar = b.querySelector(".lbm-ar"); if (ar) ar.innerHTML = arrange ? GRIP : b.__ar;
        b.classList.toggle("lbf-arr", arrange);
        const acts = el(doc, "div", "lbf-acts");
        const rn = el(doc, "button", "lbf-act lbf-blue", PENCIL + "Rename"); rn.type = "button";
        const dl = el(doc, "button", "lbf-act lbf-red", TRASH + "Delete"); dl.type = "button";
        rn.onclick = (e) => { e.stopPropagation(); closeRow(s); renamePopup(s, lbl); };
        dl.onclick = (e) => { e.stopPropagation(); closeRow(s); deleteLinkPopup(s, lbl); };
        acts.append(rn, dl);
        row.append(acts, b);
        return row;
      };
      const folderRow = (f) => {
        const n = f.links.filter((l) => byLbl.has(l)).length;
        const row = el(doc, "div", "lbf-row"); row.dataset.kind = "f"; row.dataset.key = "f:" + f.id;
        const b = el(doc, "button", "linkbot-button w-full lbm-lbtn lbf-fold" + (arrange ? " lbf-arr" : ""));
        b.type = "button"; b.dataset.fid = f.id;
        b.innerHTML = `<span class="lbm-ic">${FOLDER}</span><span class="lbm-tx"></span><span class="lbm-ar ${arrange ? "" : "lbf-cnt"}">${arrange ? GRIP : "<span></span>" + CHEV_R}</span>`;
        b.querySelector(".lbm-tx").textContent = f.name;
        if (!arrange) b.querySelector(".lbf-cnt span").textContent = String(n);
        const acts = el(doc, "div", "lbf-acts");
        const ed = el(doc, "button", "lbf-act lbf-blue", PENCIL + "Edit"); ed.type = "button";
        const dl = el(doc, "button", "lbf-act lbf-red", TRASH + "Delete"); dl.type = "button";
        ed.onclick = (e) => { e.stopPropagation(); closeRow(s); folderPopup(s, f.id); };
        dl.onclick = (e) => { e.stopPropagation(); closeRow(s); deleteFolderPopup(s, f.id); };
        acts.append(ed, dl);
        row.append(acts, b);
        return row;
      };

      let count = 0;
      if (folder) {
        folder.links.filter((l) => byLbl.has(l)).forEach((l) => { sc.appendChild(linkRow(byLbl.get(l))); count++; });
      } else {
        const folders = org.folders.map((f, i) => ({ f, i, r: rank("f:" + f.id) }))
          .sort((a, b) => (a.r < 0 ? 1e6 + a.i : a.r) - (b.r < 0 ? 1e6 + b.i : b.r));
        folders.forEach(({ f }) => sc.appendChild(folderRow(f)));
        // Links not in a folder: brand new ones first (newest first), then the order they arranged.
        const loose = present.filter((b) => !folderOf(b.dataset.lbl)).map((b, i) => ({ b, i, r: rank("l:" + b.dataset.lbl) }));
        loose.sort((a, b) => (a.r < 0 ? a.i - 1e6 : a.r) - (b.r < 0 ? b.i - 1e6 : b.r));
        loose.forEach(({ b }) => sc.appendChild(linkRow(b)));
        count = folders.length + loose.length;
      }

      s.classList.toggle("lbf-arrange", arrange);
      head.classList.toggle("lbf-show-gear", !arrange);
      head.classList.toggle("lbf-show-home", !arrange && !!folder);
      head.classList.toggle("lbf-show-done", arrange);
      const lab = folder ? folder.name.toUpperCase() : arrange ? "REARRANGE" : st.lab0;
      const n = folder ? folder.links.filter((l) => byLbl.has(l)).length : 0;
      const hn = arrange ? "Hold and drag to change the order."
        : folder ? n + " link" + (n === 1 ? "" : "s") + " in this folder."
        : count ? st.hint0 : "No saved links.";
      if (label.textContent !== lab) label.textContent = lab;
      if (hint.textContent !== hn) hint.textContent = hn;
      if (reset) sc.scrollTop = 0;
    } finally {
      st.mo?.takeRecords();
      st.busy = false;
    }
    // Lets the overlay recount the "Scroll for more links" bubble for the new list.
    requestAnimationFrame(() => sc.dispatchEvent(new Event("scroll")));
  }

  // ---- Popups (same look as the page's other popups) ----
  function sheet(s, aria, html, wide) {
    s.querySelector(".lbm-doc-ov")?.remove();
    closeMenus(s);
    const doc = s.ownerDocument;
    const ov = el(doc, "div", "lbm-doc-ov lbf-ov" + (wide ? " lbf-wide" : ""));
    ov.innerHTML = `<div class="lbm-doc-sheet lbf-sheet" role="dialog" aria-modal="true">${html}</div>`;
    ov.querySelector(".lbf-sheet").setAttribute("aria-label", aria);
    const dim = topDim(s, 0.5);
    ov.remove = () => { dim?.remove(); Element.prototype.remove.call(ov); };
    ov.onclick = (e) => { if (e.target === ov) ov.remove(); };
    s.appendChild(ov);
    ov.querySelector(".lbf-cancel")?.addEventListener("click", () => ov.remove());
    return ov;
  }

  function folderPopup(s, fid) {
    const doc = s.ownerDocument;
    const f = fid ? org.folders.find((x) => x.id === fid) : null;
    const id = "lbf-in-" + (++uid);
    const ov = sheet(s, f ? "Edit Folder" : "New Folder", `
      <p class="lbm-doc-title">${f ? "Edit Folder" : "New Folder"}</p>
      <label class="lbf-fl" for="${id}">Folder name</label>
      <input class="lbf-in" id="${id}" type="text" maxlength="30" autocomplete="off" enterkeyhint="done">
      <p class="lbf-fl">${f ? "Tap to add or remove links" : "Pick the links to put in it"}</p>
      <div class="lbf-pick"></div>
      <div class="lbf-btns"><button type="button" class="lbf-b lbf-cancel">Cancel</button><button type="button" class="lbf-b lbf-save">${f ? "Save" : "Create"}</button></div>`, true);
    const input = ov.querySelector(".lbf-in");
    input.value = f ? f.name : "";
    input.placeholder = "Folder name";
    const pick = ov.querySelector(".lbf-pick");
    const present = (s.__lbf.raw || []).map((b) => b.dataset.lbl).filter((l) => l && !org.deleted.includes(l));
    if (!present.length) pick.replaceWith(el(doc, "p", "lbf-none", "No saved links yet."));
    present.forEach((lbl) => {
      const r = el(doc, "button", "lbf-pr" + (f && f.links.includes(lbl) ? " on" : ""), `<span class="lbf-bub">${BUB}</span><span></span>`);
      r.type = "button"; r.dataset.lbl = lbl;
      r.setAttribute("aria-pressed", String(r.classList.contains("on")));
      r.lastChild.textContent = nameOf(lbl);
      r.onclick = () => { r.classList.toggle("on"); r.setAttribute("aria-pressed", String(r.classList.contains("on"))); };
      pick.appendChild(r);
    });
    requestAnimationFrame(() => pick.classList.toggle("lbf-more", pick.scrollHeight > pick.clientHeight + 1));
    const done = () => {
      const name = input.value.trim() || (f ? f.name : "New Folder");
      const chosen = [...ov.querySelectorAll(".lbf-pr.on")].map((r) => r.dataset.lbl);
      let target = f;
      if (!target) { target = { id: "f" + Date.now().toString(36) + (++uid), name, links: [] }; org.folders.push(target); }
      target.name = name;
      org.folders.forEach((x) => { if (x !== target) x.links = x.links.filter((l) => !chosen.includes(l)); });
      const kept = target.links.filter((l) => chosen.includes(l) || !present.includes(l)); // links not on this page right now stay where they were
      chosen.forEach((l) => { if (!kept.includes(l)) kept.push(l); });
      target.links = kept;
      save(); ov.remove(); buildAll(doc);
    };
    ov.querySelector(".lbf-save").onclick = done;
    input.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); done(); } };
    if (!f) setTimeout(() => input.focus({ preventScroll: true }), 60);
  }

  function renamePopup(s, lbl) {
    const doc = s.ownerDocument;
    const id = "lbf-in-" + (++uid);
    const ov = sheet(s, "Rename Link", `
      <span class="lbm-doc-ic lbf-blue-ic">${PENCIL}</span>
      <p class="lbm-doc-title">Rename Link</p>
      <p class="lbm-doc-text">Call it anything you want. Only you see this name.</p>
      <label class="lbf-fl" for="${id}">Button name</label>
      <input class="lbf-in" id="${id}" type="text" maxlength="40" autocomplete="off" enterkeyhint="done">
      <p class="lbf-was"></p>
      <div class="lbf-btns"><button type="button" class="lbf-b lbf-cancel">Cancel</button><button type="button" class="lbf-b lbf-save">Save</button></div>`);
    const input = ov.querySelector(".lbf-in");
    input.value = nameOf(lbl);
    const was = ov.querySelector(".lbf-was");
    if (org.names[lbl]) was.textContent = "Was: " + lbl; else was.remove();
    const done = () => {
      const v = input.value.trim();
      if (!v || v === lbl) delete org.names[lbl]; else org.names[lbl] = v;
      save(); ov.remove(); buildAll(doc);
    };
    ov.querySelector(".lbf-save").onclick = done;
    input.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); done(); } };
  }

  function deleteLinkPopup(s, lbl) {
    const doc = s.ownerDocument;
    const ov = sheet(s, "Delete Link?", `
      <span class="lbm-doc-ic lbf-red-ic">${TRASH}</span>
      <p class="lbm-doc-title">Delete Link?</p>
      <p class="lbm-doc-text"><b></b> will be removed from your saved links.</p>
      <div class="lbf-btns"><button type="button" class="lbf-b lbf-cancel">Keep It</button><button type="button" class="lbf-b lbf-del">Delete</button></div>`);
    ov.querySelector(".lbm-doc-text b").textContent = nameOf(lbl);
    ov.querySelector(".lbf-del").onclick = () => {
      if (!org.deleted.includes(lbl)) org.deleted.push(lbl);
      org.folders.forEach((f) => { f.links = f.links.filter((l) => l !== lbl); });
      org.order = org.order.filter((k) => k !== "l:" + lbl);
      save(); ov.remove(); buildAll(doc);
    };
  }

  function deleteFolderPopup(s, fid) {
    const doc = s.ownerDocument;
    const f = org.folders.find((x) => x.id === fid);
    if (!f) return;
    const present = new Set((s.__lbf.raw || []).map((b) => b.dataset.lbl).filter((l) => !org.deleted.includes(l)));
    const n = f.links.filter((l) => present.has(l)).length;
    const ov = sheet(s, "Delete Folder?", `
      <span class="lbm-doc-ic lbf-red-ic">${TRASH}</span>
      <p class="lbm-doc-title">Delete Folder?</p>
      <p class="lbm-doc-text"><b></b> will be removed.<span></span></p>
      <div class="lbf-btns"><button type="button" class="lbf-b lbf-cancel">Keep It</button><button type="button" class="lbf-b lbf-del">Delete</button></div>`);
    ov.querySelector(".lbm-doc-text b").textContent = f.name;
    ov.querySelector(".lbm-doc-text span").textContent = n === 0 ? ""
      : n === 1 ? " The 1 link inside moves back to your home screen list."
      : " The " + n + " links inside move back to your home screen list.";
    ov.querySelector(".lbf-del").onclick = () => {
      org.folders = org.folders.filter((x) => x.id !== fid);
      org.order = org.order.filter((k) => k !== "f:" + fid);
      save(); ov.remove();
      screensOf(doc).forEach((x) => { if (x.__lbf.view === fid) x.__lbf.view = "home"; });
      buildAll(doc);
    };
  }

  function menu(s) {
    const st = s.__lbf;
    if (s.querySelector(".lbf-menu")) { closeMenus(s); return; }
    closeRow(s);
    const doc = s.ownerDocument;
    const head = s.querySelector(".lbm-links-head");
    const veil = el(doc, "div", "lbf-veil");
    const m = el(doc, "div", "lbf-menu", `
      <button type="button" class="lbf-mi" data-a="new">${FOLDER_PLUS}<span>New Folder</span></button>
      <button type="button" class="lbf-mi" data-a="arr">${REARR}<span>Rearrange</span></button>
      <div class="lbf-tip">${LEFT}<span>${doc.defaultView.matchMedia && doc.defaultView.matchMedia("(hover: hover) and (pointer: fine)").matches ? "Drag any link left to edit." : "Swipe left on any link to edit."}</span></div>`);
    veil.onclick = () => closeMenus(s);
    s.appendChild(veil);
    topDim(s, 0.18);
    head.appendChild(m);
    head.querySelector(".lbf-gear").classList.add("lbf-on");
    m.querySelector('[data-a="new"]').onclick = (e) => { e.stopPropagation(); closeMenus(s); folderPopup(s, null); };
    m.querySelector('[data-a="arr"]').onclick = (e) => { e.stopPropagation(); closeMenus(s); st.mode = "arrange"; build(s, true); };
  }

  // ---- Swipe left (list) and hold and drag (rearrange) ----
  function gestures(s) {
    const st = s.__lbf;
    const sc = s.querySelector(".lbm-links-scroll");
    const ACT = 116;
    let sw = null, drag = null;
    const btnOf = (row) => row.querySelector(":scope > .lbm-lbtn");
    const setX = (row, x) => btnOf(row)?.style.setProperty("transform", "translateX(" + x + "px)", "important");
    const same = (row, dir) => { const n = dir > 0 ? row.nextElementSibling : row.previousElementSibling; return n && n.dataset.kind === row.dataset.kind ? n : null; };

    sc.addEventListener("pointerdown", (e) => {
      if (!s.classList.contains("lbm-ended") || e.button > 0) return;
      const row = e.target.closest(".lbf-row");
      if (!row || e.target.closest(".lbf-acts")) return;
      if (st.mode === "arrange") {
        e.preventDefault();
        drag = { row, y0: e.clientY, k: zoomOf(s), moved: false };
        st.dragging = true; st.busy = true;
        row.classList.add("lbf-lift");
        try { sc.setPointerCapture(e.pointerId); } catch {}
        return;
      }
      if (st.open && st.open !== row) closeRow(s);
      sw = { row, x0: e.clientX, y0: e.clientY, k: zoomOf(s), base: st.open === row ? -ACT : 0, x: st.open === row ? -ACT : 0, active: false, id: e.pointerId };
    });

    sc.addEventListener("pointermove", (e) => {
      if (drag) {
        let dy = (e.clientY - drag.y0) / drag.k;
        const row = drag.row;
        const next = same(row, 1), prev = same(row, -1);
        if (next && dy > (next.offsetHeight + 9) / 2) { next.after(row); drag.y0 += (next.offsetHeight + 9) * drag.k; dy -= next.offsetHeight + 9; drag.moved = true; }
        else if (prev && dy < -(prev.offsetHeight + 9) / 2) { prev.before(row); drag.y0 -= (prev.offsetHeight + 9) * drag.k; dy += prev.offsetHeight + 9; drag.moved = true; }
        if (!next && dy > 0) dy = Math.min(dy, 6);
        if (!prev && dy < 0) dy = Math.max(dy, -6);
        row.style.transform = "translateY(" + dy + "px)";
        e.preventDefault();
        return;
      }
      if (!sw) return;
      const dx = (e.clientX - sw.x0) / sw.k, dy = (e.clientY - sw.y0) / sw.k;
      if (!sw.active) {
        if (Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy)) {
          sw.active = true;
          sw.row.classList.add("lbf-swiping", "lbf-clip");
          try { sc.setPointerCapture(sw.id); } catch {}
        } else if (Math.abs(dy) > 8) { sw = null; return; } else return;
      }
      sw.x = Math.max(-ACT - 24, Math.min(0, sw.base + dx));
      setX(sw.row, sw.x);
      e.preventDefault();
    });

    const finish = () => {
      if (drag) {
        const row = drag.row;
        row.classList.remove("lbf-lift");
        row.style.transform = "";
        if (drag.moved) {
          st.swiped = Date.now();
          const st2 = s.__lbf;
          const fid = st2.view !== "home" ? st2.view : null;
          const keys = [...sc.querySelectorAll(":scope > .lbf-row")].map((r) => r.dataset.key);
          if (fid) {
            const f = org.folders.find((x) => x.id === fid);
            if (f) {
              const shown = keys.map((k) => k.slice(2));
              f.links = shown.concat(f.links.filter((l) => !shown.includes(l)));
            }
          } else {
            org.order = keys.concat(org.order.filter((k) => !keys.includes(k)));
          }
          save();
        }
        drag = null;
        st.mo?.takeRecords();
        st.dragging = false; st.busy = false;
        return;
      }
      if (!sw) return;
      const row = sw.row;
      row.classList.remove("lbf-swiping");
      if (sw.active) {
        st.swiped = Date.now();
        if (sw.x < -40) { setX(row, -ACT); st.open = row; }
        else { st.open = row; closeRow(s); }
      }
      sw = null;
    };
    sc.addEventListener("pointerup", finish);
    sc.addEventListener("pointercancel", finish);

    // Taps: swiping, rearranging and open rows never open a link by accident. Tapping a folder opens it.
    sc.addEventListener("click", (e) => {
      if (!s.classList.contains("lbm-ended") || e.target.closest(".lbf-acts")) return;
      const stop = () => { e.preventDefault(); e.stopPropagation(); };
      if (st.mode === "arrange" || Date.now() - (st.swiped || 0) < 350) return stop();
      if (st.open) { closeRow(s); return stop(); }
      const f = e.target.closest(".lbf-fold");
      if (f) { stop(); st.view = f.dataset.fid; build(s, true); }
    }, true);
  }

  function setup(s) {
    if (s.__lbf) return;
    const sc = s.querySelector(".lbm-links-scroll");
    const head = s.querySelector(".lbm-links-head");
    if (!sc || !head) return;
    const doc = s.ownerDocument;
    const st = s.__lbf = { view: "home", mode: "list", busy: false, raw: [], open: null };
    s.setAttribute("data-lbf", "1"); // 256: tells the phone screen that folders are attached
    st.lab0 = head.querySelector(".lbm-links-label")?.textContent || "LINKS SHARED WITH YOU";
    st.hint0 = head.querySelector(".lbm-links-hint")?.textContent || "";
    const corner = (cls, icon, aria) => { const b = el(doc, "button", "lbf-corner " + cls, icon); b.type = "button"; b.setAttribute("aria-label", aria); return b; };
    const gear = corner("lbf-gear", GEAR, "Settings");
    const home = corner("lbf-home", HOME, "Back to all links");
    const done = corner("lbf-done", CHECK, "Done rearranging");
    head.append(home, gear, done);
    gear.onclick = (e) => { e.stopPropagation(); menu(s); };
    home.onclick = (e) => { e.stopPropagation(); st.view = "home"; build(s, true); };
    done.onclick = (e) => { e.stopPropagation(); st.mode = "list"; build(s, true); };
    const again = () => { if (!st.busy) build(s); };
    st.mo = new MutationObserver(again);
    st.mo.observe(sc, { childList: true });
    new MutationObserver(again).observe(s, { attributes: true, attributeFilter: ["class"] });
    gestures(s);
    build(s, true);
  }

  // Waits for the phone page, then adds the settings to each phone screen (desktop and phone layouts).
  const boot = () => {
    const doc = document.getElementById("lbm-frame")?.contentDocument;
    if (!doc || !doc.head) return;
    if (!doc.getElementById("lbf-css")) { const st = doc.createElement("style"); st.id = "lbf-css"; st.textContent = CSS; doc.head.appendChild(st); }
    doc.querySelectorAll(".lbm-screen").forEach(setup);
  };
  boot();
  const fastBoot = setInterval(boot, 30); // 256: attach almost instantly while the phone screen is being built
  setTimeout(() => clearInterval(fastBoot), 5000);
  setInterval(boot, 500);
})();