/* Isolated My Links document. Password and access token exist only in this closure. */
(() => {
  'use strict';
  const loc = new URL(location.href).searchParams.get('loc') || '';
  let accountEmail = '';
  const canvas = document.getElementById('canvas');
  const spacer = document.getElementById('spacer');
  let token = '', links = [], category = '', phone = false, scale = 1, draft = null, initial = '', errors = {}, busy = false, confirmation = null, lockedUntil = 0;
  let savedNoteTimer, opener, scrollBefore = 0, privateLink = null, pendingWebsite = null;
  let categoryRowObserver;
  let checkingDevice = false;
  let checkingPassword = false;
  const touchInput = matchMedia('(any-pointer: coarse)');
  function categoryHintVisible(rowWidth, contentWidth) {
    return contentWidth > rowWidth + 1;
  }
  function updateCategoryHint() {
    const tabs=canvas.querySelector('.tabs'),hint=canvas.querySelector('.category-scroll-hint');
    if(!tabs||!hint)return;
    hint.textContent=touchInput.matches||navigator.maxTouchPoints>0?'Swipe for more categories →':'Scroll for more categories →';
    const visible=categoryHintVisible(tabs.clientWidth,tabs.scrollWidth);
    hint.classList.toggle('visible',visible);
    hint.setAttribute('aria-hidden',String(!visible));
  }
  function bindCategoryScrolling(tabs) {
    categoryRowObserver?.disconnect();
    if(!tabs)return;
    categoryRowObserver=new ResizeObserver(updateCategoryHint);
    categoryRowObserver.observe(tabs);
    tabs.addEventListener('scroll',updateCategoryHint,{passive:true});
    let drag=null,moved=false;
    tabs.addEventListener('pointerdown',event=>{
      moved=false;
      if(event.pointerType!=='mouse'||event.button!==0||tabs.scrollWidth<=tabs.clientWidth)return;
      drag={id:event.pointerId,x:event.clientX,left:tabs.scrollLeft};
    });
    tabs.addEventListener('pointermove',event=>{
      if(!drag||event.pointerId!==drag.id)return;
      const delta=event.clientX-drag.x;
      if(!moved&&Math.abs(delta)<=5)return;
      if(!moved){moved=true;tabs.setPointerCapture(event.pointerId);tabs.classList.add('dragging');}
      event.preventDefault();tabs.scrollLeft=drag.left-delta;
    });
    function endDrag(event){
      if(!drag||event.pointerId!==drag.id)return;
      drag=null;tabs.classList.remove('dragging');
      if(tabs.hasPointerCapture(event.pointerId))tabs.releasePointerCapture(event.pointerId);
    }
    tabs.addEventListener('pointerup',endDrag);
    tabs.addEventListener('pointercancel',endDrag);
    tabs.addEventListener('lostpointercapture',()=>{drag=null;tabs.classList.remove('dragging');});
    tabs.addEventListener('click',event=>{if(moved){event.preventDefault();event.stopPropagation();moved=false;}},true);
    tabs.addEventListener('wheel',event=>{
      if(event.ctrlKey||tabs.scrollWidth<=tabs.clientWidth)return;
      const delta=Math.abs(event.deltaX)>Math.abs(event.deltaY)?event.deltaX:event.deltaY;
      const unit=event.deltaMode===1?tabs.clientHeight:event.deltaMode===2?tabs.clientWidth:1;
      const before=tabs.scrollLeft;tabs.scrollLeft+=delta*unit;
      if(tabs.scrollLeft!==before)event.preventDefault();
    },{passive:false});
    updateCategoryHint();
  }
  touchInput.addEventListener('change',updateCategoryHint);
  const icons = {
    plus:'<path d="M12 5v14M5 12h14"/>', pencil:'<path d="m16 3 5 5-12 12-6 1 1-6Z M14 5l5 5"/>', trash:'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>', close:'<path d="m6 6 12 12M18 6 6 18"/>',
    eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>', eyeoff:'<path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22"/>'
  };
  function icon(name) { return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">${icons[name]}</svg>`; }
  const checkoutEyeIcon = shown => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${shown ? '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>' : '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>'}</svg>`;
  function esc(value) { return String(value ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x])); }
  function button(text, cls = 'linkbot-button', action = '', symbol = '') { return `<button type="button" class="${cls}" ${action ? `data-action="${action}"` : ''}><span>${symbol ? icon(symbol) : ''}${esc(text)}</span></button>`; }
  function switchHtml(on, action, id = '', label = '') { return `<div class="switch-group ${on ? '' : 'off'}"><span>${on ? 'ON' : 'OFF'}</span><button type="button" role="switch" aria-checked="${on}" aria-label="${label || (id ? 'Link status' : 'Link Status')}" class="switch" data-action="${action}" data-id="${id}"></button></div>`; }
  function fit() {
    const nextPhone = document.documentElement.clientWidth < 768;
    const changed = phone !== nextPhone;
    phone = nextPhone; scale = 1;
    const gapScale = document.documentElement.clientWidth / (phone ? 390 : 1440);
    document.documentElement.classList.add('my-links-native');
    document.documentElement.style.setProperty('--ml-gap-scale', String(gapScale));
    document.documentElement.style.setProperty('--ml-guide-gap', String(gapScale * 366 / 540));
    document.documentElement.classList.toggle('phone', phone);
    document.documentElement.classList.toggle('embedded-manager', !token || checkingDevice);
    canvas.style.width = '100%';
    canvas.style.transform = 'none';
    canvas.style.setProperty('--canvas-height', `${innerHeight / scale}px`);
    canvas.style.setProperty('--ml-scale', String(scale));
    canvas.style.setProperty('--frame-edge', `${8 / scale}px`);
    fitGuide();
    spacer.style.height = `${canvas.offsetHeight * scale}px`;
    canvas.style.visibility = 'visible';
    if (changed && token) { render(); if (draft) renderModal(); if (guideOpen) renderGuide(); }
    document.querySelectorAll('textarea').forEach(grow);
    syncFloatingAdd();
    updateCategoryHint();
  }
  function syncFloatingAdd() {
    let floating=document.getElementById('floating-add');
    if(!floating&&phone&&token){
      floating=document.createElement('div');floating.id='floating-add';
      floating.innerHTML=`<div class="floating-add-inner">${button('Add Link','linkbot-button','add','plus')}</div>`;
      document.body.appendChild(floating);
    }
    if(!floating)return;
    floating.style.setProperty('--floating-scale',String(scale));
    floating.hidden=!phone||!token||checkingPassword||Boolean(draft)||Boolean(confirmation)||guideOpen;
  }
  function websiteHost(raw) {
    try { return new URL(/^https?:\/\//i.test(raw.trim())?raw.trim():`https://${raw.trim()}`).hostname.toLowerCase().replace(/^www\./,''); } catch { return ''; }
  }
  function normalizedLinkUrl(raw) {
    const value=raw.trim().replace(/^https?:\/\//i,'').replace(/\/$/,'');
    const host=value.match(/^[^/?#]+/)?.[0]??'';
    return host.toLowerCase().replace(/^www\./,'')+value.slice(host.length);
  }
  function mainWebsiteConflict(url, id) {
    const host=websiteHost(url);
    return Boolean(host&&links.some(link=>link.id!==id&&link.is_main_website&&websiteHost(link.url)===host));
  }
  function showMainWebsiteError() {
    const row=document.querySelector('[data-field="is_main_website"]');if(!row)return;
    row.classList.toggle('field-error',Boolean(errors.is_main_website));
    row.querySelector('.switch-error').textContent=errors.is_main_website||'';
  }
  async function api(action, data = {}) {
    const response = await fetch('/my-links', { method:'POST', credentials:action==='username'?'same-origin':'omit', keepalive:action==='snapshot', headers:{'content-type':'application/json'}, body:JSON.stringify({ action, loc, token, ...data }) });
    const result = await response.json();
    if (response.status === 401) { storeDevice(null); token = ''; links = []; draft = null; confirmation = null; guideOpen = false; privateLink = null; document.body.style.overflowY = ''; render(); throw new Error(result.error); }
    return result;
  }
  function loginScreen(notice = '') {
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="password-area"><form class="password-box" id="password-form"><input id="password-username" name="username" type="text" autocomplete="username" readonly tabindex="-1" aria-hidden="true" value="${esc(accountEmail)}" style="position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);margin:0;padding:0;border:0"><label for="password">Password</label><div class="login-password-wrap"><input id="password" name="password" type="password" placeholder="LinkBot Login Password" autocomplete="current-password" maxlength="128" required><button type="button" class="login-password-eye" data-action="eye-login" aria-label="Show password" aria-pressed="false" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()">${checkoutEyeIcon(false)}</button></div><label class="remember-device" for="remember-device"><input id="remember-device" type="checkbox">Remember this device</label><div class="password-error" role="alert" id="password-error"></div><div class="password-notice" role="status">${esc(notice)}</div><button class="linkbot-button" type="submit"><span>Manage My Links</span></button>${button('Forgot Password?','plain','forgot')}</form></div></section></main>`;
    document.getElementById('remember-device').checked = deviceChosen();
    window.scrollTo(0,0); fit();
    document.getElementById('password-form').addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return; busy = true;
      const input = document.getElementById('password'); const submit = event.currentTarget.querySelector('[type=submit]'); submit.disabled = true;
      const passwordPage = canvas.firstElementChild;
      const remember = document.getElementById('remember-device').checked;
      checkingPassword = true;
      deviceLoadingScreen();
      function restorePasswordPage(){checkingPassword=false;token='';if(passwordPage)canvas.replaceChildren(passwordPage);fit();}
      try {
        const result = await api('login', { password:input.value, remember });
        if (result.ok) { storeDeviceChoice(remember); storeDevice(remember ? result.device?.token : null); token = result.device?.token || result.token; lockedUntil = 0; await load(); }
        else { restorePasswordPage();if (result.locked) lockedUntil = Date.now() + (result.lockedMinutes || 15) * 60000; showPasswordError(result.error || 'That password is incorrect.'); }
      } catch { restorePasswordPage();showPasswordError('Something went wrong. Please try again.'); }
      finally { checkingPassword = false; busy = false; submit.disabled = false; }
    });
  }
  const deviceKey = `my-links-device:${loc}`;
  const deviceChoiceKey = `my-links-device-choice:${loc}`;
  function savedDevice() { try { return localStorage.getItem(deviceKey); } catch { return null; } }
  function deviceChosen() { try { return localStorage.getItem(deviceChoiceKey) === 'true' || Boolean(savedDevice()); } catch { return false; } }
  function storeDeviceChoice(chosen) { try { if(chosen)localStorage.setItem(deviceChoiceKey,'true');else localStorage.removeItem(deviceChoiceKey); } catch {} }
  function storeDevice(value) { try { if(value)localStorage.setItem(deviceKey,value);else localStorage.removeItem(deviceKey); } catch {} }
  function deviceLoadingScreen() {
    canvas.innerHTML = '<main class="page password-screen"><section class="container"><div class="password-area"><div class="device-spinner" role="status" aria-label="Loading My Links"></div></div></section></main>';
    window.scrollTo(0,0); fit();
  }
  async function restoreDevice() {
    const saved = savedDevice();
    checkingDevice = Boolean(saved);
    if(!saved){render();return;}
    storeDeviceChoice(true);
    render();
    try {
      const result=await api('device_login',{device_token:saved});
      if(result.ok){token=saved;await load();}
      else {storeDevice(null);token='';}
    } catch {storeDevice(null);token='';}
    finally {checkingDevice=false;if(!token)render();}
  }
  let usernameRequest = 0;
  async function fillPasswordUsername(encryptedData) {
    const version = ++usernameRequest;
    try {
      const result = await api('username', encryptedData ? { encryptedData } : {});
      if (version !== usernameRequest) return;
      accountEmail = typeof result.email === 'string' ? result.email : '';
      const input = document.getElementById('password-username');
      if (input) input.value = accountEmail;
    } catch { /* Autofill lookup never affects password access. */ }
  }
  const contextTargets = [window.parent];
  if (window.top && window.top !== window.parent) contextTargets.push(window.top);
  let usernameContextDone = false;
  const askUsernameContext = () => { for (const target of contextTargets) { if (target !== window) try { target.postMessage({ message:'REQUEST_USER_DATA' }, '*'); } catch {} } };
  const usernameTimer = setInterval(askUsernameContext, 1000);
  setTimeout(() => { clearInterval(usernameTimer); usernameContextDone = true; }, 6000);
  window.addEventListener('message', event => {
    if (usernameContextDone || (event.source !== window.parent && event.source !== window.top) || event.data?.message !== 'REQUEST_USER_DATA_RESPONSE' || typeof event.data.payload !== 'string') return;
    let origin; try { origin = new URL(event.origin); } catch { return; }
    if (origin.protocol !== 'https:' || !/(^|\.)(gohighlevel\.com|leadconnectorhq\.com|msgsndr\.com|linkbot\.now)$/.test(origin.hostname)) return;
    usernameContextDone = true; clearInterval(usernameTimer); void fillPasswordUsername(event.data.payload);
  });
  askUsernameContext();
  void fillPasswordUsername();
  function showPasswordError(message) {
    const box = document.getElementById('password-error'); if (!box) return;
    if (lockedUntil > Date.now()) { const n = Math.max(1,Math.ceil((lockedUntil-Date.now())/60000)); box.innerHTML = `Your Account Is Locked. Try again in ${n === 1 ? '1 minute' : n+' minutes'}, or ${button('reset your password','plain','forgot')} to unlock it now.`; }
    else box.textContent = message;
    fit();
  }
  setInterval(() => { if (!token && lockedUntil > Date.now()) showPasswordError('That password is incorrect.'); }, 1000);
  function passwordProblem(value) {
    if (value.length < 8) return 'Password must be at least 8 characters.';
    if (!/[A-Z]/.test(value)) return 'Password must include an uppercase letter.';
    if (!/[0-9]/.test(value)) return 'Password must include a number.';
    if (!/[^A-Za-z0-9]/.test(value)) return 'Password must include a special character.';
    return '';
  }
  function passwordField(id, label) { return `<label for="${id}">${label}</label><div class="password-wrap"><input id="${id}" type="password" autocomplete="new-password" maxlength="128" required><button type="button" class="password-eye" data-action="eye" aria-label="Show password">${icon('eye')}</button></div>`; }
  function resetEmailScreen() {
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="top"><h1>Reset Password</h1></div><div class="password-area"><form class="password-box" id="reset-form" autocomplete="off"><p class="reset-text">Enter your account email and we'll send you a 6-digit code.</p><label for="reset-email">Email</label><input id="reset-email" name="email" type="email" placeholder="you@yourcompany.com" autocomplete="off" maxlength="255" required><div class="password-error" role="alert" id="reset-error"></div><button class="linkbot-button" type="submit"><span>Send Code</span></button>${button('Back','plain','back')}</form></div></section></main>`;
    window.scrollTo(0,0); fit();
    document.getElementById('reset-form').addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return; busy = true;
      const email = document.getElementById('reset-email').value; const submit = event.currentTarget.querySelector('[type=submit]'); submit.disabled = true;
      try { await api('request_reset_code', { email }); resetCodeScreen(email); }
      catch { const box = document.getElementById('reset-error'); if (box) box.textContent = 'Something went wrong. Please try again.'; }
      finally { busy = false; submit.disabled = false; }
    });
  }
  function resetCodeScreen(email) {
    canvas.innerHTML = `<main class="page password-screen"><section class="container"><div class="top"><h1>Reset Password</h1></div><div class="password-area"><form class="password-box" id="reset-form" data-email="${esc(email)}" autocomplete="off"><p class="reset-text">Enter the 6-digit code we sent to your email, then choose a new password.</p><label for="reset-code">6-Digit Code</label><input id="reset-code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]*" maxlength="6" required>${passwordField('reset-new','New Password')}${passwordField('reset-confirm','Confirm New Password')}<div class="password-error" role="alert" id="reset-error"></div><div class="password-notice" role="status" id="reset-notice"></div><button class="linkbot-button" type="submit"><span>Save Password</span></button>${button('Resend Code','plain','resend')}${button('Back','plain','back')}</form></div></section></main>`;
    window.scrollTo(0,0); fit();
    const form = document.getElementById('reset-form');
    form.addEventListener('submit', async event => {
      event.preventDefault(); if (busy) return;
      const code = document.getElementById('reset-code').value.trim();
      const password = document.getElementById('reset-new').value, confirm = document.getElementById('reset-confirm').value;
      const error = document.getElementById('reset-error');
      if (!/^\d{6}$/.test(code)) { error.textContent = 'Enter the 6-digit code from your email.'; return; }
      const problem = passwordProblem(password); if (problem) { error.textContent = problem; return; }
      if (password !== confirm) { error.textContent = "Passwords don't match."; return; }
      busy = true; error.textContent = ''; const submit = form.querySelector('[type=submit]'); submit.disabled = true;
      try {
        const result = await api('reset_with_code', { code, new_password: password });
        if (result.ok) loginScreen('Password updated. Enter your new password.');
        else error.textContent = result.error || 'Something went wrong. Please try again.';
      } catch { error.textContent = 'Something went wrong. Please try again.'; }
      finally { busy = false; submit.disabled = false; }
    });
  }
  async function load() {
    const result = await api('list'); if (result.error) throw new Error(result.error);
    links = result.links; privateLink = result.private_link; pendingWebsite = result.website;
    checkingDevice = false;
    checkingPassword = false;
    window.scrollTo(0,0); render();
    if (result.setup_guide_first_login) {
      opener = document.querySelector('[data-action=guide]'); scrollBefore = scrollY; guideOpen = true; renderGuide();
      void api('guide_seen').then(result => { if (result.error) throw new Error(result.error); }).catch(() => { const box=document.getElementById('page-error'); if(box)box.textContent='Something went wrong. Please try again.'; });
    } else if (pendingWebsite) { const website=pendingWebsite; pendingWebsite=null; openEditor(null,website); }
  }
  function groups() {
    const counts = new Map(); for (const link of links) if (link.category) counts.set(link.category,(counts.get(link.category)||0)+1);
    return [...counts].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  }
  function validCategory() {
    if(category==='__off')return links.some(link=>!link.is_on)?category:'';
    return category&&links.some(link=>link.category===category)?category:'';
  }
  function ordered() {
    const cats = groups().map(x=>x[0]);
    if(category==='__off')return links.filter(x=>!x.is_on).sort((a,b)=>b.created_at.localeCompare(a.created_at));
    return links.filter(x=>!category||x.category===category).sort((a,b)=> {
      if(a.is_on!==b.is_on)return a.is_on?-1:1;
      if(!category&&a.is_on){const ai=a.category?cats.indexOf(a.category):cats.length,bi=b.category?cats.indexOf(b.category):cats.length;if(ai!==bi)return ai-bi;}
      return b.created_at.localeCompare(a.created_at);
    });
  }
  const fields = [
    {key:'url',label:'URL',required:true,max:2048,placeholder:'Example: https://www.yourwebsite.com/pricing'},
    {key:'full_title',label:'Full Title',required:true,max:120,hint:'Name the exact offer, so your AI never mixes up your links.',placeholder:'Example: 12-Week Executive Coaching Program for business owners ready to scale',short:'Example: 12-Week Executive Coaching Program'},
    {key:'button_name',label:'Button Name',required:true,max:25,counter:true,hint:'The short name shown on the button. Each must be unique.',placeholder:'Example: Executive Coaching'},
    {key:'who_its_for',label:"Who It's For",required:true,max:250,multi:true,counter:true,placeholder:'Example: Business owners earning $250K+ a year who want 1-on-1 help growing their team',short:'Example: Business owners earning $250K+ a year'},
    {key:'details',label:'Details',required:true,max:5000,multi:true,counter:true,hint:'The more details you add, the better.\n(Pro Tip: Paste your link into ChatGPT and ask for a list of key details under 5,000 characters.)',placeholder:'Example:\n• 12 weekly 1-on-1 coaching calls on Zoom\n• Custom growth plan built in the first week\n• Monthly payment plan available\n• Includes a workbook and lifetime community access'},
    {key:'extra_notes',label:'Extra Notes',max:400,multi:true,counter:true,hint:'Anything else your AI should know before it shares this link.',placeholder:'Example: LinkedIn visitors get 10% off with code LINKEDIN10',short:'Example: LinkedIn visitors get 10% off'},
    {key:'category',label:'Category',max:30},
    {key:'price',label:'Price',max:40,placeholder:'Example: $2,500'},
  ];
  function chart(link) {
    const order = phone ? ['full_title','url','who_its_for','details','extra_notes','price'] : ['full_title','details','url','who_its_for','price','extra_notes'];
    return `<div class="chart">${order.filter(key=>!phone||link[key]).map(key=> {
      const field=fields.find(x=>x.key===key);let value=link[key];if(key==='url')value=value.replace(/^https?:\/\//,'');
      return `<div class="chart-cell chart-label">${esc(field.label)}</div><div class="chart-cell chart-value ${key==='url'?'url':''} ${key==='price'?'price':''} ${value?'':'none'}"><span class="clamped">${esc(value||'None added')}</span></div>`;
    }).join('')}</div>`;
  }
  function render() {
    if(checkingDevice||checkingPassword){deviceLoadingScreen();return;}
    if(!token){loginScreen();return;}
    const tabScroll=canvas.querySelector('.tabs')?.scrollLeft??0;
    const cats=groups();const offCount=links.filter(x=>!x.is_on).length;category=validCategory();
    canvas.innerHTML = `<main class="page"><section class="container"><div class="top"><h1 aria-hidden="true">My Links</h1><div class="top-actions">${button('Setup Guide','linkbot-button setup-guide-button','guide')}${phone?'':button('Add Link','linkbot-button add','add','plus')}</div></div><div class="tabs-wrap"><div class="tabs" role="tablist" aria-label="Link categories">${[['',links.length],...(offCount?[['__off',offCount]]:[]),...cats].map(([name,count])=>`<button type="button" role="tab" aria-selected="${category===name}" class="tab ${category===name?'selected':''}" data-category="${esc(name)}">${esc(name==='__off'?'Off Links':(name||'All'))}<small>(${count})</small></button>`).join('')}</div></div><div class="cards">${links.length ? ordered().map(link=>`<article class="card ${link.is_on?'':'off'}" data-id="${link.id}"><div class="card-top"><button type="button" class="icon-button" data-action="edit" title="Edit link" aria-label="Edit ${esc(link.button_name)}">${icon('pencil')}</button><button type="button" class="icon-button trash" data-action="delete" title="Delete link" aria-label="Delete ${esc(link.button_name)}">${icon('trash')}</button><h2 class="card-name">${esc(link.button_name)}</h2>${switchHtml(link.is_on,'toggle',link.id)}</div>${chart(link)}<div class="card-actions">${button('Edit','white-button','edit','pencil')}${button('Delete','white-button trash','delete','trash')}</div></article>`).join('') : '<p class="empty">No links yet. Click Add Link to get started.</p>'}</div><div class="form-error" id="page-error" role="alert"></div></section></main>`;
    fit();
    const tabs=canvas.querySelector('.tabs');if(tabs){tabs.scrollLeft=tabScroll;const hint=document.createElement('div');hint.className='category-scroll-hint';hint.setAttribute('aria-hidden','true');tabs.parentElement.appendChild(hint);}bindCategoryScrolling(tabs);
  }
  function newDraft() { return {url:'',full_title:'',button_name:'',who_its_for:'',details:'',extra_notes:'',category:'',price:'',is_on:true,is_main_website:false,included:{extra_notes:true,category:true,price:true}}; }
  let guideOpen = false;
  let guideSizeObserver;
  function guideActiveStep(circleCenters, threshold, scrollTop, scrollHeight, clientHeight) {
    if(scrollTop<=0)return 0;
    if(scrollHeight>clientHeight&&scrollTop+clientHeight>=scrollHeight-1)return circleCenters.length-1;
    let active=0;
    circleCenters.forEach((center,index)=>{if(center<=threshold)active=index;});
    return active;
  }
  function updateGuideActiveStep() {
    const overlay=document.getElementById('sg-overlay');
    if(!overlay)return;
    const circles=[...overlay.querySelectorAll('.sg-step>.sg-dot')];
    if(!circles.length)return;
    const rect=overlay.getBoundingClientRect();
    const threshold=rect.top+overlay.clientTop+overlay.clientHeight/3;
    const centers=circles.map(circle=>{const rect=circle.getBoundingClientRect();return rect.top+rect.height/2;});
    const active=guideActiveStep(centers,threshold,overlay.scrollTop,overlay.scrollHeight,overlay.clientHeight);
    circles.forEach((circle,index)=>circle.classList.toggle('sg-active',index===active));
  }
  function fitGuide() {
    const root=document.getElementById('sg-root'), wrap=document.getElementById('sg-wrap');
    if(!root||!wrap)return;
    const tablet=!phone&&document.documentElement.clientWidth<1440;
    const guideScale=tablet?(document.getElementById('sg-overlay')?.clientWidth||document.documentElement.clientWidth)/1440:1;
    const overlay=document.getElementById('sg-overlay');
    const topSpacer=overlay?.querySelector('.popup-top-spacer');
    if(phone&&overlay&&!topSpacer){const spacer=document.createElement('div');spacer.className='popup-top-spacer';spacer.setAttribute('aria-hidden','true');overlay.prepend(spacer);}
    else if(!phone&&topSpacer)topSpacer.remove();
    root.classList.toggle('sg-phone',phone);
    root.classList.toggle('sg-tablet',tablet);
    root.style.width=tablet?'1440px':'100%';
    root.style.setProperty('--ml-gap-scale',tablet?'1':String(document.documentElement.clientWidth/(phone?390:1440)));
    root.style.transform=tablet?`scale(${guideScale})`:'none';
    root.style.transformOrigin='top left';
    root.style.setProperty('--guide-outer-radius',`${8/guideScale}px`);
    const intro=root.querySelector('.sg-hd .sg-T');
    if(intro){
      intro.style.setProperty('font-size','17px');
      const baseSize=parseFloat(getComputedStyle(intro).fontSize);
      const range=document.createRange();range.selectNodeContents(intro);
      const naturalWidth=range.getBoundingClientRect().width/guideScale;
      const availableWidth=intro.getBoundingClientRect().width/guideScale;
      if(naturalWidth>availableWidth&&availableWidth>0){
        intro.style.setProperty('font-size',`${baseSize*availableWidth/naturalWidth}px`,'important');
        // Correct font-engine rounding using the same measured-width ratio.
        const fittedWidth=range.getBoundingClientRect().width/guideScale;
        if(fittedWidth>availableWidth){
          const fittedSize=parseFloat(getComputedStyle(intro).fontSize);
          intro.style.setProperty('font-size',`${fittedSize*availableWidth/fittedWidth}px`,'important');
        }
      }
    }
    wrap.style.width='100%';
    wrap.style.height=phone||tablet?`${root.offsetHeight*guideScale}px`:'';
    if(phone){
      const popup=root.querySelector('.sg-pop'), steps=[...root.querySelectorAll('.sg-step')];
      const first=steps[0],last=steps[steps.length-1];
      if(popup&&first&&last){
        const popupLeft=popup.getBoundingClientRect().left;
        const top=first.getBoundingClientRect().top+parseFloat(getComputedStyle(first,'::before').top);
        const height=last.getBoundingClientRect().bottom-top;
        root.style.setProperty('--guide-line-height',`${height}px`);
        for(const step of steps){
          const section=step.querySelector('.sg-card,.sg-fq4');if(!section)continue;
          const rect=step.getBoundingClientRect(), lane=(popupLeft+section.getBoundingClientRect().left)/2;
          step.style.setProperty('--guide-lane-left',`${lane-rect.left-1}px`);
          const segmentTop=rect.top+parseFloat(getComputedStyle(step,'::before').top);
          step.style.setProperty('--guide-line-offset',`${top-segmentTop}px`);
        }
      }
    }
    updateGuideActiveStep();
  }
  function renderGuide() {
    guideSizeObserver?.disconnect();
    document.getElementById('sg-overlay')?.remove();
    const overlay=document.createElement('div');overlay.id='sg-overlay';overlay.className='overlay';overlay.style.top=`${scrollBefore/scale}px`;
    overlay.innerHTML=`<div id="sg-wrap"><div id="sg-root" role="dialog" aria-modal="true" aria-label="Setup Guide"><div class="sg-pop"><div class="sg-hd"><div><div class="sg-k">LinkBot</div><div class="sg-h">Setup Guide</div><div class="sg-T" style="font-size:17px;margin-top:8px">Five quick steps to get the most out of your links.</div></div><button type="button" class="sg-x" aria-label="Close"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div><div class="sg-tl"><div class="sg-step"><div class="sg-dot">01</div><div><div class="sg-sh">What callers see</div><div class="sg-card" style="background:linear-gradient(180deg,#f7f9ff,#eef3ff)"><div class="sg-row3"><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg></div><div><div class="sg-t">Websites open live</div><div class="sg-T">Most websites open right on top of the call, so callers can scroll, read, and tap around while they keep talking with your assistant.</div></div></div><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg></div><div><div class="sg-t">PDFs open live</div><div class="sg-T">PDFs open right on the screen during the call to read along with your assistant, and callers can automatically save a copy to keep.</div></div></div><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/></svg></div><div><div class="sg-t">Blocked websites</div><div class="sg-T">Some sites block their pages from showing inside other apps on their end, so those links wait and open the moment the call ends.</div></div></div><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg></div><div><div class="sg-t">Login and payment pages</div><div class="sg-T">Login and payment pages block other apps on their end for account safety, so those links wait and open the moment the call ends.</div></div></div><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m10 9 5 3-5 3z"/></svg></div><div><div class="sg-t">Videos play after</div><div class="sg-T">A video's sound would play right over your assistant and cut into the conversation, so videos wait and start the moment the call ends.</div></div></div><div class="sg-pill3"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg></div><div><div class="sg-t">Links stay saved</div><div class="sg-T">Every link your assistant shares stays on the caller's screen after the call ends, so they can go back and open them any time.</div></div></div></div></div></div></div><div class="sg-step"><div class="sg-dot">02</div><div><div class="sg-sh">Fill in your links</div><div class="sg-card"><div class="sg-tg"><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7V4h16v3M9 20h6M12 4v16"/></svg></div><div class="sg-t">Button name</div></div><ul><li>Keep it short, like Book a Call, so the name fits and callers know exactly what they're clicking on.</li><li>Give every link a unique name so your AI assistant never mixes them up or shares the wrong one.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></div><div class="sg-t">Details</div></div><ul><li>Your AI assistant learns everything about this link from here, along with your main website.</li><li>Add as much detail as possible in clear, short answers with everything the AI should know.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/></svg></div><div class="sg-t">Who it's for</div></div><ul><li>Your AI assistant reads this to decide which caller should get each link and when to share it.</li><li>Describe the person this link is for in detail, like who they are and what they are looking for.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/></svg></div><div class="sg-t">Price and category</div></div><ul><li>Your assistant says the price when asked, and each category becomes a tab on your page.</li><li>Enter the price or range, leave it blank if free, and keep categories few and clear.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg></div><div class="sg-t">Main website</div></div><ul><li>Only turn this on for your home page, your AI will learn your whole site from there.</li><li>Have more than one business or offer? Turn this on for the main website of every one you have.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="16" rx="2"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/></svg></div><div class="sg-t">Booking links</div></div><ul><li>With a connected calendar, your AI assistant will book, reschedule, and cancel appointments.</li><li>If it's not connected, your AI will send this link instead for callers to book appointments with you.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16" cy="12" r="3"/></svg></div><div class="sg-t">Turn off or delete</div></div><ul><li>Turning a link off hides it from callers but saves everything, so you can turn it back on anytime.</li><li>Deleting a link removes it for good, so only delete links you are sure you will never share again.</li></ul></div><div class="sg-tp"><div class="sg-tph"><div class="sg-ii"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 7a7 7 0 0 1 11.6-1L20 9M4 15l2.3 3A7 7 0 0 0 17.9 17"/></svg></div><div class="sg-t">Keep links updated</div></div><ul><li>When your prices or offers change, edit the link and click Save so your assistant stays current.</li><li>Keep your Details current, so your assistant never shares an old price or an offer that ended.</li></ul></div></div></div></div></div><div class="sg-step sg-ai"><div class="sg-dot">03</div><div><div class="sg-sh">Let AI write it for you</div><div class="sg-card sg-b"><div class="sg-ai3"><div><div style="width:30px;height:30px;border-radius:50%;background:#fff;color:#1a54f0;font-weight:800;display:grid;place-items:center">1</div><div class="sg-T" style="color:#fff">Copy the prompt, then open a new chat in ChatGPT, Claude, or any AI tool you like, and paste it in.</div></div><div><div style="width:30px;height:30px;border-radius:50%;background:#fff;color:#1a54f0;font-weight:800;display:grid;place-items:center">2</div><div class="sg-T" style="color:#fff">After the prompt, type or paste your link into the same message at the bottom, then press Enter.</div></div><div><div style="width:30px;height:30px;border-radius:50%;background:#fff;color:#1a54f0;font-weight:800;display:grid;place-items:center">3</div><div class="sg-T" style="color:#fff">Paste each answer into its own box, Button Name, Details, Who it's for, and Category, then save.</div></div></div><div style="background:#fff;border-radius:18px;padding:22px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px"><div style="font-size:18px;font-weight:800;color:#0b1530">Your copy-and-paste prompt</div><button type="button" class="linkbot-button sg-copy"><span><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy Prompt</span></button></div><div class="sg-prompt sg-f" style="height:240px">I'm adding a link to my AI phone assistant. The assistant talks with people who visit my page, answers their questions, and shares the links that fit what they need. It can only say what I write, so I need clear, accurate information.

First, open and read my link if you can. Then, if anything important is missing, ask me a few short questions before writing.

Then write these four things:

1) BUTTON NAME (2 to 4 words): a short, clear name for the button, like "Book a Call," "See Our Prices," or "Free Guide."

2) DETAILS (80 to 200 words): everything my assistant needs to explain this link. Include whatever applies:
- What it is and what they'll find when they open it
- Key details: prices, times, dates, steps, features, locations, or whatever matters for this kind of link
- What makes it special or worth opening
- The questions people usually ask about it, with the answers
- Who it's best for, and when someone should NOT pick it
Write in plain, friendly sentences. No bullet points or emojis.

3) WHO IT'S FOR (one sentence, 10 to 25 words): the specific kind of person this link is right for.

4) CATEGORY (1 to 2 words): a simple group name, like "Services," "Pricing," "Booking," or "Free Guides."

Never make anything up. If you don't know something, write [ADD: what's missing] so I can fill it in.

My link: [paste your link]
Anything else I know about it: [prices, notes, details, or leave blank]</div></div></div></div></div><div class="sg-step"><div class="sg-dot">04</div><div><div class="sg-sh">Test your links</div><div class="sg-card"><div class="sg-pc"><div class="sg-callc"><div><div style="font-size:20px;font-weight:800">Make a test call</div><div class="sg-T" style="margin-top:6px">Open your page and talk to it the way a real customer would.</div></div><div class="linkbot-button sg-callbtn"><span><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>Call My Page</span></div></div><div><div class="sg-k" style="margin-bottom:14px;padding-left:31px">Test questions and the results you should get</div><div class="sg-tbl"><div class="sg-tr" style="grid-template-columns:1fr 56px 1fr;padding:16px 30px"><div><span class="sg-say" style="font-size:15px">What can you help me with?</span></div><div class="sg-arrow"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div><div class="sg-hear" style="font-size:15px">It asks what you need, then suggests a link</div></div><div class="sg-tr" style="grid-template-columns:1fr 56px 1fr;padding:16px 30px"><div><span class="sg-say" style="font-size:15px">Can you send me that?</span></div><div class="sg-arrow"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div><div class="sg-hear" style="font-size:15px">The right link shows up on your screen</div></div><div class="sg-tr" style="grid-template-columns:1fr 56px 1fr;padding:16px 30px"><div><span class="sg-say" style="font-size:15px">What's the difference?</span></div><div class="sg-arrow"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div><div class="sg-hear" style="font-size:15px">It goes over each option, one at a time</div></div><div class="sg-tr" style="grid-template-columns:1fr 56px 1fr;padding:16px 30px"><div><span class="sg-say" style="font-size:15px">How do I book an appointment?</span></div><div class="sg-arrow"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div><div class="sg-hear" style="font-size:15px">It books you in, or sends your booking link</div></div></div></div></div><div class="sg-fixw"><div class="sg-fixh"><div style="font-size:20px;font-weight:800">If something isn't right</div><div class="sg-T">Fix it in My Links, then call your page again to hear the change.</div></div><div class="sg-fixg"><div class="sg-fx"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/></svg></div><div><div class="sg-t">Shared Wrong Link</div><div class="sg-T">Make Who it's for more specific, so each link clearly fits one kind of caller.</div></div></div><div class="sg-fx"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/></svg></div><div><div class="sg-t">Couldn't Answer Something</div><div class="sg-T">Add the missing facts to Details, like prices, steps, and common questions.</div></div></div><div class="sg-fx"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="16" rx="2"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/></svg></div><div><div class="sg-t">Shared Link Too Early</div><div class="sg-T">Say in Who it's for exactly when to share it, so it waits for that moment.</div></div></div><div class="sg-fx"><div class="sg-bi"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/></svg></div><div><div class="sg-t">Mixed Up Links</div><div class="sg-T">Give every link its own clear name, so no two links sound like the same thing.</div></div></div></div></div></div></div></div><div class="sg-step"><div class="sg-dot">05</div><div><div class="sg-sh">Common questions</div><div class="sg-fq4"><div class="sg-fi sg-open"><div class="sg-ft"><span>Why wasn't my link shared?</span></div><div class="sg-fa">Check that the link is turned on, and that its Details clearly say who it fits and when to share it.</div></div><div class="sg-fi sg-open"><div class="sg-ft"><span>Why did it say something wrong?</span></div><div class="sg-fa">It only knows your main website and your links' Details, so add any missing or corrected facts there and call again.</div></div><div class="sg-fi sg-open"><div class="sg-ft"><span>Why didn't my link open during the call?</span></div><div class="sg-fa">Some sites block being shown inside other pages, so those links wait and open for callers the moment the call ends.</div></div><div class="sg-fi sg-open"><div class="sg-ft"><span>Why won't my button name fit?</span></div><div class="sg-fa">Button names need to fit on one line so they don't get cut off on the caller's screen, and must be 25 characters or less.</div></div></div></div></div></div><div class="sg-gfoot"></div></div></div></div></div>`;
    canvas.appendChild(overlay);document.body.style.overflowY='hidden';fitGuide();syncFloatingAdd();
    overlay.addEventListener('scroll',updateGuideActiveStep,{passive:true});
    guideSizeObserver=new ResizeObserver(fitGuide);guideSizeObserver.observe(overlay.querySelector('.sg-pop'));
    overlay.addEventListener('click',event=>{if(!event.target.closest('.sg-pop'))closeGuide();});
    overlay.querySelector('.sg-x').addEventListener('click',closeGuide);
    overlay.querySelector('.sg-copy').addEventListener('click',async()=>{
      const text=overlay.querySelector('.sg-prompt').textContent;
      try { await navigator.clipboard.writeText(text); } catch {
        const input=document.createElement('textarea');input.value=text;input.style.cssText='position:fixed;top:0;left:0;opacity:0;pointer-events:none';overlay.appendChild(input);input.select();document.execCommand('copy');input.remove();overlay.querySelector('.sg-copy').focus({preventScroll:true});
      }
    });
    const call=overlay.querySelector('.sg-callbtn');call.setAttribute('role','link');call.tabIndex=0;
    const openPage=()=>{if(privateLink)window.open(privateLink,'_blank','noopener');else showPaused();};
    call.addEventListener('click',openPage);call.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openPage();}});

    overlay.querySelector('.sg-x').focus({preventScroll:true});
  }
  function showPaused(){
    const popup=document.createElement('div');popup.className='overlay';popup.id='paused-overlay';popup.style.top=`${scrollBefore/scale}px`;popup.style.zIndex='12';popup.style.background='rgba(16,24,40,.45)';
    popup.innerHTML=`<div class="paused-pop" role="alertdialog" aria-modal="true" aria-labelledby="paused-title"><button type="button" class="paused-x" aria-label="Close">${icon('close')}</button><h2 id="paused-title" class="paused-t">Your assistant is paused.</h2><p class="paused-d">Please reactivate your LinkBot.</p></div>`;
    canvas.appendChild(popup);
    popup.querySelector('.paused-x').addEventListener('click',closePaused);
    popup.addEventListener('click',event=>{if(event.target===popup)closePaused();});
    popup.querySelector('.paused-x').focus({preventScroll:true});
  }
  function closePaused(){document.getElementById('paused-overlay')?.remove();document.querySelector('.sg-callbtn')?.focus({preventScroll:true});}

  function closeGuide(){guideSizeObserver?.disconnect();guideOpen=false;document.getElementById('sg-overlay')?.remove();document.body.style.overflowY='';opener?.focus({preventScroll:true});fit();if(pendingWebsite){const website=pendingWebsite;pendingWebsite=null;openEditor(null,website);}}
  function openEditor(link,prefill={}) {
    opener=document.activeElement;scrollBefore=scrollY;
    draft=Object.assign(newDraft(),link||prefill);draft.included={extra_notes:!link||Boolean(link.extra_notes),category:!link||Boolean(link.category),price:!link||Boolean(link.price)};
    initial=JSON.stringify(draft); errors={};if(draft.button_name.trim().length>25)errors.button_name='Maximum 25 characters';renderModal();
  }
  function fieldHtml(field) {
    const included=field.required||draft.included[field.key];const value=draft[field.key]||'';
    return `<div class="field ${Object.hasOwn(errors,field.key)?'field-error':''}" data-field="${field.key}"><div class="field-label"><label class="field-title" for="field-${field.key}">${field.required?'':`<input type="checkbox" data-include="${field.key}" ${included?'checked':''} aria-label="Include ${esc(field.label)}">`}${esc(field.label)}${field.required?'<span class="required">*</span>':''}</label>${field.hint?`<p class="field-hint">${esc(field.hint)}</p>`:''}</div><div class="field-value"><div class="input-wrap ${field.multi?'multiline':''} ${field.key==='details'?'details':''} ${included?'':'disabled'}">${field.multi?`<textarea id="field-${field.key}" data-key="${field.key}" maxlength="${field.max}" placeholder="${esc(included?(phone&&field.short?field.short:field.placeholder||''):'Not included')}" ${included?'':'disabled'}>${esc(value)}</textarea>`:`<input id="field-${field.key}" data-key="${field.key}" maxlength="${field.max}" value="${esc(value)}" placeholder="${esc(included?(phone&&field.short?field.short:field.placeholder||''):'Not included')}" ${included?'':'disabled'} autocomplete="off">`}${field.counter?`<span class="counter">${value.length.toLocaleString('en-US')} / ${field.max.toLocaleString('en-US')}</span>`:''}${field.key==='category'?'<div class="category-ghost" aria-hidden="true"></div>':''}<span class="validation" role="alert">${Object.hasOwn(errors,field.key)?`${esc(errors[field.key])}<b>!</b>`:''}</span></div></div></div>`;
  }
  function attachCounterPulse(input) {
    const counter=input.parentElement.querySelector('.counter');if(!counter)return;
    let animation;
    function overflow(count) {
      const selected=(input.selectionEnd??0)-(input.selectionStart??0);
      return !input.disabled&&count>0&&input.value.length-selected+count>input.maxLength;
    }
    function pulse() {
      animation?.cancel();
      const gray=getComputedStyle(counter).color;
      const red=getComputedStyle(document.documentElement).getPropertyValue('--red').trim();
      animation=counter.animate([
        {color:red,transform:'scale(1)',offset:0},
        {color:red,transform:'scale(1.15)',offset:1/6},
        {color:red,transform:'scale(1)',offset:1/3},
        {color:red,transform:'scale(1.15)',offset:1/2},
        {color:red,transform:'scale(1)',offset:2/3},
        {color:gray,transform:'scale(1)',offset:1}
      ],{duration:900,easing:'ease-in-out'});
    }
    input.addEventListener('beforeinput',event=>{
      if(event.inputType?.startsWith('insert')&&overflow(event.data?.length??(event.inputType==='insertLineBreak'?1:0)))pulse();
    });
    input.addEventListener('keydown',event=>{
      if(!event.ctrlKey&&!event.metaKey&&!event.altKey&&!event.isComposing&&
        (event.key.length===1||(event.key==='Enter'&&input.tagName==='TEXTAREA'))&&overflow(1))pulse();
    });
    input.addEventListener('paste',event=>{if(overflow(event.clipboardData?.getData('text/plain').length??0))pulse();});
  }
  function switchFieldHtml(key,title,description,action) {
    return `<div class="field switch-field ${errors[key]?'field-error':''}" data-field="${key}"><div class="field-label"><span class="field-title">${title}</span></div><div class="field-value switch-value"><div><p class="switch-desc">${description}</p>${key==='is_main_website'?`<p class="switch-error" role="alert">${esc(errors[key]||'')}</p>`:''}</div>${key==='is_main_website'?switchHtml(draft.is_main_website,action,'','Main Website'):switchHtml(draft.is_on,action)}</div></div>`;
  }
  function capitalizeLinkField(key, value) {
    const title = key === 'button_name' || key === 'full_title';
    const sentence = key === 'details' || key === 'who_its_for' || key === 'extra_notes';
    if (!title && !sentence) return value;
    const starts = title ? /(^|[^\p{L}\p{N}'’])(\p{Ll})/gu : /(^\s*|[.!?]\s+)(\p{Ll})/gu;
    return value.replace(starts, (match, prefix, letter) => {
      const upper = letter.toUpperCase();
      return prefix + (upper.length === letter.length ? upper : letter);
    });
  }
  function capitalizeLinkInput(input) {
    if (!draft || input.disabled) return;
    const fixed = capitalizeLinkField(input.dataset.key, input.value);
    if (fixed === input.value) return;
    input.value = fixed;
    draft[input.dataset.key] = fixed;
    if (input.tagName === 'TEXTAREA') grow(input);
  }
  function renderModal() {
    document.getElementById('editor-overlay')?.remove(); if(!draft)return;
    const overlay=document.createElement('div');overlay.id='editor-overlay';overlay.className='overlay';overlay.style.top=`${scrollBefore/scale}px`;
    overlay.innerHTML=`<div class="popup-top-spacer" aria-hidden="true"></div><form class="modal" id="link-form" role="dialog" aria-modal="true" aria-labelledby="modal-title" novalidate><div class="modal-top"><h2 id="modal-title">${draft.id?'Edit Link':'Add Link'}</h2><button type="button" class="icon-button close" data-action="close" aria-label="Close">${icon('close')}</button></div><div class="form-chart">${fields.map(fieldHtml).join('')}${switchFieldHtml('is_main_website','Main Website','Turn this on for the main website of each business or offer you have.','draft-main-toggle')}${switchFieldHtml('is_on','Link Status','Turn this off to hide this link from callers, without deleting anything.','draft-toggle')}</div><div class="form-error" id="form-error" role="alert"></div><div class="form-bottom"><div class="form-actions">${button('Cancel','white-button','close')}<button type="submit" class="linkbot-button" ${busy?'disabled':''}><span>Save Link</span></button></div></div></form>`;
    canvas.appendChild(overlay);document.body.style.overflowY='hidden';syncFloatingAdd();
    overlay.addEventListener('click',e=>{if(e.target===overlay)askClose();});
    overlay.querySelectorAll('textarea').forEach(grow);
    overlay.querySelector('#link-form').addEventListener('submit',save);
    if(busy)setSaveLoading(overlay.querySelector('[type=submit]'),true);
    overlay.querySelectorAll('[data-key]').forEach(input=>{
      attachCounterPulse(input);
      input.addEventListener('blur',()=>capitalizeLinkInput(input));
      input.addEventListener('input',()=>{
        draft[input.dataset.key]=input.value;
        if(input.dataset.key==='url'&&!mainWebsiteConflict(input.value,draft.id)){delete errors.is_main_website;showMainWebsiteError();}
        delete errors[input.dataset.key];input.closest('.field').classList.remove('field-error');input.parentElement.querySelector('.validation').textContent='';
        if(input.dataset.key==='button_name'&&input.value.trim().length>25){errors.button_name='Maximum 25 characters';input.closest('.field').classList.add('field-error');input.parentElement.querySelector('.validation').textContent=errors.button_name;}
        if(input.tagName==='TEXTAREA')grow(input);
        const count=input.parentElement.querySelector('.counter');if(count)count.textContent=`${input.value.length.toLocaleString('en-US')} / ${Number(input.maxLength).toLocaleString('en-US')}`;
        if(input.dataset.key==='category')suggestCategories(input);
      });
      if(input.dataset.key==='category') input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const first=input.closest('.field-value').querySelector('[data-suggestion]');if(first){input.value=first.dataset.suggestion;draft.category=input.value;clearSuggestions(input);}}});
    });
    overlay.querySelectorAll('[data-include]').forEach(input=>input.addEventListener('change',()=>{draft.included[input.dataset.include]=input.checked;renderModal();}));
    overlay.querySelector('[data-key]')?.focus({preventScroll:true});
  }
  function grow(input) {
    const visual=1;const minimum=input.dataset.key==='details'?(phone?104:130):(phone?36:42);
    input.style.height='0px';const height=Math.max(minimum/visual,input.scrollHeight);input.style.height=`${height}px`;input.parentElement.style.setProperty('--box-height',`${height*visual}px`);
  }
  function clearSuggestions(input){input.closest('.field-value').querySelector('.suggestion-list')?.remove();input.parentElement.querySelector('.category-ghost').textContent='';}
  function suggestCategories(input) {
    clearSuggestions(input);if(!input.value)return;
    const matches=groups().map(x=>x[0]).filter(x=>x.toLowerCase().startsWith(input.value.toLowerCase())&&x.toLowerCase()!==input.value.toLowerCase()).sort((a,b)=>a.length-b.length||a.localeCompare(b));
    if(!matches.length)return;
    input.parentElement.querySelector('.category-ghost').innerHTML=`<strong>${esc(input.value)}</strong>${esc(matches[0].slice(input.value.length))}`;
    const list=document.createElement('div');list.className='suggestion-list';list.innerHTML=matches.map(x=>`<button type="button" data-suggestion="${esc(x)}">${esc(x)}</button>`).join('');input.closest('.field-value').appendChild(list);
    list.addEventListener('click',e=>{const b=e.target.closest('[data-suggestion]');if(b){draft.category=b.dataset.suggestion;input.value=draft.category;clearSuggestions(input);input.focus();}});
  }
  function values() { const result={}; for(const field of fields)result[field.key]=!field.required&&!draft.included[field.key]?null:(draft[field.key]||'').trim();result.is_on=draft.is_on;result.is_main_website=draft.is_main_website===true;if(draft.id)result.id=draft.id;return result; }
  function markErrors() {
    for(const field of fields){const row=document.querySelector(`[data-field="${field.key}"]`);row.classList.toggle('field-error',Object.hasOwn(errors,field.key));row.querySelector('.validation').innerHTML=Object.hasOwn(errors,field.key)?`${esc(errors[field.key])}<b>!</b>`:'';}
    showMainWebsiteError();
    const first=document.querySelector('.field-error');first?.scrollIntoView({block:'center'});
  }
  function setSaveLoading(submit,saving) {
    if(saving)submit.style.width=`${submit.getBoundingClientRect().width/scale}px`;
    else submit.style.width='';
    submit.disabled=saving;submit.classList.toggle('saving',saving);
    submit.setAttribute('aria-busy',String(saving));
    submit.innerHTML=saving?'<span><i class="save-spinner" aria-hidden="true"></i>Saving…</span>':'<span>Save Link</span>';
  }
  async function save(event) {
    event.preventDefault();if(busy)return;event.currentTarget.querySelectorAll('[data-key]').forEach(capitalizeLinkInput);errors={};const link=values();for(const field of fields)if(field.required&&!link[field.key])errors[field.key]='';
    if(link.button_name.length>25)errors.button_name='Maximum 25 characters';
    if(links.some(row=>row.id!==draft.id&&normalizedLinkUrl(row.url)===normalizedLinkUrl(link.url)))errors.url='This link is already saved. Add any extra details to that link instead.';
    for(const row of links)if(row.id!==draft.id){if(row.full_title.trim().toLowerCase()===link.full_title.toLowerCase())errors.full_title='Title already exists';if(row.button_name.trim().toLowerCase()===link.button_name.toLowerCase())errors.button_name='Button name already exists';}
    if(link.is_main_website&&mainWebsiteConflict(link.url,draft.id))errors.is_main_website='This website already has a main website link.';
    if(Object.keys(errors).length){markErrors();return;}
    busy=true;const submit=event.currentTarget.querySelector('[type=submit]');setSaveLoading(submit,true);
    try { const result=await api('save',{link});if(result.errors){errors=result.errors;markErrors();return;}if(result.error)throw new Error(result.error);
      const index=links.findIndex(x=>x.id===result.link.id);if(index>=0)links[index]=result.link;else links.push(result.link);
      closeEditor();render();showSaved();
      void api('summary',{id:result.link.id,version:result.link.updated_at}).catch(()=>{});
      void api('snapshot',{id:result.link.id,version:result.link.updated_at}).catch(()=>{});
    }catch(e){const box=document.getElementById('form-error');if(box)box.textContent=e.message;}
    finally{busy=false;setSaveLoading(submit,false);}
  }
  function showSaved(){document.getElementById('saved-note')?.remove();clearTimeout(savedNoteTimer);const note=document.createElement('div');note.id='saved-note';note.className='note';note.setAttribute('role','status');note.textContent='Link saved';document.body.appendChild(note);savedNoteTimer=setTimeout(()=>note.remove(),2000);}
  function closeEditor(){draft=null;initial='';errors={};document.getElementById('editor-overlay')?.remove();document.body.style.overflowY='';opener?.focus({preventScroll:true});fit();}
  function askClose(){if(busy)return;if(JSON.stringify(draft)!==initial)showConfirm('discard');else closeEditor();}
  function showConfirm(kind,id=''){
    confirmation={kind,id};const overlay=document.createElement('div');overlay.className='overlay';overlay.id='confirm-overlay';overlay.style.top=`${scrollBefore/scale}px`;overlay.style.zIndex='11';
    const deleting=kind==='delete';overlay.innerHTML=`<div class="popup-top-spacer" aria-hidden="true"></div><div class="modal confirm" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title"><h2 id="confirm-title">${deleting?'This link will be removed permanently.':'You have unsaved changes.'}</h2><div class="form-error" id="confirm-error" role="alert"></div><div class="form-actions">${button(deleting?'Cancel':'Keep Editing','white-button','confirm-cancel')}${button(deleting?'Delete':'Discard',deleting?'linkbot-button delete-button':'linkbot-button','confirm-ok')}</div></div>`;
    canvas.appendChild(overlay);document.body.style.overflowY='hidden';syncFloatingAdd();overlay.querySelector('button').focus({preventScroll:true});
  }
  function closeConfirm(){confirmation=null;document.getElementById('confirm-overlay')?.remove();if(!draft)document.body.style.overflowY='';else document.querySelector('#editor-overlay [data-action=close]')?.focus({preventScroll:true});syncFloatingAdd();}
  document.addEventListener('click',async event=>{
    const tab=event.target.closest('[data-category]');if(tab){category=tab.dataset.category;render();return;}
    const control=event.target.closest('[data-action]');if(!control)return;const action=control.dataset.action;const id=control.dataset.id||control.closest('.card')?.dataset.id;
    if(action==='forgot'){resetEmailScreen();return;}
    if(action==='back'){loginScreen();return;}
    if(action==='resend'){if(busy)return;busy=true;control.disabled=true;const email=document.getElementById('reset-form')?.dataset.email||'';try{await api('request_reset_code',{email});const note=document.getElementById('reset-notice');if(note)note.textContent='If that email matches this account, a code is on its way.';}catch{const box=document.getElementById('reset-error');if(box)box.textContent='Something went wrong. Please try again.';}finally{busy=false;control.disabled=false;}return;}
    if(action==='eye'){const input=control.parentElement.querySelector('input');const show=input.type==='password';input.type=show?'text':'password';control.innerHTML=icon(show?'eyeoff':'eye');control.setAttribute('aria-label',show?'Hide password':'Show password');return;}
    if(action==='eye-login'){const input=control.parentElement.querySelector('input');const show=input.type==='password';input.type=show?'text':'password';control.innerHTML=checkoutEyeIcon(show);control.setAttribute('aria-label',show?'Hide password':'Show password');control.setAttribute('aria-pressed',String(show));return;}
    if(action==='guide'){opener=control;scrollBefore=scrollY;guideOpen=true;renderGuide();return;}
    if(action==='guide-close'){closeGuide();return;}
    if(action==='add'){openEditor();return;}
    if(action==='edit'){openEditor(links.find(x=>x.id===id));return;}
    if(action==='close'){askClose();return;}
    if(action==='draft-toggle'){draft.is_on=!draft.is_on;const row=control.closest('.switch-group');row.classList.toggle('off',!draft.is_on);row.querySelector('span').textContent=draft.is_on?'ON':'OFF';control.setAttribute('aria-checked',String(draft.is_on));return;}
    if(action==='draft-main-toggle'){if(!draft.is_main_website&&mainWebsiteConflict(draft.url,draft.id)){errors.is_main_website='This website already has a main website link.';showMainWebsiteError();return;}delete errors.is_main_website;showMainWebsiteError();draft.is_main_website=!draft.is_main_website;const row=control.closest('.switch-group');row.classList.toggle('off',!draft.is_main_website);row.querySelector('span').textContent=draft.is_main_website?'ON':'OFF';control.setAttribute('aria-checked',String(draft.is_main_website));return;}
    if(action==='delete'){opener=control;scrollBefore=scrollY;showConfirm('delete',id);return;}
    if(action==='confirm-cancel'){closeConfirm();return;}
    if(action==='confirm-ok'){if(busy)return;if(confirmation.kind==='discard'){closeConfirm();closeEditor();return;}busy=true;control.disabled=true;try{const result=await api('delete',{id:confirmation.id});if(result.error)throw new Error(result.error);links=links.filter(x=>x.id!==confirmation.id);closeConfirm();render();}catch(e){const box=document.getElementById('confirm-error');if(box)box.textContent=e.message;}finally{busy=false;control.disabled=false;}return;}
    if(action==='toggle'){if(control.disabled)return;control.disabled=true;const link=links.find(x=>x.id===id);try{const result=await api('toggle',{id,is_on:!link.is_on});if(result.error)throw new Error(result.error);link.is_on=!link.is_on;render();}catch(e){const box=document.getElementById('page-error');if(box)box.textContent=e.message;}finally{control.disabled=false;}}
  });
  document.addEventListener('keydown',event=>{
    const dialog=document.querySelector('#paused-overlay')||document.querySelector('#sg-overlay')||document.querySelector('#confirm-overlay')||document.querySelector('#editor-overlay');if(!dialog)return;
    if(event.key==='Escape'){event.preventDefault();if(document.getElementById('paused-overlay')){closePaused();return;}if(guideOpen)closeGuide();else if(confirmation)closeConfirm();else askClose();}

    if(event.key==='Tab'){const items=[...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),[tabindex="0"]')];const first=items[0],last=items[items.length-1];if(event.shiftKey&&(document.activeElement===first||!dialog.contains(document.activeElement))){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}
  });
  window.addEventListener('resize',fit);
  window.addEventListener('pagehide',()=>{token='';links=[];draft=null;const password=document.getElementById('password');if(password)password.value='';});
  window.addEventListener('pageshow',event=>{if(event.persisted){token='';links=[];draft=null;void restoreDevice();}});
  new ResizeObserver(()=>{fitGuide();spacer.style.height=`${canvas.offsetHeight*scale}px`;}).observe(canvas);
  Promise.resolve(document.fonts.ready).then(()=>restoreDevice());
})();