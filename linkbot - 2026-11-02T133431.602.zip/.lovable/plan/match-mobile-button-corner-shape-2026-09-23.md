# Match mobile button corner shape

- Keep every mobile button’s current height, width, text, alignment, color, and behavior.
- Change only mobile corner radii so each action button has the same height-to-corner proportion as the desktop “Start My Free Live Demo” button.
- Verify homepage, sign-in, and claim buttons on standard and small phone sizes; desktop and iPad remain unchanged.
