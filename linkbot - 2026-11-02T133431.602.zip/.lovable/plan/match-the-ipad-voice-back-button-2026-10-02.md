# Match the iPad voice Back button

## Change
- Compare the rendered checkout and voice-choice Back buttons at the iPad breakpoint.
- Adjust only the voice-choice button’s iPad-specific sizing so its on-screen width, height, text, and icon match checkout.
- Leave phone, desktop, layout, spacing, and all other controls unchanged.

## Verification
- Check both pages at 820×1180 and confirm equal rendered dimensions.
- Confirm the project still builds without errors.
