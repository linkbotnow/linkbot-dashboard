# Match the exact Profit Rocket blue buttons

## Changes
- Replace the current landing-page blue-button utility with the supplied exact size, typography, gloss, light sweep, shadows, lift, pressed, focus, disabled, and reduced-motion rules.
- Keep the existing button labels and destinations, but wrap each label and icon together in the required `span` so they stay above the shine.
- Apply this only to the landing page’s existing blue action buttons; leave all other content and layout unchanged.

## Verification
- Check the landing page at desktop and mobile sizes.
- Confirm the animated shine crosses on hover and that no page errors appear.
