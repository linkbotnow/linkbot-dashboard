# Mobile Features scrolling fix

## Scope
- Change only the Features section on phone widths below 640px.
- Leave desktop, iPad, Hero, spacing, sizing, content, and every other section unchanged.

## Implementation
- Keep the existing Hero pull-up behavior.
- Override only the phone Features section from sticky positioning to normal document flow, matching the existing Why LinkBot section behavior.
- Preserve the Features section’s current stacking order so it still pulls over the Hero before continuing smoothly through every card.
- Remove the phone-only Features travel measurement that exists solely for its sticky stop; retain all other phone measurements and styling.

## Verification
- Test phone scrolling at 393×852 and 320×568.
- Confirm Features rises over Hero, never stops at the header, scrolls through every card, and hands off normally to Why LinkBot.
- Confirm current spacing is unchanged and the project reports a clean build.
