# Fix the demo form footer on iPad only

## Scope
- Measure the rendered demo-form header, footer, footer text spacing, and divider at 768×1024, 820×1180, and 834×940 before changing code.
- Identify the iPad-only sizing mismatch without changing shared page scaling, the header, form, other footers, scrolling, or reveal behavior.
- Add the narrowest iPad-only correction to the demo-form footer in both homepage render paths.
- Re-measure all three iPad sizes, compare desktop and phone controls for regressions, capture the corrected iPad footer, and confirm diagnostics are clean.

## Technical details
- Keep `footer-match-header.ts` and all shared viewport/scaling files unchanged unless measurement proves the existing helper itself is wrong; if so, stop before editing.
- Limit selectors or behavior to `.demo-form-footer` on iPad dimensions only.
- Report before/after on-screen dimensions, cause, and exact changed lines.
