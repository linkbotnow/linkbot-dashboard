# Scale the homepage hero on iPad

## Scope
- Change only the homepage hero at widths from 640px through 1023px.
- Leave the header, Features, every later section, phones, and desktop unchanged.

## Implementation
- Treat the complete existing hero as one fixed composition so its internal spacing and proportions never reflow.
- Uniformly scale that composition to fit the available iPad width and height below the unchanged header.
- Reserve exactly the scaled hero height in the page so the Features section begins immediately afterward.
- Keep the existing layered-scroll behavior compatible with the fitted hero.

## Verification
- Check portrait and landscape iPad sizes, including 768×1024, 820×1180, 834×1194, and 1024×768.
- Confirm the hero fills the available area without clipping, internal spacing changes, or unintended scrolling.
- Confirm the header and all sections after the hero retain their current dimensions and appearance.
