# Refine desktop login background

## What will change
- Keep one consistent dot-grid spacing across the desktop header and page.
- Let illuminated dots continue through the final column at the edge of the left half.
- Fade the left dots into black at the top and bottom.
- Blend the blue-black left half smoothly into the black right half instead of using a hard center seam.
- Align the small copyright and support line to the right on desktop only.

## Guardrails
- Do not alter content sizing, positioning, scaling, card styling, or animation timing.
- Do not change the iPad or mobile presentation.

## Verification
- Check desktop at the current 1120 × 940 view and wider desktop sizes for even spacing, full-width illumination, smooth fades, unchanged layout, and no overflow.
- Confirm iPad and mobile remain unchanged.
