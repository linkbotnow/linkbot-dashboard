# Fix the wrong first-load layout

## Scope
- Change only the homepage’s pre-load sizing state.
- Make the first visible frame use the same geometry as the settled page on desktop and portrait mobile.
- Keep the existing desktop, mobile, iPad, and sideways-phone scrolling untouched.

## Implementation
- Give the homepage scaling wrapper a first-load marker.
- Before measurement completes, size the page with layout zoom and natural height instead of a one-screen absolute canvas.
- After measurement, preserve the existing final sizing and all current scroll behavior.

## Verification
- Test fresh, cache-disabled loads on desktop and portrait mobile under a throttled connection.
- Confirm no hero jump, immediate page scrolling, unchanged final appearance, and unchanged iPad/sideways-phone behavior.
