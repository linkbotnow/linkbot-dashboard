# Restore proportional iPad header buttons

## What will change
- Remove the iPad-only counter-scaling rules from only the public Sign In and Get Now buttons.
- Exclude those two buttons from broader iPad button sizing so they retain their exact desktop-authored dimensions and shrink only with the shared page/header scale.
- Leave the iPad header group enlargement, header height, logo, Test button, and loading/reveal behavior unchanged.

## Verification
- Measure the shared page scale and rendered button width, height, padding, and text size at desktop 1440×900 and iPad 768×1024, 820×1180, and 834×940.
- Confirm each iPad measurement equals its desktop value multiplied by the page scale.
- Record the first visible frames at all three iPad sizes and confirm no layout flash.

## Technical details
- Keep the change isolated to the iPad action-button stylesheet.
- The two public buttons will use their existing desktop declarations while inheriting the same 1.2× header-group transform as the logo's 1.2× transform; the shared outer header scale then reduces both proportionally.
