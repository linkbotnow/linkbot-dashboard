# Make lower homepage readable on mobile

## Goal
Keep the homepage’s current visual design exactly intact while making every section below Featured easy to read and naturally arranged on phones.

## Changes
- Leave the header, Hero, Featured section, desktop layout, copy, colors, cards, effects, and interactions unchanged.
- Reflow only the lower homepage sections at phone widths: stack layouts that are too compressed and enlarge their existing text and controls to readable sizes.
- Keep the same comparison cards, statistics, reviews, pricing card, security graphic, and FAQ styling; only change their mobile dimensions and arrangement.
- Remove the lower-section wide-canvas sizing that currently shrinks those sections into a miniature desktop view.

## Verification
- Review every lower section at 393×852 and confirm readable text, no clipping, and no horizontal overflow.
- Compare Hero and Featured before and after to confirm they did not change.
- Check the desktop homepage to confirm its layout is unchanged.
