# Phone Landscape Uses the Desktop View

## Change
- Update the shared site-wide viewport rule so a sideways phone uses the full desktop-width presentation.
- Keep portrait mobile, iPad, and desktop behavior unchanged.
- Apply this at the root level so existing and future pages inherit it automatically, including Sign In.

## Verification
- Check Sign In and the other current pages in phone portrait and phone landscape.
- Confirm landscape shows the desktop composition without clipping or unexpected scrolling.
