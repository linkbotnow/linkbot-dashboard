# Header “.Now” arrival animation

## Goal
Keep the header “.Now” mark visible by default everywhere, while replaying its existing fall only when arriving on the homepage.

## Changes
- Make the suffix’s resting CSS fully visible and change the fall animation to `backwards` fill mode.
- Trigger the existing animation directly from homepage presence rather than waiting for page load.
- Remove the animation from login and every other non-home page.
- Restart it on homepage route arrivals and persisted back-forward cache restores, without reacting to scroll, drawers, forms, or ordinary re-renders.
- Preserve the existing duration, easing, stagger, placement, sizing, colors, and 2D motion.

## Verification
- Check first load, refresh, route navigation, browser Back, and persisted `pageshow` behavior.
- Check no replay during homepage interactions or scroll.
- Compare portrait phone, landscape phone, and desktop; confirm non-home pages stay visible and static.
