# Voice page scrolling and footer correction

## Changes
- Keep the voice step in normal document flow so its header spacer, content, and footer move together with the page.
- Reuse the claim form footer’s exact class list and markup so its height, padding, colors, text size, and placement match.
- Restore the pre-Prompt-111 portrait-phone card width while retaining the newer roomy section spacing.
- Prevent the voice page or its footer from flex-growing into leftover viewport space; short pages show white space above a normal-height footer, while long pages scroll naturally.

## Verification
- Compare voice and form footer dimensions and computed text size.
- Capture full-page screenshots at desktop 1440×900, 1150×1300, iPad 820×1180, iPhone 14 portrait/landscape, and iPhone 16 portrait/landscape.
- Confirm both cards and the complete footer are reachable, nothing forms a separate scroll area, and the first visible frame remains stable.
