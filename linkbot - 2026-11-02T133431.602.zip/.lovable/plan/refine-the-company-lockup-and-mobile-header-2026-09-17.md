# Refine the company lockup and mobile header

## Changes
- Scale the complete LinkBot company lockup down slightly as one unit, preserving every internal size and spacing relationship.
- Keep the mobile header attached to the top edge while scrolling on every page where it appears.
- Leave all other header content, page content, behavior, colors, and spacing unchanged.

## Verification
- Check the lockup proportions and mobile header position on representative phone sizes.
- Confirm no other visible page elements changed.
