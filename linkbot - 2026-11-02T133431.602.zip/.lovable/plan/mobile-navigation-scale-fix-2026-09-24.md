# Mobile navigation scale fix

## Goal
Keep every phone page at its original loaded size whenever navigation occurs, including checkout → browser Back, without changing any layout or desktop/tablet behavior.

## Changes
- Detect phone route restoration and browser Back/Forward navigation.
- Reset only a retained browser zoom greater than the normal loaded scale; leave already-correct pages untouched.
- Restore the existing pinch-zoom allowance immediately after the reset.
- Keep the existing homepage canvas dimensions, visuals, and all non-phone behavior unchanged.

## Verification
- Test home → checkout → browser Back at 393×852 and 320×568.
- Repeat after zooming checkout before pressing Back.
- Confirm home, checkout, and sign-in each return to scale 1 with no horizontal overflow or page errors.
