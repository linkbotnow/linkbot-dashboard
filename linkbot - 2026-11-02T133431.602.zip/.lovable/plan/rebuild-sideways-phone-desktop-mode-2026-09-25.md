# Rebuild sideways-phone desktop mode

## Scope
- Remove and rebuild only the special sideways-phone mode.
- A sideways phone will show the existing desktop presentation exactly as it is.
- Portrait mobile, its scroller, actual iPad, and actual desktop remain unchanged.

## Implementation
- Keep the existing desktop and iPad layouts untouched.
- Replace only the orientation-specific switch that selects desktop presentation on a sideways phone.
- Do not edit the portrait phone stacking, sticky sections, measurements, spacing, or scroll behavior.

## Verification
- Compare portrait phone before and after for identical geometry and scrolling.
- Verify sideways phone selects desktop width and desktop section behavior.
- Verify actual iPad and desktop remain unchanged.
