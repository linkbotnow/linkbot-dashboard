# Match slide 3 to slide 1 on desktop and iPad

## Scope
- Keep slide 1, phone layouts, content, styling, and scrolling unchanged.
- Reuse slide 1’s existing desktop/iPad outer hero sizing for slide 3.
- Fit slide 3’s complete content as one composition within that same width and height, without changing internal spacing.
- Leave the shared header unchanged; it will continue using the same full-width desktop/iPad frame already used by slide 1.

## Verification
- Compare slide 1 and slide 3 bounds at desktop and multiple iPad portrait/landscape sizes.
- Confirm both hero backgrounds reach the exact viewport edges and have matching section bounds beneath the header.
- Confirm slide 3 content is fully visible, layered scrolling still works, and phone rendering is unchanged.
