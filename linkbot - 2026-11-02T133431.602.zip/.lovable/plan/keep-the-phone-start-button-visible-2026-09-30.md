# Keep the phone start button visible

## Scope
- Edit only `src/components/mobile/MobileHome.tsx`.
- Affect only the upright-phone homepage’s first and live-demo views.
- Preserve the hero section heights, the hidden 160px Features delay, all sticky stacking, and every non-phone layout.

## Implementation
- Replace the cached largest-height reading with one captured visible-height reading: the smaller of a temporary `100svh` probe and `window.innerHeight`.
- Capture that height only at scale 1 on initial load, after fonts settle, and after a real width change; if loading begins zoomed, retain the current layout and retry when scale returns to 1.
- Guard every first-view and live-demo hero geometry read behind the same exact scale-1 check.
- For each hero, compute equal outer space above the eyebrow and below the button.
- Adjust only the existing vertical gaps first. Preserve the phone mockup/card composition as one unit; use the existing whole-content fit only when the available height cannot be met through gap adjustment alone.
- Keep height-only browser-bar changes and scrolling from triggering measurements.

## Verification
- Test both hero views at `375×553`, `375×667`, `390×664`, `390×844`, `402×690`, and `402×874`.
- At scroll zero, confirm the header, all hero content, and CTA are visible, with matching outer gaps.
- Confirm the hero section boundaries and Features start remain unchanged.
- Emulate an initial scale of 2, confirm no sizing writes occur, then return to scale 1 and confirm the first valid layout is applied.
- Confirm no console/page errors and a clean build.
