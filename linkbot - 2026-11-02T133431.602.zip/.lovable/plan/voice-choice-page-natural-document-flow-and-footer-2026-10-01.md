# Voice choice page: natural document flow and footer

## Changes
- Remove the voice page’s viewport-height measurement, fitted-height state, orientation-specific height recalculation, fixed-page overflow lock, and card sizing based on available screen height.
- Keep the existing first-paint reveal protection, but make it depend only on fonts and stable width/layout frames so the page never flashes an interim layout.
- Put the voice content in normal document flow with normal vertical scrolling on desktop, iPad, upright phones, and sideways phones.
- Show the existing LinkBot footer after the cards on every device.
- Give upright phones fixed, balanced authored spacing between the header area, title/subtitle, cards, and footer. Keep one shared phone composition so different phone widths scale it proportionally rather than reflowing by height.
- Preserve the cards, copy, Back button behavior, header, selection state, confetti, and checkout transition.

## Isolation
- Change only `src/components/claim/VoiceChoice.tsx` unless verification reveals a selector outside that file that targets only this page.
- Do not alter `/claim` form mode or any other page.

## Verification
- Capture full-page screenshots showing the complete page and footer at desktop 1440×900, iPad 820×1180, iPhone 14 upright/sideways, and iPhone 16 upright/sideways.
- Confirm each viewport scrolls naturally from the top through both cards to the footer, and the first visible layout does not jump.
- Confirm the project build remains clean.
