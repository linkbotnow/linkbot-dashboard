# Make resized mobile scrolling match fresh mobile scrolling

## Scope
- Change only the homepage transition from desktop width into phone width.
- Preserve the existing phone scrolling calculations and appearance exactly.
- Do not change portrait phone, iPad, desktop, sideways-phone, spacing, or styling.

## Implementation
- Make the existing phone scroll setup re-run when the viewport crosses below 640px.
- Reuse the exact current phone measurement routine rather than introducing another scrolling method.
- Run the existing cleanup when crossing back above 639px so stale phone measurements cannot persist.

## Verification
- Compare a fresh 393×852 load with the same page resized from 1280×900 to 393×852.
- Confirm identical section positions, sticky offsets, scroll samples, and Features → Why LinkBot handoff.
- Confirm 393×852 fresh mobile, 834×940 iPad, 1280×900 desktop, and sideways phone remain unchanged.
