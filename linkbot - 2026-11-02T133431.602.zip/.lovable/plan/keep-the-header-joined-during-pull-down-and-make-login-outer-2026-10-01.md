# Keep the header joined during pull-down and make `/login` outer space black

## Changes
- Replace the separately fixed shared headers with document-flow sticky headers, preserving their reserved height, scale, appearance, and current route behavior. This keeps the header and page in the same moving scroll surface during browser bounce and pull-to-refresh.
- Remove only the voice-step override that currently repositions the shared header separately, because the shared flow rule will cover that page too.
- Mark `/login` at the document level while it is mounted and force only the browser-owned outer canvas for that route to the existing black/night color.
- Prevent the sideways Chrome section-color observer from replacing `/login`’s black outer canvas with the blue color sampled from login content.
- Do not alter page dimensions, viewport rules, first-paint reveal timing, content, or any non-login background.

## Verification
- Compare settled layouts before and after at desktop, iPad, iPhone 14, and iPhone 16 in both orientations.
- Simulate an in-progress top pull on `/`, `/claim` form, `/claim` voice step, and `/login`; confirm header and page remain joined.
- Emulate Safari and Chrome user agents for both phone sizes and orientations.
- Confirm sideways Chrome `/login` shows black in all space outside the page.
- Capture verification screenshots and check the preview build and runtime logs.
