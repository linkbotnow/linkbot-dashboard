# Stabilize screen scaling

## Goal
Keep every page in one consistent desktop composition at every screen width. The entire composition scales proportionally, so spacing, alignment, and element relationships do not reflow between devices.

## Changes
- Restore a single fixed 1440px design canvas around the existing pages.
- Scale that canvas with CSS transforms instead of browser `zoom`, preserving Chrome and Safari compatibility.
- Measure the scaled canvas height so scrolling and sticky behavior remain correct.
- Keep section backgrounds edge-to-edge because the scaled canvas always matches the viewport width.
- Remove the old unused `zoom` implementation to prevent competing scaling rules.
- Do not change text, colors, branding, button behavior, demo timing, form behavior, or section content.

## Verification
- Compare the home, demo form, live call, and link form at desktop, tablet, and phone widths.
- Confirm layouts retain identical proportions and do not rearrange.
- Confirm no horizontal clipping, black side borders, overlap, or broken scrolling in Chromium; use standards-based transforms compatible with Safari.
