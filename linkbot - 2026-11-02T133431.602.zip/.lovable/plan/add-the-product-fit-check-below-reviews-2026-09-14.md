# Add the product fit-check below reviews

## Changes
- Add a new interactive four-question section immediately below the reviews and above the footer.
- Match the supplied reference structure and animation while using the site’s existing blue, navy, white, typography, spacing, and button treatment.
- Rewrite every question, answer, and result specifically for the LinkedIn AI Voice Employee: profile traffic, response timing, lead follow-up, and the value of qualified conversations.
- Keep the paths honest: a strong fit receives a clear recommendation; other paths explain when the product may be less urgent without mentioning internal systems.
- Send the result action to the existing free live-demo form on this page; include Previous Question and Start Over behavior.
- Leave the reviews, header, hero, forms, feature cards, pricing, and all other sections unchanged.

## Technical details
- Reuse the already-installed Motion and Lucide packages; do not reinstall or change dependencies.
- Build the questionnaire as a focused component and add scoped styles so it cannot affect existing page elements.
- Use the project’s existing button component for all questionnaire controls.

## Verification
- Complete every answer branch and confirm Previous Question, Start Over, and the demo action work.
- Confirm the section sits directly under reviews, preserves the fixed desktop composition, and has no browser errors.
