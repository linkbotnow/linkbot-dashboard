# Fix phone rotation on the voice choice page

## Changes
- Detect physical-phone portrait versus landscape inside the voice choice step instead of relying on the temporary CSS viewport width during rotation.
- In portrait, preserve the existing fitted two-card stack and recompute its height after rotation settles so returning upright exactly matches a fresh upright opening.
- In landscape, remove the voice-page-only fixed-height and overflow locks, render the existing 1440px desktop composition through the site’s established sideways-phone scaling, and allow this page alone to scroll through both cards.
- Keep desktop, iPad, card styling, confetti, text, and navigation behavior unchanged.

## Technical details
- Scope orientation classes and overflow rules to `.vc-page` and physical phones only.
- Re-run voice-page height and readiness measurements at the existing rotation settle points so transient browser dimensions cannot become the retained portrait size.
- Keep the global viewport and scrolling behavior unchanged for every other page.

## Verification
- Capture iPhone 14 and iPhone 16 at fresh portrait, landscape top, landscape bottom, and portrait after rotating back.
- Compare fresh and returned portrait card geometry and confirm they are identical.
- Confirm landscape matches the scaled desktop arrangement and the full cards are reachable by scrolling.
- Check the current build result after the change.
