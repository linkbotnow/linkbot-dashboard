# Slow the upright phone Features rise

## Scope
- Add CSS only for the Features layer inside `.mobile-home-root` on upright phones.
- Do not alter the Hero, JavaScript, sideways-phone mode, iPad, desktop, or content below Features.

## Implementation
- Add a guarded `@supports (animation-timeline: scroll())` rule under the existing phone breakpoint and portrait orientation.
- Attach a root-scroll-driven animation to the existing Features layer for the first `var(--mh-screen-h)` of scrolling.
- Use only 2D `translateY`: start at zero, build a temporary downward lag approximating half scroll speed while Features crosses the action button, then return to zero by the end of the first screen.
- Keep unsupported browsers on the current behavior with no fallback changes.

## Verification
- Check 390×844 and 402×874 in Chromium with scroll-driven animation support.
- Confirm the Hero remains fixed, the action button stays visible longer, and Features returns to its unchanged position after one screen.
- Confirm the project reports a clean build and no runtime errors.
