# Layered Feature Cards Scroll

## Goal
Create a desktop-only, reversible layered transition around the existing Hero, Features, and Why LinkBot sections without changing their design, dimensions, spacing, content, or natural document heights.

## Behavior
1. Keep the existing normal document flow as the fallback.
2. As the Hero reaches the transition point, hold its visible surface while the complete Features section rises from the viewport bottom over it.
3. After the Features top reaches the viewport top, let the Features section continue through at its existing natural height so every card remains accessible and unchanged.
4. Near the end of Features, hold its final visible surface while Why LinkBot rises from the viewport bottom over it.
5. Drive both overlaps directly from scroll position so upward scrolling reverses the exact sequence.
6. Preserve ordinary vertical scrolling on phones and when reduced motion is enabled.

## Technical approach
- Add a narrowly scoped desktop enhancement around the three existing section nodes; do not wrap them in a tall artificial runway.
- Use sticky viewport layers and scroll-linked transforms only while each boundary transition is active.
- Derive transition progress from the real section boundaries and viewport height; do not hardcode replacement section heights.
- Keep the source sections in normal flow so disabling JavaScript or motion restores Hero → Features → Why LinkBot unchanged.
- Do not use negative margins, fixed-height spacers, or clipping containers.
- Keep existing card reveals and all section styling untouched.

## Validation
- Test forward and reverse scrolling in Preview at 1280×900 and 1081×940.
- Confirm the Hero appears normally, Features visibly rises over it, all Features content scrolls, and Why LinkBot visibly rises over the final Features view.
- Confirm no blank frames, white strips, clipping, dead scroll distance, horizontal movement, console errors, or document-height changes.
- Confirm 393×852 keeps the current normal mobile flow unchanged.
- If those checks fail, remove the enhancement and leave the restored layout intact.
