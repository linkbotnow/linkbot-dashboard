# Cleaner upright-homepage pinch zoom

## Changes
- Remove the phone-homepage effect that tracks a pinched section and toggles `mh-zoom-unpin-*` classes.
- Delete the matching CSS that changes Hero or Features from pinned to relative positioning.
- Delete the broad zoom-time rule that pauses all homepage motion and removes visual effects.
- Preserve the zoom-time reviews-track simplification, permanent gradient hero glows, pinch support, two-finger demo-frame handling, and smooth return to 100%.

## Verification
- Confirm the removed class names and broad override no longer exist in the two scoped files.
- Confirm the retained Prompt 67 rules and reviews-track rule remain.
- Check the preview build and upright phone rendering at 100%.
