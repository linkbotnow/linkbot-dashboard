# Fix mobile pricing overlap

## Change
- Compare the current phone pricing card with the supplied working version.
- Correct only the phone-only spacing/layout that positions **NO CONTRACT** beside the price and above the list.
- Keep all wording, font sizes, card styling, and whole-card scaling unchanged.
- Do not touch phone scrolling, portrait layout outside pricing, iPad, or desktop.

## Verification
- Check the pricing card on multiple phone widths and confirm **NO CONTRACT** never overlaps the list.
- Confirm all elements retain the same relative positions as the working reference while the whole card scales.
- Confirm phone scrolling, iPad, desktop, and the build remain unchanged.
