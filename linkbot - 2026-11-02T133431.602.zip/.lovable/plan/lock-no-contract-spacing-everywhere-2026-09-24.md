# Lock NO CONTRACT spacing everywhere

## Change
- Use the desktop relationship between **NO** and **CONTRACT** on phones, tablets, and desktop.
- Keep both words grouped as one unit so device scaling cannot change their internal spacing.
- Preserve the current position, surrounding pricing layout, colors, and typography.

## Verification
- Compare the word gap on phone, iPad, and desktop.
- Confirm the preview remains error-free.
