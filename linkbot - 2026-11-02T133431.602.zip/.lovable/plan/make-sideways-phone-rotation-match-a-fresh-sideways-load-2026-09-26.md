# Make sideways-phone rotation match a fresh sideways load

## Confirmed cause
- Portrait phone and sideways phone use different stacking systems.
- During rotation, the browser changes orientation, viewport width, page scale, and scroll geometry in separate steps.
- The portrait stack is cleaned up through a later React state update, while the desktop stack can initialize immediately, so both systems briefly affect Hero and Features.
- The sideways desktop stack measures that temporary geometry once and keeps the portrait scroll position. Later delayed sizing checks update the outer page, but do not rebuild the homepage stacking ranges.
- A fresh sideways load starts with settled desktop geometry, one stacking system, and scroll position zero, so it works correctly.

## Sideways-phone-only fix
- Add one orientation-transition coordinator that runs only when a physical phone enters landscape.
- Immediately suspend and clear the portrait stacking state before the sideways desktop mode is exposed.
- Treat rotation into sideways mode like a fresh sideways load: return the homepage to the top, wait for the desktop viewport and scale to stabilize, then initialize the existing desktop stacking code once.
- Re-run that initialization after the existing rotation settle points so the final measurement replaces any intermediate browser geometry.
- Keep the current sideways desktop appearance and scrolling calculations; change only when they initialize during rotation.

## Isolation
- Gate the entire change with the existing physical-phone landscape detector.
- Do not alter real desktop, iPad, portrait-phone layout, portrait sticky measurements, section spacing, or content.
- Do not change the checkout Back button rule.

## Verification
- Compare portrait-to-sideways rotation against a fresh sideways load at the same phone dimensions.
- Confirm identical Hero, Features, and Why LinkBot positions and handoffs across the full scroll.
- Repeat rotation several times, including while the portrait page is already scrolled.
- Confirm portrait phone, iPad, and real desktop retain their current geometry and scrolling.
