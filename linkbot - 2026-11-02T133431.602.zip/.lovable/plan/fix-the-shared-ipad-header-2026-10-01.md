# Fix the shared iPad header

## What will change
- Remove the homepage-only iPad header overrides that distort and clip the logo and buttons.
- Make the complete iPad header use the same proportions, black background, and gray divider as the desktop header.
- Size the whole header frame together so its visible height matches the enlarged iPad section headers, rather than enlarging only its contents.
- Apply that same shared iPad header treatment to every page that displays the header.

## What will not change
- No phone or desktop styling.
- No page content, buttons, security section, scrolling, or other layouts.

## Verification
- Compare the shared header on the homepage, account setup, checkout, and sign-in pages at both common iPad widths.
- Confirm identical height and edge alignment across pages, visible gray divider where applicable, no clipping or overlap, and unchanged phone/desktop rendering.
