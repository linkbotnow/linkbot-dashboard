# Fix phone zoom in Pricing, Security, and Why LinkBot

## Changes
- Keep all existing pinch-zoom behavior and normal 100% styling unchanged.
- Add phone-homepage-only zoom rules for the Pricing and Security sections that remove costly filters, shadows, backdrop effects, layer hints, animations, transitions, and animated-element transforms only while zoom is active.
- Refine the existing IntersectionObserver coverage marker so Features becomes hidden exactly when Why LinkBot fully covers it and becomes visible immediately on the reverse crossing, without scroll listeners or scroll-time measurements.
- Keep layout, section sizes, spacing, and all desktop, iPad, sideways-phone, and other-page behavior unchanged.

## Verification
- Check 390×844 and 402×874 at 100% while scrolling down and back up slowly and quickly for missing Features content, blank gaps, or visual changes.
- Simulate the active zoom state to confirm only Pricing and Security lose the targeted heavy effects and that all normal styles return afterward.
- Confirm the preview builds cleanly and report the heavy effects found plus every changed file and line range.
