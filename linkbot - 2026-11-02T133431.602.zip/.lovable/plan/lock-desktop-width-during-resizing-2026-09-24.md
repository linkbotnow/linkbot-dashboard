# Lock desktop width during resizing

## Goal
Keep the desktop site and header flush with both browser edges throughout window resizing, without changing any desktop, iPad, or mobile design.

## Changes
- Make the desktop page frame and header update their width and scale immediately from the same viewport measurement.
- Keep the fixed 1440px composition intact; only its outer frame and proportional scale will track the browser width.
- Clip horizontal overflow at the document and scaling wrappers so no transient right-side gap or scrollbar can appear.
- Limit the new behavior to desktop widths; preserve the existing iPad and mobile paths exactly.

## Verification
- Resize the homepage repeatedly across desktop widths above the 1024px breakpoint and confirm both edges remain flush.
- Check for horizontal overflow, right-side gaps, header lag, and layout movement during resize.
- Confirm representative iPad and phone widths retain their existing geometry.
