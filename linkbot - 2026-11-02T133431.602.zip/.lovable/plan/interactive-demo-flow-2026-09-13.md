# Interactive Demo Flow

## What will change
- Keep the header visible at the top while scrolling.
- Preserve the current hero and form designs as the first two states.
- Replace the current “You’re in the queue” confirmation after submission with a third, same-height demo state on the existing dark background.
- Build that third state in the reference’s split layout: concise custom-demo copy on the left and a dark premium phone on the right.
- Start the phone in a futuristic connecting state with animated blue signal rings and moving connection details.
- Automatically transition into the live receptionist screen shown in the second reference, styled with Profit Rocket colors.
- Add a red iPhone-style end-call control at the bottom of the phone.
- After ending the call, reveal a prominent “Get Now” action in the third state.
- Keep the rest of the page unchanged.

## Interaction flow
```text
Original hero → Form → Connecting phone → Live agent → End call → Get Now
```

## Technical details
- Keep all states inside the existing first-page demo area so its background and 919px height remain stable.
- Use local React state and timed transitions only; no live voice or GHL connection yet.
- Use existing semantic colors, typography, button styling, and motion-reduction support.
- Verify the full flow, sticky header, equal heights, and no layout shifts in the live preview.
