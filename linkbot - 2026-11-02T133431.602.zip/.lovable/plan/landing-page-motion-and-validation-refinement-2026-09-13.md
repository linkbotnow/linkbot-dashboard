# Landing-page motion and validation refinement

## Changes
- Keep the review cards scrolling continuously, including while hovered or focused.
- Add restrained, repeating motion to the content containers below the opening section without changing their layout or copy.
- Add a soft blue backlight behind the selected setup step so it stands out more clearly.
- Give “Try Your Free Live Demo Here” a brief attention pulse about every ten seconds.
- Require the website field to contain a complete domain ending such as `.com`, `.ai`, or another valid suffix, with nothing missing after it.
- Match the phone’s final “Start talking” button to the existing glossy blue site buttons.
- Leave all other content, layout, and behavior unchanged.

## Verification
- Check the opening demo, form validation, below-hero motion, phone restart state, and review loop in the live page.
- Confirm the website rejects `www.profit` and accepts complete domains.
- Confirm the review loop does not pause on hover.
- Confirm reduced-motion preferences disable the new decorative movement.
