# Lock the iPad sign-in composition

## Scope
- Change only the `/login` page between 640px and 1023px wide.
- Preserve mobile and desktop layouts exactly as they are.

## Implementation
- Treat the approved second-photo iPad composition as a fixed-size canvas.
- Let it display at full size when space permits, then uniformly scale the entire composition down as the iPad narrows.
- Prevent the story text, Capture/Convert cards, checklist, and sign-in card from independently reflowing or gaining height.
- Keep the current background dots and audio animation unchanged.

## Verification
- Compare several iPad widths and heights to confirm proportions remain fixed and no scrolling appears.
- Confirm mobile and desktop measurements remain unchanged.
