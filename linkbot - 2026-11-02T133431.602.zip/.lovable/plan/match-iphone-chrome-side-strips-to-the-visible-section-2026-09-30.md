# Match iPhone Chrome side strips to the visible section

## Implementation
- Extend only the existing page-level viewport effect in `src/routes/__root.tsx`.
- Activate the strip-color observer only when the browser is Chrome on iPhone and the physical phone is sideways.
- Observe the current page’s direct top-level sections, footers, and visible FAQ drawer with a 1px center-line IntersectionObserver.
- Resolve each active element’s displayed background: use its computed solid color, otherwise the first gradient color stop, otherwise the nearest non-transparent ancestor, with `var(--color-night)` as fallback.
- Write the resolved color to the inline backgrounds of `html` and `body` only when the active section or resolved color changes.
- Rebuild observation when page content changes, without scroll listeners or per-frame work.
- Disconnect observers and remove both inline background values whenever the phone is upright, the browser is not Chrome on iPhone, or the effect unmounts.

## Verification
- Record the resolved strip color for every homepage section, footer, and open FAQ drawer.
- Confirm the behavior switches sections at the screen’s vertical center.
- Confirm Safari, upright phones, desktop, and iPad receive no inline background changes.
- Confirm no viewport text, width, scaling, layout, CSS rule, or other file changes.
