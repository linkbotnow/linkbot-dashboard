# Hide iPhone scroll indicators

## Changes
- Append CSS-only scrollbar suppression rules to the end of the global stylesheet.
- Preserve the current page scroller and all existing scrolling, layout, sizing, and sideways-phone behavior.
- Strengthen WebKit scrollbar, thumb, and track hiding for Safari and Chrome on iPhone.

## Verification
- Confirm only the global stylesheet changed.
- Confirm the site still builds and the added rules do not alter which element scrolls.
