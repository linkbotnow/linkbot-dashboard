# Lock the phone homepage before reveal

## Changes
- Keep the existing phone boot screen active based only on the boot-ready class, rather than revealing as soon as the phone homepage mounts.
- Stop clearing the boot screen during the first mount pass.
- Wait for the real site fonts, then allow the existing hero measurements and React layout updates to settle before revealing.
- Preserve the existing 2500ms emergency reveal and error fallback so the page can never remain blank.
- Leave all final dimensions, spacing, visual styling, other devices, pages, and user interactions unchanged.

## Verification
- Record first load and reload at 390×844 and 402×874 with touch emulation and 4× CPU throttling.
- Compare tracked element rectangles from the first visible frame through three seconds after reveal.
- Confirm zero position or size changes after reveal, note hidden duration, and verify the preview build remains healthy.

## Technical details
- The current early reveal is caused by the CSS `:has(.mobile-home-root)` condition and the mount-time class removal. Delayed font callbacks, initial ResizeObserver callbacks, and dependent hero state updates then finish after visibility begins.
- The readiness gate will use `document.fonts.ready` and stable animation frames; no scroll measurements, intervals, CSS zoom, or 3D transforms will be added.
