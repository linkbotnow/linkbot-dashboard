# Match the password-field arrow size

- Add one narrowly scoped style for the two `/claim` password fields so Safari’s grey Caps Lock arrow is constrained to the same on-screen size as its adjacent grey key icon.
- Leave the fields, form layout, sizing systems, and every other device/page unchanged.
- Verify both password fields in the preview and confirm the project remains error-free.
