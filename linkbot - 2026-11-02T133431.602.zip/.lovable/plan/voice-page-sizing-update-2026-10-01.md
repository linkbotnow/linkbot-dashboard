# Voice page sizing update

## Scope
Edit only `src/components/claim/VoiceChoice.tsx`. Preserve voice selection, navigation, header, colors, card styling, and all other pages.

## Changes
- Size the voice section so the existing site header plus this section equals the visible viewport height; move the existing footer outside that first-screen height so it begins below the fold.
- Retain the desktop/iPad canvas-scale measurement, but calculate the section height from the header’s rendered bottom edge and the current visual viewport. Apply the same viewport-fit behavior on phones.
- Match the title to the homepage headline exactly:
  - Manrope display font
  - weight 800
  - letter spacing `-0.035em`
  - desktop/iPad authored size `72px`, inheriting the same outer canvas scaling
  - phone rendered size derived from the upright homepage headline at the current phone width
- Increase each two-line card label to the largest size constrained by both card width and height, with equal visual inset and centered alignment.

## Verification
Check 1440×900, 1280×800, 820×1180, and 390×844. Confirm:
- the footer starts immediately after the first visible screen;
- the complete voice section remains visible before the footer on desktop and iPad;
- card labels are centered, balanced, and unclipped;
- computed title font size, weight, family, and letter spacing match the homepage headline at each viewport;
- selecting a card still proceeds normally and no page errors occur.
