# Restore Mobile Layered Section Scroll

## Goal
Make the existing Hero → Features → Why LinkBot stacking effect work on phones while leaving the already-correct desktop and iPad implementation untouched.

## Cause confirmed
- The scroll controller explicitly requires a viewport of at least 640px, so it clears itself on phones.
- Every CSS rule that creates the layered positioning, transforms, and stacking order is also inside the same desktop-only media query.
- The live phone preview confirms the controller reports `phase: off` and none of the three sections receives layered positioning.

## Changes
1. Keep the current desktop/iPad code and media query byte-for-byte unchanged.
2. Add a separate phone-only stacking style block for widths below 640px, reusing the same section classes and layer order.
3. Enable the existing measurement and scroll controller on phones without changing its desktop/iPad calculations.
4. On phones, use the existing direct scroll-position transform path rather than the CSS scroll-timeline path so the transformed 1440px canvas scale is handled consistently.
5. Keep the held background section stationary while only the incoming section rises; preserve natural Features height and reversible upward scrolling.
6. Retain all current mobile pinch-zoom safety: suspend layer updates while zoomed, avoid large shadows, and resume from a fresh measurement at normal scale.
7. Do not change section content, dimensions, spacing, colors, card layout, hero layouts, header, or any non-mobile rule.

## Validation
- Test forward and reverse scrolling at 393×852 and 320×568.
- Check both the initial hero and completed live-demo hero state.
- Confirm Hero remains fixed while Features rises, then Features remains fixed while Why LinkBot rises.
- Confirm no black/white gaps, background shaking, horizontal movement, clipped content, dead scroll distance, or browser errors.
- Recheck 834×940 and 1280×900 to confirm desktop/iPad geometry and behavior are unchanged.
