# Bring CONTRACT forward

## Change
- Adjust only the stacking order of the **CONTRACT** word so it renders in front of **NO** on phones, tablets, and desktop.
- Preserve its current size, spacing, position, and all surrounding pricing content.

## Verification
- Confirm the pricing mark renders correctly at phone and desktop sizes.
- Confirm the preview remains error-free.
