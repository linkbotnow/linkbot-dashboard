# Restore pinned headers and prevent pull-down movement

## Changes
- Restore `MobileHeader.tsx`, `DesktopHeaderMount.tsx`, the voice-step header override, and their related CSS selectors exactly to the snapshot immediately before Prompt 114, including each spacer and normal-scroll behavior.
- Keep every `/login` black outer-background change from Prompt 114 unchanged.
- Prevent only a downward overscroll gesture while the document is already at its top. Install the guard before page reveal, covering touch pull-down/pull-to-refresh and wheel/trackpad bounce without affecting upward scrolling, ordinary page scrolling, layout, spacing, or route-specific header behavior.
- Replace the Prompt 114 architecture note with the restored fixed-header rule and update the task checklist.

## Verification
- Compare pre-114 and restored header source line-for-line, then list every before/after line changed.
- Capture normal top, normal scrolled, and attempted pull-down states for `/`, `/claim`, the voice step, and `/login` under Safari and Chrome phone profiles on iPhone 14 and iPhone 16, upright and sideways.
- Repeat normal-scroll and attempted pull-down checks at iPad 820×1180 and desktop 1440×900.
- Confirm header position during normal scrolling, zero exposed separation during attempted pull-down, unchanged page geometry, black sideways `/login` outer space, no console errors, and a passing preview build.
