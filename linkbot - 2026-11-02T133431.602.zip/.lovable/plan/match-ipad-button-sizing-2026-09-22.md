# Match iPad button sizing

- Measure the existing “Start My Free Live Demo” button as the iPad reference.
- Apply that rendered height and text size to the site’s actionable buttons only at 640–1023px, preserving widths, colors, spacing, and behavior.
- Keep navigation logos, icon controls, demo step tabs, FAQ rows, and phone-demo controls unchanged because they are controls rather than site action buttons.
- Verify the homepage, sign-in, and checkout pages at portrait and landscape iPad sizes; confirm phone and desktop remain unchanged.
