# Match iPad header buttons to the logo

## What will change
- Measure the desktop logo, Sign In button, Get Now button, their padding, and their text.
- Remove only the iPad cancellation that currently prevents Sign In and Get Now from receiving the logo's exact shared enlargement.
- Keep both buttons at their desktop-authored dimensions inside the header, so the same outer scale and same 1.2× enlargement produce identical button-to-logo ratios on iPad.

## What will not change
- No changes to the logo, Test button, header height, loading/reveal behavior, desktop, phones, or page content.

## Verification
- Compare logo-to-button width, height, padding, and text ratios at desktop 1440×900 and iPad 768×1024, 820×1180, and 834×940.
- Record the first visible frames at all three iPad sizes and confirm no geometry changes after reveal.
- Confirm the preview build passes.
