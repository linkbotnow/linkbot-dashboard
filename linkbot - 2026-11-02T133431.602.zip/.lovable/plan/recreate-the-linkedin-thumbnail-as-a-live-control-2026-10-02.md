# Recreate the LinkedIn thumbnail as a live control

## Scope
- Replace only the blue thumbnail photo inside the mock LinkedIn Featured section with crisp HTML/CSS matching the current artwork.
- Make the central microphone a real button that immediately opens the existing call experience.
- Preserve the white caption box and its wording exactly as-is.
- Leave every surrounding page, layout, viewport, reveal, and interaction unchanged.

## Technical details
- Reuse the existing microphone icon, design tokens, press animation, and call state.
- Remove the thumbnail image import after the live recreation replaces it.
- Verify the thumbnail visually and confirm the microphone click reaches the call screen.
