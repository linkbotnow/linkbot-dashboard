# Review section redesign

## What will change
- Keep the existing Profit Rocket navy, blue, white, slate, and yellow-star colors.
- Rebuild only the review section as a split layout matching the reference: message and supporting details on the left, stacked review cards on the right.
- Style each review as a compact white card with an initial avatar, first name, five yellow stars, age label, and review text.
- Expand the illustrative set to ten cards while keeping the examples clearly identified as previews until verified reviews are supplied.
- Remove arrows, dots, and manual navigation controls.
- Run the cards upward continuously in a seamless loop so the first card follows the last from below, with no visible reset.
- Pause movement while a visitor hovers or focuses a review, and stop motion for visitors who request reduced motion.

## Technical details
- Update only `src/routes/index.tsx`, `src/styles.css`, and the matching roadmap item.
- Render two identical review lists in one vertical track for a mathematically seamless infinite loop.
- Use a CSS keyframe animation rather than timer-driven scrolling, avoiding jumpy end-of-list resets and unnecessary React state.
- Keep the layout fluid: stacked on narrow screens and split into two columns on larger screens.

## Verification
- Check the review section at desktop and mobile widths.
- Confirm ten unique reviews appear, no arrows are present, cards loop upward cleanly, and the browser console stays clear.
