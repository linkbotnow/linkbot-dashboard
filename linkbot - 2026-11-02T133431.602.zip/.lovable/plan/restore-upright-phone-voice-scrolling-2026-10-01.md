# Restore upright-phone voice scrolling

## Changes
- Replace the document-only pull-down check with a check that follows the touched scrollable area. Block only a true top-edge pull-down; never block ordinary upward navigation inside nested scrollers.
- On upright phones only, remove the voice page from any clipped frame behavior and let its header spacer, content, complete cards, and matching claim footer form one continuous document.
- Preserve the current voice-card dimensions while balancing the existing vertical gaps around the title, cards, and footer.
- Leave sideways phones, iPad, desktop, pinned headers, login surroundings, selection/confetti, and first-paint reveal unchanged.

## Technical details
- Scope voice layout changes to portrait physical phones and `.vc-page`.
- Determine the active vertical scroll container from the touch target’s ancestor chain; allow nested scrolling whenever that container has remaining scroll range.
- Keep the gesture guard installed before page reveal.

## Verification
- Check iPhone 14 at 390×844 and iPhone 16 at 402×874 in Safari and Chrome profiles.
- For each, capture the top, both complete cards, footer, and the returned-to-top state after scrolling down and back up.
- Confirm card dimensions, footer equivalence, no clipping, no page errors, and a clean preview build.
