# Isolate iPad button sizing

- Move every iPad-only button size override out of the shared homepage sizing block into a dedicated iPad button stylesheet.
- Keep the exact current iPad button dimensions and exceptions; this change only creates a safe boundary for future button edits.
- Leave all phone selectors, mobile measurements, sticky sections, and scrolling code untouched.
- Verify portrait-phone geometry and scrolling before and after, then confirm iPad buttons and desktop remain unchanged.
