# Restore voice card sizing and stacking

## Scope
Edit only `src/components/claim/VoiceChoice.tsx`. Preserve all text, colors, selection behavior, navigation, header, footer, and other pages.

## Changes
- Restore the taller card shape and spacing shown in the second reference image on desktop.
- Make the title visibly heavier while retaining its current wording and one-line fit behavior.
- Stack the cards on iPad, matching the third reference image.
- Stack and uniformly scale the complete card composition on phones so both cards remain above the footer without overlap at every phone height.
- Keep each card’s shape, corner treatment, shadows, and text proportions consistent while scaling.

## Verification
Check 1440×900, 1280×800, 820×1180, and 390×844, confirming desktop matches the second reference, iPad stacks, and phone cards never enter the footer.
