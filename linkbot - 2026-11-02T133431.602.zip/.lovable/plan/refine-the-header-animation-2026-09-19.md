# Refine the header animation

## Changes
- Speed up the existing sequential `.Now` letter drop while preserving its current path, bounce, sizing, and eligible pages.
- Make the initial “AI GROWTH ENGINE” reveal rise smoothly from below with the same motion language as later tagline rotations instead of appearing abruptly.
- Leave all layout, typography, spacing, wording, and other behavior unchanged.

## Verification
- Confirm the animation on the home and login pages and verify non-eligible pages remain static.
