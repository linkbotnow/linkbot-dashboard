# Make every portrait-phone page fit its screen width

## Scope
- Change portrait phones only.
- Keep the approved 393px phone presentation as the reference and scale it uniformly to each phone’s actual width.
- Preserve desktop, iPad, sideways-phone desktop mode, content, spacing, and scrolling behavior.

## Changes
- Add one shared portrait-phone width-fit calculation instead of letting fixed-size phone elements remain visually oversized on narrow screens.
- Apply it to the mobile header and every native-width phone page, including sign-in, checkout, and the homepage demo form.
- Keep the homepage’s existing 1440px canvas scaling, but ensure its separate mobile header uses the same exact phone-width fit.
- Remove horizontal spill from the fitted portrait-phone wrappers without changing any section’s authored layout.

## Verification
- Check fresh loads at 320×568, 360×640, 375×667, 393×852, and 430×932.
- Confirm the header, homepage, demo form, sign-in, and checkout each meet both screen edges without clipping or empty side space.
- Confirm homepage phone stacking and scrolling remain unchanged.
- Confirm 834px iPad, 1280px desktop, and sideways-phone mode remain unchanged.
