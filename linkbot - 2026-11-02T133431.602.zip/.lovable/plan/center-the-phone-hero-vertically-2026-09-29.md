# Center the phone hero vertically

## Scope
- Edit only `src/components/mobile/MobileHome.tsx`.
- Affect only the portrait-phone test homepage shown at `/?mobile=1`.
- Preserve the current hero size, fit calculation, horizontal spacing, stacking, boot behavior, and measurement safeguards.

## Implementation
- Add a guarded hero top-space value alongside the existing hero fit state.
- In the existing hero-fit measurement, reuse the captured viewport height, measured eyebrow-to-button height, and unchanged fit factor.
- Calculate the remaining visible space below the header after scaling the hero content.
- Set the top space to half that remainder, with a minimum of `40px × --mobile-scale`.
- Replace the hero’s fixed `160px × --mobile-scale` top padding with that computed value.
- Skip state writes when the value differs by no more than 0.5px, preserving the no-feedback-loop behavior.

## Verification
- Check `393×852`, `375×667`, `430×932`, and `400×700` at `/?mobile=1`.
- Measure space above the eyebrow and below the button; confirm each pair differs by no more than 2px.
- Confirm fit factors and horizontal spacing are unchanged.
- Scroll from top through the page and back repeatedly; confirm hero measurement writes remain zero during scrolling.
- Confirm Features still covers the pinned hero as before and the build remains clean.
