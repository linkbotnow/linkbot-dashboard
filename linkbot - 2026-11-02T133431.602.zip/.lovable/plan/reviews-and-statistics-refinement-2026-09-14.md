# Reviews and statistics refinement

## Changes
- Remove the three “24/7,” “Voice,” and “Instant” tiles from the reviews section, leaving that area focused strictly on the review message and moving review cards.
- Keep the review cards, text, movement, section colors, and layout behavior unchanged.
- Place the 39%, 41%, and 7× statistics inside one premium shared container with clear separation and the existing labels.
- Animate all three values from zero when the statistics container first scrolls into view.
- Synchronize the count durations so 39%, 41%, and 7× all reach their final values at the same moment.
- Run the counter once, preserve the final values afterward, and show final values immediately when reduced motion is requested.

## Technical details
- Update only the landing page statistics and review sections plus their scoped visual styles.
- Use an IntersectionObserver and requestAnimationFrame for a one-time, synchronized count animation.
- Keep the existing section size, copy, ordering, backgrounds, and all unrelated page elements untouched.

## Verification
- Confirm the review benefit tiles are gone and the review carousel remains unchanged.
- Confirm all counters start together, finish together, and display 39%, 41%, and 7× correctly.
- Check the result at the current smaller desktop viewport and a full desktop viewport without console errors.
