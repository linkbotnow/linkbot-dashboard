# Match every footer to the homepage footer

## Scope
- Inventory and verify the footers on the homepage, homepage live-demo form, claim form, claim voice choice, checkout, login, and the public voice/demo page.
- Treat the homepage live-demo form and public voice page as demo-page footers for the text-centering exception.
- Leave the homepage footer and both demo-page footers unchanged except where a footer color must match the homepage.

## Changes
- Use the homepage footer's existing `--color-night` background as the single footer color on every page.
- Remove or cover footer-local transparency and the login page's bottom black fade only where they make a footer appear different.
- Add a shared footer-color class to non-homepage footers without changing their dimensions, copy, typography, or links.
- Vertically center the text in the claim form, claim voice-choice, checkout, and login footers by making their existing footer box center its current text; preserve each footer's measured outer height.

## Verification
- Record before/after computed colors, visible center-point colors, footer heights, and text space above/below.
- Capture every footer at desktop 1440×900, iPad 820×1180, iPhone 14 and iPhone 16 upright and sideways.
- Confirm unchanged footer heights, no first-frame flash, no console errors, and a clean build.
