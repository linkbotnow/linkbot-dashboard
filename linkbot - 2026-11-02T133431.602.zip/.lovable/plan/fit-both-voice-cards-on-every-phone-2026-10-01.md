# Fit both voice cards on every phone

## Goal
On the voice-choice step only, keep the title, supporting line, and both voice cards visible within the phone screen below the header, with no page scrolling.

## Changes
- Adjust only `src/components/claim/VoiceChoice.tsx`.
- On phone widths, size the two-card stack from the available visible height while preserving each card’s current proportions and styling.
- Keep tablet and desktop layouts unchanged.
- Verify short and tall phone sizes, including the provided 393px-wide reference.

## Technical details
- Use the existing measured viewport height and container sizing rather than fixed per-device breakpoints.
- Ensure the card grid can shrink in both width and height, and prevent overflow on this step only.
