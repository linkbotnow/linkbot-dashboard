# Keep phone homepage stacking active with FAQ open

## Cause
- The portrait-phone stylesheet explicitly changes the Hero and Features from their normal pinned stacking positions to ordinary relative flow whenever the FAQ drawer is open.
- That open-state override, not FAQ height measurement, is what makes the page behave flat. Closing the FAQ removes the override and restores stacking.

## Change
- Remove only the open-FAQ rules that reset the Hero and Features positioning.
- Preserve the FAQ drawer's current layer order, instant open-state treatment, accordion behavior, and paused decorative animations.
- Do not add measurements or any scroll-time layout work.
- Limit the change to the existing upright-phone homepage styling.

## Verification
- On iPhone 14 (390×844) and iPhone 16 (402×874), test Safari and Chrome profiles.
- Capture the reverse-scroll sequence from the FAQ with it open, then repeat with it closed.
- Compare Hero, Features, and Why LinkBot positions to confirm identical stacking in both states.
- Confirm FAQ open/close behavior, no first-frame flash, no console errors, and a clean build.
