import { defineConfig } from 'nitro/config';

export default defineConfig({
  routeRules: {
    '/lb-widget.html': { headers: { 'Cache-Control': 'no-cache' } },
    '/lb-widget-chat.html': { headers: { 'Cache-Control': 'no-cache' } },
  },
});