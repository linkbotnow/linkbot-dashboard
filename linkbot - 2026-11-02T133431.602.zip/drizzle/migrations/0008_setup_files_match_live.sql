-- 189B: brings the setup files in line with the live database. No-op on live.
ALTER TABLE public.demo_requests ADD COLUMN IF NOT EXISTS last_name text;