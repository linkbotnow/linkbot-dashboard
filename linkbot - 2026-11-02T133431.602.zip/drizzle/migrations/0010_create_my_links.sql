CREATE TABLE public.my_links (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 ghl_location_id text NOT NULL,
 url text NOT NULL,
 button_name text NOT NULL,
 full_title text NOT NULL,
 who_its_for text NOT NULL,
 details text NOT NULL,
 extra_notes text,
 category text,
 price text,
 is_on boolean NOT NULL DEFAULT true,
 type text NOT NULL DEFAULT 'link',
 ai_summary text,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.my_links TO service_role;
ALTER TABLE public.my_links ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX my_links_button_name_unique ON public.my_links (ghl_location_id, lower(trim(button_name)));
CREATE UNIQUE INDEX my_links_full_title_unique ON public.my_links (ghl_location_id, lower(trim(full_title)));
CREATE INDEX my_links_location_idx ON public.my_links (ghl_location_id);
CREATE TABLE public.my_links_settings (
 ghl_location_id text PRIMARY KEY,
 website_prompt_shown_at timestamptz
);
GRANT ALL ON public.my_links_settings TO service_role;
ALTER TABLE public.my_links_settings ENABLE ROW LEVEL SECURITY;