CREATE OR REPLACE FUNCTION public.business_website_match_key(value text)
RETURNS text LANGUAGE sql IMMUTABLE STRICT SET search_path = public
AS $$ SELECT lower(regexp_replace(regexp_replace(regexp_replace(trim(value), '^https?://', '', 'i'), '^www\.', '', 'i'), '/$', '')) $$;
REVOKE ALL ON FUNCTION public.business_website_match_key(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.business_website_match_key(text) TO service_role;
UPDATE public.my_links AS l SET is_main_website = true WHERE EXISTS (SELECT 1 FROM public.client_slugs AS b WHERE b.ghl_location_id = l.ghl_location_id AND nullif(trim(b.website), '') IS NOT NULL AND public.business_website_match_key(l.url) = public.business_website_match_key(b.website));