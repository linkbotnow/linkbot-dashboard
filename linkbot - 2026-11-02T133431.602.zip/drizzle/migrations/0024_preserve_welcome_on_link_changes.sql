CREATE OR REPLACE FUNCTION public.new_bot_link_code(p_bot_id uuid)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_bot public.client_slugs; v_code text;
BEGIN
 SELECT * INTO v_bot FROM public.client_slugs WHERE id = p_bot_id FOR UPDATE;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'reason', 'bot_not_found'); END IF;
 IF v_bot.status <> 'active' OR v_bot.activated_at IS NULL THEN RETURN jsonb_build_object('ok', false, 'reason', 'not_active'); END IF;
 IF v_bot.link_code IS NOT NULL THEN INSERT INTO public.retired_link_codes (link_code) VALUES (v_bot.link_code) ON CONFLICT (link_code) DO NOTHING; END IF;
 v_code := public.generate_link_code();
 UPDATE public.client_slugs SET link_code = v_code WHERE id = p_bot_id;
 RETURN jsonb_build_object('ok', true, 'slug', v_bot.slug, 'link_code', v_code, 'changed', true);
END;
$function$;
CREATE OR REPLACE FUNCTION public.rename_bot_slug(p_bot_id uuid, p_new_slug text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE v_slug text := lower(btrim(p_new_slug)); v_bot public.client_slugs; v_existing public.client_slugs;
BEGIN
 SELECT * INTO v_bot FROM public.client_slugs WHERE id = p_bot_id FOR UPDATE;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'reason', 'bot_not_found'); END IF;
 IF v_bot.status <> 'active' OR v_bot.activated_at IS NULL THEN RETURN jsonb_build_object('ok', false, 'reason', 'not_active'); END IF;
 IF v_slug !~ '^[a-z0-9_-]+(\.[a-z0-9_-]+)*$' OR length(v_slug) < 3 OR length(v_slug) > 30 THEN RETURN jsonb_build_object('ok', false, 'reason', 'invalid_name'); END IF;
 IF length(v_slug) = 12 THEN RETURN jsonb_build_object('ok', false, 'reason', 'name_taken'); END IF;
 IF v_slug = v_bot.slug THEN RETURN jsonb_build_object('ok', true, 'slug', v_bot.slug, 'link_code', v_bot.link_code, 'changed', false); END IF;
 SELECT * INTO v_existing FROM public.client_slugs WHERE slug = v_slug FOR UPDATE;
 IF FOUND THEN
  IF v_existing.status NOT IN ('active','paused') AND v_existing.activated_at IS NULL AND v_existing.hold_expires_at IS NOT NULL AND v_existing.hold_expires_at < now() THEN PERFORM public.release_expired_holds(v_slug);
  ELSE RETURN jsonb_build_object('ok', false, 'reason', 'name_taken'); END IF;
 END IF;
 UPDATE public.client_slugs SET slug = v_slug WHERE id = p_bot_id;
 RETURN jsonb_build_object('ok', true, 'slug', v_slug, 'link_code', v_bot.link_code, 'changed', true);
EXCEPTION WHEN unique_violation THEN RETURN jsonb_build_object('ok', false, 'reason', 'name_taken');
END;
$function$;