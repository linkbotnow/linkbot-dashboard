CREATE OR REPLACE FUNCTION public.my_links_url_key(raw_url text) RETURNS text LANGUAGE sql IMMUTABLE STRICT SET search_path = public AS $$
WITH cleaned AS (SELECT regexp_replace(regexp_replace(btrim(raw_url), '^https?://', '', 'i'), '/$', '') AS value), parts AS (SELECT substring(value from '^[^/?#]+') AS host, substring(value from '[/ ?#].*$') AS suffix FROM cleaned)
SELECT regexp_replace(lower(host), '^www\.', '') || coalesce(suffix, '') FROM parts;
$$;
REVOKE ALL ON FUNCTION public.my_links_url_key(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.my_links_url_key(text) TO service_role;
CREATE OR REPLACE FUNCTION public.my_links_lock_url_writes() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$ BEGIN LOCK TABLE public.my_links IN SHARE ROW EXCLUSIVE MODE; RETURN NULL; END; $$;
REVOKE ALL ON FUNCTION public.my_links_lock_url_writes() FROM PUBLIC;
CREATE TRIGGER my_links_url_write_lock BEFORE INSERT OR UPDATE OF url, ghl_location_id ON public.my_links FOR EACH STATEMENT EXECUTE FUNCTION public.my_links_lock_url_writes();
CREATE OR REPLACE FUNCTION public.my_links_reject_duplicate_url() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$ BEGIN
IF EXISTS (SELECT 1 FROM public.my_links existing WHERE existing.ghl_location_id = NEW.ghl_location_id AND existing.id <> NEW.id AND public.my_links_url_key(existing.url) = public.my_links_url_key(NEW.url)) THEN
RAISE EXCEPTION USING ERRCODE = '23505', CONSTRAINT = 'my_links_unique_normalized_url', MESSAGE = 'my_links_unique_normalized_url';
END IF; RETURN NEW; END; $$;
REVOKE ALL ON FUNCTION public.my_links_reject_duplicate_url() FROM PUBLIC;
CREATE TRIGGER my_links_unique_normalized_url BEFORE INSERT OR UPDATE OF url, ghl_location_id ON public.my_links FOR EACH ROW EXECUTE FUNCTION public.my_links_reject_duplicate_url();