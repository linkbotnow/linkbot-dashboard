CREATE OR REPLACE FUNCTION public.claim_account_is_leftover(p_account_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT EXISTS (SELECT 1 FROM public.customer_accounts a WHERE a.id = p_account_id)
 AND NOT EXISTS (SELECT 1 FROM public.client_slugs b WHERE b.owner_account_id = p_account_id
 AND (b.activated_at IS NOT NULL OR b.status IN ('active','paused') OR (b.status = 'reserved' AND b.hold_expires_at > now())));
$$;
REVOKE ALL ON FUNCTION public.claim_account_is_leftover(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_account_is_leftover(uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.remove_leftover_accounts(p_account_id uuid DEFAULT NULL)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE a public.customer_accounts; removed integer := 0;
BEGIN
 LOCK TABLE public.customer_accounts, public.client_slugs IN SHARE ROW EXCLUSIVE MODE;
 FOR a IN SELECT * FROM public.customer_accounts WHERE (p_account_id IS NULL OR id = p_account_id) FOR UPDATE LOOP
  IF NOT public.claim_account_is_leftover(a.id) THEN CONTINUE; END IF;
  DELETE FROM public.checkout_passes WHERE bot_id IN (SELECT id FROM public.client_slugs WHERE owner_account_id = a.id);
  WITH gone AS (
   DELETE FROM public.client_slugs WHERE owner_account_id = a.id AND status = 'reserved' AND activated_at IS NULL AND hold_expires_at <= now() RETURNING *
  ) INSERT INTO public.security_audit_log(event_type, details) SELECT 'hold_expired', to_jsonb(gone) FROM gone;
  DELETE FROM public.customer_sessions WHERE account_id = a.id;
  DELETE FROM public.password_resets WHERE account_id = a.id;
  UPDATE public.legal_signatures SET account_id = NULL WHERE account_id = a.id;
  INSERT INTO public.security_audit_log(event_type, details) VALUES ('leftover_account_removed', jsonb_build_object('email', a.email));
  DELETE FROM public.customer_accounts WHERE id = a.id;
  removed := removed + 1;
 END LOOP;
 RETURN removed;
END;
$$;
REVOKE ALL ON FUNCTION public.remove_leftover_accounts(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.remove_leftover_accounts(uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.release_expired_holds(p_slug text DEFAULT NULL)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_count integer;
BEGIN
 WITH gone AS (
  DELETE FROM public.client_slugs WHERE status NOT IN ('active','paused') AND activated_at IS NULL
  AND hold_expires_at IS NOT NULL AND hold_expires_at < now() AND (p_slug IS NULL OR slug = p_slug) RETURNING *
 ) INSERT INTO public.security_audit_log(event_type, details) SELECT 'hold_expired', to_jsonb(gone) FROM gone;
 GET DIAGNOSTICS v_count = ROW_COUNT;
 RETURN v_count;
END;
$$;
REVOKE ALL ON FUNCTION public.release_expired_holds(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.release_expired_holds(text) TO service_role;
DO $$ BEGIN
 PERFORM cron.schedule('release-expired-link-holds', '0 * * * *', 'SELECT public.release_expired_holds(); SELECT public.remove_leftover_accounts();');
END $$;