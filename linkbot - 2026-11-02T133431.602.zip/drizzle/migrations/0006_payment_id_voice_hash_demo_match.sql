ALTER TABLE public.client_slugs ADD COLUMN IF NOT EXISTS activated_payment_id text, ADD COLUMN IF NOT EXISTS voice_sent_hash text;
CREATE INDEX IF NOT EXISTS client_slugs_activated_payment_id_idx ON public.client_slugs (activated_payment_id);
COMMENT ON COLUMN public.client_slugs.voice_sent IS 'DEPRECATED for repeat checks: replaced by voice_sent_hash';

CREATE OR REPLACE FUNCTION public.find_recent_demo_request(p_email text, p_website text, p_since timestamptz)
RETURNS TABLE(id uuid, repeat_of uuid) LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT d.id, d.repeat_of FROM public.demo_requests d
  WHERE lower(d.email) = lower(p_email) AND lower(d.website) = lower(p_website) AND d.created_at >= p_since
  ORDER BY d.created_at ASC LIMIT 1
$$;
REVOKE ALL ON FUNCTION public.find_recent_demo_request(text, text, timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.find_recent_demo_request(text, text, timestamptz) TO service_role;