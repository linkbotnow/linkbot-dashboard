ALTER TABLE public.my_links ADD COLUMN IF NOT EXISTS snapshot_blocked_at timestamptz;
CREATE TABLE public.snapshot_usage (
  month text PRIMARY KEY,
  requests integer NOT NULL DEFAULT 0
);
GRANT ALL ON public.snapshot_usage TO service_role;
ALTER TABLE public.snapshot_usage ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION public.take_snapshot_request(p_limit integer DEFAULT 90)
RETURNS boolean
LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$
  INSERT INTO public.snapshot_usage (month, requests)
  VALUES (to_char(now() AT TIME ZONE 'utc', 'YYYY-MM'), 1)
  ON CONFLICT (month) DO UPDATE SET requests = snapshot_usage.requests + 1
  WHERE snapshot_usage.requests < p_limit
  RETURNING true;
$$;
REVOKE ALL ON FUNCTION public.take_snapshot_request(integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.take_snapshot_request(integer) TO service_role;