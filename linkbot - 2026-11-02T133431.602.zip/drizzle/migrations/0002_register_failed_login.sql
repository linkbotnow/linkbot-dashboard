CREATE OR REPLACE FUNCTION public.register_failed_login(p_account_id uuid, p_max int, p_lock_minutes int)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_locked boolean;
BEGIN
  UPDATE public.customer_accounts SET
    failed_attempts = CASE WHEN failed_attempts + 1 >= p_max THEN 0 ELSE failed_attempts + 1 END,
    locked_until = CASE WHEN failed_attempts + 1 >= p_max THEN now() + make_interval(mins => p_lock_minutes) ELSE locked_until END
  WHERE id = p_account_id AND (locked_until IS NULL OR locked_until <= now())
  RETURNING (locked_until IS NOT NULL AND locked_until > now()) INTO v_locked;
  IF NOT FOUND THEN RETURN 'already_locked'; END IF;
  RETURN CASE WHEN v_locked THEN 'locked_now' ELSE 'counted' END;
END; $$;
REVOKE ALL ON FUNCTION public.register_failed_login(uuid, int, int) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.register_failed_login(uuid, int, int) TO service_role;