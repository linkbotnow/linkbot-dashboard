CREATE OR REPLACE FUNCTION public.my_links_website_host(raw_url text)
RETURNS text LANGUAGE sql IMMUTABLE STRICT SET search_path = public
AS $$
  SELECT lower(regexp_replace(regexp_replace(regexp_replace(substring(btrim(raw_url) from '(?i)^https?://([^/?#]+)'), '^.*@', ''), ':[0-9]+$', ''), '^www\.', '', 'i'));
$$;
REVOKE ALL ON FUNCTION public.my_links_website_host(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.my_links_website_host(text) TO service_role;
CREATE UNIQUE INDEX IF NOT EXISTS my_links_one_main_website_per_host
ON public.my_links (ghl_location_id, public.my_links_website_host(url))
WHERE is_main_website = true;