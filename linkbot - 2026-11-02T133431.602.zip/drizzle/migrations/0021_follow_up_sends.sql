CREATE TABLE public.follow_up_sends (
 location_id text NOT NULL,
 contact_id text NOT NULL,
 state text NOT NULL DEFAULT 'sending' CHECK (state IN ('sending','sent')),
 started_at timestamptz NOT NULL DEFAULT now(),
 sent_at timestamptz,
 PRIMARY KEY (location_id, contact_id)
);
GRANT ALL ON public.follow_up_sends TO service_role;
REVOKE ALL ON public.follow_up_sends FROM anon, authenticated;
ALTER TABLE public.follow_up_sends ENABLE ROW LEVEL SECURITY;
COMMENT ON TABLE public.follow_up_sends IS 'Server-only owner-approved follow-up sends; reservations prevent concurrent or uncertain duplicate delivery.';