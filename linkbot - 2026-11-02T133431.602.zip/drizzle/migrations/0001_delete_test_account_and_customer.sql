DO $$
DECLARE
  v_account_id uuid;
BEGIN
  SELECT id INTO v_account_id FROM public.customer_accounts WHERE lower(email) = 'test@test.com';

  CREATE TEMP TABLE _test_bot_ids ON COMMIT DROP AS
  SELECT id FROM public.client_slugs
  WHERE slug = 'linkbottest'
     OR lower(email) = 'test@test.com'
     OR (v_account_id IS NOT NULL AND owner_account_id = v_account_id);

  DELETE FROM public.customer_sessions WHERE account_id = v_account_id;
  DELETE FROM public.password_resets WHERE account_id = v_account_id;
  DELETE FROM public.checkout_passes WHERE bot_id IN (SELECT id FROM _test_bot_ids);
  DELETE FROM public.legal_signatures WHERE lower(email) = 'test@test.com' OR account_id = v_account_id;
  DELETE FROM public.billing_events WHERE client_id IN (SELECT id FROM _test_bot_ids);

  DELETE FROM public.client_slugs WHERE id IN (SELECT id FROM _test_bot_ids);
  DELETE FROM public.customer_accounts WHERE id = v_account_id;
END $$;