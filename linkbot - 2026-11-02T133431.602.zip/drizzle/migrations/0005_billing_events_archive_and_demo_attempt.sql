ALTER TABLE public.billing_events ADD COLUMN IF NOT EXISTS archived_bot_id uuid, ADD COLUMN IF NOT EXISTS archived_bot_slug text, ADD COLUMN IF NOT EXISTS archived_bot_email text;

CREATE OR REPLACE FUNCTION public.register_demo_code_attempt(p_id uuid, p_max integer DEFAULT 5)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE v_attempts integer;
BEGIN
  UPDATE public.demo_codes
     SET failed_attempts = failed_attempts + 1
   WHERE id = p_id AND used_at IS NULL AND expires_at > now() AND failed_attempts < p_max
  RETURNING failed_attempts INTO v_attempts;
  RETURN v_attempts; -- NULL when expired, used, or out of tries
END $$;
REVOKE ALL ON FUNCTION public.register_demo_code_attempt(uuid, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.register_demo_code_attempt(uuid, integer) TO service_role;