CREATE TABLE public.linkbot_app_tokens (
 company_id text PRIMARY KEY,
 access_token text,
 refresh_token text,
 expires_at timestamptz,
 updated_at timestamptz DEFAULT now()
);
GRANT ALL ON public.linkbot_app_tokens TO service_role;
ALTER TABLE public.linkbot_app_tokens ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.linkbot_location_tokens (
 location_id text PRIMARY KEY,
 access_token text,
 expires_at timestamptz,
 updated_at timestamptz DEFAULT now()
);
GRANT ALL ON public.linkbot_location_tokens TO service_role;
ALTER TABLE public.linkbot_location_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_slugs ADD COLUMN voice_choice text;
ALTER TABLE public.client_slugs ADD CONSTRAINT client_slugs_voice_choice_valid CHECK (voice_choice IS NULL OR voice_choice IN ('female','male'));
CREATE FUNCTION public.linkbot_claim_token_refresh(p_company_id text, p_version timestamptz, p_claim timestamptz) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
 UPDATE public.linkbot_app_tokens SET updated_at = p_claim WHERE company_id = p_company_id AND updated_at IS NOT DISTINCT FROM p_version AND (updated_at IS NULL OR updated_at <= now());
 RETURN FOUND;
END;
$$;
REVOKE ALL ON FUNCTION public.linkbot_claim_token_refresh(text,timestamptz,timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.linkbot_claim_token_refresh(text,timestamptz,timestamptz) TO service_role;