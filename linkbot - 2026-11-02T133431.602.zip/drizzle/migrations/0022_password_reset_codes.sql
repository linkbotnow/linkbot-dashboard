ALTER TABLE public.password_resets ADD COLUMN type TEXT NOT NULL DEFAULT 'link';
ALTER TABLE public.password_resets ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE public.password_resets ADD CONSTRAINT password_resets_type_check CHECK (type IN ('link', 'code'));
COMMENT ON COLUMN public.password_resets.type IS 'link = reset-link email code; code = 6-digit in-box reset code';
COMMENT ON COLUMN public.password_resets.attempts IS 'Wrong-code tries for type=code; code stops working at 5';