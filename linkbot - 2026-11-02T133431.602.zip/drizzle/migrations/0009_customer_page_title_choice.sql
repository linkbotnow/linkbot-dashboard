ALTER TABLE public.client_slugs
  ADD COLUMN IF NOT EXISTS page_title_choice text NOT NULL DEFAULT 'name'
  CHECK (page_title_choice IN ('name', 'business'));