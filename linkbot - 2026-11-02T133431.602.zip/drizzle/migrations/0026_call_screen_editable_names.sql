ALTER TABLE public.client_slugs ADD COLUMN call_screen_name_text text, ADD COLUMN call_screen_business_text text;
COMMENT ON COLUMN public.client_slugs.call_screen_name_text IS 'Independent edited caller screen name; NULL uses signup name.';
COMMENT ON COLUMN public.client_slugs.call_screen_business_text IS 'Independent edited caller screen business name; NULL uses signup business.';