CREATE TABLE public.call_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account text NOT NULL,
  page text,
  link_id uuid NOT NULL,
  button_name text NOT NULL,
  call_key text,
  ids text[] NOT NULL DEFAULT '{}',
  excluded_ids text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.call_shares TO service_role;
ALTER TABLE public.call_shares ENABLE ROW LEVEL SECURITY;
CREATE INDEX call_shares_account_created ON public.call_shares(account, created_at);
CREATE INDEX call_shares_ids ON public.call_shares USING gin(ids);
CREATE TABLE public.call_share_debug (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  share_id uuid REFERENCES public.call_shares(id) ON DELETE CASCADE,
  raw_request jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.call_share_debug TO service_role;
ALTER TABLE public.call_share_debug ENABLE ROW LEVEL SECURITY;
CREATE INDEX call_share_debug_created ON public.call_share_debug(created_at);
CREATE FUNCTION public.match_call_shares(p_account text, p_ids text[])
RETURNS TABLE(link_id uuid, button_name text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT DISTINCT s.link_id, s.button_name
  FROM public.call_shares s
  WHERE s.account = p_account
    AND s.created_at >= now() - interval '60 minutes'
    AND s.call_key IS NOT NULL
    AND EXISTS (
      SELECT 1 FROM unnest(s.ids) candidate
      WHERE candidate = ANY(p_ids)
        AND NOT EXISTS (SELECT 1 FROM public.call_shares excluded WHERE candidate = ANY(excluded.excluded_ids))
        AND (SELECT count(DISTINCT other.call_key) FROM public.call_shares other WHERE candidate = ANY(other.ids)) = 1
    );
$$;
REVOKE ALL ON FUNCTION public.match_call_shares(text, text[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.match_call_shares(text, text[]) TO service_role;
CREATE FUNCTION public.cleanup_call_share_debug()
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public
AS $$ DELETE FROM public.call_share_debug WHERE created_at < now() - interval '7 days'; $$;
REVOKE ALL ON FUNCTION public.cleanup_call_share_debug() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_call_share_debug() TO service_role;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
    PERFORM cron.schedule('call-share-debug-seven-days', '17 * * * *', 'SELECT public.cleanup_call_share_debug()');
  ELSE
    RAISE EXCEPTION 'pg_cron is required for seven-day debug retention';
  END IF;
END $$;