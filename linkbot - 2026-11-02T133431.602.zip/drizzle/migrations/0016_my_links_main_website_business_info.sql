ALTER TABLE public.my_links ADD COLUMN IF NOT EXISTS is_main_website boolean NOT NULL DEFAULT false;
ALTER TABLE public.my_links ADD COLUMN IF NOT EXISTS site_info text;
ALTER TABLE public.my_links ADD COLUMN IF NOT EXISTS site_info_read_at timestamptz;
ALTER TABLE public.my_links ADD COLUMN IF NOT EXISTS site_info_failed boolean NOT NULL DEFAULT false;
ALTER TABLE public.my_links_settings ADD COLUMN IF NOT EXISTS business_info text;
ALTER TABLE public.my_links_settings ADD COLUMN IF NOT EXISTS business_info_sent_at timestamptz;