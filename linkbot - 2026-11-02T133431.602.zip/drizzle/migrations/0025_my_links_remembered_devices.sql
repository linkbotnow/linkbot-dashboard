CREATE TABLE public.my_links_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid REFERENCES public.customer_accounts(id) ON DELETE CASCADE,
  ghl_location_id text NOT NULL,
  token_hash text NOT NULL UNIQUE,
  credential_version text NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.my_links_devices TO service_role;
ALTER TABLE public.my_links_devices ENABLE ROW LEVEL SECURITY;
CREATE POLICY my_links_devices_no_client_access ON public.my_links_devices FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);
CREATE INDEX my_links_devices_account_id ON public.my_links_devices(account_id);
CREATE OR REPLACE FUNCTION public.revoke_my_links_devices_on_password_change() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF OLD.password_hash IS DISTINCT FROM NEW.password_hash THEN
    UPDATE public.my_links_devices SET revoked_at = now() WHERE account_id = NEW.id AND revoked_at IS NULL;
  END IF;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.revoke_my_links_devices_on_password_change() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER customer_accounts_revoke_my_links_devices AFTER UPDATE OF password_hash ON public.customer_accounts FOR EACH ROW EXECUTE FUNCTION public.revoke_my_links_devices_on_password_change();
COMMENT ON TABLE public.my_links_devices IS 'Optional location-scoped My Links remembered-device grants; only hashed random tokens persist server-side; password changes revoke grants.';