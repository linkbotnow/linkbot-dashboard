import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { Lock, ShieldCheck } from "lucide-react";
import { useEffect, useLayoutEffect, useState, type ReactNode } from "react";
import { armRevealWatchdog, forceReveal, hardReveal, revealWhenSettled, useRevealWhenSettled } from "@/lib/boot-reveal";

import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { DesktopScale } from "@/components/layout/DesktopScale";
import { DesktopHeaderMount } from "@/components/layout/DesktopHeaderMount";
import { useMobileHomeSwitch } from "@/components/mobile/MobileHome";
import { MobileHeader } from "@/components/layout/MobileHeader";
import { HoverlessLink } from "@/components/navigation/HoverlessLink";
import { DESKTOP_CANVAS_WIDTH, isPhoneLandscapeViewport } from "@/lib/desktop-scale";
import { setHeroZoomPaused } from "@/lib/hero-pause";
import { supabase } from "@/integrations/supabase/client";
import appCss from "../styles.css?url";
import ipadButtonCss from "../styles/ipad-buttons.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { useClaimVoiceStep } from "@/lib/claim-voice-step";
import { UNSUPPORTED_DEVICE_SCRIPT } from "@/lib/unsupported-device";
import { createPortal } from "react-dom";
import { FitLine } from "@/components/FitLine";


function NotFoundComponent() {
  useRevealWhenSettled();
  // 192B: portal outside the scaled canvas so it always shows at normal size.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;
  return createPortal(
    <div className="lb-message-page">
      <title>Page not found | LinkBot</title>
      <div className="lb-message-inner">
        <div className="lb-message-lines">
          <FitLine className="lb-message-line">This page doesn't exist.</FitLine>
        </div>
        <button type="button" className="linkbot-button lb-message-button" onClick={() => { window.location.href = "https://linkbot.now/"; }}>
          <span>Go to LinkBot.Now</span>
        </button>
      </div>
    </div>,
    document.body,
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  useRevealWhenSettled();
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error instanceof Error ? error : new Error(String(error)), { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="lb-message-page">
      <div className="lb-message-inner">
        <div className="lb-message-lines">
          <FitLine className="lb-message-line">This page didn't load.</FitLine>
          <FitLine className="lb-message-line">Something went wrong on our end.</FitLine>
        </div>
        <button
          type="button"
          onClick={() => {
            router.invalidate();
            reset();
          }}
          className="linkbot-button lb-message-button"
        >
          <span>Try Again</span>
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover",
      },
      { name: "format-detection", content: "telephone=no, email=no, address=no" },
      { title: "LinkBot | AI Voice Employees for LinkedIn" },
      { name: "description", content: "Your own AI voice employee that answers, qualifies and books appointments 24/7 from a single link." },
      { name: "author", content: "LinkBot" },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "LinkBot" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "stylesheet", href: ipadButtonCss },
      { rel: "icon", href: "/favicon.ico?v=3", sizes: "any" },
      { rel: "icon", href: "/favicon.png?v=3", type: "image/png", sizes: "64x64" },
      { rel: "icon", href: "/icon-512.png?v=3", type: "image/png", sizes: "512x512" },
      { rel: "shortcut icon", href: "/favicon.ico?v=3" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png?v=3", sizes: "180x180" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Manrope:wght@400;500;600;700;800&family=Instrument+Serif:ital@1&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="pg-boot" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: UNSUPPORTED_DEVICE_SCRIPT }} />
        {/* Paint guards must exist before external styles or hydration arrive.
            Opacity also hides descendants that explicitly set visibility. */}
        <style>{`html.pg-boot body, html.mh-boot body,
          html:not(.pg-forced) .desktop-scale-frame:not(.is-measured),
          html:not(.pg-forced) .desktop-header-spacer:not(.is-measured) .desktop-header-frame {
            opacity: 0 !important;
          }
#pg-offline .pg-offline-msg {
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color: #6b7280;
  font-size: 14px;
  font-weight: 400;
  line-height: normal;
}
#pg-offline .pg-offline-btn {
  appearance: none; -webkit-appearance: none; border: 0; outline: none; text-decoration: none; cursor: pointer;
  position: relative; isolation: isolate; overflow: hidden;
  display: inline-flex; height: 44px; align-items: center; justify-content: center; padding: 0 24px;
  border-radius: 8px; white-space: nowrap;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  font-size: 12px; line-height: 1; font-weight: 700; letter-spacing: 0.01em; color: #ffffff;
  background-color: #1a54f0;
  background-color: oklch(0.52 0.24 264);
  background-image: linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0) 45%, rgba(0, 0, 0, 0.18) 100%);
  background-blend-mode: overlay;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.28), inset 0 -1px 0 rgba(0, 0, 0, 0.35), inset 0 0 0 1px rgba(255, 255, 255, 0.06), 0 1px 0 rgba(0, 0, 0, 0.18), 0 10px 22px -8px rgba(15, 23, 42, 0.35), 0 22px 48px -16px rgba(15, 23, 42, 0.28);
  transition: transform 450ms cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 450ms cubic-bezier(0.2, 0.8, 0.2, 1), filter 300ms ease;
}
#pg-offline .pg-offline-btn::before {
  content: ""; position: absolute; inset: 0 0 50% 0; z-index: 0; pointer-events: none; border-radius: inherit;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.22), rgba(255, 255, 255, 0));
}
#pg-offline .pg-offline-btn::after {
  content: ""; position: absolute; inset: 0; z-index: 1; pointer-events: none; border-radius: inherit;
  background: linear-gradient(115deg, transparent 30%, rgba(255, 255, 255, 0.28) 50%, transparent 70%);
  transform: translateX(-120%);
  transition: transform 900ms cubic-bezier(0.2, 0.8, 0.2, 1);
}
#pg-offline .pg-offline-btn > span { position: relative; z-index: 2; pointer-events: none; }
#pg-offline .pg-offline-btn:hover {
  color: #ffffff; transform: translateY(-3px) scale(1.015); filter: brightness(1.06);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.4), inset 0 -1px 0 rgba(0, 0, 0, 0.4), inset 0 0 0 1px rgba(255, 255, 255, 0.1), 0 2px 0 rgba(0, 0, 0, 0.18), 0 18px 34px -10px rgba(15, 23, 42, 0.4), 0 36px 70px -22px rgba(26, 84, 240, 0.55);
}
#pg-offline .pg-offline-btn:hover::after { transform: translateX(120%); }
#pg-offline .pg-offline-btn:active {
  transform: translateY(0) scale(0.99); filter: brightness(0.98);
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.35), inset 0 -1px 0 rgba(255, 255, 255, 0.08), 0 6px 14px -8px rgba(15, 23, 42, 0.35);
}
#pg-offline .pg-offline-track {
  display: none; position: relative; isolation: isolate; overflow: hidden;
  height: 44px; padding: 0 24px; align-items: center; justify-content: center; white-space: nowrap;
  border-radius: 8px; background: oklch(1 0 0);
  box-shadow: inset 0 0 0 1px oklch(0.91 0.012 250), 0 10px 22px -8px color-mix(in oklab, oklch(0.13 0.05 260) 22%, transparent), 0 22px 48px -16px color-mix(in oklab, oklch(0.52 0.24 264) 28%, transparent);
}
#pg-offline .pg-offline-track-label {
  position: relative; z-index: 5;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  font-size: 12px; line-height: 1; font-weight: 700; letter-spacing: 0.01em; color: #ffffff;
  -webkit-font-smoothing: antialiased; text-rendering: geometricPrecision;
}
#pg-offline .pg-offline-bar {
  position: absolute; inset: 0; width: 100%; height: 100%; z-index: 1;
  border-radius: inherit; overflow: hidden; transform: scaleX(0); transform-origin: left center;
  background-color: oklch(0.52 0.24 264);
  background-image: linear-gradient(180deg, color-mix(in oklab, oklch(1 0 0) 12%, transparent) 0%, transparent 50%, color-mix(in oklab, oklch(0.13 0.05 260) 12%, transparent) 100%);
  box-shadow: inset 0 1px 0 color-mix(in oklab, oklch(1 0 0) 28%, transparent), inset 0 -1px 0 color-mix(in oklab, oklch(0.13 0.05 260) 24%, transparent);
}
#pg-offline .pg-offline-bar.is-running { animation: pg-offline-build 10s cubic-bezier(0.22, 0.75, 0.18, 1) forwards !important; }
#pg-offline .pg-offline-bar::after {
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background: linear-gradient(108deg, transparent 40%, color-mix(in oklab, oklch(1 0 0) 30%, transparent) 50%, transparent 60%);
  transform: translateX(-130%);
  animation: pg-offline-scan 1.8s cubic-bezier(0.45, 0, 0.55, 1) infinite !important;
}
@keyframes pg-offline-build { 0% { transform: scaleX(0); } 100% { transform: scaleX(1); } }
@keyframes pg-offline-scan { 0% { transform: translateX(-140%); opacity: 0; } 25% { opacity: 0.9; } 100% { transform: translateX(240%); opacity: 0; } }
html.pg-rotate-hold body { opacity: 0 !important; }`}</style>
        <HeadContent />
        {/* Keep fixed headers and their page spacers joined by blocking only a
            downward overscroll gesture made when the complete active scroll
            chain is at its top. This runs before reveal and preserves nested
            scrollers and ordinary upward navigation. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{var pgPullY=0,pgPullStartY=0,pgPullTarget=null,pgPullLegal=false;var pgCanScrollUp=function(t){for(var n=t instanceof Element?t:null;n&&n!==document.documentElement;n=n.parentElement){var s=getComputedStyle(n),o=s.overflowY;if((o==='auto'||o==='scroll'||o==='overlay')&&n.scrollHeight>n.clientHeight+1&&n.scrollTop>0)return true}return (scrollY||document.documentElement.scrollTop||document.body.scrollTop||0)>0||((window.visualViewport&&window.visualViewport.offsetTop)||0)>0.5};addEventListener('touchstart',function(e){if(e.touches.length===1){pgPullY=pgPullStartY=e.touches[0].clientY;pgPullTarget=e.target;pgPullLegal=matchMedia('(max-width:639px)').matches&&e.target instanceof Element&&!!e.target.closest('.legal-overlay')}},{passive:true});addEventListener('touchmove',function(e){if(e.touches.length!==1||pgPullLegal)return;var y=e.touches[0].clientY;if(y>pgPullY&&(!matchMedia('(max-width:639px)').matches||y-pgPullStartY>10)&&!pgCanScrollUp(pgPullTarget))e.preventDefault();pgPullY=y},{passive:false});addEventListener('touchend',function(){pgPullTarget=null;pgPullLegal=false},{passive:true});addEventListener('touchcancel',function(){pgPullTarget=null;pgPullLegal=false},{passive:true});addEventListener('wheel',function(e){if(e.deltaY<0&&!pgCanScrollUp(e.target))e.preventDefault()},{passive:false})}catch(e){}",
          }}
        />
        {/* Portrait phones use one authored 393px layout viewport. The browser
            fits that viewport to the physical screen before first paint, so the
            complete phone UI scales uniformly on narrower and wider phones. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "window.__pgCssReady=function(){try{return getComputedStyle(document.documentElement).getPropertyValue('--pg-css-ready').trim()==='1'}catch(e){return true}};window.__pgReloadStaleOnce=function(){try{var k='pgStaleReload:'+location.pathname+location.search,now=Date.now(),previous=Number(sessionStorage.getItem(k));if(previous&&now-previous<30000)return;sessionStorage.setItem(k,String(now));location.reload()}catch(e){}};var pgCssProbePending=false;window.__pgCheckStaleCss=function(){if(pgCssProbePending)return;var l=document.querySelector('link[rel=\"stylesheet\"][href*=\"/assets/styles\"]');if(!l)return;pgCssProbePending=true;fetch(l.href,{cache:'no-store'}).then(function(r){if(r.status===404)window.__pgReloadStaleOnce()}).catch(function(){}).finally(function(){pgCssProbePending=false})};addEventListener('error',function(e){var l=e.target;if(l&&l.tagName==='LINK'&&l.rel==='stylesheet'&&l.href.indexOf('/assets/styles')!==-1){window.__pgCheckStaleCss();window.__pgShowOffline()}},true);addEventListener('pageshow',function(e){if(e.persisted&&!window.__pgCssReady()){window.__pgCheckStaleCss();window.__pgShowOffline()}});window.__pgShowOffline = function(){ if(!window.__pgCssReady())window.__pgCheckStaleCss(); if (document.getElementById('pg-offline')) return; var d = document.documentElement; d.classList.add('pg-boot'); var box = document.createElement('div'); box.id = 'pg-offline'; box.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;text-align:center;padding:24px'; var msg = document.createElement('div'); msg.className = 'pg-offline-msg'; var track = document.createElement('div'); track.className = 'pg-offline-track'; track.setAttribute('role', 'status'); track.setAttribute('aria-label', 'Loading'); var bar = document.createElement('span'); bar.className = 'pg-offline-bar'; track.appendChild(bar); var trackLabel = document.createElement('span'); trackLabel.className = 'pg-offline-track-label'; trackLabel.textContent = 'Reconnecting...'; track.appendChild(trackLabel); var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'pg-offline-btn'; var btnLabel = document.createElement('span'); btnLabel.textContent = 'Try Again'; btn.appendChild(btnLabel); box.appendChild(msg); box.appendChild(track); box.appendChild(btn); d.appendChild(box);  var cssLink = document.querySelector('link[rel=\"stylesheet\"][href*=\"/assets/styles\"]'); var checkUrl = cssLink ? cssLink.href : location.href; var done = false; var phaseTimer; var poll; var stop = function(){ done = true; clearTimeout(phaseTimer); clearInterval(poll); window.removeEventListener('online', check); }; var check = function(){ if (done) return; if (window.__pgCssReady()) { stop(); box.remove(); if (window.__pgHardReveal) window.__pgHardReveal(); else { d.classList.add('pg-forced'); d.classList.remove('pg-boot','mh-boot'); } return; } fetch(checkUrl, { cache: 'no-store' }).then(function(r){ if (cssLink && r.status===404 && !done) { window.__pgReloadStaleOnce(); return; } if (r.ok && !done) { stop(); location.reload(); } }).catch(function(){}); }; var showFailed = function(){ if (done) return; msg.textContent = 'Sorry, connection unsuccessful.'; track.style.display = 'none'; bar.classList.remove('is-running'); btn.style.display = 'inline-flex'; }; var startReconnecting = function(){ if (done) return; msg.textContent = 'Connection lost.'; btn.style.display = 'none'; track.style.display = 'inline-flex'; bar.classList.remove('is-running'); void bar.offsetWidth; bar.classList.add('is-running'); clearTimeout(phaseTimer); phaseTimer = setTimeout(showFailed, 10000); check(); }; btn.onclick = startReconnecting; window.addEventListener('online', check); poll = setInterval(check, 3000); startReconnecting(); };try{var pgD=document.documentElement;pgD.classList.add('pg-boot');/* At 1s request committed sizing; slow hydration is not a sizing error. */setTimeout(function pgWait(){try{if(window.__pgForceReveal){window.__pgForceReveal()}else if(pgD.classList.contains('pg-boot')){setTimeout(pgWait,50)}}catch(e){if(!window.__pgCssReady()){window.__pgShowOffline();return}pgD.classList.add('pg-forced');pgD.classList.remove('pg-boot','mh-boot')}},1000);setTimeout(function(){if(!window.__pgCssReady()){window.__pgShowOffline();return}if(window.__pgHardReveal){window.__pgHardReveal()}else if(pgD.classList.contains('pg-boot')){if(!window.__pgCssReady()){window.__pgShowOffline();return}pgD.classList.add('pg-forced');pgD.classList.remove('pg-boot','mh-boot')}},2500);}catch(e){}try{const v=document.querySelector('meta[name=viewport]');const sw=Math.max(screen.width,screen.height),sh=Math.min(screen.width,screen.height),land=matchMedia('(orientation: landscape)').matches;var fw=sw;if(navigator.userAgent.indexOf('CriOS')>=0){var cw=document.documentElement.clientWidth||window.innerWidth;if(land&&cw>=sw*0.6&&cw<sw*0.995){fw=cw;try{sessionStorage.setItem('pgChromeLandW',String(Math.round(cw)))}catch(e){}}else{try{var sv=Number(sessionStorage.getItem('pgChromeLandW'))||0;if(sv>=sw*0.6&&sv<=sw+1)fw=sv}catch(e){}}}var fs=Math.round(fw/1440*10000)/10000;if(v&&sh<=600){if(land&&sw>sh){pgD.classList.add('phone-landscape-layout')}v.content=land&&sw>sh?'width=1440, initial-scale='+fs+', minimum-scale='+fs+', maximum-scale='+fs+', viewport-fit=cover':(navigator.userAgent.indexOf('CriOS')>=0?'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover':'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover')}}catch(e){}try{const sw=Math.max(screen.width,screen.height),sh=Math.min(screen.width,screen.height),land=matchMedia('(orientation: landscape)').matches;const w=sh<=600&&land&&sw>sh?1440:(document.documentElement.clientWidth||window.innerWidth);const nativePage=/^\\/(login|forgot-password|reset-password|checkout|welcome)(?:\\/|$)/.test(location.pathname);const nativePhone=w<640&&(location.pathname==='/'||location.pathname==='/claim'||nativePage);document.documentElement.style.setProperty('--canvas-fallback-scale',String(nativePage||nativePhone?1:w/1440))}catch(e){}try{const d=document.documentElement,sh=Math.min(screen.width,screen.height),land=matchMedia('(orientation: landscape)').matches;if(location.pathname==='/'&&sh<=600&&!land&&matchMedia('(pointer: coarse)').matches){d.classList.add('mh-boot');d.style.setProperty('--mobile-scale',String(sh/1440));var mhS=Math.max(window.screen.width,window.screen.height),mhV=0;try{var mhP=document.createElement('div');mhP.style.cssText='position:absolute;top:0;left:0;width:0;height:100lvh;visibility:hidden;pointer-events:none';d.appendChild(mhP);mhV=mhP.getBoundingClientRect().height;d.removeChild(mhP)}catch(e){}d.style.setProperty('--mh-screen-h',(mhV>=mhS*0.8&&mhV<=mhS?mhV:mhS)+'px');setTimeout(function(){d.classList.remove('mh-boot')},2500)}}catch(e){}try{var nd=document.documentElement,nsh=Math.min(screen.width,screen.height),nreal=nsh<=600&&!matchMedia('(orientation: landscape)').matches&&matchMedia('(pointer: coarse)').matches;if(location.pathname==='/'&&!nreal&&matchMedia('(max-width: 639px)').matches){nd.classList.add('mh-boot');nd.style.setProperty('--mobile-scale',String((nd.clientWidth||window.innerWidth)/1440));nd.style.setProperty('--mh-screen-h',window.innerHeight+'px');setTimeout(function(){nd.classList.remove('mh-boot')},2500)}}catch(e){}",
          }}
        />

        {/* Prompt 148: the Prompt 48 reload-on-rotate-upright script was removed —
            reloading re-ran the first-load hiding and blinked the page black.
            The upright layout now switches live, like sideways does; on turning
            upright this sets the same two sizes the first-load script sets. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{if(Math.min(screen.width,screen.height)<=600&&matchMedia('(pointer: coarse)').matches){var orMq=matchMedia('(orientation: portrait)');var orFn=function(){if(!orMq.matches)return;var d=document.documentElement,sh=Math.min(screen.width,screen.height),sw=Math.max(screen.width,screen.height),v=0;d.style.setProperty('--mobile-scale',String(sh/1440));try{var p=document.createElement('div');p.style.cssText='position:absolute;top:0;left:0;width:0;height:100lvh;visibility:hidden;pointer-events:none';d.appendChild(p);v=p.getBoundingClientRect().height;d.removeChild(p)}catch(e){}d.style.setProperty('--mh-screen-h',(v>=sw*0.8&&v<=sw?v:sw)+'px')};if(orMq.addEventListener)orMq.addEventListener('change',orFn);else orMq.addListener(orFn)}}catch(e){}",
          }}
        />
        {/* Desktop homepage only: browsers may restore the old scroll position
            after an early scrollTo(0, 0). Keep the first few paint frames pinned
            to the top so a stale mid-page Features frame can never be shown. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{if(location.pathname==='/'&&window.matchMedia('(min-width: 1024px)').matches){if('scrollRestoration' in history)history.scrollRestoration='manual';try{sessionStorage.removeItem('tsr-scroll-restoration-v1_3')}catch(e){}let n=0;const p=()=>{window.scrollTo(0,0);if(++n<12)requestAnimationFrame(p)};p();addEventListener('pageshow',()=>window.scrollTo(0,0),{once:true});}}catch(e){}",
          }}
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  // Hide before an incoming route can paint; reveal only its settled geometry.
  // This does not change DesktopScale's measurement or resize/rotation handling.
  useLayoutEffect(() => {
    (window as Window & { __pgForceReveal?: () => void }).__pgForceReveal = forceReveal;
    (window as Window & { __pgHardReveal?: () => void }).__pgHardReveal = hardReveal;
    // A thrown sizing effect/observer is different from a slow measurement.
    const sizingError = (event: ErrorEvent) => {
      const source = `${event.filename} ${event.error instanceof Error ? event.error.stack ?? "" : ""}`;
      if (/DesktopScale|DesktopHeaderMount|desktop-scale|boot-reveal/.test(source)) forceReveal(true);
    };
    window.addEventListener("error", sizingError);
    const hide = router.subscribe("onBeforeLoad", () => {
      document.documentElement.classList.add("pg-boot");
      armRevealWatchdog();
    });
    const reveal = router.subscribe("onResolved", () => revealWhenSettled());
    return () => {
      hide();
      reveal();
      window.removeEventListener("error", sizingError);
    };
  }, [router]);
  const renderedPathname = useRouterState({
    // Use the active browser location, not the previously resolved route.
    // During mobile Back, resolvedLocation can remain on /claim for a frame
    // after the homepage has mounted, making its 1440px canvas inherit the
    // checkout's native-phone width before correcting itself.
    select: (state) => state.location.pathname,
  });

  // Mobile browsers can exhaust their graphics memory when pinch zoom asks
  // several animated/composited sections to be rasterized at once. Mark every
  // route while zoomed so motion and expensive paint effects pause globally;
  // the normal scale=1 presentation remains unchanged.
  useLayoutEffect(() => {
    const viewport = window.visualViewport;
    let frame = 0;
    let pinching = false;
    let pinchDistance = 0;
    let zoomedLayer: "hero" | "features" | null = null;
    let pausedAnimations: Animation[] = [];

    const isPhone = () => window.matchMedia("(max-width: 639px)").matches;
    const getTouchDistance = (touches: TouchList) => {
      const first = touches.item(0);
      const second = touches.item(1);
      if (!first || !second) return 0;
      return Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);
    };
    // 256: the iPad homepage (touch, 640px+) pauses motion while zoomed too.
    const isIPadHome = () =>
      window.location.pathname === "/" && window.matchMedia("(min-width: 640px) and (pointer: coarse)").matches;
    // 257: touch homepage (phones and iPad) switches to zoom light mode the
    // instant a pinch begins. Light mode is pure CSS (html.home-zoom-light
    // pauses every animation on the page) plus the hero's pausable timers.
    const isHome = () => window.location.pathname === "/";
    const isTouch = () => window.matchMedia("(pointer: coarse)").matches;
    let lightOn = false;
    let lightScriptAnimations: Animation[] = [];
    const setLight = (on: boolean) => {
      const next = on;
      if (next === lightOn) return;
      lightOn = next;
      document.documentElement.classList.toggle("home-zoom-light", next);
      setHeroZoomPaused(next);
      // Script-driven animations (Motion reveals) are not reached by CSS.
      if (next) {
        lightScriptAnimations = document.getAnimations().filter(
          (a) => a.playState === "running" && !("animationName" in a) && !("transitionProperty" in a),
        );
        lightScriptAnimations.forEach((a) => a.pause());
      } else {
        lightScriptAnimations.forEach((a) => { if (a.playState === "paused") a.play(); });
        lightScriptAnimations = [];
      }
    };
    const pauseMotion = () => {
      // 257: on the touch homepage the CSS light mode pauses everything; a JS
      // pause/play would override the off-screen and covered-hero CSS pauses.
      if (isHome() && isTouch()) return;
      if ((!isPhone() && !isIPadHome()) || pausedAnimations.length) return;
      pausedAnimations = document.getAnimations().filter((animation) => animation.playState === "running");
      pausedAnimations.forEach((animation) => animation.pause());
    };
    const restoreMotion = () => {
      pausedAnimations.forEach((animation) => {
        if (animation.playState === "paused") animation.play();
      });
      pausedAnimations = [];
    };
    const syncZoomedLayer = () => {
      document.documentElement.classList.toggle("mobile-zoom-lock-hero", zoomedLayer === "hero");
      document.documentElement.classList.toggle("mobile-zoom-lock-features", zoomedLayer === "features");
    };
    const sync = () => {
      frame = 0;
      const zoomed = (viewport?.scale ?? 1) > 1.01;
      document.documentElement.classList.toggle("mobile-zoom-active", pinching || zoomed);
      setLight(pinching || zoomed);
      if (pinching || zoomed) pauseMotion();
      else {
        zoomedLayer = null;
        syncZoomedLayer();
        restoreMotion();
      }
    };
    const schedule = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(sync);
    };
    const markPinchTarget = (target: EventTarget | null) => {
      const el = target instanceof Element ? target : null;
      if (el?.closest(".layer-scroll-hero")) zoomedLayer = "hero";
      else if (el?.closest(".layer-scroll-features")) zoomedLayer = "features";
      syncZoomedLayer();
    };
    const beginPinch = (event: TouchEvent) => {
      if (event.touches.length < 2) return;
      // 257: light mode first, before the browser starts zooming.
      setLight(true);
      pinching = true;
      pinchDistance = getTouchDistance(event.touches);
      markPinchTarget(event.target);
      document.documentElement.classList.add("mobile-zoom-active");
      pauseMotion();
    };
    // 257: Safari's gesturestart fires as the second finger lands; switch modes
    // only (the gesture itself is never cancelled).
    const beginGesture = (event: Event) => {
      setLight(true);
      pinching = true;
      markPinchTarget(event.target);
      document.documentElement.classList.add("mobile-zoom-active");
      pauseMotion();
    };
    const limitPinchOut = (event: TouchEvent) => {
      if (!isPhone() || event.touches.length < 2) return;
      if (document.querySelector(".mobile-home-root")) return;
      const nextDistance = getTouchDistance(event.touches);
      const shrinking = pinchDistance > 0 && nextDistance < pinchDistance;
      pinchDistance = nextDistance;
      if (shrinking && (viewport?.scale ?? 1) <= 1.01) event.preventDefault();
    };
    const limitSafariPinchOut = (event: Event) => {
      if (!isPhone() || document.querySelector(".mobile-home-root")) return;
      const gesture = event as Event & { scale?: number };
      if ((gesture.scale ?? 1) < 1 && (viewport?.scale ?? 1) <= 1.01) event.preventDefault();
    };
    const finishPinch = (event: TouchEvent) => {
      // 257: on the homepage light mode holds until no finger is touching.
      if (isHome() && event.touches.length > 0) return;
      pinching = false;
      pinchDistance = 0;
      schedule();
    };
    sync();
    viewport?.addEventListener("resize", schedule);
    viewport?.addEventListener("scroll", schedule);
    document.addEventListener("touchstart", beginPinch, { passive: true });
    document.addEventListener("touchmove", limitPinchOut, { passive: false });
    document.addEventListener("touchend", finishPinch, { passive: true });
    document.addEventListener("touchcancel", finishPinch, { passive: true });
    document.addEventListener("gesturestart", beginGesture, { passive: true });
    document.addEventListener("gesturechange", limitSafariPinchOut, { passive: false });
    const endGesture = () => { if (isTouch()) return; pinching = false; schedule(); window.setTimeout(schedule, 300); };
    document.addEventListener("gestureend", endGesture, { passive: true });
    const recheckOnScroll = () => {
      if (isTouch()) return;
      // 480: a normal scroll at normal zoom means no pinch is in progress — release right away.
      if (pinching && Math.abs((window.visualViewport?.scale ?? 1) - 1) < 0.01) {
        pinching = false;
        window.clearTimeout(gestureTimer);
      }
      if (pinching) return;
      schedule();
    };
    window.addEventListener("scroll", recheckOnScroll, { passive: true });
    // 478: on a Mac, gestureend does not reliably clear the pinch flag. Every gesture update
    // re-arms a short timer; when updates stop, the flag clears and sync re-checks the real zoom level.
    let gestureTimer = 0;
    const holdGesture = () => {
      if (isTouch()) return;
      pinching = true;
      window.clearTimeout(gestureTimer);
      gestureTimer = window.setTimeout(() => { pinching = false; schedule(); }, 1000);
    };
    document.addEventListener("gesturestart", holdGesture, { passive: true });
    document.addEventListener("gesturechange", holdGesture, { passive: true });
    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      viewport?.removeEventListener("resize", schedule);
      viewport?.removeEventListener("scroll", schedule);
      document.removeEventListener("touchstart", beginPinch);
      document.removeEventListener("touchmove", limitPinchOut);
      document.removeEventListener("touchend", finishPinch);
      document.removeEventListener("touchcancel", finishPinch);
      document.removeEventListener("gesturestart", beginGesture);
      document.removeEventListener("gesturechange", limitSafariPinchOut);
      document.removeEventListener("gestureend", endGesture);
      window.removeEventListener("scroll", recheckOnScroll);
      document.removeEventListener("gesturestart", holdGesture);
      document.removeEventListener("gesturechange", holdGesture);
      window.clearTimeout(gestureTimer);
      restoreMotion();
      setLight(false);
      document.documentElement.classList.remove("mobile-zoom-active");
      document.documentElement.classList.remove("mobile-zoom-lock-hero", "mobile-zoom-lock-features");
    };
  }, []);

  useLayoutEffect(() => {
    let viewport = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
    if (!viewport) return;
    // Portrait phones share one authored width. The browser fits all 393px of
    // that composition to the physical screen, so small phones never crop or
    // enlarge individual controls. Pinch zooming in remains available.
    const phonePortraitContent = "width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover";
    const deviceContent = "width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover";
    // 343: Chrome on iPhone is locked at normal zoom; set once and never changed.
    const criosNormalZoomContent = "width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover";
    let lastChromeVisibleWidth = 0;
    try { lastChromeVisibleWidth = Number(sessionStorage.getItem("pgChromeLandW")) || 0; } catch { /* ignore */ }
    const currentTagScale = () => {
      const meta = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
      const match = meta?.content.match(/initial-scale=([0-9.]+)/);
      return match ? Number(match[1]) : 0;
    };
    const landscapeFitScale = () => {
      const screenLong = Math.max(window.screen.width, window.screen.height);
      let visibleWidth = screenLong;
      if (navigator.userAgent.includes("CriOS")) {
        // Chrome shows the page only between its side strips. While the 1440px
        // layout is applied at a scale we set, the visible width in screen points
        // is the visible layout width multiplied by that scale.
        const landscape = window.matchMedia("(orientation: landscape)").matches;
        const tagScale = currentTagScale();
        const layoutIs1440 = document.documentElement.clientWidth >= 1400;
        const visibleLayoutWidth = window.visualViewport?.width ?? window.innerWidth;
        const measured = landscape && layoutIs1440 && tagScale ? visibleLayoutWidth * tagScale : 0;
        const appliedScale = window.visualViewport?.scale ?? 0;
        const zoomApplied = tagScale > 0 && Math.abs(appliedScale - tagScale) <= 0.002;
        if (!lastChromeVisibleWidth && zoomApplied && measured >= screenLong * 0.6 && measured <= screenLong + 1) {
          lastChromeVisibleWidth = Math.round(measured);
          try { sessionStorage.setItem("pgChromeLandW", String(lastChromeVisibleWidth)); } catch { /* ignore */ }
        }
        if (lastChromeVisibleWidth) visibleWidth = lastChromeVisibleWidth;
      }
      const s = visibleWidth / DESKTOP_CANVAS_WIDTH;
      return Math.round(s * 10000) / 10000;
    };
    const desktopLandscapeContentFor = () => {
      const s = landscapeFitScale();
      return `width=${DESKTOP_CANVAS_WIDTH}, initial-scale=${s}, minimum-scale=${s}, maximum-scale=${s}, viewport-fit=cover`;
    };

    const syncViewport = () => {
      const phoneLandscape = isPhoneLandscapeViewport();
      if (phoneLandscape) {
        // A sideways phone deliberately changes to the authored desktop
        // viewport. During rotation Mobile Safari can report the destination
        // scale before firing orientationchange; that is not a user pinch and
        // must not block the viewport switch.
        syncAllViewportContent(desktopLandscapeContentFor());
        if (navigator.userAgent.includes("CriOS")) {
          // Chrome on iPhone can apply a viewport change one rotation late; replace the
          // tag now and once more on the next frame so it takes effect immediately.
          replaceViewportMeta();
          window.requestAnimationFrame(() => {
            if (isPhoneLandscapeViewport()) replaceViewportMeta();
          });
        }
        // Replacing the same browser-neutral tag makes a browser discard any
        // zoom restored across a reload without prescribing a scale that can
        // crop or undersize a different browser's visible screen.
        if (!wasLandscape) scheduleLandscapeViewportRefresh();
        if (navigator.userAgent.includes("CriOS")) startChromeSideStripMatching();
        else stopChromeSideStripMatching();
        wasLandscape = true;
        return;
      }
      stopChromeSideStripMatching();
      wasLandscape = false;
      const screenWidth = Math.max(window.screen.width, window.screen.height);
      const screenHeight = Math.min(window.screen.width, window.screen.height);
      const physicalPhone = screenHeight <= 600 && screenWidth > screenHeight;
      // Portrait phone: always restore the phone viewport. Rotating back from
      // sideways leaves a non-1 browser scale behind; that leftover scale is
      // not a user pinch and must never keep the page on the desktop version.
      const nextContent = navigator.userAgent.includes("CriOS")
        ? criosNormalZoomContent
        : physicalPhone
          ? phonePortraitContent
          : deviceContent;
      syncAllViewportContent(nextContent);
    };

    // 418: Chrome sideways — if the applied zoom drifts from the first-homepage
    // fit scale, briefly pin that exact scale, then restore the normal tag.
    let chromeFitCorrections = 0;
    let chromeFitWasLandscape = isPhoneLandscapeViewport();
    let chromeFitFrame = 0;
    const enforceChromeFitScale = () => {
      if (!navigator.userAgent.includes("CriOS")) return;
      if (!isPhoneLandscapeViewport()) { chromeFitWasLandscape = false; return; }
      if (!chromeFitWasLandscape) { chromeFitWasLandscape = true; chromeFitCorrections = 0; }
      const want = landscapeFitScale();
      const got = window.visualViewport?.scale ?? 0;
      if (Math.abs(got - want) <= 0.01) return;
      if (chromeFitCorrections >= 3) return;
      chromeFitCorrections += 1;
      const n = Math.round((want + 0.0001) * 10000) / 10000;
      syncAllViewportContent(`width=${DESKTOP_CANVAS_WIDTH}, initial-scale=${n}, minimum-scale=${n}, maximum-scale=${n}, viewport-fit=cover`);
      window.cancelAnimationFrame(chromeFitFrame);
      chromeFitFrame = window.requestAnimationFrame(() => {
        chromeFitFrame = 0;
        replaceViewportMeta();
      });
    };
    const syncViewportAfterRotation = () => {
      chromeFitCorrections = 0;
      syncViewport();
      // Orientation, browser scale and the viewport meta settle in separate
      // steps; re-assert the correct mode at the same settle points the rest
      // of the rotation handling already uses.
      for (const delay of [100, 300, 600]) {
        window.setTimeout(() => {
          syncViewport();
          enforceChromeFitScale();
        }, delay);
      }
    };

    // Re-apply one identical browser-neutral sideways viewport after load and
    // rotation settle. This clears a restored zoom without calculating or
    // forcing a browser-dependent scale.
    let landscapeRefreshTimers: number[] = [];
    let wasLandscape = isPhoneLandscapeViewport();
    // Keep every viewport tag in agreement and ours last: the framework can
    // re-add its own tag after hydration, and a later tag would override the
    // 1440px value. With a single tag this is the same write as before.
    const syncAllViewportContent = (content: string) => {
      for (const meta of document.querySelectorAll<HTMLMetaElement>('meta[name="viewport"]')) {
        if (meta.content !== content) meta.content = content;
      }
    };
    const replaceViewportMeta = () => {
      const current = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
      if (!current) return;
      if (!viewport || viewport.closest("head") === null || !viewport.dataset["prompt54"]) {
        // Add our own tag instead of removing the framework's: React owns that
        // node, and removing it makes React crash ("removeChild") on navigation.
        const replacement = document.createElement("meta");
        replacement.name = "viewport";
        replacement.content = current.content;
        replacement.dataset["prompt54"] = "1";
        viewport = replacement;
      }
      syncAllViewportContent(desktopLandscapeContentFor());
      document.head.appendChild(viewport); // ours last, so it wins
    };
    const scheduleLandscapeViewportRefresh = () => {
      landscapeRefreshTimers.forEach((timer) => window.clearTimeout(timer));
      landscapeRefreshTimers = [700, 1600, 3000].map((delay) =>
        window.setTimeout(() => {
          if (!isPhoneLandscapeViewport()) return;
          replaceViewportMeta();
          enforceChromeFitScale();
        }, delay),
      );
    };
    const landscapeRefreshOnLoad = () => {
      if (isPhoneLandscapeViewport()) scheduleLandscapeViewportRefresh();
    };

    // Prompt 56 (Chrome on iPhone, sideways only): Chrome paints the areas
    // beside the notch with the document background. Match that background to
    // whichever top-level page section crosses a 1px line at screen center.
    let sideStripObserver: IntersectionObserver | null = null;
    let sideStripMutationObserver: MutationObserver | null = null;
    let sideStripElements: Element[] = [];
    let activeSideStripElement: Element | null = null;
    let activeSideStripColor = "";
    const rootBackground = document.documentElement.style.getPropertyValue("background-color");
    const rootBackgroundPriority = document.documentElement.style.getPropertyPriority("background-color");
    const bodyBackground = document.body.style.getPropertyValue("background-color");
    const bodyBackgroundPriority = document.body.style.getPropertyPriority("background-color");

    const isTransparentColor = (color: string) =>
      color === "transparent" || color === "rgba(0, 0, 0, 0)" || color === "rgb(0 0 0 / 0)";

    // Prompt 137: the area outside the page is always solid black — never a
    // section color. Only the document (outside) background is written; the
    // page body keeps its own colors.
    const writeSideStripColor = (element: Element) => {
      const color = "rgb(0, 0, 0)";
      if (activeSideStripElement === element && activeSideStripColor === color) return;
      activeSideStripElement = element;
      activeSideStripColor = color;
      document.documentElement.style.backgroundColor = color;
    };

    const restoreSideStripBackgrounds = () => {
      if (rootBackground) document.documentElement.style.setProperty("background-color", rootBackground, rootBackgroundPriority);
      else document.documentElement.style.removeProperty("background-color");
      if (bodyBackground) document.body.style.setProperty("background-color", bodyBackground, bodyBackgroundPriority);
      else document.body.style.removeProperty("background-color");
      activeSideStripElement = null;
      activeSideStripColor = "";
    };

    const getTopLevelPageSections = () => {
      const candidates = Array.from(document.querySelectorAll("section, footer"));
      return candidates.filter((element) => {
        if (element.closest('[data-sonner-toaster]')) return false;
        if (element.matches(".pr-faq")) return Boolean(element.closest(".faq-drawer--open"));
        const ancestorSelector = element.tagName === "FOOTER" ? "footer" : "section";
        return element.parentElement?.closest(ancestorSelector) === null;
      });
    };

    const getCenteredSideStripSection = () => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      for (const hit of document.elementsFromPoint(centerX, centerY)) {
        const section = sideStripElements.find((element) => element === hit || element.contains(hit));
        if (section) return section;
      }
      return sideStripElements.find((element) => {
        const rect = element.getBoundingClientRect();
        return rect.top <= centerY && rect.bottom >= centerY;
      });
    };

    const observeSideStripSections = () => {
      if (!sideStripObserver) return;
      sideStripObserver.disconnect();
      sideStripElements = getTopLevelPageSections();
      sideStripElements.forEach((element) => sideStripObserver?.observe(element));
      const centered = getCenteredSideStripSection();
      writeSideStripColor(centered ?? document.documentElement);
    };

    function startChromeSideStripMatching() {
      if (sideStripObserver || !isPhoneLandscapeViewport() || !navigator.userAgent.includes("CriOS")) return;
      const viewportHeight = Math.max(1, window.innerHeight);
      const topMargin = -Math.floor(viewportHeight / 2);
      const bottomMargin = -(viewportHeight - Math.floor(viewportHeight / 2) - 1);
      sideStripObserver = new IntersectionObserver(
        (entries) => {
          if (!entries.some((entry) => entry.isIntersecting)) return;
          const centered = getCenteredSideStripSection();
          if (centered) writeSideStripColor(centered);
        },
        { rootMargin: `${topMargin}px 0px ${bottomMargin}px 0px`, threshold: 0 },
      );
      sideStripMutationObserver = new MutationObserver(observeSideStripSections);
      sideStripMutationObserver.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class", "aria-hidden"],
      });
      observeSideStripSections();
    }

    function stopChromeSideStripMatching() {
      sideStripObserver?.disconnect();
      sideStripMutationObserver?.disconnect();
      sideStripObserver = null;
      sideStripMutationObserver = null;
      sideStripElements = [];
      restoreSideStripBackgrounds();
    }

    if (document.readyState === "complete") landscapeRefreshOnLoad();
    else window.addEventListener("load", landscapeRefreshOnLoad, { once: true });

    syncViewport();
    window.addEventListener("resize", syncViewport);
    window.addEventListener("orientationchange", syncViewportAfterRotation);
    return () => {
      window.cancelAnimationFrame(chromeFitFrame);
      landscapeRefreshTimers.forEach((timer) => window.clearTimeout(timer));
      stopChromeSideStripMatching();
      window.removeEventListener("load", landscapeRefreshOnLoad);
      window.removeEventListener("resize", syncViewport);
      window.removeEventListener("orientationchange", syncViewportAfterRotation);
      for (const meta of document.querySelectorAll<HTMLMetaElement>('meta[data-prompt54]')) meta.remove();
      viewport = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
      if (viewport) viewport.content = deviceContent;
    };
  }, []);

  // 342: hide the page while a touch device rotates, then reveal once the
  // existing reveal gate confirms the page is sized for the new orientation.
  // 351: upright-phone rotation to "/" also gets the mh-boot guard plus a soft
  // fade-in (pg-rotate-fade) that is removed 3000ms later.
  useEffect(() => {
    const portraitMq = window.matchMedia("(orientation: portrait)");
    const coarseMq = window.matchMedia("(pointer: coarse)");
    let fadeTimer: number | undefined;
    let lastPortrait = portraitMq.matches;
    let lastWidth = document.documentElement.clientWidth;
    // 352: hide at the very first sign of rotation — any of the triggers below
    // may fire first, so all of them hide synchronously. If the page is already
    // hidden for this rotation, only re-request the reveal.
    // 369E: after a turn the browser can leave its visible area shifted inside
    // the page (Chrome on iPhone). For a few seconds after each turn, whenever
    // the visible area is offset, a real 1px scroll and back re-aligns it
    // without changing the page's scroll position. Stops at the first touch.
    let realignTimers: number[] = [];
    let realignStop: (() => void) | null = null;
    const startRealign = () => {
      realignStop?.();
      const vv = window.visualViewport;
      if (!vv) return;
      let touched = false;
      const realign = () => {
        if (isChrome && !document.documentElement.classList.contains("pg-rotate-hold")) return;
        if (touched || vv.offsetTop <= 0.5) return;
        const y = window.scrollY;
        window.scrollTo(0, y + 1);
        window.requestAnimationFrame(() => {
          if (!touched) window.scrollTo(0, y);
        });
      };
      const onTouch = () => { touched = true; };
      window.addEventListener("touchstart", onTouch, { passive: true, once: true });
      vv.addEventListener("resize", realign);
      realignTimers = [300, 900, 1700, 2500, 3500].map((delay) => window.setTimeout(realign, delay));
      // 369F: Chrome on iPhone keeps a stale toolbar offset after a turn, so the
      // page top lands under the header. A real short scroll down and back (the
      // same move that fixes it by hand) resets it. Runs only while the page is
      // still hidden by the rotation fade, and only if still at the top.
      if (navigator.userAgent.includes("CriOS")) {
        const nudge = () => {
          if (isChrome && !document.documentElement.classList.contains("pg-rotate-hold")) return;
          if (touched || window.scrollY > 2) return;
          window.scrollTo(0, 120);
          window.requestAnimationFrame(() => {
            window.requestAnimationFrame(() => {
              if (!touched) window.scrollTo(0, 0);
            });
          });
        };
        realignTimers.push(window.setTimeout(nudge, 250));
        realignTimers.push(window.setTimeout(nudge, 650));
      }
      realignStop = () => {
        realignTimers.forEach((t) => window.clearTimeout(t));
        realignTimers = [];
        window.removeEventListener("touchstart", onTouch);
        vv.removeEventListener("resize", realign);
        realignStop = null;
      };
      realignTimers.push(window.setTimeout(() => realignStop?.(), 4000));
    };
    // 389: Chrome keeps adjusting its zoom for ~1s after a turn. Keep the page
    // hidden until that is over, do the final top alignment while hidden, then
    // reveal once. Nothing re-aligns the page after the reveal in Chrome.
    let holdTimer: number | undefined;
    const isChrome = navigator.userAgent.includes("CriOS");
    const finishChromeHold = () => {
      const html = document.documentElement;
      if (window.scrollY <= 130) {
        window.scrollTo(0, 120);
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(() => {
            window.scrollTo(0, 0);
            window.requestAnimationFrame(() => {
              window.requestAnimationFrame(() => html.classList.remove("pg-rotate-hold"));
            });
          });
        });
      } else {
        html.classList.remove("pg-rotate-hold");
      }
    };
    const hideForRotation = () => {
      if (!coarseMq.matches) return;
      if (isChrome) {
        document.documentElement.classList.add("pg-rotate-hold");
        if (holdTimer !== undefined) window.clearTimeout(holdTimer);
        holdTimer = window.setTimeout(finishChromeHold, 1300);
      }
      startRealign();
      const html = document.documentElement;
      if (html.classList.contains("pg-boot")) {
        revealWhenSettled();
        return;
      }
      html.classList.add("pg-boot");
      if (portraitMq.matches && location.pathname === "/" && Math.min(window.screen.width, window.screen.height) <= 600) {
        html.classList.add("mh-boot");
      }
      html.classList.add("pg-rotate-fade");
      if (fadeTimer !== undefined) window.clearTimeout(fadeTimer);
      fadeTimer = window.setTimeout(() => {
        fadeTimer = undefined;
        html.classList.remove("pg-rotate-fade");
      }, 3000);
      armRevealWatchdog(false);
      revealWhenSettled();
    };
    const onOrientationChange = () => {
      lastPortrait = portraitMq.matches;
      hideForRotation();
    };
    const onResize = () => {
      const w = document.documentElement.clientWidth;
      if (w === lastWidth) return; // height-only changes (toolbars) are not rotations
      lastWidth = w;
      hideForRotation();
    };
    const screenOrientation = window.screen.orientation;
    window.addEventListener("orientationchange", hideForRotation);
    if (screenOrientation) screenOrientation.addEventListener("change", hideForRotation);
    window.addEventListener("resize", onResize);
    if (portraitMq.addEventListener) portraitMq.addEventListener("change", onOrientationChange);
    else portraitMq.addListener(onOrientationChange);
    return () => {
      window.removeEventListener("orientationchange", hideForRotation);
      if (screenOrientation) screenOrientation.removeEventListener("change", hideForRotation);
      window.removeEventListener("resize", onResize);
      if (portraitMq.removeEventListener) portraitMq.removeEventListener("change", onOrientationChange);
      else portraitMq.removeListener(onOrientationChange);
      if (fadeTimer !== undefined) window.clearTimeout(fadeTimer);
      realignStop?.();
      if (holdTimer !== undefined) window.clearTimeout(holdTimer);
      document.documentElement.classList.remove("pg-rotate-hold");
    };
  }, []);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      router.invalidate();
      if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
    });
    return () => data.subscription.unsubscribe();
  }, [router, queryClient]);

  // Mobile only: while the home page's demo form ("Never Miss A LinkedIn Lead
  // Again!") is open, the header swaps Sign In / Get Now for a single blue
  // Back button that returns to the hero view.
  const [demoFormActive, setDemoFormActive] = useState(false);
  useEffect(() => {
    if (renderedPathname !== "/") {
      setDemoFormActive(false);
      return;
    }
    const onActive = (event: Event) => setDemoFormActive(Boolean((event as CustomEvent).detail));
    const onBack = () => setDemoFormActive(false);
    window.addEventListener("linkbot:demo-form-active", onActive);
    window.addEventListener("linkbot:demo-form-back", onBack);
    return () => {
      window.removeEventListener("linkbot:demo-form-active", onActive);
      window.removeEventListener("linkbot:demo-form-back", onBack);
    };
  }, [renderedPathname]);

  // The voice choice (inside /claim) and /checkout share /claim's secure-checkout header treatment.
  const claimVoiceStep = useClaimVoiceStep() && renderedPathname === "/claim";
  const claimLikePath = renderedPathname === "/claim" || renderedPathname === "/checkout" || renderedPathname === "/welcome";
  const loginLikePath = renderedPathname === "/login" || renderedPathname === "/forgot-password" || renderedPathname === "/reset-password";

  const mobileActions =
    loginLikePath ? null : claimLikePath ? (
      <span className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-brand/60 bg-black/40 px-2.5 py-1.5 text-[0.55rem] font-extrabold uppercase tracking-[0.12em] text-white">
        <Lock className="h-3 w-3 shrink-0 text-brand" strokeWidth={2} />
        Secure checkout
      </span>
    ) : demoFormActive && renderedPathname === "/" ? (
      <button
        type="button"
        onClick={() => window.dispatchEvent(new CustomEvent("linkbot:demo-form-back"))}
        className="linkbot-button !h-9 !px-2.5 !text-[0.6rem]"
      >
        <span className="whitespace-nowrap">Go Back</span>
      </button>
    ) : (
      <nav className="flex shrink-0 items-center gap-1.5" aria-label="Main navigation">
        <HoverlessLink
          to="/login"
          className="inline-flex h-9 shrink-0 items-center justify-center whitespace-nowrap rounded-md border border-night-border px-2.5 text-[0.6rem] font-bold uppercase tracking-wide text-white"
        >
          Sign In
        </HoverlessLink>
        <HoverlessLink to="/claim" className="linkbot-button !h-9 !px-2.5 !text-[0.6rem]">
          <span className="whitespace-nowrap">Get Now</span>
        </HoverlessLink>
      </nav>
    );

  const desktopActions =
    loginLikePath ? null : claimLikePath ? (
      <div className="flex shrink-0 items-center justify-end gap-3">
        {[
          { icon: ShieldCheck, label: "SOC 2 audited", className: "hidden sm:inline-flex", active: false },
          { icon: Lock, label: "AES 256 encrypted", className: "inline-flex", active: false },
          { icon: Lock, label: "Secure checkout", className: "inline-flex", active: true },
        ].map(({ icon: Icon, label, className, active }) => (
          <span
            key={label}
            className={`${className} shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1.5 text-[0.5rem] tracking-[0.12em] sm:gap-2 sm:px-3.5 sm:py-2 sm:text-[0.6rem] sm:tracking-[0.16em] font-extrabold uppercase ${active ? "border-brand/60 bg-black/40 text-white" : "border-white/15 bg-white/[0.06] text-night-foreground"}`}
          >
            <Icon className={`h-3 w-3 shrink-0 sm:h-3.5 sm:w-3.5 ${active ? "text-brand" : "text-night-foreground"}`} strokeWidth={2} />
            {label}
          </span>
        ))}
      </div>
    ) : (
      <nav className="flex shrink-0 items-center gap-1 sm:gap-2" aria-label="Main navigation">
        <Button variant="outline-night" size="sm" asChild className="header-signin-button header-public-signin inline-flex h-9 border px-2.5 text-[0.55rem] sm:h-12 sm:border-2 sm:px-6 sm:text-xs">
          <HoverlessLink to="/login">Sign In</HoverlessLink>
        </Button>
        <HoverlessLink to="/claim" className="linkbot-button header-public-get-now !h-8 !px-2.5 !text-[0.55rem] sm:!h-11 sm:!px-5 sm:!text-xs">
          <span className="whitespace-nowrap">Get Now</span>
        </HoverlessLink>
      </nav>
    );

  const showHeader =
    renderedPathname === "/" ||
    renderedPathname === "/claim" ||
    renderedPathname === "/welcome" ||
    loginLikePath;
  const renderedSearch = useRouterState({ select: (state) => state.location.searchStr });
  const mobileHomeActive = useMobileHomeSwitch(renderedPathname, renderedSearch) && renderedPathname === "/";

  return (
    <QueryClientProvider client={queryClient}>
      {showHeader && (
        <MobileHeader
          actions={mobileActions}
          inPageFlow={renderedPathname === "/claim"}
          tone={(renderedPathname === "/claim" && !claimVoiceStep) || renderedPathname === "/welcome" || (renderedPathname === "/" && demoFormActive) ? "light" : "dark"}
          transparent={loginLikePath}
        />
      )}
      {showHeader && (
        <DesktopHeaderMount
          actions={desktopActions}
          tone={(renderedPathname === "/claim" && !claimVoiceStep) || renderedPathname === "/welcome" || (renderedPathname === "/" && demoFormActive) ? "light" : "dark"}
          transparent={loginLikePath}
        />
      )}
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <DesktopScale
        phoneLayoutZoom={mobileHomeActive ? false : renderedPathname === "/" && !demoFormActive}
        nativeBelow={
          mobileHomeActive
            ? 640
            : loginLikePath ||
              renderedPathname === "/checkout" ||
              renderedPathname === "/welcome"
            ? Number.POSITIVE_INFINITY
            : renderedPathname === "/claim" || (renderedPathname === "/" && demoFormActive)
              ? 640
              : undefined
        }
      >
        <Outlet />
      </DesktopScale>
      <Toaster position="top-center" richColors />
    </QueryClientProvider>
  );
}
