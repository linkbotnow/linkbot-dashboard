import { createFileRoute } from "@tanstack/react-router";
import { legalRedirect } from "@/lib/legal-page.server";

export const Route = createFileRoute("/terms")({
  server: { handlers: { GET: () => legalRedirect("terms") } },
});
