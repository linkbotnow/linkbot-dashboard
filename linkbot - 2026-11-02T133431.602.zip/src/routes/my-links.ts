import { createFileRoute } from '@tanstack/react-router';

const description = 'Privately manage the links your LinkBot can share.';
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="robots" content="noindex,nofollow"><title>My Links | LinkBot</title><meta name="description" content="${description}"><meta property="og:title" content="My Links | LinkBot"><meta property="og:description" content="${description}"><meta property="og:type" content="website"><meta name="twitter:card" content="summary"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=block" rel="stylesheet"><link rel="stylesheet" href="/my-links.css"><link rel="stylesheet" href="/my-links-native.css"></head><body><div id="spacer"><div id="canvas"></div></div><script src="/my-links.js" defer></script></body></html>`;

export const Route = createFileRoute('/my-links')({
  head: () => ({ meta: [
    { title: 'My Links | LinkBot' }, { name: 'description', content: description },
    { property: 'og:title', content: 'My Links | LinkBot' }, { property: 'og:description', content: description },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' },
    { name: 'robots', content: 'noindex,nofollow' },
  ] }),
  server: { handlers: {
    GET: () => new Response(html, { headers: {
      'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex, nofollow',
      'content-security-policy': "frame-ancestors 'self' https://*.leadconnectorhq.com https://*.gohighlevel.com https://*.linkbot.now https://*.msgsndr.com",
      'referrer-policy': 'same-origin',
    } }),
    POST: async ({ request }) => (await import('../lib/my-links.server')).handleMyLinks(request),
  } },
});