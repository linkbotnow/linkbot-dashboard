import { createFileRoute } from "@tanstack/react-router";
import { LoginPage } from "@/components/auth/LoginScreen";

const TITLE = "Sign In | LinkBot";
const DESCRIPTION =
  "Sign in to your LinkBot account to access your AI dashboard.";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <LoginPage view="login" />,
});
