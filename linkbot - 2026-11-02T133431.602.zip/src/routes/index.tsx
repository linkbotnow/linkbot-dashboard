import { PricingCardNew } from "@/components/landing/PricingCardNew";
import { CompareCostDesktop } from "@/components/landing/CompareCost";
import { pinDemoViewToTop, useDemoViewTop } from "@/lib/scroll-top";
import { FooterLegalLink } from "@/components/legal/LegalModal";
import { createFileRoute, useLocation } from "@tanstack/react-router";
import { useRevealWhenSettled } from "@/lib/boot-reveal";
import { MobileHome, isMobileHomeSwitchActive, isNarrowDesktopWindow, useMobileHomeSwitch } from "@/components/mobile/MobileHome";
import { useQuery } from "@tanstack/react-query";
import { Component, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { useHomeFooterFit } from "@/lib/home-footer-fit";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { ArrowRight, Check, ChevronDown } from "lucide-react";
import { HoverlessLink } from "@/components/navigation/HoverlessLink";
import { LinkBotFAQ } from "@/components/landing/LinkBotFAQ";
import { LinkBotQuestions } from "@/components/landing/LinkBotQuestions";
import { DESKTOP_CANVAS_WIDTH, getDesktopScale, isPhoneLandscapeViewport } from "@/lib/desktop-scale";
import { FEATURES, FEATURE_LABELS, FEATURE_STAGGER, FeatureBannerGraphic, FitOneLine } from "@/components/landing/landing-content";
import { DemoRequestForm, DemoStage, LiveDemoStage } from "@/components/landing/HeroDemo";
import { ReviewCarousel, ScrollReveal, StatsCounter } from "@/components/landing/LandingWidgets";
import { getCheckoutConfig } from "@/lib/site-config.functions";
import { cn } from "@/lib/utils";
import { setHeroPaused } from "@/lib/hero-pause";

const TABLET_FORM_WIDTH = 880;
const CTA_CLASSES = "linkbot-button";

const TITLE = "LinkBot | Instant AI Voice Employee";
const SHARE_TITLE = "AI Voice Employee";
const DESC = "Turn your LinkedIn profile into a live conversation with a ready to use AI voice employee that answers questions and captures leads.";
const SHARE_IMAGE = "https://linkbot.now/linkbot-share-square.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: SHARE_TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://linkbot.now/" },
      { property: "og:image", content: SHARE_IMAGE },
      { property: "og:image:secure_url", content: SHARE_IMAGE },
      { property: "og:image:type", content: "image/jpeg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "1200" },
      { property: "og:image:alt", content: "LinkBot.Now" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: SHARE_TITLE },
      { name: "twitter:image", content: SHARE_IMAGE },
    ],
    links: [{ rel: "canonical", href: "https://linkbot.now/" }],
  }),
  component: Landing,
});

function clearMobileBoot() {
  if (typeof document !== "undefined") document.documentElement.classList.remove("mh-boot");
}

class MobileHomeBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch(error: unknown) {
    clearMobileBoot();
    console.error("[MobileHome] crashed, showing the regular homepage instead:", error);
  }
  override render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

function Landing() {
  // Keep the page hidden until its final layout has settled (first load).
  useRevealWhenSettled();
  const location = useLocation();
  const mobileActive = useMobileHomeSwitch(location.pathname, location.searchStr);
  // Never leave the page hidden: once the switch has decided on the regular
  // homepage, drop the boot guard (the first hydration pass is skipped only
  // when the switch is about to turn on).
  useEffect(() => {
    if (!mobileActive && !isMobileHomeSwitchActive()) clearMobileBoot();
  }, [mobileActive]);
  // Prompt 125: narrow desktop window — give the phone homepage the same
  // window-fitted scale a phone gets from its boot script.
  useLayoutEffect(() => {
    if (!mobileActive || !isNarrowDesktopWindow()) return;
    const d = document.documentElement;
    const set = () => {
      if (!isNarrowDesktopWindow()) return;
      d.style.setProperty("--mobile-scale", String((d.clientWidth || window.innerWidth) / 1440));
      d.style.setProperty("--mh-screen-h", `${window.innerHeight}px`);
    };
    set();
    window.addEventListener("resize", set);
    return () => {
      window.removeEventListener("resize", set);
      d.style.removeProperty("--mobile-scale");
      d.style.removeProperty("--mh-screen-h");
    };
  }, [mobileActive]);
  return mobileActive ? (
    <MobileHomeBoundary fallback={<DesktopHome />}>
      <MobileHome />
    </MobileHomeBoundary>
  ) : (
    <DesktopHome />
  );
}


// Per-tab key: a refresh keeps the finished live demo, a brand new window
// starts over so duplicate demos are never generated.
const DEMO_SESSION_KEY = "linkbot:live-demo-company";
const DEMO_FORM_OPEN_KEY = "linkbot:demo-form-open";

function DesktopHome() {
  const { data: checkout } = useQuery({ queryKey: ["checkout-config"], queryFn: () => getCheckoutConfig(), staleTime: 300_000 });
  const [demoView, setDemoView] = useState<"hero" | "form" | "call">("hero");
  useDemoViewTop(demoView);
  const [demoCompany, setDemoCompany] = useState("Your Business");
  // Once a visitor has created their live demo, this tab stays on the live demo
  // view — the intro and the form are never shown again (a brand new window
  // starts fresh, so no duplicate demos are generated).
  const [demoLocked, setDemoLocked] = useState(false);
  const [heroVisible, setHeroVisible] = useState(true);
  const [desktopScaleUp, setDesktopScaleUp] = useState<number | null>(null);
  const [layerRetry, setLayerRetry] = useState(0);
  const [tabletZoom, setTabletZoom] = useState<number | null>(null);
  const [formFitScale, setFormFitScale] = useState(1);
  const formFullHeightRef = useRef(0);
  const [faqOpen, setFaqOpen] = useState(false);
  const homeFooterRef = useRef<HTMLElement>(null);
  useHomeFooterFit(homeFooterRef, [faqOpen]);
  const demoFooterRef = useRef<HTMLElement>(null);
  useFooterMatchHeader(demoFooterRef, "rgb(173, 173, 173)", [demoView]);
  const mainRef = useRef<HTMLElement>(null);
  const heroRef = useRef<HTMLElement>(null);
  const heroCompositionRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLElement>(null);
  const questionsRef = useRef<HTMLElement>(null);
  const demoFormRef = useRef<HTMLDivElement>(null);
  const sidewaysRotationSettlingRef = useRef(false);
  const [activeFeature, setActiveFeature] = useState<number | null>(null);
  const featureTargetRef = useRef<number | null>(null);
  const featureRefs = useRef<Array<HTMLDivElement | null>>([]);
  const chatCloseTextRef = useRef<HTMLDivElement>(null);
  const chatCloseCardRef = useRef<HTMLDivElement>(null);

  // Desktop and iPad-sized screens: scale the "From chat to close" pricing card as one unit so its
  // height is 15% bigger than the 10%-bigger matched size from Prompt 269 (1.1 × 1.15 = 1.265× the
  // matched text-block height; Prompts 267/268 matched exactly). A transform scale is used (never
  // zoom) so the card's content cannot reflow, and
  // the frame's layout height is set to the scaled height so the space it takes grows with it. The
  // card's frame sits in an items-center grid column, so the taller frame stays vertically centered
  // on the text block and the extra size extends evenly above and below it. The factor is measured
  // from the live layout, never guessed, and kept exact by a ResizeObserver as fonts and reveal
  // animations settle.
  useEffect(() => {
    const card = chatCloseCardRef.current;
    const text = chatCloseTextRef.current;
    if (!card || !text) return;
    const frame = card.parentElement;
    if (!frame) return;
    const shouldScaleCard = () =>
      Math.min(window.screen.width, window.screen.height) > 600 &&
      window.matchMedia("(min-width: 640px)").matches;
    // Prompt 309: the chart in this section reads the card's on-screen factor
    // from the section, so its corners can match the card's on screen.
    const section = card.closest("section");
    const CARD_GROW = 1.1 * 1.15;
    const apply = () => {
      if (!shouldScaleCard()) {
        card.style.transform = "";
        card.style.transformOrigin = "";
        frame.style.height = "";
        section?.style.removeProperty("--pc2-k");
        return;
      }
      // Measure the natural layout first (transforms never affect it).
      card.style.transform = "";
      frame.style.height = "";
      const textH = text.offsetHeight;
      const cardH = card.offsetHeight;
      if (textH > 0 && cardH > 0) {
        // Preserve the existing desktop 0.85 CSS zoom when measuring the
        // card's authored height; iPad's computed zoom remains 1.
        const cardZoom = Number.parseFloat(getComputedStyle(card).zoom) || 1;
        const scale = (CARD_GROW * textH) / (cardH * cardZoom);
        card.style.transformOrigin = "top center";
        card.style.transform = `scale(${scale})`;
        // Prompt 308: the card's own on-screen factor, so its button can be authored
        // at the site's button size divided by it (fixed CSS; the button's slot has a
        // fixed height, so this never feeds back into the card's measured height).
        card.style.setProperty("--pc2-k", String(scale * cardZoom));
        section?.style.setProperty("--pc2-k", String(scale * cardZoom));
        frame.style.height = `${CARD_GROW * textH}px`;
      }
    };
    const ro = new ResizeObserver(apply);
    ro.observe(text);
    ro.observe(card);
    apply();
    window.addEventListener("resize", apply);
    window.addEventListener("orientationchange", apply);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", apply);
      window.removeEventListener("orientationchange", apply);
      card.style.transform = "";
      card.style.transformOrigin = "";
      frame.style.height = "";
      section?.style.removeProperty("--pc2-k");
    };
  }, []);

  // Clicking the header lockup while already on the home page returns to the top
  // of the landing view instead of doing nothing.
  useEffect(() => {
    const goHome = () => {
      setDemoView(demoLocked ? "call" : "hero");
      window.scrollTo({ top: 0, behavior: "auto" });
    };
    window.addEventListener("linkbot:home-nav", goHome);
    return () => window.removeEventListener("linkbot:home-nav", goHome);
  }, [demoLocked]);

  // iPad only: make the hero itself occupy the complete viewport beneath the
  // unchanged site header. The hero keeps its existing internal composition;
  // only its outer vertical canvas grows or contracts as one section.
  useLayoutEffect(() => {
    const hero = heroRef.current;
    const composition = heroCompositionRef.current;
    if (!hero || !composition) return;
    let frame = 0;
    let measuredWidth = 0;
    let measuredHeight = 0;

    const clear = () => {
      hero.classList.remove("ipad-fit-hero");
      hero.classList.remove("call-fit-screen");
      hero.classList.remove("call-fit-landscape");
      hero.classList.remove("desktop-hero-fold");
      hero.style.removeProperty("--ipad-hero-height");
      hero.style.removeProperty("--desktop-hero-min-height");
      composition.style.removeProperty("--ipad-hero-content-scale");
    };

    const apply = (force = false) => {
      frame = 0;
      if ((window.visualViewport?.scale ?? 1) !== 1 && !isPhoneLandscapeViewport()) return;
      const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
      if (demoView === "form" || viewportWidth < 640) {
        clear();
        return;
      }

      // Safari can emit resize events while its browser chrome moves even though
      // the page's actual layout viewport has not changed. Keep the initially
      // fitted composition locked unless the real layout dimensions change.
      const viewportHeight = document.documentElement.clientHeight || window.innerHeight;
      // 372: same rule for the hero height on a sideways phone: ignore toolbar
      // height-only changes after the first fit; a real width change still re-fits.
      if (!force && isPhoneLandscapeViewport() && measuredWidth > 0 && viewportWidth === measuredWidth) return;
      if (!force && viewportWidth === measuredWidth && viewportHeight === measuredHeight) return;
      measuredWidth = viewportWidth;
      measuredHeight = viewportHeight;

      const headerHeight = Number.parseFloat(
        getComputedStyle(document.documentElement).getPropertyValue("--site-header-height"),
      ) || 0;
      const outerScale = getDesktopScale(viewportWidth);
      const viewportHeroHeight = Math.max(1, (viewportHeight - headerHeight) / outerScale);
      hero.style.setProperty("--ipad-hero-height", `${viewportHeroHeight}px`);

      // Desktop intro only: preserve the approved hero height, but extend its
      // bottom edge when a shorter natural hero would expose Features at load.
      if (demoView === "hero" && viewportWidth >= 1024) {
        hero.classList.remove("ipad-fit-hero", "call-fit-screen");
        hero.classList.add("desktop-hero-fold");
        hero.style.setProperty("--desktop-hero-min-height", `${viewportHeroHeight}px`);
        composition.style.removeProperty("--ipad-hero-content-scale");
        return;
      }

      hero.classList.remove("desktop-hero-fold");
      hero.style.removeProperty("--desktop-hero-min-height");

      // Slide three keeps every piece of content at its approved size. Only its
      // blank space above and below contracts so the complete hero ends exactly
      // at the bottom of the screen beneath the unchanged header.
      // Sideways phone only: the live demo grows to fit its content (minimum one
      // screen below the header) and starts at the top instead of centering.
      if (demoView === "call" && isPhoneLandscapeViewport()) {
        hero.classList.remove("ipad-fit-hero", "call-fit-screen");
        hero.classList.add("call-fit-landscape");
        composition.style.removeProperty("--ipad-hero-content-scale");
        return;
      }
      hero.classList.remove("call-fit-landscape");

      if (demoView === "call" && viewportWidth >= 1024) {
        hero.classList.remove("ipad-fit-hero");
        hero.classList.add("call-fit-screen");
        composition.style.removeProperty("--ipad-hero-content-scale");
        return;
      }

      hero.classList.remove("call-fit-screen");
      hero.classList.add("ipad-fit-hero");

      // Measure the unchanged headline in authored layout pixels. Locking its
      // width to 72rem makes it exactly as wide as the header and Why LinkBot
      // content after DesktopScale applies the shared outer tablet scale.
      composition.style.setProperty("--ipad-hero-content-scale", "1");
      const headline = composition.querySelector("h1");
      const authoredContentWidth = Math.max(
        1,
        demoView === "hero" ? (headline?.clientWidth ?? 1) : composition.clientWidth,
      );
      // Slide three keeps the exact mobile composition intact and scales as one
      // unit. Its width stays capped near the shared content width, while its
      // height can reduce further so the complete composition always fits the
      // iPad viewport with balanced space above and below.
      const contentScale = demoView === "call"
        ? Math.min(1120 / 998.4, Math.max(0.1, (viewportHeroHeight - 224) / composition.scrollHeight))
        : 1152 / authoredContentWidth;
      composition.style.setProperty("--ipad-hero-content-scale", `${contentScale}`);
      const completeContentHeight = composition.scrollHeight * contentScale + 224;
      hero.style.setProperty(
        "--ipad-hero-height",
        `${demoView === "call" ? viewportHeroHeight : Math.max(viewportHeroHeight, completeContentHeight)}px`,
      );
    };

    const schedule = () => {
      if (frame || ((window.visualViewport?.scale ?? 1) !== 1 && !isPhoneLandscapeViewport())) return;
      frame = window.requestAnimationFrame(() => apply());
    };

    apply(true);
    window.addEventListener("resize", schedule);
    window.addEventListener("orientationchange", schedule);
    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", schedule);
      window.removeEventListener("orientationchange", schedule);
      clear();
    };
  }, [demoView]);

  const formFlagReadyRef = useRef(false);
  useEffect(() => {
    if (!formFlagReadyRef.current) { formFlagReadyRef.current = true; return; }
    try {
      if (demoView === "form") window.sessionStorage.setItem(DEMO_FORM_OPEN_KEY, "1");
      else window.sessionStorage.removeItem(DEMO_FORM_OPEN_KEY);
    } catch { /* private mode */ }
  }, [demoView]);

  useEffect(() => {
    // A visitor who already created their live demo in this tab stays on it,
    // even after a refresh.
    let saved: string | null = null;
    try {
      saved = window.sessionStorage.getItem(DEMO_SESSION_KEY);
    } catch {
      saved = null;
    }
    if (saved) {
      setDemoCompany(saved);
      setDemoLocked(true);
      setDemoView("call");
    } else {
      let formOpen = false;
      try { formOpen = window.sessionStorage.getItem(DEMO_FORM_OPEN_KEY) === "1"; } catch { formOpen = false; }
      setDemoView(formOpen ? "form" : "hero");
    }
    const hash = window.location.hash.replace("#", "");
    if (hash) {
      const target = document.getElementById(hash);
      if (target) {
        requestAnimationFrame(() => {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        });
        return;
      }
      window.history.replaceState(null, "", window.location.pathname + window.location.search);
    }
    window.scrollTo(0, 0);
  }, []);

  // Sideways-phone only: rotation changes orientation, viewport width, browser
  // scale and scroll geometry in separate steps. Tear down the portrait sticky
  // stack immediately, keep the page at the same clean starting point as a
  // fresh sideways load, then rebuild the existing desktop stack after each of
  // the browser's layout settle points. Real desktop, iPad and portrait phone
  // never enter this branch.
  useLayoutEffect(() => {
    const pendingTimers = new Set<number>();

    const clearPortraitStack = () => {
      const main = mainRef.current;
      const hero = heroRef.current;
      const features = featuresRef.current;
      const canvas = main?.closest<HTMLElement>(".desktop-scale-canvas");
      if (!main || !hero || !features) return;

      main.classList.remove(
        "layered-scroll-ready",
        "layered-scroll-native",
        "layered-scroll-mobile-native",
        "layered-scroll-measuring",
      );
      main.style.removeProperty("--layer-mobile-header-top");
      main.style.removeProperty("--layer-mobile-feature-top");
      for (const element of [hero, features]) {
        element.style.removeProperty("--layer-scroll-y");
        element.style.removeProperty("--layer-hold-start");
        element.style.removeProperty("--layer-hold-end");
        element.style.removeProperty("--layer-hold-distance");
      }
      features.style.removeProperty("padding-bottom");
      canvas?.classList.remove("layered-scroll-phone-canvas");
      canvas?.style.removeProperty("--layer-mobile-canvas-scale");
    };

    const settleSidewaysLayout = () => {
      if (!isPhoneLandscapeViewport()) return;
      window.scrollTo(0, 0);
      sidewaysRotationSettlingRef.current = false;
      // DesktopScale owns the outer document height. Notify its existing
      // resize path after the portrait-only padding/classes are gone so the
      // rotated page receives the same final height as a fresh landscape load.
      window.dispatchEvent(new Event("resize"));
      setLayerRetry((value) => value + 1);
    };

    const handleOrientationChange = () => {
      if (!isPhoneLandscapeViewport()) return;
      sidewaysRotationSettlingRef.current = true;
      clearPortraitStack();
      window.scrollTo(0, 0);

      for (const delay of [100, 300, 600]) {
        const timer = window.setTimeout(() => {
          pendingTimers.delete(timer);
          settleSidewaysLayout();
        }, delay);
        pendingTimers.add(timer);
      }
      // 369C: the browser adjusts its sideways zoom at varying moments for a few
      // seconds after a turn; return to the very top after each adjustment and at
      // fixed checkpoints, until the visitor touches the screen.
      {
        let touched = false;
        const toTop = () => {
          if (navigator.userAgent.includes("CriOS") && !document.documentElement.classList.contains("pg-rotate-hold")) return;
          if (touched || !isPhoneLandscapeViewport()) return;
          // The browser can leave its visible area shifted down inside the page
          // while the page itself reports the top; a real 1px scroll and back
          // makes it re-align the visible area with the page top.
          window.scrollTo(0, 1);
          window.requestAnimationFrame(() => {
            if (!touched) window.scrollTo(0, 0);
          });
        };
        const onTouch = () => { touched = true; };
        const vv = window.visualViewport;
        window.addEventListener("touchstart", onTouch, { passive: true, once: true });
        vv?.addEventListener("resize", toTop);
        for (const delay of [900, 1700, 2500, 3100, 4000]) {
          const timer = window.setTimeout(() => {
            pendingTimers.delete(timer);
            toTop();
            if (delay === 4000) {
              window.removeEventListener("touchstart", onTouch);
              vv?.removeEventListener("resize", toTop);
            }
          }, delay);
          pendingTimers.add(timer);
        }
      }
    };

    // 369: coming from upright, this sideways layout mounts after the turn and
    // misses the orientationchange event; run the same settle steps once now.
    if (
      isPhoneLandscapeViewport() &&
      document.documentElement.classList.contains("pg-rotate-fade")
    ) {
      handleOrientationChange();
    }
    window.addEventListener("orientationchange", handleOrientationChange);
    return () => {
      pendingTimers.forEach((timer) => window.clearTimeout(timer));
      window.removeEventListener("orientationchange", handleOrientationChange);
    };
  }, []);

  useLayoutEffect(() => {
    const main = mainRef.current;
    const hero = heroRef.current;
    const features = featuresRef.current;
    const questions = questionsRef.current;
    // The layered pull-up applies to the hero slide and the live-demo (slide 3)
    // view alike; only the form view opts out.
    if (!main || !hero || !features || !questions || demoView === "form") return;

    if (sidewaysRotationSettlingRef.current) return;

    const desktop = window.matchMedia("(min-width: 640px)");
    if (!desktop.matches) {
      // If the width wasn't settled yet at mount, start stacking as soon as it is.
      const retry = () => { if (desktop.matches) setLayerRetry((n) => n + 1); };
      desktop.addEventListener("change", retry);
      const late = window.setTimeout(retry, 300);
      return () => { desktop.removeEventListener("change", retry); window.clearTimeout(late); };
    }
    let frame = 0;
    let heroStart = 0;
    let heroEnd = 0;
    let featuresStart = 0;
    let featuresEnd = 0;
    let heroPinnedTop = 0;
    let featuresPageTop = 0;
    let questionsPageTop = 0;
    let scale = 1;
    let measuredViewportWidth = document.documentElement.clientWidth;
    let measuredViewportHeight = document.documentElement.clientHeight;
    // 433: last measured layout heights, so scroll-time checks can notice
    // section height changes without re-measuring on every scroll event.
    let lastHeroHeight = 0;
    let lastFeaturesHeight = 0;
    let lastFeaturesGap = 0;

    const clamp01 = (value: number) => Math.max(0, Math.min(1, value));
    // 253: iPad pauses the hero demo while Features fully covers it.
    const isIPad =
      /iPad/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

    // When the browser supports scroll-driven animations, the hold is handed to
    // the compositor: JS only publishes the measured ranges, so the stationary
    // layer can never lag a frame behind native scrolling (the jitter source).
    const nativeTimeline =
      typeof CSS !== "undefined" &&
      typeof CSS.supports === "function" &&
      CSS.supports("animation-timeline: scroll(root block)");
    let useNative = nativeTimeline;
    // HOMEPAGE-5: Safari only (Mac/iPad). Its scroll arrives a frame ahead of
    // the hold's push-back; these flags drive the Safari-only smoothing below.
    const safariUa = navigator.userAgent;
    const safari =
      /Safari/i.test(safariUa) && !/Chrome|CriOS|Chromium|FxiOS|EdgiOS|Edg\/|OPR|Android/i.test(safariUa);
    let safariFrame = 0;
    if (safari) main.classList.add("safari-layer-hold");


    const holdVars = ["--layer-hold-start", "--layer-hold-end", "--layer-hold-distance"];

    const clear = () => {
      main.classList.remove("layered-scroll-ready");
      main.classList.remove("layered-scroll-native");
      hero.classList.remove("layer-holding");
      features.classList.remove("layer-holding");
      for (const element of [hero, features]) {
        element.style.removeProperty("--layer-scroll-y");
        for (const name of holdVars) element.style.removeProperty(name);
      }
    };

    const setHold = (element: HTMLElement, start: number, end: number) => {
      // Whole-pixel ranges keep Safari's scroll timeline from wobbling on
      // fractional offsets; the distance uses the same rounded range.
      const s = Math.max(0, Math.round(start));
      const e = Math.max(s + 1, Math.round(end));
      element.style.setProperty("--layer-hold-start", `${s}px`);
      element.style.setProperty("--layer-hold-end", `${e}px`);
      element.style.setProperty("--layer-hold-distance", `${(e - s) / scale}px`);
    };

    const paint = () => {
      frame = 0;
      // 409: sideways phones scroll straight through in normal page flow.
      if (isPhoneLandscapeViewport()) { clear(); return; }
      if (!desktop.matches || ((window.visualViewport?.scale ?? 1) !== 1 && !isPhoneLandscapeViewport())) {
        clear();
        return;
      }

      const scrollY = window.scrollY;
      const inHeroReveal = scrollY >= heroStart && scrollY < heroEnd;
      const inNextReveal = scrollY >= featuresStart && scrollY < featuresEnd;
      let heroLift = 0;
      let featuresLift = 0;

      if (inHeroReveal) {
        heroLift = (scrollY - heroStart) / scale;
      } else if (inNextReveal) {
        featuresLift = (scrollY - featuresStart) / scale;
      }

      // 383: on sideways phones, only treat a section as a moving layer while it
      // is actually being held, so it does not occupy graphics memory otherwise.
      hero.classList.toggle("layer-holding", inHeroReveal);
      features.classList.toggle("layer-holding", inNextReveal);

      if (!useNative) {
        hero.style.setProperty("--layer-scroll-y", `${heroLift}px`);
        features.style.setProperty("--layer-scroll-y", `${featuresLift}px`);
      }
    };

    const measure = () => {
      // 409: sideways phones scroll straight through in normal page flow.
      if (isPhoneLandscapeViewport()) { clear(); return; }
      hero.style.removeProperty("--layer-scroll-y");
      features.style.removeProperty("--layer-scroll-y");
      // A re-measure can land in the middle of an active hold. Any hold offset
      // still applied while the rectangles are read would be folded into the
      // published ranges, which then shifts the hold itself — the feedback loop
      // that shows up as shaking. Neutralise both layers for the read.
      main.classList.add("layered-scroll-measuring");

      scale = hero.offsetWidth > 0 ? hero.getBoundingClientRect().width / hero.offsetWidth : 1;
      if (!Number.isFinite(scale) || scale <= 0) {
        main.classList.remove("layered-scroll-measuring");
        clear();
        return;
      }

      const featuresRect = features.getBoundingClientRect();
      const questionsRect = questions.getBoundingClientRect();
      const heroRect = hero.getBoundingClientRect();
      const heroPageTop = heroRect.top + window.scrollY;
      featuresPageTop = featuresRect.top + window.scrollY;
      questionsPageTop = questionsRect.top + window.scrollY;
      heroStart = Math.max(0, featuresPageTop - window.innerHeight);
      // The hold must last exactly as long as the incoming layer needs to travel
      // one full viewport (bottom edge -> top edge). Ending it any earlier drops
      // the held layer back down while part of it is still visible, which reads
      // as a band of empty black appearing above the rising section.
      heroEnd = Math.max(heroStart + 1, featuresPageTop);
      heroPinnedTop = heroPageTop - heroStart;
      featuresStart = questionsPageTop - window.innerHeight;
      featuresEnd = questionsPageTop;
      main.classList.remove("layered-scroll-measuring");
      main.classList.add("layered-scroll-ready");
      // 433: remember the layout heights measured here; offsetHeight/offsetTop
      // are layout values, so the hold transforms never affect them.
      lastHeroHeight = hero.offsetHeight;
      lastFeaturesHeight = features.offsetHeight;
      lastFeaturesGap = questions.offsetTop - features.offsetTop;
      if (useNative && desktop.matches) {
        setHold(hero, heroStart, heroEnd);
        setHold(features, featuresStart, featuresEnd);
        main.classList.add("layered-scroll-native");
      } else {
        main.classList.remove("layered-scroll-native");
      }
      paint();
    };

    const scheduleMeasure = () => {
      if (frame || ((window.visualViewport?.scale ?? 1) !== 1 && !isPhoneLandscapeViewport())) return;
      frame = window.requestAnimationFrame(measure);
    };

    let zoomLight = document.documentElement.classList.contains("home-zoom-light");
    let zoomMeasureTimer = 0;
    const zoomObserver = new MutationObserver(() => {
      const nextZoomLight = document.documentElement.classList.contains("home-zoom-light");
      if (nextZoomLight === zoomLight) return;
      zoomLight = nextZoomLight;
      if (zoomLight && useNative) {
        useNative = false;
        main.classList.remove("layered-scroll-native");
        window.addEventListener("scroll", handleScroll, { passive: true });
        paint();
      } else if (!zoomLight && nativeTimeline) {
        // 477: zoom ended — once the browser is back at normal scale, re-run this whole effect
        // from scratch (exactly like a fresh page load) so nothing measured while zoomed is kept.
        window.removeEventListener("scroll", handleScroll);
        useNative = true;
        let tries = 0;
        const waitForNormalScale = () => {
          window.clearTimeout(zoomMeasureTimer);
          const s = window.visualViewport?.scale ?? 1;
          if (Math.abs(s - 1) < 0.01 || tries >= 20) {
            if (frame) { window.cancelAnimationFrame(frame); frame = 0; }
            measure();
            return;
          }
          tries += 1;
          zoomMeasureTimer = window.setTimeout(waitForNormalScale, 100);
        };
        zoomMeasureTimer = window.setTimeout(waitForNormalScale, 0);
      }
    });
    zoomObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });

    const handleResize = () => {
      const nextWidth = document.documentElement.clientWidth;
      const nextHeight = document.documentElement.clientHeight;
      // 372: on a sideways phone the browser toolbar sliding while scrolling
      // changes only the height; re-measuring mid-scroll releases the held layer
      // for a frame (shake / black seam). Only a real width change re-measures.
      if (isPhoneLandscapeViewport() && nextWidth === measuredViewportWidth) return;
      // HOMEPAGE-5: Safari's address bar showing/hiding changes only the height.
      if (safari && nextWidth === measuredViewportWidth) return;
      if (nextWidth === measuredViewportWidth && nextHeight === measuredViewportHeight) return;
      measuredViewportWidth = nextWidth;
      measuredViewportHeight = nextHeight;
      scheduleMeasure();
    };

    // 433: throttled to once every 400ms, this check notices real section
    // height changes and re-measures — but never while a hold is active.
    let lastHeightCheck = 0;
    const checkHeights = () => {
      const now = Date.now();
      if (now - lastHeightCheck < 400) return;
      lastHeightCheck = now;
      const scrollY = window.scrollY;
      const holding =
        (scrollY >= heroStart && scrollY < heroEnd) ||
        (scrollY >= featuresStart && scrollY < featuresEnd);
      if (holding) return;
      if (
        Math.abs(hero.offsetHeight - lastHeroHeight) > 1 ||
        Math.abs(features.offsetHeight - lastFeaturesHeight) > 1 ||
        Math.abs(questions.offsetTop - features.offsetTop - lastFeaturesGap) > 1
      ) {
        scheduleMeasure();
      }
    };

    const handleScroll = () => {
      if ((window.visualViewport?.scale ?? 1) !== 1 && !isPhoneLandscapeViewport()) return;
      checkHeights();
      paint();
      // HOMEPAGE-5: in Safari also re-apply the push-back at the very start of
      // the next screen update, before it is drawn, so it lands with the scroll.
      if (safari && !safariFrame) {
        safariFrame = window.requestAnimationFrame(() => {
          safariFrame = 0;
          if (!useNative) paint();
        });
      }
    };


    // These sections have fixed authored geometry. Observing the translated
    // layers themselves created a measurement feedback loop on Safari: the
    // observer repeatedly republished the scroll ranges while a layer was
    // moving, causing visible shaking and occasionally dropping the final
    // Features → Why LinkBot hold. Measure after layout/fonts settle and only
    // again when the real layout viewport changes.
    measure();
    // Sideways-phone rotation settles in several browser layout passes. The
    // outer frame is rewritten after those passes; observe that frame only on
    // a physical phone in landscape so each correction republishes the same
    // desktop hold ranges from final geometry. Fresh landscape loads also take
    // this harmless path. Real desktop and iPad never create this observer.
    const scaleFrame = isPhoneLandscapeViewport()
      ? main.closest<HTMLElement>(".desktop-scale-frame")
      : null;
    const scaleFrameObserver = scaleFrame ? new ResizeObserver(scheduleMeasure) : null;
    if (scaleFrame && scaleFrameObserver) scaleFrameObserver.observe(scaleFrame);
    // 433: re-check the stored heights shortly after mount as well, in case
    // content settled after the initial measure.
    const heightTimer1 = window.setTimeout(checkHeights, 1000);
    const heightTimer2 = window.setTimeout(checkHeights, 3000);
    window.addEventListener("load", scheduleMeasure);
    document.fonts?.ready.then(scheduleMeasure).catch(() => {});
    if (!useNative) window.addEventListener("scroll", handleScroll, { passive: true });
    // 253: iPad pauses the hero demo timers while Features fully covers it (Prompt 180).
    const handleIpadPause = () => setHeroPaused(window.scrollY >= heroEnd && heroEnd > 1);
    if (isIPad) window.addEventListener("scroll", handleIpadPause, { passive: true });
    window.addEventListener("resize", handleResize);
    window.addEventListener("orientationchange", handleResize);
    desktop.addEventListener("change", scheduleMeasure);
    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      if (safariFrame) window.cancelAnimationFrame(safariFrame);
      main.classList.remove("safari-layer-hold");
      zoomObserver.disconnect();
      window.clearTimeout(zoomMeasureTimer);
      scaleFrameObserver?.disconnect();
      window.clearTimeout(heightTimer1);
      window.clearTimeout(heightTimer2);
      window.removeEventListener("load", scheduleMeasure);
      window.removeEventListener("scroll", handleScroll);
      if (isIPad) {
        window.removeEventListener("scroll", handleIpadPause);
        setHeroPaused(false);
      }
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("orientationchange", handleResize);
      desktop.removeEventListener("change", scheduleMeasure);
      clear();
    };
  }, [demoView, layerRetry]);





  // The hero canvas is scaled down to fit phones, so the hero headline's true
  // on-screen size is smaller than its CSS font-size. Publish that real size
  // as --hero-live-fs so the demo form title can never render larger than the
  // hero headline itself.
  const publishHeroHeadlineSize = () => {
    const heroHeadline = document.querySelector<HTMLElement>("h1.headline");
    if (!heroHeadline) return;
    const rect = heroHeadline.getBoundingClientRect();
    const fontSize = parseFloat(window.getComputedStyle(heroHeadline).fontSize);
    const scale = heroHeadline.offsetWidth > 0 ? rect.width / heroHeadline.offsetWidth : 1;
    document.documentElement.style.setProperty("--hero-live-fs", `${(fontSize * scale).toFixed(2)}px`);
  };

  const openDemoForm = () => {
    if (demoLocked) {
      setDemoView("call");
      pinDemoViewToTop();
      return;
    }
    publishHeroHeadlineSize();
    setDemoView("form");
  };

  useLayoutEffect(() => {
    const updateScale = () => {
      const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
      setDesktopScaleUp(viewportWidth < 640 ? null : 1 / getDesktopScale(viewportWidth));
    };
    const onResize = () => {
      // Pinch zoom must never trigger a relayout of the scaled hero canvas.
      // A sideways phone deliberately reports a non-1 scale while presenting
      // the desktop canvas, so let that orientation transition finish.
      if (
        window.visualViewport &&
        window.visualViewport.scale !== 1 &&
        !isPhoneLandscapeViewport()
      ) return;
      updateScale();
      requestAnimationFrame(publishHeroHeadlineSize);
    };
    updateScale();
    requestAnimationFrame(publishHeroHeadlineSize);
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
    };
  }, []);

  // Mobile only: tell the fixed mobile header when the demo form is open so it
  // can swap Sign In / Get Now for a single blue Back button, and listen for
  // that button to return to the hero view.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent("linkbot:demo-form-active", { detail: demoView === "form" }));
    const onBack = () => setDemoView(demoLocked ? "call" : "hero");
    window.addEventListener("linkbot:demo-form-back", onBack);
    return () => window.removeEventListener("linkbot:demo-form-back", onBack);
  }, [demoView, demoLocked]);


  // iPad/tablet only (640-1023px): lay the form out narrower and scale it up so
  // it fills the whole page, keeping its rows intact. Desktop is untouched.
  useEffect(() => {
    if (demoView !== "form") {
      setTabletZoom(null);
      setFormFitScale(1);
       return;
    }
    const compute = () => {
      const vw = document.documentElement.clientWidth || window.innerWidth;
      setTabletZoom(vw >= 640 && vw < 1024 ? DESKTOP_CANVAS_WIDTH / TABLET_FORM_WIDTH : null);
    };
    compute();
    window.addEventListener("resize", compute);
    window.addEventListener("orientationchange", compute);
    return () => {
      window.removeEventListener("resize", compute);
      window.removeEventListener("orientationchange", compute);
    };
  }, [demoView]);

  // iPad/tablet only: stretch the form's vertical rhythm so it fills the page
  // height between the header and the footer. Phone and desktop are untouched.
  useEffect(() => {
    if (demoView !== "form") return;
    const node = demoFormRef.current;
    if (!node) return;
    let frame = 0;
    const apply = () => {
      const vw = document.documentElement.clientWidth || window.innerWidth;
      if (vw < 640 || vw >= 1024) {
        if (formFitScale !== 1) setFormFitScale(1);
        node.style.removeProperty("--form-gap");
        const t = node.querySelector<HTMLElement>("h2")?.parentElement;
        if (t) t.style.marginTop = "";
        const f = node.querySelector<HTMLElement>("form");
        if (f) f.style.marginTop = "";
        return;
      }
      // Prompt 151: the space below the Back button and above the footer
      // both equal the iPad homepage hero's top space (header bottom to the
      // eyebrow text), which centers 0.8852×width of content in the viewport
      // below the header. The rest of the height is spread evenly over the six
      // gaps (title block → fields, the four field rows, consent → button).
      const title = node.querySelector<HTMLElement>("h2");
      const titleBox = title?.parentElement;
      const form = node.querySelector<HTMLElement>("form");
      const back = node.querySelector<HTMLElement>(".demo-back-btn");
      const submit = node.querySelector<HTMLElement>("form button[type=submit]");
      const footer = [...document.querySelectorAll<HTMLElement>(".demo-form-footer")].find((el) => el.offsetParent !== null);
      const header = [...document.querySelectorAll<HTMLElement>(".desktop-header-frame, header")].find((el) => el.offsetParent !== null);
      if (!title || !titleBox || !form || !back || !submit || !footer || !header) return;
      const vh = window.visualViewport?.height ?? window.innerHeight;
      const target = Math.max(48, (vh - header.getBoundingClientRect().height - 0.8852 * vw) / 2);
      let gap = 16;
      let formTop = 32;
      node.style.setProperty("--form-gap", `${gap}px`);
      form.style.marginTop = `${formTop}px`;
      titleBox.style.marginTop = "";
      for (let i = 0; i < 10; i += 1) {
        const scale = titleBox.getBoundingClientRect().width / Math.max(1, titleBox.offsetWidth) || 1;
        // Prompt 154: measured from the header's bottom, not the Back button.
        const above = title.getBoundingClientRect().top - header.getBoundingClientRect().bottom;
        const current = parseFloat(titleBox.style.marginTop || "0");
        titleBox.style.marginTop = `${current + (target - above) / scale}px`;
        const below = footer.getBoundingClientRect().top - submit.getBoundingClientRect().bottom;
        const d = (below - target) / 6 / scale;
        if (Math.abs(target - above) < 0.3 && Math.abs(below - target) < 0.3) break;
        gap = Math.max(0, gap + d);
        formTop = Math.max(0, formTop + d);
        node.style.setProperty("--form-gap", `${gap}px`);
        form.style.marginTop = `${formTop}px`;
      }
      // Prompt 431: if the gaps are already at 0 and the button still sits
      // closer than the target to the footer, shrink the whole form as one
      // piece so it keeps the target space above the title and below the button.
      const headerBottom = header.getBoundingClientRect().bottom;
      const footerTop = footer.getBoundingClientRect().top;
      const titleTop = title.getBoundingClientRect().top;
      const submitBottom = submit.getBoundingClientRect().bottom;
      if (gap <= 0.05 && formTop <= 0.05 && submitBottom > footerTop - target) {
        const available = footerTop - headerBottom - 2 * target;
        const content = Math.max(1, submitBottom - titleTop);
        const next = Math.min(1, (available / content) * formFitScale);
        if (Math.abs(next - formFitScale) > 0.005) {
          if (next < 1) formFullHeightRef.current = content / formFitScale;
          setFormFitScale(next);
        }
      } else if (formFitScale !== 1) {
        if (footerTop - headerBottom - 2 * target >= formFullHeightRef.current + 2) setFormFitScale(1);
      }
    };
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(apply);
    };
    schedule();
    const timers = [150, 400, 900, 1600, 2600].map((ms) => window.setTimeout(schedule, ms));
    window.addEventListener("resize", schedule);
    window.addEventListener("orientationchange", schedule);
    return () => {
      cancelAnimationFrame(frame);
      timers.forEach((t) => window.clearTimeout(t));
      window.removeEventListener("resize", schedule);
      window.removeEventListener("orientationchange", schedule);
      node.style.removeProperty("--form-gap");
      const t = node.querySelector<HTMLElement>("h2")?.parentElement;
      if (t) t.style.marginTop = "";
      const f = node.querySelector<HTMLElement>("form");
      if (f) f.style.marginTop = "";
    };
  }, [demoView, tabletZoom, formFitScale]);

  // Prompt 152: desktop (1024+) only — the demo form's fields span exactly the
  // header content (mascot's left edge to Get Now's right edge). Only the form's
  // own width and left offset change; text, heights and spacing stay the same.
  useEffect(() => {
    if (demoView !== "form") return;
    const node = demoFormRef.current;
    if (!node) return;
    let frame = 0;
    const reset = (form: HTMLElement) => {
      form.style.removeProperty("width");
      form.style.removeProperty("max-width");
      form.style.removeProperty("margin-left");
    };
    const apply = () => {
      const form = node.querySelector<HTMLElement>("form");
      if (!form) return;
      reset(form);
      const vw = document.documentElement.clientWidth || window.innerWidth;
      if (vw < 1024) return;
      const header = [...document.querySelectorAll<HTMLElement>(".desktop-header-frame header, header")].find((el) => el.offsetParent !== null);
      const logo = header?.querySelector<HTMLElement>(".pr-brand-lockup");
      const getNow = [...(header?.querySelectorAll<HTMLElement>("a,button") ?? [])].filter((el) => el.offsetParent !== null && /get now/i.test(el.textContent ?? "")).pop();
      if (!logo || !getNow) return;
      const left = logo.getBoundingClientRect().left;
      const right = getNow.getBoundingClientRect().right;
      const rect = form.getBoundingClientRect();
      const scale = rect.width / Math.max(1, parseFloat(getComputedStyle(form).width)) || 1;
      form.style.maxWidth = "none";
      form.style.width = `${(right - left) / scale}px`;
      form.style.marginLeft = `${(left - rect.left) / scale}px`;
    };
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(apply);
    };
    schedule();
    const timers = [150, 400, 900, 1600, 2600].map((ms) => window.setTimeout(schedule, ms));
    window.addEventListener("resize", schedule);
    return () => {
      cancelAnimationFrame(frame);
      timers.forEach((t) => window.clearTimeout(t));
      window.removeEventListener("resize", schedule);
      const form = node.querySelector<HTMLElement>("form");
      if (form) reset(form);
    };
  }, [demoView]);

  useEffect(() => {
    const section = heroRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry) setHeroVisible(entry.isIntersecting); },
      { threshold: 0.3 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const onScroll = () => {
      if (window.scrollY <= 0 && faqOpen) {
        setFaqOpen(false);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [faqOpen]);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const nodes = featureRefs.current.filter(Boolean) as HTMLDivElement[];
      if (nodes.length === 0) return;
      const center = window.innerHeight / 2;
      const first = nodes[0]!.getBoundingClientRect();
      const last = nodes[nodes.length - 1]!.getBoundingClientRect();
      // Before the list reaches the viewport center, nothing is highlighted.
      if (first.top + first.height / 2 > center + window.innerHeight / 2) {
        featureTargetRef.current = null;
        return;
      }
      // Past the list, keep the last card lit instead of dropping the highlight.
      if (last.top + last.height / 2 < center) {
        featureTargetRef.current = nodes.length - 1;
        return;
      }
      let best = 0;
      let bestDistance = Number.POSITIVE_INFINITY;
      nodes.forEach((node, index) => {
        const rect = node.getBoundingClientRect();
        const distance = Math.abs(rect.top + rect.height / 2 - center);
        if (distance < bestDistance) {
          bestDistance = distance;
          best = index;
        }
      });
      featureTargetRef.current = best;
    };
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Advance on one persistent clock. Scroll events only move the destination,
  // so rapid scrolling cannot cancel a card's turn or jump across indices.
  useEffect(() => {
    const timer = window.setInterval(() => {
      setActiveFeature((current) => {
        const target = featureTargetRef.current;
        if (target === null) return current === null ? null : null;
        if (current === null) return 0;
        if (current === target) return current;
        return current + (target > current ? 1 : -1);
      });
    }, 320);
    return () => window.clearInterval(timer);
  }, []);



  const callCta = (
    <HoverlessLink to="/claim" className={cn(CTA_CLASSES, "hero-demo-cta-mobile")}><span>Buy Now</span></HoverlessLink>
  );

  return (
    <div
      className={cn("min-h-screen bg-background text-foreground", demoView === "form" && "demo-form-focus")}
      style={
        demoView === "form" && desktopScaleUp
            ? { minHeight: `calc((100dvh - var(--site-header-height, 80px)) * ${desktopScaleUp})` }
            : undefined
      }
    >
      <main
        ref={mainRef}
        className={demoView === "form" ? undefined : "layered-scroll-ready"}
      >
        <section ref={heroRef} className={`night-panel demo-form-focus-hero layer-scroll-hero relative overflow-hidden ${demoView === "hero" ? "desktop-hero-fold px-6 pb-16 pt-12" : demoView === "form" ? "px-6 pb-16 pt-12" : "px-6 pb-16 pt-12"}`}>
          <div className="demo-form-focus-glow pointer-events-none absolute -top-40 left-1/2 h-[40rem] w-[60rem] -translate-x-1/2 rounded-full bg-brand/25 blur-[140px]" />
          <div className={`relative mx-auto flex max-w-6xl flex-col justify-center text-center ${demoView === "hero" ? "min-h-[806px]" : demoView === "call" ? "slide-three-hero-inner min-h-[928px]" : "min-h-[820px]"}`}>

            {demoView === "form" ? (
              <div
                ref={demoFormRef}
                id="live-demo"
                className="mx-auto w-full max-w-[900px] scroll-mt-20"
                style={
                  tabletZoom && tabletZoom > 1
                      ? ({
                          "--form-width": `${TABLET_FORM_WIDTH}px`,
                          transform: `scale(${tabletZoom * formFitScale})`,
                          transformOrigin: "top center",
                        } as React.CSSProperties)
                      : undefined
                }
              >
                <div className="demo-form-focus-card rounded-[2rem] border border-border bg-surface px-10 pb-12 pt-8 shadow-elev-3 sm:origin-center sm:px-14 sm:pb-14 sm:pt-9">
                  <DemoRequestForm
                    onBack={() => setDemoView("hero")}
                    onComplete={(companyName) => {
                      setDemoCompany(companyName);
                      setDemoLocked(true);
                      try {
                        window.sessionStorage.setItem(DEMO_SESSION_KEY, companyName);
                      } catch {
                        /* private mode — the lock simply lasts for this view */
                      }
                      setDemoView("call");
                    }}
                  />
                </div>
              </div>
            ) : demoView === "call" ? (
              <LiveDemoStage compositionRef={heroCompositionRef} companyName={demoCompany} getNowCta={callCta} />
            ) : (
              <div ref={heroCompositionRef} className="hero-main-composition">
                <p className="pr-eyebrow" style={{ fontWeight: 700 }}>BUILT EXCLUSIVELY FOR YOUR LINKEDIN PROFILE</p>
                <h1 className="headline mx-auto mt-4 max-w-5xl whitespace-nowrap text-7xl text-night-foreground">
                  Instant{" "}<span className="headline inline-block text-brand">AI Voice Employee</span>
                </h1>
                <p className="mx-auto mt-3 max-w-none whitespace-nowrap text-base font-semibold leading-6 text-night-foreground">
                  <span className="">Turn static profile visits into live voice conversations</span>
                  <span className=""> that answers, qualifies and captures leads for you.</span>
                </p>

                <DemoStage demoPublicUrl={checkout?.demoPublicUrl ?? null} onOpenForm={openDemoForm} pulse={heroVisible} />
              </div>
            )}
          </div>
        </section>

        <section ref={featuresRef} id="features" className="feature-section layer-scroll-features night-panel -mt-px">
          <div className="section-banner-strip feature-banner-strip">
            <span className="section-banner-strip-text">Features</span>
          </div>
          <div className="mx-auto w-full max-w-[96rem] px-2 pt-[0.65rem]">
            <div className="feature-puzzle">
              {FEATURES.map((f, i) => {
                const s = FEATURE_STAGGER[i]!;
                const justifyClass = { center: "justify-center", start: "justify-start", end: "justify-end" }[s.justify];
                const from = s.justify === "end" ? "right" : "left";
                const active = activeFeature === i;
                return (
                  <ScrollReveal
                    key={f.title}
                    from={from}
                    delay={60}
                    className={cn("feature-puzzle-slot flex w-full", justifyClass, `feature-slot-${i + 1}`)}
                  >
                    <div
                      ref={(node) => { featureRefs.current[i] = node; }}
                      className={cn(
                        "feature-banner relative h-full overflow-hidden border",
                        active ? "border-brand feature-card-active" : "border-white/10",
                      )}
                      data-feature={i}
                    >
                      <div className="feature-banner-copy">
                        <div className="feature-banner-copy-lock">
                          <span className="feature-banner-kicker">{FEATURE_LABELS[i]}</span>
                          <h3 className="feature-banner-title w-full font-display font-extrabold text-night-foreground">{f.title}</h3>
                          <p className="feature-banner-body mt-3 w-full text-night-muted" data-mobile-body={f.mobileBody}><span className="fb-body-desktop">{f.desktopBody ?? f.body}</span>{f.ipadBody ? (<><span className="fb-body-non-ipad">{f.body}</span><span className="fb-body-ipad">{f.ipadBody}</span></>) : <span className="fb-body-base">{f.body}</span>}</p>
                        </div>
                      </div>
                      <FeatureBannerGraphic index={i} />
                    </div>
                  </ScrollReveal>
                );
              })}
            </div>
            <ScrollReveal delay={100} className="pr-featured-reveal">
              <article className="pr-featured-card">
                <div className="pr-featured-copy">
                  <span className="pr-featured-kicker">Hidden by design</span>
                  <h3 className="pr-featured-title">Protected Like Your Identity</h3>
                  <p className="pr-featured-text">Your AI speaks for you, so we lock it like it matters! If anyone copies or types your custom domain into a url directly, it leads nowhere. A secret code hidden behind your link is the only way in, so strangers can&apos;t drain your bot, misuse it, or pretend to be you with it.</p>
                </div>
                <div className="pr-featured-icon" aria-hidden="true">
                  <svg viewBox="0 0 120 120" fill="none">
                    <g className="pr-ad-unit">
                      <path className="pr-ad-bracket" d="M4 18 V4 H18 M102 4 H116 V18 M116 102 V116 H102 M18 116 H4 V102" />
                      <circle className="pr-ad-core" cx="60" cy="46" r="27" />
                      <path className="pr-ad-ring" pathLength={1} d="M60 19 A27 27 0 1 1 59.99 19" />
                      <path className="pr-ad-slash" pathLength={1} d="M41 27 L79 65" />
                      <rect className="pr-ad-scan" x="8" y="8" width="104" height="2" rx="1" />
                      <g className="pr-ad-label">
                        <rect className="pr-ad-plate" x="10" y="90" width="100" height="18" rx="3" />
                        <text className="pr-ad-text" x="60" y="102.6" textAnchor="middle" textLength="86" lengthAdjust="spacingAndGlyphs">ACCESS DENIED</text>
                      </g>
                    </g>
                  </svg>
                </div>
              </article>
            </ScrollReveal>
          </div>
        </section>



        <LinkBotQuestions onStartDemo={openDemoForm} sectionRef={questionsRef} />

        <section className="cost-of-waiting-section border-y border-border bg-surface">
          <div className="mx-auto max-w-6xl px-6 py-[clamp(4rem,8vw,6rem)] text-center">
            <ScrollReveal repeat>
              <p className="eyebrow">The cost of waiting</p>
              <h2 className="headline mx-auto mt-3 max-w-[26ch] text-balance text-5xl text-ink">
                The <span className="text-brand">best time to answer</span> is while interest is still high.
              </h2>
              <p className="mx-auto mt-4 max-w-[62ch] text-balance text-base font-semibold leading-7 text-muted-foreground">While you are in meetings, on calls, or asleep, your AI is handling conversations, capturing leads, and keeping your pipeline moving. You build the business, let LinkBot handle the first impression for you.</p>
              <StatsCounter />
            </ScrollReveal>
          </div>
        </section>

        <ReviewCarousel />

        <section className="night-panel overflow-hidden">
          <div className="mx-auto grid max-w-6xl grid-cols-2 items-center gap-24 px-6 py-24">
            <div className="max-w-xl" ref={chatCloseTextRef}>
              <p className="eyebrow">From chat to close</p>
              <h2 className="headline mt-4 text-balance text-5xl text-night-foreground">
                <span className="block">Runs like your best employee,</span>
                <span className="block"><span className="text-brand">without the high payroll costs</span>.</span>
              </h2>
              <p className="mt-4 max-w-[60ch] text-base font-semibold leading-7 text-night-muted">
                No sick or vacation days! Get another set of hands for your business without another salary, schedule, or person to manage. LinkBot is ready to work around the clock for one simple monthly price with no long-term contract.
              </p>
              <ul className="mt-8 space-y-5">
                {["Turn your profile into another call to action", "No salary, benefits, training, or employee overhead", "Be there for every opportunity without answering yourself"].map((t) => (
                  <li key={t} className="flex items-start gap-4 text-night-foreground/90">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-brand/30 bg-brand/10">
                      <Check className="h-3.5 w-3.5 text-brand" strokeWidth={3} />
                    </span>
                    <FitOneLine text={t} className="text-[15px] font-medium tracking-tight" />
                  </li>
                ))}
              </ul>
            </div>
            <div className="pricing-mobile-frame">
            <div className="pricing-fit-desktop relative" ref={chatCloseCardRef}>
              <ScrollReveal id="pricing" repeat downOnly className="pricing-reveal relative"><PricingCardNew /></ScrollReveal>
            </div>
            </div>
          </div>
          <CompareCostDesktop />
        </section>

        <section className="security-graphic-section">
          <div className="security-orbit security-orbit-outer" aria-hidden="true"><i /><i /><i /><i /></div>
          <div className="security-orbit security-orbit-inner" aria-hidden="true"><i /><i /><i /><i /></div>

          <div className="relative mx-auto flex min-h-[46rem] max-w-6xl flex-col justify-between px-6 py-28">
            <div className="grid grid-cols-[1.1fr_0.9fr] items-center gap-12">
              <div className="relative z-10 max-w-xl">
                <p className="eyebrow">Security</p>
                <h2 className="headline mt-3 text-balance text-5xl text-ink">
                  <span className="block">Your business always</span>
                  <span className="block">stays <span className="text-brand">your business</span>.</span>
                </h2>
                <p className="mt-5 max-w-[58ch] text-base font-semibold leading-7 text-ink-soft">
                  Conversations, lead details, and personal data<br className="hidden" /> are encrypted, independently audited, and<br className="hidden" /> continuously tested against threats.
                </p>
              </div>

              <div className="contents">
                <div
                  className="security-lockup"
                  aria-label="Conversation and lead data protected by audited encryption"
                >
                  <div className="security-orbit security-orbit-outer !left-1/2 !top-1/2 hidden" aria-hidden="true"><i /><i /><i /><i /></div>
                  <div className="security-orbit security-orbit-inner !left-1/2 !top-1/2 hidden" aria-hidden="true"><i /><i /><i /><i /></div>
                  <div className="security-feed security-feed-top" aria-hidden="true"><span>Conversation</span></div>
                  <div className="security-feed security-feed-bottom" aria-hidden="true"><span>Lead data</span></div>
                  <div className="security-seal">
                    <span className="security-seal-kicker">Protected by</span>
                    <strong>AES</strong>
                    <span className="security-seal-number">256</span>
                    <span className="security-seal-footer">Encrypted at rest</span>
                  </div>
                </div>

              <div className="security-promises col-span-2 border-t">
                {[
                  { meaning: <>Independent experts verify it.</>, key: "independent", proof: "SOC 2 Type II | Audited every year" },
                  { meaning: <>Conversations unreadable.</>, key: "conversations", proof: "AES 256 at rest | TLS 1.2+ in transit" },
                  { meaning: <>Security threats get caught early.</>, key: "threats", proof: "PEN TESTING | CONTINUOUS SCANNING" },
                ].map((item) => (
                  <div key={item.key} className="security-promise">
                    <p>{item.meaning}</p>
                    <span>{item.proof}</span>
                  </div>
                ))}
              </div>
            </div>
            </div>
          </div>
        </section>

        <div className={`faq-drawer ${faqOpen ? "faq-drawer--open" : ""}`} aria-hidden={!faqOpen} inert={!faqOpen}>
          <LinkBotFAQ />
        </div>
      </main>

      <footer
        ref={homeFooterRef}
        className="night-panel relative border-t border-night-border px-6 pb-8 pt-28 text-center text-sm text-night-muted"
      >
        <button
          type="button"
          onClick={() => setFaqOpen((open) => !open)}
          aria-expanded={faqOpen}
          aria-controls="faq"
          className="faq-pull-tab"
        >
          <span className="faq-pull-tab__cord" aria-hidden="true">
            <span />
          </span>
          <span className="faq-pull-tab__tag">
            <span className="faq-pull-tab__copy">
              <small>{faqOpen ? "CLICK TO CLOSE" : "Have questions?"}</small>
              <strong>{faqOpen ? "CLOSE FAQ" : "CLICK FOR ANSWERS"}</strong>
            </span>
            <span className="faq-pull-tab__action" aria-hidden="true">
              <ChevronDown className={`faq-pull-tab__chevron ${faqOpen ? "faq-pull-tab__chevron--open" : ""}`} />
            </span>
          </span>
        </button>
        <p>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>

      {demoView === "form" && (
        <footer
          ref={demoFooterRef}
          className="demo-form-footer site-footer-balanced night-panel border-t border-night-border px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted"
        >
          <p>
            <span className="footer-stack">
              <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
            </span>
          </p>
        </footer>
      )}
    </div>
  );
}

