import { createFileRoute } from "@tanstack/react-router";
import { LoginPage } from "@/components/auth/LoginScreen";

const TITLE = "Forgot Password | LinkBot";
const DESCRIPTION = "Request a link to reset your LinkBot account password.";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <LoginPage view="forgot" />,
});
