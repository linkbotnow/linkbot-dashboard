import { createFileRoute } from "@tanstack/react-router";
import { legalRedirect } from "@/lib/legal-page.server";

export const Route = createFileRoute("/privacy")({
  server: { handlers: { GET: () => legalRedirect("privacy") } },
});
