import { createFileRoute } from "@tanstack/react-router";
import { legalRedirect } from "@/lib/legal-page.server";

export const Route = createFileRoute("/refund")({
  server: { handlers: { GET: () => legalRedirect("refund") } },
});
