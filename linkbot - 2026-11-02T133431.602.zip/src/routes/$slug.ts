import { FIT_LINE_SCRIPT } from "@/lib/fit-line";
/**
 * Client widget hosting page: linkbot.ai/<their-slug>
 *
 * The page goes live the moment a client reserves their link and stays public:
 * anyone with the link can open it, and it can be embedded on any site.
 * While the widget id has not arrived from GoHighLevel yet, it serves a clean
 * minimal placeholder. Raw HTML keeps it instant on every device.
 */
import { createFileRoute } from "@tanstack/react-router";
import { VOICE_PAGE_BODY, VOICE_PAGE_HEAD, VOICE_PAGE_PAUSED_BODY, VOICE_PAGE_PENDING_BODY } from "@/lib/voice-page.server";
import { NOT_FOUND_HTML } from "@/lib/not-found-page";
import { CLAIM_SLUG_PATTERN, RESERVED_CLAIM_SLUGS } from "@/lib/claim-slug";
import appCss from "../styles.css?url";

// 192: every miss shows the same not-found page, so it never reveals whether a name exists.
const BLANK_HTML = NOT_FOUND_HTML;

function blank() {
  return new Response(BLANK_HTML, {
    status: 404,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "x-robots-tag": "noindex, nofollow",
    },
  });
}

const PAGE_HEAD = `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<style>
  html,body{margin:0;padding:0;height:100%;background:transparent;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}
  body{overflow:hidden;}
  .pending{display:flex;align-items:center;justify-content:center;height:100%;color:#6b7280;font-size:14px;}
  .pending.has-li{flex-direction:column;gap:16px;}
  #lb.pending,noscript .pending{flex-direction:column;gap:16px;}
  .li-btn.li-white{color:oklch(0.52 0.24 264);background-color:#fff;background-image:linear-gradient(180deg,#ffffff 0%,#f3f5fb 100%);background-blend-mode:normal;box-shadow:inset 0 1px 0 rgba(255,255,255,.3),inset 0 0 0 1px rgba(37,71,208,.16),0 1px 1px rgba(15,23,42,.06),0 8px 18px -10px rgba(37,71,208,.35),0 18px 36px -18px rgba(15,23,42,.18);}
  .li-btn{cursor:pointer;border:0;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;height:44px;padding:0 24px;border-radius:8px;white-space:nowrap;font-family:"Inter",ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:12px;line-height:1;font-weight:700;letter-spacing:0.01em;color:#fff;text-decoration:none;background-color:oklch(0.52 0.24 264);background-image:linear-gradient(180deg,rgba(255,255,255,.16) 0%,rgba(255,255,255,0) 45%,rgba(0,0,0,.18) 100%);background-blend-mode:overlay;box-shadow:inset 0 1px 0 rgba(255,255,255,.28),inset 0 -1px 0 rgba(0,0,0,.35),inset 0 0 0 1px rgba(255,255,255,.06),0 1px 0 rgba(0,0,0,.18),0 10px 22px -8px rgba(15,23,42,.35),0 22px 48px -16px rgba(15,23,42,.28);}
</style>`;

/** Link preview robots (LinkedIn, Facebook/Instagram/WhatsApp, X, Slack, Discord, Telegram, iMessage, etc.) may read pages to build the share card.
 *  Search engines still always get "noindex, nofollow", so private links never appear in search results. People are not affected either way. */
const PREVIEW_BOT = /LinkedInBot|facebookexternalhit|Facebot|meta-externalagent|Twitterbot|Slackbot|Discordbot|TelegramBot|WhatsApp|Pinterestbot|redditbot|Embedly|SkypeUriPreview|vkShare|iframely|Snapchat/i;

/** Misses (404 or dead-end) allowed per visitor connection per hour. */
const MISSES_PER_HOUR = 30;

const SITE_ORIGIN = "https://linkbot.now";
const SHARE_IMAGE = `${SITE_ORIGIN}/customer-preview.png`;
const NOTE_PREFIX = "linkbot.realLink.";

// 241: live demo phone on customer pages (same overlay as /livedemo), loaded with the customer's own widget.
const LIVE_STYLE = `<style>
  html.lb-live,html.lb-live body{background:#000 !important;}
  html.lb-live body{display:flex;align-items:center;justify-content:center;}
  @media (pointer: coarse) and (max-width: 599px), (pointer: coarse) and (max-height: 599px){html.lb-live,html.lb-live body{background:#fff !important;}}
  html.lb-live chat-widget{display:block!important;width:100%;opacity:0!important;pointer-events:none!important;position:fixed!important;left:0!important;top:0!important;transform:translateX(-300vw)!important;z-index:0!important;}
</style>`;
const LIVE_HEAD = `<link id="lb-app-css" rel="stylesheet" href="${appCss}">\n<script>document.documentElement.classList.add("lb-live");</script>\n${LIVE_STYLE}`;
const LIVE_LOADERS = `<script>(function(){["/livedemo-overlay.js","/livedemo-folders.js"].forEach(function(src){if(!document.querySelector('script[src="'+src+'"]')){var s=document.createElement("script");s.src=src;document.body.appendChild(s);}});})();</script>`;

function esc(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

/** 4L26: the customer's saved Greeting Name for the calling screen; falls back to their first name. */
function greetingName(row: { full_name: string | null; slug: string; greeting_choice: string | null; greeting_name_text: string | null; greeting_business_text: string | null }): string {
  const saved = (row.greeting_choice === "business" ? row.greeting_business_text : row.greeting_name_text) ?? "";
  return saved.trim() || (row.full_name ?? "").trim().split(/\s+/)[0] || "";
}

/** Only these page facts reach the browser, escaped for a script tag. */
function pageState(state: { name?: string; screenName?: string; paused?: boolean; cancelled?: boolean }): string {
  return `<script>window.__LB_PAGE=${JSON.stringify(state).replace(/</g, "\\u003c")};</script>`;
}

function html(body: string, extraHead = "", title = "Voice assistant", cache = "no-store", preview = false): Response {
  return new Response(
    `<!doctype html>\n<html lang="en">\n<head>\n${preview ? PAGE_HEAD.replace('<meta name="robots" content="noindex, nofollow">\n', "") : PAGE_HEAD}\n<title>${esc(title)}</title>\n${extraHead}\n</head>\n<body>\n${body}\n</body>\n</html>`,
    {
      status: 200,
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": cache,
        ...(preview ? {} : { "x-robots-tag": "noindex, nofollow" }),
      },
    },
  );
}

function widgetTag(widgetId: string): string {
  return `<script src="https://widgets.leadconnectorhq.com/loader.js" data-resources-url="https://widgets.leadconnectorhq.com/chat-widget/loader.js" data-widget-id="${widgetId}" async></script>`;
}


function visitorIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  const first = forwarded.split(",")[0]?.trim();
  // 185: cf-connecting-ip first; first x-forwarded-for value only if it is missing.
  return request.headers.get("cf-connecting-ip")?.trim() || first || request.headers.get("x-real-ip") || "";
}

async function hashIp(ip: string): Promise<string> {
  if (!ip) return "";
  const bytes = new TextEncoder().encode(`widget-page:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function pageTitle(row: { full_name: string | null; last_name: string | null; company_name: string | null; page_title_choice: string | null; slug: string; call_screen_name_text?: string | null; call_screen_business_text?: string | null }): string {
  const person = row.call_screen_name_text ?? ([row.full_name, row.last_name].filter(Boolean).join(" ").trim() || row.slug);
  const business = row.call_screen_business_text ?? (row.company_name ?? "").trim();
  return row.page_title_choice === "business" && business ? business : person;
}

async function serveCustomerLink({ request, params }: { request: Request; params: { slug: string } }): Promise<Response> {
        const slug = String(params.slug ?? "").toLowerCase();
        const preview = PREVIEW_BOT.test(request.headers.get("user-agent") ?? ""); // share-card robots only
        if (!CLAIM_SLUG_PATTERN.test(slug) || RESERVED_CLAIM_SLUGS.has(slug)) return blank();

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Only misses are limited; a connection over the limit gets the plain 404 for the hour.
        const ipHash = await hashIp(visitorIp(request));
        let overLimit = false;
        if (ipHash) {
          const windowStart = new Date();
          windowStart.setUTCMinutes(0, 0, 0);
          const { data: hit } = await supabaseAdmin
            .from("widget_page_hits")
            .select("hits")
            .eq("ip_hash", ipHash)
            .eq("window_start", windowStart.toISOString())
            .maybeSingle();
          overLimit = (hit?.hits ?? 0) > MISSES_PER_HOUR;
        }
        const miss = async (response: Response) => {
          if (ipHash) {
            await supabaseAdmin.rpc("register_widget_page_hit", { p_ip_hash: ipHash, p_limit: MISSES_PER_HOUR });
          }
          return response;
        };

        const columns = "slug, full_name, last_name, ghl_widget_id, status, linkedin_url, company_name, page_title_choice, greeting_choice, greeting_name_text, greeting_business_text, call_screen_name_text, call_screen_business_text";

        // Real link: exactly 12 characters matching an active customer's private code.
        if (slug.length === 12) {
          const { data: row } = await supabaseAdmin
            .from("client_slugs")
            .select(columns)
            .eq("link_code", slug)
            .in("status", ["active", "paused"])
            .maybeSingle();
          if (!row) {
            // 4L26: a cancelled bot's retired private link shows the cancelled screen and never counts as a miss.
            const { data: retired } = await supabaseAdmin.from("retired_link_codes").select("link_code").eq("link_code", slug).maybeSingle();
            if (retired) return html(`${pageState({ cancelled: true })}\n${LIVE_LOADERS}`, LIVE_HEAD, "Voice assistant", "no-store", false);
            // A matching real link always opens; only misses are limited.
            return overLimit ? blank() : miss(blank());
          }

          const name = [row.full_name, row.last_name].filter(Boolean).join(" ").trim() || row.slug;
          const nameLink = `linkbot.now/${row.slug}`;
          const widgetId = (row.ghl_widget_id ?? "").replace(/[^A-Za-z0-9_-]/g, "");
          const meta = [
            `<meta property="og:type" content="website">`,
            `<meta property="og:title" content="Get Answers. Access Resources. Connect Faster.">`,
            `<meta property="og:image" content="${SHARE_IMAGE}">`,
            `<meta property="og:image:type" content="image/png">`,
            `<meta property="og:url" content="${SITE_ORIGIN}/${esc(slug)}">`,
            `<meta name="twitter:card" content="summary_large_image">`,
            `<meta name="twitter:title" content="Get Answers. Access Resources. Connect Faster.">`,
            `<meta name="twitter:image" content="${SHARE_IMAGE}">`,
          ].join("\n");
          const note = JSON.stringify({ w: widgetId });
          const script = `<script>try{sessionStorage.setItem(${JSON.stringify(NOTE_PREFIX + row.slug)},${JSON.stringify(note)});}catch(e){}try{history.replaceState(null,"","/${row.slug}");}catch(e){}</script>`;
          const paused = row.status === "paused";
          const voiceBody = paused ? VOICE_PAGE_PAUSED_BODY : widgetId ? VOICE_PAGE_BODY : VOICE_PAGE_PENDING_BODY;
           if (preview) return html("", meta, pageTitle(row), "no-store", true); // 242: preview robots (LinkedIn etc.) get a clean preview-only page, no scripts
            if (paused) return html(`${script}\n${pageState({ name: greetingName(row), screenName: pageTitle(row), paused: true })}\n${LIVE_LOADERS}`, `${meta}\n${LIVE_HEAD}`, pageTitle(row), "no-store", preview); // 4L26: paused uses the call page, no widget
            if (widgetId) return html(`${script}\n${pageState({ name: greetingName(row), screenName: pageTitle(row) })}\n${widgetTag(widgetId)}\n${LIVE_LOADERS}`, `${meta}\n${LIVE_HEAD}`, pageTitle(row), "no-store", preview); // 241/253: live demo phone, widget loads in order like /livedemo
           return html(`${voiceBody}\n${widgetId && !paused ? widgetTag(widgetId) : ""}\n${script}`, `${meta}\n${VOICE_PAGE_HEAD}`, pageTitle(row), "no-store", preview);
        }

        // Name link: only for active customers. Active name links never count toward or get blocked by the miss limit.
        const { data: row } = await supabaseAdmin
          .from("client_slugs")
          .select(columns)
          .eq("slug", slug)
          .in("status", ["active", "paused"])
          .maybeSingle();
        if (!row) return miss(blank());

        const name = (row.full_name ?? "").trim().split(/\s+/)[0] || row.slug;
        const fullName = [row.full_name, row.last_name].filter(Boolean).join(" ").trim() || row.slug; // 257: page title
        const widgetId = (row.ghl_widget_id ?? "").replace(/[^A-Za-z0-9_-]/g, "");
        const deadEndLine1 = `This AI assistant opens from ${name}'s LinkedIn profile.`;
        const deadEndLine2 = "Tap their link there to start the live conversation.";
        const js = (v: string) => JSON.stringify(v).replace(/</g, "\\u003c");
        const li = /^https:\/\/www\.linkedin\.com\/in\/[A-Za-z0-9_%-]+\/?$/.test(row.linkedin_url ?? "") ? row.linkedin_url! : "";
        const liLabel = `Go to ${name}'s LinkedIn`;
        // Visitors who arrived through the real link in this tab get the voice page back (refresh keeps working).
        const script = `<script>(function(){var n=null;try{n=JSON.parse(sessionStorage.getItem(${js(NOTE_PREFIX + row.slug)})||"null");}catch(e){}
var box=document.getElementById("lb");if(!n){var c=document.getElementById("lb-css");if(c)c.remove();var v=document.getElementById("lb-voice");if(v)v.remove();box.className="pending";var m=document.createElement("div");m.setAttribute("data-fit-line","");m.textContent=${js(deadEndLine1)};box.appendChild(m);var m2=document.createElement("div");m2.setAttribute("data-fit-line","");m2.textContent=${js(deadEndLine2)};box.appendChild(m2);var li=${js(li)};if(li){box.className="pending has-li";var a=document.createElement("button");a.type="button";a.className="li-btn";a.onclick=function(){location.href=li;};a.textContent=${js(liLabel)};box.appendChild(a);}var g=document.createElement("button");g.type="button";g.className=li?"li-btn li-white":"li-btn";g.onclick=function(){location.href="https://linkbot.now";};g.textContent="Get Your Own LinkBot";box.appendChild(g);if(window.__fitLines)window.__fitLines();return;}
var paused=${row.status === "paused" ? "true" : "false"};if(!paused&&${!widgetId ? "true" : "false"})return;var w=${js(widgetId)};window.__LB_PAGE={name:${js(greetingName(row))},screenName:${js(pageTitle(row))},paused:paused};
if(!paused){var s=document.createElement("script");s.src="https://widgets.leadconnectorhq.com/loader.js";s.async=true;s.setAttribute("data-resources-url","https://widgets.leadconnectorhq.com/chat-widget/loader.js");s.setAttribute("data-widget-id",w);document.body.appendChild(s);}var vv=document.getElementById("lb-voice");if(vv)vv.style.visibility="hidden";var l=document.createElement("link");l.id="lb-app-css";l.rel="stylesheet";l.href=${js(appCss)};document.head.appendChild(l);document.documentElement.classList.add("lb-live");["/livedemo-overlay.js","/livedemo-folders.js"].forEach(function(src){var x=document.createElement("script");x.src=src;document.body.appendChild(x);});})();</script>`;
        const voiceBody = row.status === "paused" ? VOICE_PAGE_PAUSED_BODY : widgetId ? VOICE_PAGE_BODY : VOICE_PAGE_PENDING_BODY;
         return html(`<div id="lb-voice">${voiceBody}</div>\n<div id="lb"></div>\n<noscript><div class="pending"><div>${esc(deadEndLine1)}</div><div>${esc(deadEndLine2)}</div></div></noscript>\n${FIT_LINE_SCRIPT}\n${script}`, `${VOICE_PAGE_HEAD}\n${LIVE_STYLE}`, pageTitle(row), "no-store", preview);
}

export const Route = createFileRoute("/$slug")({
  server: {
    handlers: {
      GET: serveCustomerLink,
      HEAD: async ({ request, params }) => {
        const res = await serveCustomerLink({ request, params });
        return new Response(null, { status: res.status, headers: res.headers });
      },
    },
  },
});
