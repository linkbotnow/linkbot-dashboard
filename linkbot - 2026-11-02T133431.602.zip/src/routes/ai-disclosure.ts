import { createFileRoute } from "@tanstack/react-router";
import { legalRedirect } from "@/lib/legal-page.server";

export const Route = createFileRoute("/ai-disclosure")({
  server: { handlers: { GET: () => legalRedirect("ai-disclosure") } },
});
