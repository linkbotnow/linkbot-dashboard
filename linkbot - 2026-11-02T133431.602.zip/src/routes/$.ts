import { createFileRoute } from "@tanstack/react-router";
import { NOT_FOUND_HTML } from "@/lib/not-found-page";

// 192B: any multi-part address that is not a real page gets the standalone not-found page.
export const Route = createFileRoute("/$")({
  server: {
    handlers: {
      GET: async () =>
        new Response(NOT_FOUND_HTML, {
          status: 404,
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-store",
            "x-robots-tag": "noindex, nofollow",
          },
        }),
    },
  },
});
