import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { LegalModal } from "@/components/legal/LegalModal";
import { useRevealWhenSettled } from "@/lib/boot-reveal";
import { getSignHandoff, setSignHandoff, type SignHandoff } from "@/lib/sign-handoff";

// 244: phones sign the Legal Terms on this real page (nothing rendered underneath).
// It reuses the exact signing pages from LegalModal; the form stays on /claim's
// in-memory handoff, and nothing is created here.
export const Route = createFileRoute("/sign")({
  head: () => ({
    meta: [
      { title: "Sign the Legal Terms — LinkBot.Now" },
      { name: "description", content: "Review and sign the LinkBot.Now Legal Terms to continue to checkout." },
      { property: "og:title", content: "Sign the Legal Terms — LinkBot.Now" },
      { property: "og:description", content: "Review and sign the LinkBot.Now Legal Terms to continue to checkout." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SignPage,
});

function SignPage() {
  useRevealWhenSettled();
  const navigate = useNavigate();
  const [handoff, setHandoff] = useState<SignHandoff | null>(null);
  const leftRef = useRef(false);

  useEffect(() => {
    const h = getSignHandoff();
    if (!h) {
      void navigate({ to: "/claim", replace: true });
      return;
    }
    setHandoff(h);
    const root = document.documentElement;
    root.classList.add("legal-sign-route");
    return () => root.classList.remove("legal-sign-route");
  }, [navigate]);

  if (!handoff) return null;

  // 449E: close the phone keyboard and wait for it to settle before going back.
  const leave = () => {
    if (leftRef.current) return;
    leftRef.current = true;
    (document.activeElement as HTMLElement | null)?.blur();
    const vv = window.visualViewport;
    if (!vv) {
      window.setTimeout(() => window.history.back(), 300);
      return;
    }
    const start = performance.now();
    const wait = () => {
      if (Math.abs(vv.height - window.innerHeight) <= 2 || performance.now() - start >= 400) {
        window.history.back();
        return;
      }
      requestAnimationFrame(wait);
    };
    wait();
  };

  return (
    <LegalModal
      open
      mode="sign"
      onClose={() => leave()}
      expectedName={handoff.expectedName}
      onSign={(name) => {
        (document.activeElement as HTMLElement | null)?.blur();
        setSignHandoff({ ...handoff, signatureName: name });
        leave();
      }}
    />
  );
}
