import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

async function logout() {
  const { endSession } = await import("@/lib/account.server");
  await endSession();
  return new Response(null, { status: 302, headers: { Location: "/login", "Cache-Control": "no-store" } });
}

// /logout is a server-only route. If the client router ever navigates here
// in-app (no full page load), there is no server response — without this
// fallback the route renders nothing and the boot-reveal gate keeps the body
// hidden forever (blank page). Force a real navigation so the server handler
// always runs.
function LogoutFallback() {
  useEffect(() => {
    window.location.replace("/logout");
  }, []);
  return null;
}

export const Route = createFileRoute("/logout")({
  component: LogoutFallback,
  server: { handlers: { GET: logout, POST: logout } },
});
