import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

export const Route = createFileRoute('/api/public/voice-sample/$voice')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const voice = z.enum(['female', 'male']).safeParse(params.voice);
        if (!voice.success) return new Response(null, { status: 404 });
        try {
          // Only these two public samples may be read with privileged access.
          const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
          const { data, error } = await supabaseAdmin.storage.from('voice-samples').download(`${voice.data}.mp3`);
          if (error || !data) return new Response(null, { status: 404 });
          return new Response(data, {
            headers: { 'content-type': 'audio/mpeg', 'cache-control': 'public, max-age=86400' },
          });
        } catch {
          return new Response(null, { status: 404 });
        }
      },
    },
  },
});