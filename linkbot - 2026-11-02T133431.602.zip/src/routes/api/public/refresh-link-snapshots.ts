import { createFileRoute } from '@tanstack/react-router';
import { authenticateCronRequest } from '@/integrations/supabase/cron-auth';
import { SNAPSHOTS_ENABLED } from '@/lib/link-view-rules';
export const Route = createFileRoute('/api/public/refresh-link-snapshots')({ server: { handlers: { POST: async ({ request }) => {
  const denied = await authenticateCronRequest(request);
  if (denied) return denied;
  const { z } = await import('zod');
  if (!z.object({ kind: z.literal('daily') }).strict().safeParse(await request.json().catch(() => null)).success) return new Response('Invalid request', { status: 400 });
  if (!SNAPSHOTS_ENABLED) return Response.json({ captured: 0, reason: 'disabled' });
  const { refreshSnapshots } = await import('@/lib/link-snapshot.server');
  if (!process.env['SCREENSHOTONE_ACCESS_KEY']) return Response.json({ captured: 0, reason: 'key_missing' });
  const task = refreshSnapshots().catch(() => { console.error('Daily link snapshots failed'); });
  const runtimeRequest = request as Request & { waitUntil?: (promise: Promise<unknown>) => void; runtime?: { cloudflare?: { context?: { waitUntil: (promise: Promise<unknown>) => void } } } };
  const ctx = runtimeRequest.runtime?.cloudflare?.context;
  if (ctx) ctx.waitUntil(task);
  else if (runtimeRequest.waitUntil) runtimeRequest.waitUntil(task);
  else await task;
  return Response.json({ accepted: true });
} } } });