import { createFileRoute } from '@tanstack/react-router';
import { SNAPSHOTS_ENABLED } from '@/lib/link-view-rules';
export const Route = createFileRoute('/api/public/link-snapshot')({ server: { handlers: { GET: async ({ request }) => {
  if (!SNAPSHOTS_ENABLED) return new Response(null, { status: 204, headers: { 'cache-control': 'no-store' } });
  const { registeredLink } = await import('@/lib/link-view.server');
  const link = await registeredLink(new URL(request.url).searchParams.get('u') ?? '');
  if (!link?.snapshot_path || link.snapshot_url_source !== link.url) return new Response('Snapshot not captured yet', { status: 404, headers: { 'cache-control': 'no-store' } });
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const { data, error } = await supabaseAdmin.storage.from('link-snapshots').download(link.snapshot_path);
  if (error || !data) return new Response('Snapshot unavailable', { status: 404 });
  return new Response(data, { headers: { 'content-type': 'image/png', 'cache-control': 'public, max-age=600', 'x-content-type-options': 'nosniff' } });
} } } });