/**
 * 226: GET /api/public/frame-check?url=<https link>
 * Answers { ok: true } only when the website allows being shown inside the LinkBot page (full-screen link panel).
 * Answers { ok: false } when the site refuses, the link isn't a public https address, or the check fails.
 */
import { createFileRoute } from "@tanstack/react-router";

const PRIVATE_HOST = /^(localhost|127\.|10\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|\[)/i;

function publicHttps(target: URL): boolean {
  const host = target.hostname.toLowerCase().replace(/\.$/, "");
  return target.protocol === "https:" && !target.username && !target.password
    && (target.port === "" || target.port === "443")
    && host.includes(".") && !PRIVATE_HOST.test(host) && !/^[\d.]+$/.test(host)
    && !/(?:^|\.)(?:localhost|local|internal|test|invalid|onion)$/.test(host);
}

function allowsFraming(headers: Headers): boolean {
  let hasAncestors = false;
  const permitted = (headers.get("content-security-policy") ?? "").split(",").every((policy) => {
    const fa = policy.split(";").map((s) => s.trim()).find((s) => /^frame-ancestors\b/i.test(s));
    if (!fa) return true;
    hasAncestors = true;
    const sources = fa.split(/\s+/).slice(1).map((s) => s.toLowerCase().replace(/\/$/, ""));
    return sources.some((s) => s === "*" || s === "https:" || s === "https://linkbot.now" || s === "linkbot.now");
  });
  return permitted && (hasAncestors || (headers.get("x-frame-options") ?? "").trim() === "");
}

const UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";

export const Route = createFileRoute("/api/public/frame-check")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        let ok = false;
        try {
          const raw = new URL(request.url).searchParams.get("url") ?? "";
          if (raw.length > 0 && raw.length <= 2048) {
            let target = new URL(raw);
            const signal = AbortSignal.timeout(5000);
            for (let hop = 0; hop <= 5; hop++) {
              if (!publicHttps(target)) break;
              let res = await fetch(target.toString(), { method: "GET", redirect: "manual", signal, headers: { "user-agent": UA, accept: "text/html,*/*" } });
              if (res.status === 0) {
                // Runtime hides redirects: follow them and check where it landed.
                res = await fetch(target.toString(), { method: "GET", redirect: "follow", signal, headers: { "user-agent": UA, accept: "text/html,*/*" } });
                const landed = new URL(res.url || target.toString());
                ok = publicHttps(landed) && res.status >= 200 && res.status < 300 && allowsFraming(res.headers);
                try { await res.body?.cancel(); } catch {}
                break;
              }
              const location = res.headers.get("location");
              const status = res.status;
              const headers = res.headers;
              try { await res.body?.cancel(); } catch {}
              if (status >= 300 && status < 400 && location) { target = new URL(location, target); continue; }
              ok = status >= 200 && status < 300 && allowsFraming(headers);
              break;
            }
          }
        } catch {
          ok = false;
        }
        return new Response(JSON.stringify({ ok }), {
          status: 200,
          headers: { "content-type": "application/json", "cache-control": ok ? "public, max-age=600" : "no-store" },
        });
      },
    },
  },
});
