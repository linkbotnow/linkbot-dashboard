/**
 * Post-payment activation webhook (HighLevel workflow "Webhook" action).
 *
 * Every request must carry the shared secret header `x-pr-activate-secret`
 * (secret name: GHL_ACTIVATION_SECRET). Requests without it are rejected.
 *
 * Payload fields understood (top level or inside customData):
 *   email       – the client's email address (primary identifier)
 *   paymentId   – unique payment ID; each one is processed only once
 *   locationId  – their HighLevel sub-account id
 *   widgetId    – the Voice AI widget id to embed on their page
 *
 * On success the reserved slug becomes active and the widget page at
 * linkbot.now/<slug> starts serving that widget id.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const PayloadSchema = z
  .object({
    email: z.string().max(255).optional(),
    contact_email: z.string().max(255).optional(),
    locationId: z.string().max(100).optional(),
    location_id: z.string().max(100).optional(),
    widgetId: z.string().max(120).optional(),
    widget_id: z.string().max(120).optional(),
    paymentId: z.string().max(200).optional(),
    botId: z.string().max(100).optional(),
    bot_id: z.string().max(100).optional(),
    payment_id: z.string().max(200).optional(),
    location: z.object({ id: z.string().max(100).optional() }).passthrough().optional(),
    contact: z.object({ email: z.string().max(255).optional() }).passthrough().optional(),
    customData: z.record(z.string(), z.unknown()).optional(),
  })
  .passthrough();

function pick(record: Record<string, unknown> | undefined, ...keys: string[]): string | undefined {
  if (!record) return undefined;
  for (const key of keys) {
    const value = record[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return undefined;
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export const Route = createFileRoute("/api/public/webhooks/activate")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const expected = process.env["GHL_ACTIVATION_SECRET"];
        if (!expected) {
          console.error("[activate] GHL_ACTIVATION_SECRET is not configured");
          return new Response("Unauthorized", { status: 401 });
        }
        const provided = request.headers.get("x-pr-activate-secret") ?? "";
        if (!provided || !timingSafeEqual(provided, expected)) {
          return new Response("Unauthorized", { status: 401 });
        }

        const { sendAlert, sendLinksIfReady } = await import("@/lib/bot-events.server");
        // 194: early rejections (after the secret check) also alert the owner; status codes unchanged.
        const reject = async (body: string, status: number, reason: string, info: { email?: string | undefined; paymentId?: string | undefined } = {}) => {
          await sendAlert("payment_rejected", {
            email: info.email ?? null,
            message: `Payment ${info.paymentId ?? "(unknown)"} rejected: ${reason}.`,
          });
          return new Response(body, { status });
        };

        let raw: unknown;
        try {
          raw = await request.json();
        } catch {
          return reject("Invalid payload", 400, "invalid JSON");
        }
        let parsed: z.infer<typeof PayloadSchema>;
        try {
          parsed = PayloadSchema.parse(raw);
        } catch {
          const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
          const c = (r["customData"] && typeof r["customData"] === "object" ? r["customData"] : {}) as Record<string, unknown>;
          const s = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : undefined);
          return reject("Invalid payload", 400, "invalid payload", {
            email: s(r["email"]) ?? s(c["email"]),
            paymentId: s(r["paymentId"]) ?? s(r["payment_id"]) ?? s(c["paymentId"]) ?? s(c["payment_id"]),
          });
        }

        const custom = parsed.customData as Record<string, unknown> | undefined;
        // 194: empty or whitespace-only values count as missing at every level.
        const first = (...values: unknown[]): string | undefined => {
          for (const v of values) if (typeof v === "string" && v.trim()) return v.trim();
          return undefined;
        };
        const email = first(parsed.email, parsed.contact_email, parsed.contact?.email, pick(custom, "email", "contact_email"))?.toLowerCase();
        const locationId = first(parsed.locationId, parsed.location_id, parsed.location?.id, pick(custom, "locationId", "location_id"));
        const widgetId = first(parsed.widgetId, parsed.widget_id, pick(custom, "widgetId", "widget_id"));
        const paymentId = first(parsed.paymentId, parsed.payment_id, pick(custom, "paymentId", "payment_id"));

        // 452: optional bot ID from the payment link; used only when it is a well-formed ID.
        const rawBotId = first(parsed.botId, parsed.bot_id, pick(custom, "botId", "bot_id"));
        const botId = rawBotId && /^[0-9a-f-]{36}$/i.test(rawBotId) ? rawBotId : null;

        if (!email || !email.includes("@")) return reject("Missing email", 400, "missing email", { paymentId });
        if (!paymentId) return reject("Missing paymentId", 400, "missing paymentId", { email });
        if (widgetId && !/^[A-Za-z0-9_-]{6,64}$/.test(widgetId)) {
          return reject("Invalid widgetId", 400, "invalid widgetId format", { email, paymentId });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const json = (body: unknown, status = 200) =>
          new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

        // Each payment ID is processed once; a repeat does nothing unless the first attempt failed.
        let event: { id: string } | null = null;
        const { data: inserted, error: eventError } = await supabaseAdmin
          .from("billing_events")
          .insert({
            external_event_id: paymentId,
            event_type: "payment",
            ghl_location_id: locationId ?? null,
            safe_payload: { email },
          })
          .select("id")
          .single();
        if (eventError) {
          if (eventError.code === "23505") {
            const { data: existingEvent } = await supabaseAdmin
              .from("billing_events")
              .select("id, processing_status, received_at")
              .eq("external_event_id", paymentId)
              .maybeSingle();
            // 451: also retry a payment stuck in RECEIVED for over 2 minutes.
            const stuck =
              existingEvent?.processing_status === "RECEIVED" &&
              Date.now() - new Date(existingEvent.received_at).getTime() > 2 * 60 * 1000;
            if (existingEvent && (existingEvent.processing_status === "FAILED" || stuck)) {
              // 185: claim the retry atomically; only one request can take it, PROCESSED never.
              let claim = supabaseAdmin
                .from("billing_events")
                .update({ processing_status: "RECEIVED", received_at: new Date().toISOString(), processing_error: null })
                .eq("id", existingEvent.id)
                .eq("processing_status", existingEvent.processing_status);
              if (stuck) claim = claim.eq("received_at", existingEvent.received_at);
              const { data: claimed } = await claim.select("id");
              if (!claimed || claimed.length === 0) return json({ ok: true, duplicate: true });
              event = { id: existingEvent.id };
            } else {
              return json({ ok: true, duplicate: true });
            }
          } else {
            console.error("[activate] payment log failed", eventError.code);
            await sendAlert("payment_rejected", { email, message: `Payment ${paymentId} rejected: payment log failed (${eventError.code ?? "unknown"}).` });
            return new Response("Activation failed", { status: 500 });
          }
        } else {
          event = inserted;
        }
        if (!event) return new Response("Activation failed", { status: 500 });
        // 191: every FAILED activation also alerts the owner (GoHighLevel still retries on the 500).
        const failAlert = (failedBotId: string | null, step: string) =>
          sendAlert("payment_activation_failed", {
            email,
            botId: failedBotId ?? botId,
            message: `Payment ${paymentId} activation failed at step: ${step}.`,
          });
        const finish = (status: string, clientId: string | null, error?: string) =>
          supabaseAdmin
            .from("billing_events")
            .update({ processing_status: status, client_id: clientId, processing_error: error ?? null, processed_at: new Date().toISOString() })
            .eq("id", event.id)
            .neq("processing_status", "PROCESSED");

        // 194: a database error in any lookup is a failure (retried), never "no match".
        class LookupFailed extends Error {}
        const need = <T,>(r: { data: T; error: unknown }, step: string): T => {
          if (r.error) {
            console.error(`[activate] ${step} failed`, r.error);
            throw new LookupFailed(step);
          }
          return r.data;
        };

        try {
        // 188B: checked first — this paymentId already activated a bot: finish it, no alert.
        const activatedBy = need(
          await supabaseAdmin.from("client_slugs").select("id").eq("activated_payment_id", paymentId).limit(1).maybeSingle(),
          "activated payment lookup",
        );
        if (activatedBy) {
          await finish("PROCESSED", activatedBy.id);
          await sendLinksIfReady(activatedBy.id);
          await (await import('@/lib/linkbot/app.server')).fillWidgetIds({ botId: activatedBy.id }).catch(() => console.error('[activate] automatic widget lookup failed'));
          return json({ ok: true, duplicate: true });
        }

        const DAY_AGO = () => new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        // 191: archive entries that are safe to restore (never cancelled bots or retired links), newest first.
        const restorable = async (rows: { details: unknown }[] | null) => {
          for (const r of rows ?? []) {
            const d = r.details as Record<string, unknown> | null;
            if (!d || typeof d["slug"] !== "string") continue;
            const id = typeof d["id"] === "string" ? (d["id"] as string) : null;
            if (id) {
              const live = need(await supabaseAdmin.from("client_slugs").select("id").eq("id", id).maybeSingle(), "restore live check");
              if (live) continue;
              const cancelled = need(
                await supabaseAdmin
                  .from("security_audit_log")
                  .select("id")
                  .eq("event_type", "bot_cancelled")
                  .eq("details->>id", id)
                  .limit(1),
                "restore cancelled check",
              );
              if (cancelled && cancelled.length > 0) continue;
            }
            if (typeof d["link_code"] === "string") {
              const retired = need(
                await supabaseAdmin.from("retired_link_codes").select("link_code").eq("link_code", d["link_code"] as string).maybeSingle(),
                "restore retired check",
              );
              if (retired) continue;
            }
            return d;
          }
          return null;
        };
        const archiveById = async (id: string) =>
          need(
            await supabaseAdmin
              .from("security_audit_log")
              .select("details")
              .eq("event_type", "hold_expired")
              .eq("details->>id", id)
              .gte("created_at", DAY_AGO())
              .order("created_at", { ascending: false })
              .limit(10),
            "archive lookup",
          );
        // Restores one archive entry; returns the response to send.
        const restore = async (old: Record<string, unknown>) => {
          const oldId = typeof old["id"] === "string" ? (old["id"] as string) : null;
          const oldSlug = old["slug"] as string;
          const holder = need(await supabaseAdmin.from("client_slugs").select("id").eq("slug", oldSlug).maybeSingle(), "restore name check");
          if (holder) {
            await finish("CONFLICT_HOLD_EXPIRED_LINK_TAKEN", null, "Payment arrived after the hold expired and another customer has reserved this link.");
            await sendAlert("hold_expired_conflict", {
              email,
              botId: oldId,
              message: `Payment ${paymentId} arrived after the hold expired and another customer has reserved ${oldSlug}.`,
            });
            return json({ ok: false, reason: "link_taken_after_hold_expired" }, 409);
          }
          const str = (k: string) => (typeof old[k] === "string" ? (old[k] as string) : null);
          const { data: restored, error: restoreError } = await supabaseAdmin
            .from("client_slugs")
            .insert({
              ...(oldId ? { id: oldId } : {}),
              email: str("email")?.toLowerCase() ?? email,
              slug: oldSlug,
              link_code: str("link_code"),
              full_name: str("full_name"),
              last_name: str("last_name"),
              phone: str("phone"),
              company_name: str("company_name"),
              website: str("website"),
              owner_account_id: str("owner_account_id"),
              allowed_domains: Array.isArray(old["allowed_domains"]) ? (old["allowed_domains"] as string[]) : [],
              // 190: keep the archived widget and LinkedIn unless the payment brings a newer widget.
              ghl_widget_id: str("ghl_widget_id"),
              linkedin_url: str("linkedin_url"),
              status: "active",
              activated_at: new Date().toISOString(),
              activated_payment_id: paymentId,
              ...(locationId ? { ghl_location_id: locationId } : {}),
              ...(widgetId ? { ghl_widget_id: widgetId } : {}),
            })
            .select("id, ghl_widget_id")
            .single();
          if (restoreError || !restored) {
            console.error("[activate] restore after expired hold failed", restoreError);
            await finish("FAILED", null, "restore failed");
            await failAlert(oldId, "restore failed");
            return new Response("Activation failed", { status: 500 });
          }
          await finish("PROCESSED", restored.id);
          // 194: a widget saved on the archive after it was read is never lost.
          if (!restored.ghl_widget_id && oldId) {
            const { data: latest } = await supabaseAdmin
              .from("security_audit_log")
              .select("details")
              .eq("event_type", "hold_expired")
              .eq("details->>id", oldId)
              .order("created_at", { ascending: false })
              .limit(1)
              .maybeSingle();
            const w = (latest?.details as Record<string, unknown> | null)?.["ghl_widget_id"];
            if (typeof w === "string" && w) {
              await supabaseAdmin.from("client_slugs").update({ ghl_widget_id: w }).eq("id", restored.id).is("ghl_widget_id", null);
            }
          }
          await sendLinksIfReady(restored.id);
          await (await import('@/lib/linkbot/app.server')).fillWidgetIds({ botId: restored.id }).catch(() => console.error('[activate] automatic widget lookup failed'));
          if(locationId)await (await import('@/lib/linkbot/greeting.server')).initializeGreetingName(locationId,str('full_name')).catch(() => console.error('[activate] Greeting Name setup failed'));
          if(locationId){const {data:ownerBot}=await supabaseAdmin.from('client_slugs').select('email,full_name,company_name').eq('id',restored.id).maybeSingle();await (await import('@/lib/linkbot/greeting.server')).sendOwnerValues(locationId,{email:ownerBot?.email??str('email')??null,fullName:ownerBot?.full_name??str('full_name')??null,companyName:ownerBot?.company_name??str('company_name')??null}).catch(() => console.error('[activate] Owner custom values setup failed'));}
          return json({ ok: true, slug: oldSlug, botId: restored.id });
        };

        let row: { id: string; slug: string; status: string } | null = null;
        // 190: what the named botId turned out to be.
        let named: "none" | "reserved" | "paid" | "missing" = "none";
        let mismatchEmail: string | null = null;
        if (botId) {
          // 452: match the exact bot the payment link named.
          const byId = need(
            await supabaseAdmin.from("client_slugs").select("id, slug, status, email").eq("id", botId).maybeSingle(),
            "named bot lookup",
          );
          if (byId && byId.status === "reserved") {
            // 190a: the named unpaid bot is activated even when the payment email differs.
            named = "reserved";
            row = byId;
            if (byId.email.toLowerCase() !== email) mismatchEmail = byId.email.toLowerCase();
          } else if (byId && (byId.status === "active" || byId.status === "paused")) {
            named = "paid";
          } else {
            named = "missing";
          }
        }
        // 194: a named bot that no longer exists is restored first, by its own id.
        if (named === "missing" && botId) {
          const old = await restorable(await archiveById(botId));
          if (old) return restore(old);
        }
        if (!row) {
          // The email's most recent bot that reached checkout and is not yet paid.
          row = need(
            await supabaseAdmin
              .from("client_slugs")
              .select("id, slug, status")
              .eq("email", email.toLowerCase())
              .eq("status", "reserved")
              .order("updated_at", { ascending: false })
              .limit(1)
              .maybeSingle(),
            "email lookup",
          );
        }

        if (row) {
          const { data: activated, error: updateError } = await supabaseAdmin
            .from("client_slugs")
            .update({
              status: "active",
              activated_at: new Date().toISOString(),
              activated_payment_id: paymentId,
              ...(locationId ? { ghl_location_id: locationId } : {}),
              ...(widgetId ? { ghl_widget_id: widgetId } : {}),
            })
            .eq("id", row.id)
            .eq("status", "reserved")
            .select("id");

          if (updateError) {
            console.error("[activate] activation failed", updateError);
            await finish("FAILED", row.id, "activation failed");
            await failAlert(row.id, "activation failed");
            return new Response("Activation failed", { status: 500 });
          }
          if (activated && activated.length > 0) {
            await finish("PROCESSED", row.id);
            if (mismatchEmail && row.id === botId) {
              await sendAlert("payment_email_mismatch", {
                email,
                botId: row.id,
                message: `Payment ${paymentId} email ${email} differs from bot email ${mismatchEmail} (bot ${row.id}).`,
              });
            }
            if (named === "missing" && botId && row.id !== botId) {
              await sendAlert("payment_bot_mismatch", {
                email,
                botId: row.id,
                message: `Payment ${paymentId} named bot ${botId}, which could not be restored; activated bot ${row.id} instead.`,
              });
            }
            await sendLinksIfReady(row.id);
            await (await import('@/lib/linkbot/app.server')).fillWidgetIds({ botId: row.id }).catch(() => console.error('[activate] automatic widget lookup failed'));
            const {data:greetingBot}=await supabaseAdmin.from('client_slugs').select('full_name,ghl_location_id,email,company_name').eq('id',row.id).maybeSingle();
            if(greetingBot?.ghl_location_id)await (await import('@/lib/linkbot/greeting.server')).initializeGreetingName(greetingBot.ghl_location_id,greetingBot.full_name).catch(() => console.error('[activate] Greeting Name setup failed'));
            if(greetingBot?.ghl_location_id)await (await import('@/lib/linkbot/greeting.server')).sendOwnerValues(greetingBot.ghl_location_id,{email:greetingBot.email,fullName:greetingBot.full_name,companyName:greetingBot.company_name}).catch(() => console.error('[activate] Owner custom values setup failed'));
            return json({ ok: true, slug: row.slug, botId: row.id });
          }
          // The hold was released in the meantime: fall through to the restore path.
        }

        // 190b: the named bot was already paid and no other unpaid bot exists.
        if (named === "paid") {
          // 191: a newer hold for this email that expired after its latest activation is rescued first.
          const lastPaid = need(
            await supabaseAdmin
              .from("client_slugs")
              .select("activated_at")
              .eq("email", email.toLowerCase())
              .not("activated_at", "is", null)
              .order("activated_at", { ascending: false })
              .limit(1)
              .maybeSingle(),
            "last paid lookup",
          );
          const current = need(
            await supabaseAdmin.from("client_slugs").select("id").eq("email", email.toLowerCase()).eq("status", "reserved").maybeSingle(),
            "current hold lookup",
          );
          if (lastPaid?.activated_at && !current) {
            const newer = need(
              await supabaseAdmin
                .from("security_audit_log")
                .select("details")
                .eq("event_type", "hold_expired")
                .eq("details->>email", email.toLowerCase())
                .gte("created_at", DAY_AGO())
                .gt("created_at", lastPaid.activated_at)
                .order("created_at", { ascending: false })
                .limit(10),
              "newer hold lookup",
            );
            const old = await restorable(newer);
            if (old) {
              const holder = need(
                await supabaseAdmin.from("client_slugs").select("id").eq("slug", old["slug"] as string).maybeSingle(),
                "restore name check",
              );
              if (!holder) return restore(old);
            }
          }
          await finish("ALREADY_ACTIVE_BOT", botId);
          await sendAlert("payment_already_active_bot", {
            email,
            botId,
            message: `Payment ${paymentId} arrived for already-active bot ${botId} (${email}). Possible double payment.`,
          });
          return json({ ok: true, alreadyActive: true });
        }
        // 190d: no botId, and this email had a bot activated by another payment in the last 10 minutes.
        if (named === "none") {
          const recent = need(
            await supabaseAdmin
              .from("client_slugs")
              .select("id, activated_payment_id")
              .eq("email", email.toLowerCase())
              .gte("activated_at", new Date(Date.now() - 10 * 60 * 1000).toISOString())
              .neq("activated_payment_id", paymentId)
              .order("activated_at", { ascending: false })
              .limit(1)
              .maybeSingle(),
            "recent activation lookup",
          );
          if (recent) {
            await finish("ALREADY_ACTIVE_BOT", recent.id);
            await sendAlert("payment_already_active_bot", {
              email,
              botId: recent.id,
              message: `Payment ${paymentId} arrived for ${email}, whose bot ${recent.id} was just activated by another payment. Possible double payment.`,
            });
            return json({ ok: true, alreadyActive: true });
          }
        }

        {
          // The hold may have expired and been cleaned up before payment arrived.
          // 452: only archives from the last 24 hours. 191: by the named bot id (any email), else by email.
          const archived = botId
            ? await archiveById(botId)
            : need(
                await supabaseAdmin
                  .from("security_audit_log")
                  .select("details")
                  .eq("event_type", "hold_expired")
                  .gte("created_at", DAY_AGO())
                  .eq("details->>email", email.toLowerCase())
                  .order("created_at", { ascending: false })
                  .limit(10),
                "archive lookup",
              );
          const old = await restorable(archived);
          const current = need(
            await supabaseAdmin.from("client_slugs").select("id").eq("email", email.toLowerCase()).eq("status", "reserved").maybeSingle(),
            "current hold lookup",
          );
          if (!old || current) {
            await finish("NO_MATCHING_UNPAID_BOT", current?.id ?? null);
            await sendAlert("payment_no_match", {
              email,
              botId: current?.id ?? null,
              message: `Payment ${paymentId} matches no unpaid bot.`,
            });
            return new Response("No unpaid bot for this email", { status: 404 });
          }
          return restore(old);
        }
        } catch (err) {
          if (!(err instanceof LookupFailed)) throw err;
          await finish("FAILED", null, err.message);
          await failAlert(null, err.message);
          return new Response("Lookup failed", { status: 500 });
        }
      },
    },
  },
});
