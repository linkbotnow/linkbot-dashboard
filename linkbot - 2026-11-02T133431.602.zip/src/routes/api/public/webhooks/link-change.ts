/**
 * GoHighLevel link changes for paid, active bots.
 * Header: x-link-change-secret (GHL_LINK_CHANGE_SECRET).
 * Body: { botId, action: "rename", newName } or { botId, action: "new_link" }.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const SITE = "https://linkbot.now";

const Schema = z.discriminatedUnion("action", [
  z.object({ botId: z.string().uuid(), action: z.literal("rename"), newName: z.string().max(64) }),
  z.object({ botId: z.string().uuid(), action: z.literal("new_link") }),
]);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

type RpcResult = { ok: boolean; reason?: string; slug?: string; link_code?: string; changed?: boolean };

export const Route = createFileRoute("/api/public/webhooks/link-change")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { secretMatches, sendLinkUpdate } = await import("@/lib/bot-events.server");
        const expected = process.env["GHL_LINK_CHANGE_SECRET"];
        if (!expected) {
          console.error("[link-change] GHL_LINK_CHANGE_SECRET is not configured");
          return new Response("Unauthorized", { status: 401 });
        }
        if (!secretMatches(request.headers.get("x-link-change-secret") ?? "", expected)) {
          return new Response("Unauthorized", { status: 401 });
        }
        let data: z.infer<typeof Schema>;
        try {
          data = Schema.parse(await request.json());
        } catch {
          return new Response("Invalid payload", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        let result: RpcResult;
        if (data.action === "rename") {
          const { CLAIM_SLUG_PATTERN, RESERVED_CLAIM_SLUGS } = await import("@/lib/claim-slug");
          const name = data.newName.trim().toLowerCase();
          if (!CLAIM_SLUG_PATTERN.test(name) || RESERVED_CLAIM_SLUGS.has(name)) {
            // Still report a missing or inactive bot first.
            const { data: bot } = await supabaseAdmin.from("client_slugs").select("status, activated_at").eq("id", data.botId).maybeSingle();
            if (!bot) return json({ ok: false, reason: "bot_not_found" });
            if (bot.status !== "active" || !bot.activated_at) return json({ ok: false, reason: "not_active" });
            return json({ ok: false, reason: "invalid_name" });
          }
          const { data: r, error } = await supabaseAdmin.rpc("rename_bot_slug", { p_bot_id: data.botId, p_new_slug: name });
          if (error) {
            console.error("[link-change] rename failed", error);
            return json({ ok: false, reason: "error" }, 500);
          }
          result = r as RpcResult;
        } else {
          const { data: r, error } = await supabaseAdmin.rpc("new_bot_link_code", { p_bot_id: data.botId });
          if (error) {
            console.error("[link-change] new link failed", error);
            return json({ ok: false, reason: "error" }, 500);
          }
          result = r as RpcResult;
        }

        if (!result.ok) return json({ ok: false, reason: result.reason });
        if (result.changed) await sendLinkUpdate(data.botId, data.action === "rename" ? "domain_change" : "new_link");
        return json({ ok: true, botId: data.botId, nameLink: `${SITE}/${result.slug}`, realLink: `${SITE}/${result.link_code}` });
      },
    },
  },
});
