/**
 * GoHighLevel bot updates: widget ready, pause, resume, cancel.
 * Header: x-bot-status-secret (GHL_BOT_STATUS_SECRET). Body: { botId, action, widgetId? }.
 */
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Schema = z.object({
  botId: z.string().uuid(),
  action: z.enum(["widget_ready", "pause", "resume", "cancel"]),
  widgetId: z.string().regex(/^[A-Za-z0-9_-]{6,64}$/).optional(),
});

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

export const Route = createFileRoute("/api/public/webhooks/bot-status")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { secretMatches, sendLinksIfReady, sendAlert } = await import("@/lib/bot-events.server");
        const expected = process.env["GHL_BOT_STATUS_SECRET"];
        if (!expected) {
          console.error("[bot-status] GHL_BOT_STATUS_SECRET is not configured");
          return new Response("Unauthorized", { status: 401 });
        }
        if (!secretMatches(request.headers.get("x-bot-status-secret") ?? "", expected)) {
          return new Response("Unauthorized", { status: 401 });
        }
        let data: z.infer<typeof Schema>;
        try {
          data = Schema.parse(await request.json());
        } catch {
          return new Response("Invalid payload", { status: 400 });
        }
        if (data.action === "widget_ready" && !data.widgetId) return new Response("Missing widgetId", { status: 400 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const failedEarly = (step: string, err: { code?: string; message?: string }) => {
          console.error(`[bot-status] ${step} failed`, err.code ?? err.message);
          return new Response("Update failed", { status: 500 });
        };
        const { data: row } = await supabaseAdmin
          .from("client_slugs")
          .select("*")
          .eq("id", data.botId)
          .in("status", data.action === "widget_ready" ? ["active", "paused", "reserved"] : ["active", "paused"])
          .maybeSingle();
        // 191: widget ready for a hold that already expired — store it on the archive for a later restore.
        const saveOnArchive = async (): Promise<Response | null> => {
          const { data: arch } = await supabaseAdmin
            .from("security_audit_log")
            .select("id, details")
            .eq("event_type", "hold_expired")
            .eq("details->>id", data.botId)
            .gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();
          if (!arch) return null;
          const details = { ...(arch.details as Record<string, unknown>), ghl_widget_id: data.widgetId! };
          const { error: e } = await supabaseAdmin.from("security_audit_log").update({ details }).eq("id", arch.id);
          if (e) return failedEarly("archive widget", e);
          return json({ ok: true, botId: data.botId, action: data.action, archived: true });
        };
        // 194: neither the bot nor its archive could take the widget.
        const widgetNotSaved = async () => {
          await sendAlert("widget_not_saved", {
            botId: data.botId,
            message: `Widget ${data.widgetId} for bot ${data.botId} could not be saved: no bot or archived hold found.`,
          });
          return new Response("Not found", { status: 404 });
        };
        if (!row) {
          if (data.action === "widget_ready") return (await saveOnArchive()) ?? widgetNotSaved();
          return new Response("Not found", { status: 404 });
        }

        const failed = (step: string, err: { code?: string; message?: string }) => {
          console.error(`[bot-status] ${step} failed`, err.code ?? err.message);
          return new Response("Update failed", { status: 500 });
        };
        if (data.action === "widget_ready") {
          const { data: saved, error: e } = await supabaseAdmin.from("client_slugs").update({ ghl_widget_id: data.widgetId! }).eq("id", row.id).select("id");
          if (e) return failed("widget_ready", e);
          // 194: the bot was deleted meanwhile — fall back to its archive.
          if (!saved || saved.length === 0) return (await saveOnArchive()) ?? widgetNotSaved();
          await sendLinksIfReady(row.id);
        } else if (data.action === "pause") {
          const { error: e } = await supabaseAdmin.from("client_slugs").update({ status: "paused" }).eq("id", row.id);
          if (e) return failed("pause", e);
        } else if (data.action === "resume") {
          const { error: e } = await supabaseAdmin.from("client_slugs").update({ status: "active" }).eq("id", row.id);
          if (e) return failed("resume", e);
          await sendLinksIfReady(row.id);
        } else {
          // Cancel: retire the real-link code forever, archive the bot, free the name link.
          if (row.link_code) {
            const { error: e } = await supabaseAdmin.from("retired_link_codes").upsert({ link_code: row.link_code }, { onConflict: "link_code" });
            if (e) return failed("retire code", e);
          }
          const { error: logErr } = await supabaseAdmin.from("security_audit_log").insert({ event_type: "bot_cancelled", details: row });
          if (logErr) return failed("audit log", logErr);
          // 186: keep payment history readable after the bot row is gone.
          const { error: archErr } = await supabaseAdmin
            .from("billing_events")
            .update({ archived_bot_id: row.id, archived_bot_slug: row.slug, archived_bot_email: row.email })
            .eq("client_id", row.id);
          if (archErr) return failed("archive billing", archErr);
          const { error } = await supabaseAdmin.from("client_slugs").delete().eq("id", row.id);
          if (error) {
            console.error("[bot-status] cancel failed", error.code);
            return new Response("Cancel failed", { status: 500 });
          }
        }
        return json({ ok: true, botId: row.id, action: data.action });
      },
    },
  },
});
