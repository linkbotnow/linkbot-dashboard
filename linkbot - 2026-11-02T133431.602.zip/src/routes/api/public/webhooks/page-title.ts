import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Schema = z.object({
  botId: z.string().uuid(),
  titleChoice: z.enum(["name", "business"]),
});

export const Route = createFileRoute("/api/public/webhooks/page-title")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { secretMatches } = await import("@/lib/bot-events.server");
        const expected = process.env["GHL_BOT_STATUS_SECRET"];
        if (!expected || !secretMatches(request.headers.get("x-bot-status-secret") ?? "", expected)) {
          return new Response("Unauthorized", { status: 401 });
        }
        let data: z.infer<typeof Schema>;
        try {
          data = Schema.parse(await request.json());
        } catch {
          return new Response("Invalid payload", { status: 400 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: row, error } = await supabaseAdmin
          .from("client_slugs")
          .update({ page_title_choice: data.titleChoice })
          .eq("id", data.botId)
          .in("status", ["active", "paused", "reserved"])
          .select("id")
          .maybeSingle();
        if (error) return new Response("Update failed", { status: 500 });
        if (!row) return new Response("Not found", { status: 404 });
        return Response.json({ ok: true, botId: data.botId, titleChoice: data.titleChoice });
      },
    },
  },
});