import { createFileRoute } from '@tanstack/react-router';
import { SNAPSHOTS_ENABLED } from '@/lib/link-view-rules';
export const Route = createFileRoute('/api/public/view-mode')({ server: { handlers: { GET: async ({ request }) => {
  try {
    const { registeredLink, linkMode } = await import('@/lib/link-view.server');
    const link = await registeredLink(new URL(request.url).searchParams.get('u') ?? '');
    if (!link) return Response.json({ mode: 'snapshot', snapshot_url: null }, { status: 404, headers: { 'cache-control': 'no-store' } });
    const result = await linkMode(link);
    return Response.json({ ...result, snapshot_url: SNAPSHOTS_ENABLED ? result.snapshot_url : null }, { headers: { 'cache-control': 'public, max-age=3600' } });
  } catch { return Response.json({ mode: 'snapshot', snapshot_url: null }, { status: 503, headers: { 'cache-control': 'no-store' } }); }
} } } });