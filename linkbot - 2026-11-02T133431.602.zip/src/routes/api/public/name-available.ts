/**
 * Live name-link check for GoHighLevel: GET /api/public/name-available?name=<name>
 * Same rules and check as /claim. Answers only { available: true|false }.
 * Callable from pages on app.linkbot.now.
 */
import { createFileRoute } from "@tanstack/react-router";

const ALLOWED_ORIGIN = "https://app.linkbot.now";

function cors(request: Request): Record<string, string> {
  const origin = request.headers.get("origin");
  return origin === ALLOWED_ORIGIN
    ? { "Access-Control-Allow-Origin": ALLOWED_ORIGIN, "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "content-type", Vary: "Origin" }
    : { Vary: "Origin" };
}

export const Route = createFileRoute("/api/public/name-available")({
  server: {
    handlers: {
      OPTIONS: async ({ request }) => new Response(null, { status: 204, headers: cors(request) }),
      GET: async ({ request }) => {
        const name = (new URL(request.url).searchParams.get("name") ?? "").slice(0, 64);
        let available = false;
        try {
          const { checkSlugAvailability } = await import("@/lib/slug-availability.server");
          available = (await checkSlugAvailability(name)).available;
        } catch {
          available = false;
        }
        return new Response(JSON.stringify({ available }), {
          headers: { "content-type": "application/json", "cache-control": "no-store", ...cors(request) },
        });
      },
    },
  },
});
