import {createFileRoute} from '@tanstack/react-router';
import {authenticateCronRequest} from '@/integrations/supabase/cron-auth';
export const Route=createFileRoute('/api/public/linkbot/fill-widgets')({server:{handlers:{POST:async({request})=>{
  const denied=await authenticateCronRequest(request);if(denied)return denied;
  try{await (await import('@/lib/linkbot/app.server')).fillWidgetIds();return Response.json({ok:true});}
  catch{console.error('LinkBot widget reconciliation failed');return Response.json({ok:false},{status:500});}
}}}});