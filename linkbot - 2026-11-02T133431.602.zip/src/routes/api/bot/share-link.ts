import { createFileRoute } from '@tanstack/react-router';
export const Route = createFileRoute('/api/bot/share-link')({ server: { handlers: {
  GET: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'share'),
  POST: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'share'),
} } });