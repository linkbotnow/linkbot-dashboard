import { createFileRoute } from '@tanstack/react-router';
export const Route = createFileRoute('/api/bot/get-link-details')({ server: { handlers: {
  GET: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'details'),
  POST: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'details'),
} } });