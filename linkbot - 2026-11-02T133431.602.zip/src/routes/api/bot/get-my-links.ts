import { createFileRoute } from '@tanstack/react-router';
export const Route = createFileRoute('/api/bot/get-my-links')({ server: { handlers: {
  GET: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'list'),
  POST: async ({ request }) => (await import('@/lib/bot-links.server')).botLinks(request, 'list'),
} } });