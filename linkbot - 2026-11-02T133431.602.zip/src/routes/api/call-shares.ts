import { createFileRoute } from '@tanstack/react-router';
export const Route = createFileRoute('/api/call-shares')({ server: { handlers: {
  GET: async ({ request }) => (await import('@/lib/call-shares.server')).callShares(request),
  POST: async ({ request }) => (await import('@/lib/call-shares.server')).callShares(request),
} } });