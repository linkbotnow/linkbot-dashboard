import { createFileRoute } from '@tanstack/react-router';
export const Route = createFileRoute('/api/page-links')({ server: { handlers: {
  GET: async ({ request }) => (await import('@/lib/bot-links.server')).pageLinks(request),
} } });