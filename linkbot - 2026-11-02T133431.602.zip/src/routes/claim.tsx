import { scrollToTopSettled } from "@/lib/scroll-top";
import { pinPhoneTop } from "@/lib/phone-top-pin";
import { FooterLegalLink, LegalModal } from "@/components/legal/LegalModal";
import { PhoneCountryPicker, formatPhone, sendablePhone, isValidPhone, maxDigitsFor } from "@/components/landing/HeroDemo";
import { claimWebsiteShape } from "@/lib/claim-website";
import { PHONE_COUNTRIES, parsePhone, type PhoneCountry } from "@/lib/phone-countries";
import { FitLine } from "@/components/FitLine";
import { PasswordEye } from "@/components/auth/PasswordEye";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { useRevealWhenSettled } from "@/lib/boot-reveal";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { BadgeCheck, Clock, CreditCard, Loader2, Lock } from "lucide-react";
import { checkClaimEmail, checkClaimPassword, checkClaimSlug, checkClaimWebsite, endClaimPass, getClaimPrefill, getPassPaid, reserveClaimSlug, ClaimEmailRule } from "@/lib/claim.functions";

import { DESKTOP_CANVAS_WIDTH, getDesktopScale, getDesktopViewport } from "@/lib/desktop-scale";
import { attachSizeHealing } from "@/lib/size-healing";

const CLAIM_TABLET_WIDTH = 1200;
const DESKTOP_CHECKOUT_BOTTOM_SPACE = 64;
// Desktop checkout: hold the composition at exactly the site's own text scale
// (zoom 1 on the 1440 canvas), letting the page scroll instead of shrinking,
// then pull the whole finished composition back uniformly so it reads more
// zoomed out — every proportion and spacing relationship stays identical.
const DESKTOP_ZOOM_OUT = 0.9;
const DESKTOP_FIT = CLAIM_TABLET_WIDTH / DESKTOP_CANVAS_WIDTH;

import { readStoredClaimOrder, storeClaimOrder, type ClaimOrder } from "@/lib/claim-order";
import { isClaimVoiceStep, setClaimVoiceStep } from "@/lib/claim-voice-step";
import { ClaimOrderAside } from "@/components/claim/ClaimOrderAside";
import { VoiceChoice } from "@/components/claim/VoiceChoice";
import { getSignHandoff, isPhoneSignPage, setSignHandoff } from "@/lib/sign-handoff";
import {
  MAX_SLUG_LENGTH,
  claimSlugFormatMessage,
  normalizeClaimSlug,
  readStoredClaimContact,
  validateClaimSlug,
  type ClaimContact,
} from "@/lib/claim-slug";

const TITLE = "Choose your personal link | LinkBot";
const DESCRIPTION =
  "Pick the personal linkbot.now link for your AI voice employee, reserve it instantly and continue to secure checkout.";

const PHONE_INCOMPLETE = "Please enter your full phone number, including area code.";

export const Route = createFileRoute("/claim")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ClaimPage,
});

type Availability =
  | { state: "idle" }
  | { state: "checking" }
  | { state: "available" }
  | { state: "taken" }
  | { state: "invalid"; message: string };

// Safari shows its own native Caps Lock arrow inside password fields; Chrome
// and other browsers show nothing. This custom hint fills that gap, so it is
// rendered only where the native indicator does not exist. Touch devices
// (iPad/iPhone) are the exception: Safari there draws only an unstyleable
// native blue pill (hidden in CSS), no inline arrow, so the custom hint shows
// there too — pinned to the bottom-left corner where the blue pill sat.
const HAS_NATIVE_CAPS_INDICATOR =
  typeof navigator !== "undefined" && /^((?!chrome|chromium|android).)*safari/i.test(navigator.userAgent);

// Read at hint-render time, not page load. The hint only renders after the
// user focuses a field (client-only), so SSR never evaluates it and hydration
// cannot mismatch.
function isCoarsePointer(): boolean {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(pointer: coarse)").matches;
}

// Focus events carry no modifier state, so remember the last Caps Lock state
// seen on any key/pointer event anywhere on the page (capture phase).
let lastCapsState = false;
if (typeof window !== "undefined") {
  const track = (e: Event) => {
    const m = e as KeyboardEvent;
    if (typeof m.getModifierState === "function") lastCapsState = m.getModifierState("CapsLock");
  };
  for (const type of ["keydown", "keyup", "mousedown", "pointerdown", "mousemove"]) {
    window.addEventListener(type, track, { capture: true, passive: true });
  }
}

function capsLockOn(event: React.SyntheticEvent<HTMLInputElement>): boolean {
  const native = event.nativeEvent as KeyboardEvent;
  if (typeof native.getModifierState === "function") {
    lastCapsState = native.getModifierState("CapsLock");
    return lastCapsState;
  }
  return lastCapsState;
}

function CapsLockHint({ visible, corner = "right", rightOffsetPx }: { visible: boolean; corner?: "right" | "left"; rightOffsetPx?: number | undefined }) {
  if (!visible) return null;
  return (
    <span
      className={corner === "left" ? "claim-caps-hint claim-caps-hint--left" : "claim-caps-hint"}
      aria-hidden="true"
      style={corner !== "left" && rightOffsetPx !== undefined ? { right: `${rightOffsetPx}px` } : undefined}
    >
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="0" y="0" width="24" height="24" rx="6" fill="#8e8e93" />
        <path d="M12 5.5l4.5 5.5h-2.7v5h-3.6v-5H7.5L12 5.5z" fill="#ffffff" />
        <rect x="9" y="17.5" width="6" height="2" rx="1" fill="#ffffff" />
      </svg>
    </span>
  );
}

const cleanWebsite = (v: string) => {
  let s = v;
  if (/^www\./i.test(s) && /^(https?:\/\/|www\.)/i.test(s.slice(4))) s = s.slice(4);
  return s.replace(/^https?:\/\//i, "");
};
const caretEndIfWww = (e: { currentTarget: HTMLInputElement }) => {
  const el = e.currentTarget;
  if (el.value === "www.") requestAnimationFrame(() => el.setSelectionRange(4, 4));
};

function ClaimPage() {
  const websiteInputRef = useRef<HTMLInputElement>(null);
  // Keep the page hidden until its final layout has settled (first load).
  useRevealWhenSettled();
  const navigate = useNavigate();
  const footerRef = useRef<HTMLElement>(null);
  const check = useServerFn(checkClaimSlug);
  const reserve = useServerFn(reserveClaimSlug);
  const prefillFn = useServerFn(getClaimPrefill);
  const passPaidFn = useServerFn(getPassPaid);
  const checkEmailFn = useServerFn(checkClaimEmail);
  const checkPasswordFn = useServerFn(checkClaimPassword);
  const checkWebsiteFn = useServerFn(checkClaimWebsite);
  // True while a valid, unpaid checkout pass covers an already-created account.
  const [hasAccount, setHasAccount] = useState(false);

  const [contact, setContact] = useState<ClaimContact | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhoneRaw] = useState("");
  const [phoneCountry, setPhoneCountry] = useState<PhoneCountry>(PHONE_COUNTRIES[0]!);
  const [phoneError, setPhoneError] = useState(false);
  const phoneCountryRef = useRef(phoneCountry);
  phoneCountryRef.current = phoneCountry;
  const setPhone = (raw: string) => {
    const parsed = parsePhone(raw, phoneCountryRef.current);
    phoneCountryRef.current = parsed.country;
    setPhoneCountry(parsed.country);
    setPhoneRaw(formatPhone(parsed.digits, parsed.country));
    setPhoneError(false);
  };
  const phoneDigits = phone.replace(/\D/g, "");
  const fullPhone = phoneDigits ? `${phoneCountry.dial} ${sendablePhone(phone, phoneCountry)}` : "";
  const [password, setPassword] = useState("");
  const [wrongPassword, setWrongPassword] = useState<false | "wrong" | "locked">(false);
  const [lockedMinutes, setLockedMinutes] = useState(15);
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);
  const [capsHint, setCapsHint] = useState<{ password: boolean; confirm: boolean }>({
    password: false,
    confirm: false,
  });

  // Keep the Caps Lock hint in sync from any keyboard/mouse/touch event on the
  // page while a password field is focused — including the click/tap that
  // focuses it (mousedown/pointerup/click fire after focus in Chrome).
  useEffect(() => {
    const sync = (e: Event) => {
      const m = e as KeyboardEvent;
      if (typeof m.getModifierState === "function") lastCapsState = m.getModifierState("CapsLock");
      const id = (document.activeElement as HTMLElement | null)?.id;
      if (id === "claim-password") setCapsHint((p) => (p.password === lastCapsState ? p : { ...p, password: lastCapsState }));
      else if (id === "claim-password-confirm") setCapsHint((p) => (p.confirm === lastCapsState ? p : { ...p, confirm: lastCapsState }));
    };
    const types = ["keydown", "keyup", "pointerdown", "pointerup", "mousedown", "mouseup", "click", "mousemove", "touchend", "focusin"];
    for (const t of types) document.addEventListener(t, sync, { capture: true, passive: true });
    return () => {
      for (const t of types) document.removeEventListener(t, sync, { capture: true });
    };
  }, []);
  const [companyName, setCompanyName] = useState("");
  const [website, setWebsite] = useState("");
  const [websiteCheck, setWebsiteCheck] = useState<{ value: string; valid: boolean } | null>(null);
  const [websiteChecking, setWebsiteChecking] = useState(false);
  const websiteReq = useRef(0);
  const [slug, setSlug] = useState("");
  const [rawSlug, setRawSlug] = useState("");
  const [availability, setAvailability] = useState<Availability>({ state: "idle" });
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  // 250: phones returning signed from /sign go straight to the voice step (no form flash)
  // while the claim saves in the background; `voiceReady` resolves with the saved order.
  const [voiceOrder, setVoiceOrder] = useState<ClaimOrder | null>(() => {
    const h = getSignHandoff();
    if (!h || h.kind !== "claim" || !h.signatureName) return null;
    const d = h.draft;
    return { firstName: d.firstName.trim(), ...(d.lastName.trim() ? { lastName: d.lastName.trim() } : {}), email: d.email.trim().toLowerCase(), slug: d.slug };
  });
  const [voiceReady, setVoiceReady] = useState<Promise<ClaimOrder | null> | null>(null);
  const voiceReadyResolve = useRef<((o: ClaimOrder | null) => void) | null>(null);
  // iPad and desktop share the exact same 1000px checkout composition.
  const [tabletFill, setTabletFill] = useState<number | null>(null);
  const [isDesktop, setIsDesktop] = useState(false);
  useLayoutEffect(() => {
    let appliedWidth: number | undefined;
    const update = () => {
      if ((window.visualViewport?.scale ?? 1) > 1.01) return;
      const viewport = getDesktopViewport();
      const vw = viewport.width;
      appliedWidth = vw;
      const on = vw >= 640;
      // Keep touch-first iPads on the single fixed checkout canvas, including
      // landscape widths that overlap desktop breakpoints. The canvas then
      // scales as one unit instead of reflowing its text into new line breaks.
      const desktop = vw >= 1024 && window.matchMedia("(pointer: fine)").matches;
      setTabletFill(on ? 1 / getDesktopScale(vw) : null);
      setIsDesktop(desktop);
      document.body.classList.toggle("claim-ipad-layout", on && !desktop);
      document.body.classList.toggle("claim-desktop-layout", desktop);
    };
    update();
    const detachHealing = attachSizeHealing(() => appliedWidth !== undefined && Math.abs(appliedWidth - getDesktopViewport().width) > 1, update);
    window.addEventListener("resize", update);
    // After a rotation the layout needs two extra passes to settle, so the
    // order box measures correctly once the turn is finished.
    let settleA = 0;
    let settleB = 0;
    const onOrientationChange = () => {
      update();
      window.clearTimeout(settleA);
      window.clearTimeout(settleB);
      settleA = window.setTimeout(update, 400);
      settleB = window.setTimeout(update, 900);
    };
    window.addEventListener("orientationchange", onOrientationChange);
    return () => {
      detachHealing();
      document.body.classList.remove("claim-ipad-layout");
      document.body.classList.remove("claim-desktop-layout");
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", onOrientationChange);
      window.clearTimeout(settleA);
      window.clearTimeout(settleB);
    };
  }, []);

  // Desktop only: shrink the whole composition uniformly (widths stay full,
  // every inner size and gap stays exactly proportional) until it fits the screen.
  const gridRef = useRef<HTMLDivElement | null>(null);
  const fitRef = useRef(DESKTOP_FIT);
  const [fit, setFit] = useState(DESKTOP_FIT);
  const gridMinRef = useRef<number | null>(null);
  const [gridMin, setGridMin] = useState<number | null>(null);
  useLayoutEffect(() => {
    if (!isDesktop) {
      fitRef.current = 1;
      setFit(1);
      gridMinRef.current = null;
      setGridMin(null);
      return;
    }
    let raf = 0;
    let stop = false;
    let measuredWidth: number | undefined;
    const measure = () => {
      if (stop) return;
      const grid = gridRef.current;
      if (!grid) return;
      const footer = document.querySelector("footer");
      const footerH = footer ? footer.getBoundingClientRect().height : 0;
      // Measure from the document origin, not the viewport. Browser resize
      // events can fire while scrolling; viewport-relative `top` then drops by
      // scrollY and incorrectly makes the checkout grow after it has loaded.
      const documentTop = grid.getBoundingClientRect().top + window.scrollY;
      const avail = window.innerHeight - documentTop - footerH - 2;
      if (avail <= 0) return;
      // Natural (unfilled) rendered height of the composition.
      const prevMin = grid.style.minHeight;
      grid.style.minHeight = "0px";
      const natural = grid.getBoundingClientRect().height;
      grid.style.minHeight = prevMin;
      if (natural <= 0) return;
      measuredWidth = getDesktopViewport().width;
      const nextMin = avail;
      if (gridMinRef.current === null || Math.abs(nextMin - gridMinRef.current) > 1) {
        gridMinRef.current = nextMin;
        setGridMin(nextMin);
      }
      const next = DESKTOP_FIT;
      if (Math.abs(next - fitRef.current) < 0.004) return;
      fitRef.current = next;
      setFit(next);
    };
    let frames = 0;
    const tick = () => {
      measure();
      if (stop || frames++ > 60) return;
      raf = requestAnimationFrame(tick);
    };
    tick();
    const timers = [60, 200, 500, 1000].map((t) => window.setTimeout(measure, t));
    const onResize = () => {
      if ((window.visualViewport?.scale ?? 1) !== 1) return;
      fitRef.current = DESKTOP_FIT;
      setFit(DESKTOP_FIT);
      window.setTimeout(measure, 50);
      window.setTimeout(measure, 200);
    };
    window.addEventListener("resize", onResize);
    const detachHealing = attachSizeHealing(() => Boolean(gridRef.current) && measuredWidth !== undefined && Math.abs(measuredWidth - getDesktopViewport().width) > 1, onResize);
    return () => {
      detachHealing();
      stop = true;
      cancelAnimationFrame(raf);
      timers.forEach((t) => window.clearTimeout(t));
      window.removeEventListener("resize", onResize);
    };
  // Re-measure when the form view (re)appears after the voice choice, so the
  // desktop fit is applied to the real form instead of the missing grid.
  }, [isDesktop, voiceOrder === null]);
  const requestId = useRef(0);

  // Voice choice takes over the whole page at this same address.
  useEffect(() => {
    // Prompt 161: browser Back from the GHL checkout (full reload) also reopens the voice choice.
    let backFromGhl = false;
    try {
      const nav = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
      backFromGhl = nav?.type === "back_forward" && window.sessionStorage.getItem("linkbot.claim.ghlVisited") === "1";
    } catch {
      /* unavailable */
    }
    const stored = isClaimVoiceStep() || backFromGhl ? readStoredClaimOrder() : null;
    if (stored) {
      setClaimVoiceStep(true);
      setVoiceOrder(stored);
    }
    else setClaimVoiceStep(false);
    return () => setClaimVoiceStep(false);
  }, []);
  function openVoiceChoice(order: ClaimOrder) {
    setClaimVoiceStep(true);
    setVoiceOrder(order);
    scrollToTopSettled();
  }
  function closeVoiceChoice() {
    setVoiceReady(null);
    setClaimVoiceStep(false);
    setVoiceOrder(null);
    scrollToTopSettled();
    pinPhoneTop();
  }

  useEffect(() => {
    const stored = readStoredClaimContact();
    if (stored) {
      setContact(stored);
      setFirstName(stored.firstName);
      if (stored.lastName) setLastName(stored.lastName);
      setEmail(stored.email);
      if (stored.phone) setPhone(stored.phone);
      if (stored.companyName) setCompanyName(stored.companyName);
      if (stored.website) setWebsite(stored.website);
    }
  }, []);

  // 188: a pass for an already-paid bot goes to /welcome ("You're all set!").
  // 188B: only when reached with the browser's Back/Forward, never on a normal visit.
  useEffect(() => {
    const check = () => { void passPaidFn().then((r) => { if (r.paid) window.location.replace("/welcome"); }).catch(() => {}); };
    let viaHistory = false;
    try {
      const nav = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
      viaHistory = nav?.type === "back_forward";
    } catch { /* unavailable */ }
    if (viaHistory) check();
    const onShow = (e: PageTransitionEvent) => { if (e.persisted) check(); };
    window.addEventListener("pageshow", onShow);
    return () => window.removeEventListener("pageshow", onShow);
  }, [passPaidFn]);

  // A valid, unpaid checkout pass: show that person's form filled in (never the password).
  useEffect(() => {
    let cancelled = false;
    void prefillFn()
      .then((p) => {
        if (cancelled || !p) return;
        setHasAccount(true);
        setRawSlug(p.slug);
        setSlug(normalizeClaimSlug(p.slug));
        setFirstName(p.firstName);
        setLastName(p.lastName);
        setEmail(p.email);
        setPhone(p.phone);
        setCompanyName(p.companyName);
        setWebsite(p.website);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [prefillFn]);

  // 244: coming back from the phone /sign page — refill the form (kept in memory only)
  // and, if they signed, continue exactly as the pop-up's "Sign and Continue" does.
  const [pendingSignature, setPendingSignature] = useState<string | null>(null);
  useEffect(() => {
    const h = getSignHandoff();
    if (!h || h.kind !== "claim") return;
    setSignHandoff(null);
    scrollToTopSettled();
    const d = h.draft;
    setFirstName(d.firstName);
    setLastName(d.lastName);
    setEmail(d.email);
    setPhoneCountry(d.phoneCountry);
    phoneCountryRef.current = d.phoneCountry;
    setPhoneRaw(d.phone);
    setPassword(d.password);
    setConfirmPassword(d.confirmPassword);
    setCompanyName(d.companyName);
    setWebsite(d.website);
    setRawSlug(d.rawSlug);
    setSlug(d.slug);
    if (h.signatureName) {
      setClaimVoiceStep(true);
      setVoiceReady(new Promise<ClaimOrder | null>((resolve) => { voiceReadyResolve.current = resolve; }));
      setPendingSignature(h.signatureName);
    }
  }, []);

  const problemMessage = useMemo(() => {
    const formatMessage = claimSlugFormatMessage(rawSlug);
    if (formatMessage) return formatMessage;
    const problem = validateClaimSlug(slug);
    if (problem === "too_short") return "Use at least 3 characters.";
    if (problem === "format") return "Letters, numbers, periods, underscores and hyphens only. No period at the start or end, or two in a row.";
    if (problem === "reserved") return "That one is already taken, please try another";
    return null;
  }, [slug, rawSlug]);

  // 191: the typed email (when valid) goes with the name check so an own unpaid hold shows available.
  // 194: the same email rule as the server.
  const slugCheckEmail = ClaimEmailRule.safeParse(email).success ? email.trim().toLowerCase() : "";
  useEffect(() => {
    // 326: bump the id first so a late answer from any earlier check (including
    // the empty/invalid early returns below) can never enable the button.
    const id = ++requestId.current;
    if (!slug) {
      setAvailability({ state: "idle" });
      return;
    }
    if (problemMessage) {
      setAvailability({ state: "invalid", message: problemMessage });
      return;
    }
    setAvailability({ state: "checking" });
    const timer = setTimeout(() => {
      void check({ data: { slug, ...(slugCheckEmail ? { email: slugCheckEmail } : {}) } })
        .then((result) => {
          if (id !== requestId.current) return;
          setAvailability(result.available ? { state: "available" } : { state: "taken" });
        })
        .catch(() => {
          if (id !== requestId.current) return;
          setAvailability({ state: "invalid", message: "Couldn't check that name. Please try again." });
        });
    }, 350);
    return () => clearTimeout(timer);
  }, [slug, problemMessage, check, slugCheckEmail]);

  const emailValid = ClaimEmailRule.safeParse(email).success;
  // 449: existing accounts are found on the form, before any signing.
  const [existingEmail, setExistingEmail] = useState(false);
  const [existingPaid, setExistingPaid] = useState(true);
  const [signedInOwner, setSignedInOwner] = useState(false);
  const [emailChecking, setEmailChecking] = useState(false);
  // 191: signed-in customers never see the checkout-time-ran-out password message.
  useEffect(() => {
    if (signedInOwner) setSubmitError((m) => (m === "Your checkout time ran out. Please re-enter your password to continue." ? null : m));
  }, [signedInOwner]);
  const emailReq = useRef(0);
  useEffect(() => {
    const id = ++emailReq.current;
    setExistingEmail(false);
    setSignedInOwner(false);
    if (hasAccount || !emailValid) { setEmailChecking(false); return; }
    setEmailChecking(true);
    const target = email.trim().toLowerCase();
    const timer = setTimeout(() => {
      checkEmailFn({ data: { email: target } })
        .then((res) => { if (id === emailReq.current) { setExistingEmail(res.exists); setExistingPaid(res.hasPaidBot); setSignedInOwner(!!res.signedInOwner); } })
        .catch(() => { /* treat as new */ })
        .finally(() => { if (id === emailReq.current) setEmailChecking(false); });
    }, 500);
    return () => clearTimeout(timer);
  }, [email, emailValid, hasAccount, checkEmailFn]);
  const passwordStrong =
    password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[0-9]/.test(password) &&
    /[^A-Za-z0-9]/.test(password);
  const passwordValid = hasAccount || (signedInOwner && !hasAccount) || (existingEmail ? password.length > 0 : passwordStrong && password === confirmPassword);
  const passwordHint = hasAccount || existingEmail || signedInOwner || !password
    ? ""
    : !passwordStrong
      ? "Password needs at least 8 characters, one uppercase letter, one number and one special character."
      : confirmPassword && password !== confirmPassword
        ? "Passwords do not match."
        : "";
  // 326: every starred field must be filled before the button unlocks.
  const websiteFull = website.trim();
  const websiteValid = claimWebsiteShape(websiteFull) && !(websiteCheck?.value === websiteFull && !websiteCheck.valid);
  async function validateWebsite(value: string) {
    const id = ++websiteReq.current;
    const target = value.trim();
    setWebsiteChecking(true);
    let valid = claimWebsiteShape(target);
    try { if (valid) valid = (await checkWebsiteFn({ data: { website: target } })).valid; }
    catch { /* DNS/transport outage must not block checkout. */ }
    if (id === websiteReq.current) {
      setWebsiteCheck({ value: target, valid });
      setWebsiteChecking(false);
      if (!valid) setShowMissing(true);
    }
    return valid;
  }
  const phoneValid = isValidPhone(phoneDigits, phoneCountry);
  const canConfirm =
    availability.state === "available" &&
    firstName.trim().length > 0 &&
    lastName.trim().length > 0 &&
    phoneValid &&
    companyName.trim().length > 0 &&
    websiteValid &&
    emailValid &&
    passwordValid &&
    !emailChecking &&
    !websiteChecking &&
    !submitting;

  // Legal Terms signing (Prompt 205): required before anything is created, unless a valid pass shows they already signed.
  const [signOpen, setSignOpen] = useState(false);
  const [signError, setSignError] = useState<string | null>(null);

  const [showMissing, setShowMissing] = useState(false);
  const [missPulse, setMissPulse] = useState(0);
  // 461: focusing any field clears the in-box errors, like the demo form.
  const clearMissing = () => { setShowMissing(false); setMissPulse(0); };

  async function onConfirm(event: React.FormEvent) {
    event.preventDefault();
    if (submitting) return;
    if (!canConfirm) { if (showMissing) setMissPulse((k) => k + 1); setShowMissing(true); return; }
    if (!await validateWebsite(websiteFull)) return;
    if (!isValidPhone(phoneDigits, phoneCountry)) {
      setPhoneError(true);
      return;
    }
    if (existingEmail && !hasAccount) {
      setSubmitting(true);
      setSubmitError(null);
      try {
        const res = await checkPasswordFn({ data: { email: email.trim().toLowerCase(), password } });
        if (!res.ok) { if (res.reason === "locked") setLockedMinutes(res.lockedMinutes ?? 15); setWrongPassword(res.reason === "locked" ? "locked" : "wrong"); return; }
        setWrongPassword(false);
      } catch {
        setSubmitError("We couldn't save that link. Please try again.");
        return;
      } finally {
        setSubmitting(false);
      }
    }
    if (hasAccount) {
      void submitClaim();
      return;
    }
    setSignError(null);
    if (isPhoneSignPage()) {
      setSignHandoff({
        kind: "claim",
        expectedName: `${firstName} ${lastName}`,
        draft: { firstName, lastName, email, phone, phoneCountry, password, confirmPassword, companyName, website, rawSlug, slug },
      });
      void navigate({ to: "/sign" });
      return;
    }
    setSignOpen(true);
  }

  async function submitClaim(signatureName?: string) {
    setSubmitting(true);
    setSubmitError(null);

    const fullWebsite = website.trim();

    try {
      const result = await reserve({
        data: {
          slug,
          firstName: firstName.trim(),
          ...(lastName.trim() ? { lastName: lastName.trim() } : {}),
          email: email.trim().toLowerCase(),
          ...(hasAccount || signedInOwner ? {} : { password }),
          ...(fullPhone ? { phone: fullPhone } : {}),
          ...(companyName.trim() ? { companyName: companyName.trim() } : {}),
          ...(fullWebsite ? { website: fullWebsite } : {}),
          ...(signatureName ? { signature: { fullName: signatureName, agreedSensitiveUse: true as const, agreedTerms: true as const } } : {}),
        },
      });
      setSignOpen(false);
      if (result.ok) {
        // Keep the submitted details for the voice choice, /checkout and the webhook.
        // The password never leaves this function's reserve call.
        const order: ClaimOrder = {
          firstName: firstName.trim(),
          ...(lastName.trim() ? { lastName: lastName.trim() } : {}),
          email: email.trim().toLowerCase(),
          ...(fullPhone ? { phone: fullPhone } : {}),
          ...(companyName.trim() ? { companyName: companyName.trim() } : {}),
          ...(fullWebsite ? { website: fullWebsite } : {}),
          slug,
          ...(result.botId ? { botId: result.botId } : {}),
        };
        storeClaimOrder(order);
        setWrongPassword(false);
        // The account now exists: lock the form like a reload with a valid pass, and clear the typed password.
        setHasAccount(true);
        setPassword("");
        setConfirmPassword("");
        if (voiceReadyResolve.current) {
          voiceReadyResolve.current(order);
          voiceReadyResolve.current = null;
          setVoiceOrder(order);
        } else openVoiceChoice(order);
        return;
      }
      if (result.reason === "invalid_website") {
        setWebsiteCheck({ value: fullWebsite, valid: false });
        setShowMissing(true);
      } else if (result.reason === "taken") {
        setAvailability({ state: "taken" });
      } else if (result.reason === "locked") {
        setLockedMinutes(result.lockedMinutes);
        setWrongPassword("locked");
      } else if (result.reason === "wrong_password") {
        setWrongPassword("wrong");
      } else if (result.reason === "pass_expired") {
        // 189: pass ran out while open — back to the normal form for this email; signing required again.
        setHasAccount(false);
        setPassword("");
        setConfirmPassword("");
        // 190: say why the form changed.
        setSubmitError("Your checkout time ran out. Please re-enter your password to continue.");
      } else if (result.reason === "sign_in_needed") {
        // 190: the sign-in ended — back to the returning-customer password field for this email.
        setSignedInOwner(false);
        setExistingEmail(true);
        setPassword("");
        // 194: the returning-customer note follows this email's real paid state.
        void checkEmailFn({ data: { email: email.trim().toLowerCase() } })
          .then((res) => setExistingPaid(res.hasPaidBot))
          .catch(() => { /* keep current note */ });
      } else {
        setSubmitError("We couldn't save that link. Please try again.");
      }
    } catch {
      setSignOpen(false);
      setSubmitError("We couldn't save that link. Please try again.");
    } finally {
      setSubmitting(false);
      // 250: background claim failed — leave the voice step and show the form with its error.
      if (voiceReadyResolve.current) {
        voiceReadyResolve.current(null);
        voiceReadyResolve.current = null;
        setVoiceReady(null);
        closeVoiceChoice();
      }
    }
  }

  useEffect(() => {
    if (!pendingSignature) return;
    const name = pendingSignature;
    setPendingSignature(null);
    void submitClaim(name);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingSignature]);

  useFooterMatchHeader(footerRef, "rgb(173, 173, 173)", [voiceOrder]);
  const claimGridStyle: React.CSSProperties | undefined = 
            tabletFill
              ? {
                  width: `${CLAIM_TABLET_WIDTH / (isDesktop ? fit : 1)}px`,
                  boxSizing: "border-box",
                  marginLeft: "auto",
                  marginRight: "auto",
                  zoom: (DESKTOP_CANVAS_WIDTH / CLAIM_TABLET_WIDTH) * (isDesktop ? fit * DESKTOP_ZOOM_OUT : 1),
                  minHeight:
                    isDesktop && gridMin !== null
                      ? `${((gridMin + DESKTOP_CHECKOUT_BOTTOM_SPACE) * tabletFill) / ((DESKTOP_CANVAS_WIDTH / CLAIM_TABLET_WIDTH) * fit * DESKTOP_ZOOM_OUT)}px`
                      : `calc((100dvh - var(--site-header-height, 80px) - 42px) * ${(tabletFill * CLAIM_TABLET_WIDTH) / DESKTOP_CANVAS_WIDTH})`,
                }
              : undefined
          ;
  if (voiceOrder) return <VoiceChoice order={voiceOrder} onBack={closeVoiceChoice} ready={voiceReady} gridRef={gridRef} gridStyle={claimGridStyle} />;

  const inputClass = (extra = "px-4", err = false) =>
    `h-12 w-full rounded-xl border ${err ? "border-ink" : "border-border focus:border-brand"} bg-surface text-base font-medium text-ink placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-brand/30 ${extra}`;
  const boxError = (show: boolean, text: string) =>
    show ? (
      <p className="pointer-events-none absolute inset-px z-10 flex items-center rounded-[11px] bg-surface px-4 text-xl font-black text-ink max-sm:rounded-[11px] max-sm:px-4 max-sm:text-base">
        <span key={missPulse} className={missPulse > 0 ? "demo-email-error-pulse" : undefined}>{text}</span>
      </p>
    ) : null;
  const errSlug = showMissing && !slug.trim();
  const errEmail = showMissing && !emailValid;
  const errPw = showMissing && !hasAccount && !signedInOwner && !password;
  const errConfirm = showMissing && !hasAccount && !signedInOwner && !existingEmail && !confirmPassword;
  const errFirst = showMissing && !firstName.trim();
  const errLast = showMissing && !lastName.trim();
  const errPhone = showMissing && !phoneValid;
  const errCompany = showMissing && !companyName.trim();
  const errWebsite = showMissing && !websiteValid;

  return (
    <div className="claim-page-root flex min-h-screen flex-col bg-night">

      <main className="flex-1 bg-surface">
        <div>
        <div
          ref={gridRef}
          className="claim-grid grid w-full min-w-0 gap-6 overflow-hidden px-4 py-8 lg:grid-cols-[30rem_minmax(0,1fr)] lg:gap-14 lg:overflow-visible lg:px-10 lg:py-16 xl:px-16"
          style={claimGridStyle}
        >
          <ClaimOrderAside onBack={() => navigate({ to: "/" })} />

        <div className="min-w-0 animate-fade-up">
          <div className="relative min-w-0 w-full text-left">
            <button
              type="button"
              onClick={() => navigate({ to: "/" })}
              className="hidden items-center rounded-full border border-border bg-surface-2 px-4 py-2 text-[0.65rem] font-extrabold uppercase tracking-[0.16em] text-ink shadow-elev-1 transition-all hover:border-brand hover:text-brand hover:shadow-elev-2 lg:inline-flex lg:px-5 lg:py-2.5 lg:text-xs"
            >
              ← Back
            </button>

            <div className="mt-6 text-center">
              <h2 className="headline mx-auto whitespace-nowrap text-[clamp(1.15rem,5.4vw,1.95rem)] font-black leading-[1.05] tracking-tight text-ink lg:text-[clamp(1.35rem,2.4vw,1.95rem)]">
                SET UP YOUR ACCOUNT:
              </h2>
              <p className="mx-auto mt-2 max-w-[38ch] text-[0.8rem] font-bold leading-5 text-muted-foreground lg:mt-3 lg:max-w-none lg:text-sm lg:leading-6">
                Pick the link for your AI voice employee and confirm your details to continue.
              </p>
            </div>


              <form onSubmit={onConfirm} noValidate className="mt-6 grid min-w-0 grid-cols-2 gap-x-6 gap-y-4 lg:gap-y-3">
                <div className="relative col-span-2">
                  <label htmlFor="claim-slug" className="block whitespace-nowrap text-[clamp(0.68rem,3vw,0.75rem)] font-bold text-ink">
                     Custom LinkBot Domain:
                  </label>
                   <div className={`claim-field-shell relative mt-2 flex h-12 min-w-0 items-center rounded-xl border ${errSlug ? "border-ink" : "border-border"} bg-surface px-3 focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/30 sm:px-4`}>
                     <span className="shrink-0 select-none text-[clamp(0.72rem,3.3vw,1rem)] font-semibold text-ink">linkbot.now/</span>
                    <input
                      id="claim-slug"
                      value={slug}
                      onFocus={clearMissing}
                      onChange={(event) => {
                        const raw = event.target.value.replace(/\s+/g, "");
                        setRawSlug(raw);
                        setSlug(normalizeClaimSlug(raw));
                      }}
                      maxLength={MAX_SLUG_LENGTH}
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      placeholder="yourbusiness"
                       className="min-w-0 flex-1 bg-transparent px-1 text-[clamp(0.72rem,3.3vw,1rem)] font-medium text-ink placeholder:text-muted-foreground/70 outline-none"
                    />
                    <span className="flex shrink-0 items-center gap-2 pl-2" aria-live="polite">
                      {availability.state === "idle" ? null : availability.state === "checking" ? (
                        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                      ) : (
                        <>
                          <span
                            className={`h-2 w-2 rounded-full ${availability.state === "available" ? "bg-success" : "bg-destructive"}`}
                            aria-hidden="true"
                          />
                           <span className="whitespace-nowrap text-[clamp(0.6rem,2.7vw,0.75rem)] font-medium text-muted-foreground">
                            {availability.state === "available" ? "Available" : "Not Available"}
                          </span>
                        </>
                      )}
                    </span>
                    {boxError(errSlug, "Invalid link name")}
                  </div>
                  <p className="mt-2 text-[11px] leading-4 text-muted-foreground">
                      This link appears visible to everyone instead of your real link for privacy protection. If used as url, access is denied.
                  </p>
                  <FitLine className="mt-1 min-h-4 text-[11px] font-bold" aria-live="polite">
                    {availability.state === "taken" && (
                      <span className="text-destructive">That one is already taken, please try another</span>
                    )}
                    {availability.state === "invalid" && (
                      <span className="text-destructive">{availability.message}</span>
                    )}
                    {availability.state === "available" && <span className="text-success">That link is available.</span>}
                  </FitLine>
                </div>

                 <p className="claim-section-title col-span-2 mt-1 whitespace-nowrap text-[clamp(0.68rem,3vw,0.75rem)] font-bold text-ink">Login Credentials:</p>

                <div className="relative col-span-2">
                  <input
                    id="claim-email"
                    aria-label="Email"
                    type="email"
                    autoComplete="email"
                    maxLength={255}
                    placeholder="Email Address*"
                    value={email}
                    readOnly={hasAccount}
                    onChange={(event) => { if (!hasAccount) { setEmail(event.target.value); setWrongPassword(false); } }}
                    onFocus={clearMissing}
                    className={inputClass("px-4", errEmail)}
                  />
                  {boxError(errEmail, "Invalid email")}
                  {signedInOwner && !hasAccount ? (
                    <p className="mt-2 text-[11px] leading-4 text-muted-foreground">You're signed in. Continue to add another LinkBot.</p>
                  ) : null}
                  {existingEmail && !hasAccount ? (
                    <p className="mt-2 text-[11px] leading-4 text-muted-foreground">{existingPaid ? "Welcome back! Enter your password to add another LinkBot." : "Welcome back! Enter your password to continue."}</p>
                  ) : null}
                  {hasAccount ? (
                    <button
                      type="button"
                      onClick={async () => {
                        try { await endClaimPass(); } catch { /* ignore */ }
                        for (const k of ["linkbot-claim-contact", "linkbot-claim-order", "linkbot.claim.ghlVisited", "linkbot.claim.voiceSent"]) {
                          try { sessionStorage.removeItem(k); } catch { /* ignore */ }
                        }
                        window.location.assign("/claim");
                      }}
                      className="mt-2 text-[11px] leading-4 text-muted-foreground underline"
                    >
                      Not you? Start over
                    </button>
                  ) : null}
                </div>

                {signedInOwner && !hasAccount ? null : (
                <div className="relative col-span-2 sm:col-span-1">
                  <input
                    id="claim-password"
                    aria-label="Password"
                    type={showPw && !hasAccount ? "text" : "password"}
                    autoComplete={existingEmail && !hasAccount ? "current-password" : "new-password"}
                    maxLength={128}
                    placeholder={existingEmail && !hasAccount ? "Your existing LinkBot password" : "Choose Password*"}
                    value={hasAccount ? "••••••••" : password}
                    readOnly={hasAccount}
                    onChange={(event) => { if (!hasAccount) { setPassword(event.target.value); setWrongPassword(false); } }}
                    onKeyDown={(event) => setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) }))}
                    onKeyUp={(event) => setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) }))}
                    onFocus={(event) => { clearMissing(); setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) })); }}
                    onBlur={() => setCapsHint((prev) => ({ ...prev, password: false }))}
                    className={inputClass(hasAccount ? "px-4" : "pl-4 pr-12", errPw)}
                  />
                  {boxError(errPw, "Invalid password")}
                  <CapsLockHint
                    visible={(!HAS_NATIVE_CAPS_INDICATOR || isCoarsePointer()) && capsHint.password}
                    corner={hasAccount ? (isCoarsePointer() ? "left" : "right") : "right"}
                    rightOffsetPx={hasAccount ? undefined : 44}
                  />
                  {hasAccount ? null : <PasswordEye shown={showPw} onToggle={() => setShowPw((v) => !v)} />}
                </div>
                )}

                {(existingEmail || signedInOwner) && !hasAccount ? null : (
                <div className="relative col-span-2 sm:col-span-1">
                  <input
                    id="claim-password-confirm"
                    aria-label="Confirm password"
                    type={showConfirmPw && !hasAccount ? "text" : "password"}
                    autoComplete="new-password"
                    maxLength={128}
                    placeholder="Confirm Password*"
                    value={hasAccount ? "••••••••" : confirmPassword}
                    readOnly={hasAccount}
                    onChange={(event) => { if (!hasAccount) setConfirmPassword(event.target.value); }}
                    onKeyDown={(event) => setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) }))}
                    onKeyUp={(event) => setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) }))}
                    onFocus={(event) => { clearMissing(); setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) })); }}
                    onBlur={() => setCapsHint((prev) => ({ ...prev, confirm: false }))}
                    className={inputClass(hasAccount ? "px-4" : "pl-4 pr-12", errConfirm)}
                  />
                  {boxError(errConfirm, "Invalid password")}
                  <CapsLockHint
                    visible={(!HAS_NATIVE_CAPS_INDICATOR || isCoarsePointer()) && capsHint.confirm}
                    corner={hasAccount ? (isCoarsePointer() ? "left" : "right") : "right"}
                    rightOffsetPx={hasAccount ? undefined : 44}
                  />
                  {hasAccount ? null : <PasswordEye shown={showConfirmPw} onToggle={() => setShowConfirmPw((v) => !v)} />}
                </div>
                )}

                {passwordHint || wrongPassword ? (
                  <p className="col-span-2 text-[clamp(0.62rem,2.6vw,0.7rem)] font-semibold text-destructive">
                    {passwordHint ? passwordHint : wrongPassword === "locked" ? (
                      <>Your Account Is Locked. Try again in {lockedMinutes === 1 ? "1 minute" : `${lockedMinutes} minutes`}, or <button type="button" className="cursor-pointer underline" onClick={() => window.location.assign("/forgot-password")}>reset your password</button> to unlock it now.</>
                    ) : (
                      <>That email or password is incorrect. <button type="button" className="cursor-pointer underline" onClick={() => window.location.assign("/forgot-password")}>Forgot password?</button></>
                    )}
                  </p>
                ) : null}

                 <p className="claim-section-title col-span-2 mt-1 whitespace-nowrap text-[clamp(0.68rem,3vw,0.75rem)] font-bold text-ink">Profile Information:</p>

                <div className="relative col-span-2">
                  <input
                    id="claim-name"
                    aria-label="First name"
                    type="text"
                    autoComplete="given-name"
                    maxLength={80}
                    placeholder="First Name*"
                    value={firstName}
                    onChange={(event) => setFirstName(event.target.value)}
                    onFocus={clearMissing}
                    className={inputClass("px-4", errFirst)}
                  />
                  {boxError(errFirst, "Invalid first name")}
                </div>

                <div className="relative col-span-2 sm:col-span-1">
                  <input
                    id="claim-last-name"
                    aria-label="Last name"
                    type="text"
                    autoComplete="family-name"
                    maxLength={80}
                    placeholder="Last Name*"
                    value={lastName}
                    onChange={(event) => setLastName(event.target.value)}
                    onFocus={clearMissing}
                    className={inputClass("px-4", errLast)}
                  />
                  {boxError(errLast, "Invalid last name")}
                </div>

                <div className="relative col-span-2 sm:col-span-1">
                  <div className="flex gap-2">
                    <PhoneCountryPicker
                      country={phoneCountry}
                      unscaledPhone
                      onSelect={(c) => {
                        phoneCountryRef.current = c;
                        setPhoneCountry(c);
                        setPhoneRaw(formatPhone(phoneDigits.slice(0, maxDigitsFor(c)), c));
                        setPhoneError(false);
                      }}
                    />
                    <div className="relative min-w-0 flex-1">
                      <input
                        id="claim-phone"
                        aria-label="Phone"
                        type="tel"
                        autoComplete="tel"
                        inputMode="tel"
                        placeholder="(555) 123-4567*"
                        value={phone}
                        onChange={(event) => setPhone(event.target.value)}
                        onFocus={clearMissing}
                        className={inputClass("px-4", errPhone)}
                      />
                      {boxError(errPhone, "Invalid phone number")}
                    </div>
                  </div>
                  {phoneError ? (
                    <p className="mt-1 text-[clamp(0.62rem,2.6vw,0.7rem)] font-semibold text-destructive">{PHONE_INCOMPLETE}</p>
                  ) : null}
                </div>

                <div className="relative col-span-2">
                  <input
                    id="claim-company"
                    aria-label="Company name"
                    type="text"
                    autoComplete="organization"
                    maxLength={120}
                    placeholder="Company Name*"
                    value={companyName}
                    onChange={(event) => setCompanyName(event.target.value)}
                    onFocus={clearMissing}
                    className={inputClass("px-4", errCompany)}
                  />
                  {boxError(errCompany, "Invalid company name")}
                </div>

                <div className="claim-section-block relative col-span-2">
                  <label htmlFor="claim-website" className="mb-2 block text-[clamp(0.68rem,3vw,0.75rem)] font-bold leading-snug text-ink">
                    <span className="sm:hidden">Company website:</span>
                     <span className="hidden sm:inline">What is your company website so we can train your custom AI voice employee?</span>
                  </label>
                  <div className="relative">
                    <input
                      ref={websiteInputRef}
                      id="claim-website"
                      type="text"
                      autoComplete="url"
                      maxLength={255}
                      placeholder="www.yourrealwebsite.com*"
                      value={website}
                      onChange={(event) => {
                        ++websiteReq.current;
                        setWebsiteChecking(false);
                        setWebsiteCheck(null);
                        setWebsite(cleanWebsite(event.target.value));
                      }}
                      onFocus={(e) => {
                        clearMissing();
                        const el = e.currentTarget;
                        if (el.value === "") {
                          setWebsite("www.");
                          setTimeout(() => { if (document.activeElement === el) el.setSelectionRange(4, 4); }, 0);
                        } else {
                          caretEndIfWww(e);
                        }
                      }}
                      onBlur={(e) => {
                        if (e.currentTarget.value.toLowerCase() === "www.") setWebsite("");
                        else void validateWebsite(e.currentTarget.value);
                      }}
                      className={inputClass("px-4", errWebsite)}
                    />
                    {boxError(errWebsite, "Invalid website")}
                  </div>
                </div>

                {submitError && (
                  <p className="col-span-2 text-xs font-bold text-destructive">
                    {submitError}
                  </p>
                )}

                <div className="col-span-2 mt-1">
                  <button
                    type="submit"
                    disabled={submitting}
                    aria-disabled={!canConfirm}
                    style={!canConfirm ? { cursor: "not-allowed", opacity: 0.55, transform: "none", filter: "none" } : undefined}
                    className="claim-confirm linkbot-button w-full disabled:cursor-not-allowed"
                  >
                    <span>{submitting ? "Reserving your link…" : "Confirm and continue to checkout"}</span>
                  </button>
                  <p className="mt-4 flex items-center justify-center gap-2 text-[11px] font-semibold text-muted-foreground">
                    <Lock className="h-3.5 w-3.5 text-brand" />
                    Your custom domain link is reserved for 30 minutes from the moment you click confirm until payment is received.
                  </p>

                  <div className="mt-8 grid grid-cols-1 justify-items-center gap-3 border-t border-border pt-6 sm:mt-10 sm:flex sm:flex-wrap sm:items-center sm:justify-center sm:gap-x-10 sm:gap-y-4 sm:pt-8">
                    {[
                      { icon: CreditCard, label: "Card charged at checkout only", order: "order-1" },
                      { icon: Clock, label: "Your link is held for 30 minutes", order: "order-2" },
                      { icon: BadgeCheck, label: "No contract", order: "order-3 sm:order-none" },
                    ].map(({ icon: Icon, label, order }) => (
                      <span key={label} className={`${order} flex items-center gap-2.5`}>
                        <Icon className="h-4 w-4 shrink-0 text-brand" strokeWidth={2} />
                        <span className="whitespace-nowrap text-[clamp(0.58rem,2.5vw,0.68rem)] font-black uppercase tracking-[0.14em] text-ink-soft">
                          {label}
                        </span>
                      </span>
                    ))}
                  </div>
                </div>
              </form>
          </div>
        </div>
        </div>
        </div>
      </main>

      <LegalModal
        open={signOpen}
        mode="sign"
        onClose={() => setSignOpen(false)}
        signing={submitting}
        signError={signError}
        expectedName={`${firstName} ${lastName}`}
        onSign={(name) => submitClaim(name)}
      />

      <footer ref={footerRef} className="demo-form-footer site-footer-balanced night-panel px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted">
        <p>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>
    </div>


  );
}
