import { createFileRoute } from "@tanstack/react-router";
import { WelcomePage } from "@/components/welcome/WelcomeView";

export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Welcome to LinkBot.Now" },
      { name: "description", content: "Your LinkBot account is being set up." },
      { property: "og:title", content: "Welcome to LinkBot.Now" },
      { property: "og:description", content: "Your LinkBot account is being set up." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <WelcomePage />,
});
