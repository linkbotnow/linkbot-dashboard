import { createFileRoute } from "@tanstack/react-router";
import { LoginPage } from "@/components/auth/LoginScreen";

const TITLE = "Reset Password | LinkBot";
const DESCRIPTION = "Choose a new password for your LinkBot account.";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => <LoginPage view="reset" />,
});
