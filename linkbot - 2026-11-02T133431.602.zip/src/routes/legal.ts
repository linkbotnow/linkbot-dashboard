import { createFileRoute } from "@tanstack/react-router";
import { legalPage } from "@/lib/legal-page.server";

export const Route = createFileRoute("/legal")({
  server: { handlers: { GET: () => legalPage() } },
});
