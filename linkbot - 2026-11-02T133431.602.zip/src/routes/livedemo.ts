import { createFileRoute } from "@tanstack/react-router";
import appCss from "../styles.css?url";

// Standalone black live demo page; no site layout, header or footer.
const LIVED_DEMO_HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>LinkBot Live Demo</title>
<meta property="og:type" content="website">
<meta property="og:url" content="https://linkbot.now/livedemo">
<meta property="og:title" content="LinkBot Live Demo">
<meta property="og:image" content="https://linkbot.now/customer-preview.png">
<meta property="og:image:type" content="image/png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="https://linkbot.now/customer-preview.png">
<link id="lb-app-css" rel="stylesheet" href="${appCss}">
<style>
  html,body{margin:0;padding:0;height:100%;background:#000;}
  @media (pointer: coarse) and (max-width: 599px), (pointer: coarse) and (max-height: 599px){html,body{background:#fff;}}
  body{display:flex;align-items:center;justify-content:center;}
  chat-widget{display:block!important;width:100%;}
  chat-widget{opacity:0!important;pointer-events:none!important;}
  chat-widget{position:fixed!important;left:0!important;top:0!important;transform:translateX(-300vw)!important;z-index:0!important;}
</style>
</head>
<body>
<script src="https://widgets.leadconnectorhq.com/loader.js" data-resources-url="https://widgets.leadconnectorhq.com/chat-widget/loader.js" data-widget-id="6ad3d73cd3ae3b035cfacf6d"></script>
<script>(function(){if(!document.querySelector('script[src="/livedemo-overlay.js"]')){var s=document.createElement("script");s.src="/livedemo-overlay.js";document.body.appendChild(s);}})();</script>
<script>(function(){if(!document.querySelector('script[src="/livedemo-folders.js"]')){var s=document.createElement("script");s.src="/livedemo-folders.js";document.body.appendChild(s);}})();</script>
</body>
</html>`;

// Link preview robots (LinkedIn, Facebook/Instagram/WhatsApp, X, Slack, Discord, Telegram, iMessage, etc.) may read this page to build the share card.
// Search engines still always get "noindex, nofollow". People are not affected either way.
const PREVIEW_BOT = /LinkedInBot|facebookexternalhit|Facebot|meta-externalagent|Twitterbot|Slackbot|Discordbot|TelegramBot|WhatsApp|Pinterestbot|redditbot|Embedly|SkypeUriPreview|vkShare|iframely|Snapchat/i;

export const Route = createFileRoute("/livedemo")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const preview = PREVIEW_BOT.test(request.headers.get("user-agent") ?? ""); // share-card robots only
        return new Response(preview ? LIVED_DEMO_HTML.replace('<meta name="robots" content="noindex, nofollow">\n', "") : LIVED_DEMO_HTML, {
          status: 200,
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-store",
            ...(preview ? {} : { "x-robots-tag": "noindex, nofollow" }),
          },
        });
      },
    },
  },
});
