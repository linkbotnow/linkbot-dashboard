import { createFileRoute } from '@tanstack/react-router';

const title = 'Send Follow-Up Email | LinkBot', description = 'Privately review and send your LinkBot lead follow-up email.';
const headers = { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex, nofollow', 'referrer-policy': 'no-referrer' };
function documentHtml(valid: boolean) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>${title}</title><meta name="description" content="${description}"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:type" content="website"><meta name="twitter:card" content="summary"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=block" rel="stylesheet"><link rel="stylesheet" href="/my-links.css"><link rel="stylesheet" href="/follow-up.css"></head><body${valid ? '' : ' class="follow-form"'}><div id="spacer"><div id="canvas">${valid ? '' : '<main class="follow-shell"><section class="follow-card"><p class="follow-confirm">This link isn\'t valid.</p></section></main>'}</div></div>${valid ? '<script src="/follow-up.js" defer></script>' : ''}</body></html>`;
}
export const Route = createFileRoute('/app/follow-up')({
  head: () => ({ meta: [{ title }, { name: 'description', content: description }, { property: 'og:title', content: title }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex,nofollow' }] }),
  server: { handlers: {
    GET: async ({ request }) => {
      const { validFollowUpQuery, followUpBot } = await import('../lib/follow-up.server');
      const query = validFollowUpQuery(new URL(request.url));
      try { return new Response(documentHtml(Boolean(query.success && await followUpBot(query.data.account))), { headers }); }
      catch { console.error('LinkBot follow-up page lookup failed'); return new Response(documentHtml(false), { headers }); }
    },
    POST: async ({ request }) => (await import('../lib/follow-up.server')).handleFollowUp(request),
  } },
});