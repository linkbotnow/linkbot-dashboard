"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { useLocation } from "@tanstack/react-router";

import logoAsset from "@/assets/linkbot-logo-transparent.png";
import { HoverlessLink } from "@/components/navigation/HoverlessLink";
import { cn } from "@/lib/utils";
import "./linkbot-brand.css";

const ROTATING_WORDS = ["AI GROWTH ENGINE", "WORK LESS. CONNECT MORE."];

function RotatingWords({
  nameWidth,
  nameOffset,
  enabled,
}: {
  nameWidth: number | null;
  nameOffset: number;
  enabled: boolean;
}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hasEntered, setHasEntered] = useState(false);
  const [appliedWidth, setAppliedWidth] = useState<number | null>(null);
  const nameWidthRef = useRef<number | null>(null);
  nameWidthRef.current = nameWidth;

  useEffect(() => {
    if (!enabled) return;

    const interval = window.setInterval(() => {
      setCurrentIndex((current) =>
        current === ROTATING_WORDS.length - 1 ? 0 : current + 1,
      );
      setAppliedWidth(nameWidthRef.current);
    }, 4200);

    return () => window.clearInterval(interval);
  }, [enabled]);

  useEffect(() => {
    if (nameWidth === null) {
      setAppliedWidth(null);
      return;
    }

    if (appliedWidth !== null) return;

    setAppliedWidth(nameWidth);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nameWidth]);

  // Keep the measured width in sync once it has already been adopted.
  useEffect(() => {
    if (appliedWidth !== null && nameWidth !== null && appliedWidth !== nameWidth) {
      setAppliedWidth(nameWidth);
    }
  }, [nameWidth, appliedWidth]);

  const currentText = ROTATING_WORDS[currentIndex] ?? ROTATING_WORDS[0]!;

  return (
    <span
      className="pr-brand-rotator"
      aria-hidden={!enabled}
      style={
        appliedWidth
          ? {
              width: `${appliedWidth}px`,
              marginLeft: `${nameOffset}px`,
              visibility: enabled ? "visible" : "hidden",
            }
          : { visibility: enabled ? "visible" : "hidden" }
      }
    >
      <span className="pr-brand-screen-reader">{currentText}</span>
      <AnimatePresence mode="wait">
        {enabled ? (
          <motion.span
            key={currentIndex}
            aria-hidden="true"
            className={cn(
              "pr-brand-rotator-line",
              currentIndex === 1 && "pr-brand-rotator-line-stretch",
            )}
            initial={
              hasEntered
                ? { y: "100%", opacity: 0 }
                : { opacity: 0 }
            }
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "-120%", opacity: 0 }}
            transition={
              hasEntered
                ? { type: "tween", duration: 0.4, ease: "easeOut" }
                : { duration: 0.3, ease: "easeOut" }
            }
            onAnimationComplete={() => setHasEntered(true)}
          >
            {Array.from(currentText).map((character, index) => (
              <span
                key={`${currentIndex}-${index}`}
                className="pr-brand-rotator-character"
              >
                {character === " " ? "\u00A0" : character}
              </span>
            ))}
          </motion.span>
        ) : null}
      </AnimatePresence>
    </span>
  );
}


// Phones only: the wordmark animation plays once per visit, on the first
// arrival, and only if the phone is upright then. Every later mount (rotation,
// header swaps, page changes, reloads in the same visit) shows the final state.
const PHONE_WORDMARK_KEY = "linkbot-phone-wordmark-played";
let phoneWordmarkDecision: { play: boolean; at: number } | null = null;
function isPhoneDevice() {
  return Math.min(window.screen.width, window.screen.height) <= 600 && window.matchMedia("(pointer: coarse)").matches;
}
function phoneWordmarkMayPlay(): boolean {
  if (!phoneWordmarkDecision) {
    let played = false;
    try {
      played = sessionStorage.getItem(PHONE_WORDMARK_KEY) === "1";
      sessionStorage.setItem(PHONE_WORDMARK_KEY, "1");
    } catch {
      /* storage unavailable: still decided once per page load */
    }
    const upright = window.matchMedia("(orientation: portrait)").matches;
    phoneWordmarkDecision = { play: !played && upright, at: Date.now() };
  }
  // Header instances mounting together on that first arrival share the decision.
  return phoneWordmarkDecision.play && Date.now() - phoneWordmarkDecision.at < 1500;
}

export function LinkBotBrand({ compact = false }: { compact?: boolean } = {}) {
  const { pathname } = useLocation();
  const isHome = pathname === "/";

  // The falling ".Now" animation belongs only to homepage arrivals. Its base
  // CSS remains the visible resting state, so this trigger is never required
  // for the suffix to appear.
  // 392: decide before the first paint (not in an effect) so a header that
  // mounts after a rotation never starts the intro for even one frame.
  const [phoneSkip, setPhoneSkip] = useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return isPhoneDevice() && sessionStorage.getItem(PHONE_WORDMARK_KEY) === "1";
    } catch {
      return false;
    }
  });
  useEffect(() => {
    if (isPhoneDevice() && !phoneWordmarkMayPlay()) setPhoneSkip(true);
  }, []);
  const animateSuffix = isHome && !phoneSkip;
  const showSuffix = true;
  const [armed, setArmed] = useState(false);
  const [suffixLanded, setSuffixLanded] = useState(false);

  useEffect(() => {
    setSuffixLanded(false);

    if (!animateSuffix) {
      setArmed(false);
      setSuffixLanded(true);
      return;
    }

    // Remove and restore the class across a paint so every homepage arrival
    // starts a fresh CSS animation without tying visibility to window.load.
    setArmed(false);
    let frame = 0;
    const replay = () => {
      cancelAnimationFrame(frame);
      setArmed(false);
      frame = requestAnimationFrame(() => setArmed(true));
    };

    // 414: on phones, switch both header copies (upright and the hidden
    // sideways one) to the finished logo once the intro is over — or
    // immediately if the phone turns first — so a header that becomes
    // visible after a rotation never starts the intro.
    let phoneIntroTimer: ReturnType<typeof setTimeout> | null = null;
    const finishPhoneIntro = () => {
      if (!isPhoneDevice()) return;
      setArmed(false);
      setSuffixLanded(true);
      setPhoneSkip(true);
    };
    const portraitMql = window.matchMedia("(orientation: portrait)");

    replay();
    const onPageShow = (event: PageTransitionEvent) => {
      if (event.persisted) replay();
    };
    window.addEventListener("pageshow", onPageShow);

    if (isPhoneDevice()) {
      phoneIntroTimer = setTimeout(finishPhoneIntro, 4000);
      window.addEventListener("orientationchange", finishPhoneIntro);
      portraitMql.addEventListener("change", finishPhoneIntro);
    }

    return () => {
      window.removeEventListener("pageshow", onPageShow);
      cancelAnimationFrame(frame);
      if (phoneIntroTimer) clearTimeout(phoneIntroTimer);
      window.removeEventListener("orientationchange", finishPhoneIntro);
      portraitMql.removeEventListener("change", finishPhoneIntro);
    };
  }, [animateSuffix]);

  const handleSuffixLanded = () => {
    setSuffixLanded(true);
  };



  const rowRef = useRef<HTMLSpanElement | null>(null);
  const [nameWidth, setNameWidth] = useState<number | null>(null);
  const [nameOffset, setNameOffset] = useState(0);

  useEffect(() => {
    if (!showSuffix || !suffixLanded) {
      setNameWidth(null);
      setNameOffset(0);
      return;
    }

    let observer: ResizeObserver | null = null;

    const measure = () => {
      // Pinch zoom changes painted bounds without changing the authored logo.
      // Ignore it so the wordmark cannot enter a ResizeObserver feedback loop.
      // Sideways phones are always zoomed out to fit the 1440 layout, so the
      // page scale is never 1 there; skipping would leave the rotating words
      // hidden forever (Prompt 140). Measurements are converted back to layout
      // pixels below, so they are scale-independent.
      const phoneLandscape = document.documentElement.classList.contains("phone-landscape-layout");
      if (!phoneLandscape && (window.visualViewport?.scale ?? 1) !== 1) return;
      const row = rowRef.current;
      if (!row) return;

      // Measure the painted ink of "LinkBot.Now" (left edge of the L to the
      // right edge of the W) rather than the layout box, which carries
      // letter-spacing slack on both ends.
      const characters = row.querySelectorAll<HTMLElement>(
        ".pr-brand-wordmark-link, .pr-brand-wordmark-bot, .pr-brand-suffix-character",
      );
      if (!characters.length) {
        setNameWidth(Math.round(row.offsetWidth));
        return;
      }

      let left = Infinity;
      let right = -Infinity;
      characters.forEach((node) => {
        const rect = node.getBoundingClientRect();
        if (rect.width === 0) return;
        left = Math.min(left, rect.left);
        right = Math.max(right, rect.right);
      });

      if (!Number.isFinite(left) || !Number.isFinite(right)) return;

      const rowRect = row.getBoundingClientRect();
      // Rects are post-zoom; convert back to layout pixels.
      const scale = row.offsetWidth > 0 ? rowRect.width / row.offsetWidth : 1;
      const safeScale = scale > 0 ? scale : 1;
      setNameOffset(Math.round(((left - rowRect.left) / safeScale) * 100) / 100);
      setNameWidth(Math.round(((right - left) / safeScale) * 100) / 100);
    };

    measure();
    if (typeof ResizeObserver !== "undefined" && rowRef.current) {
      observer = new ResizeObserver(measure);
      observer.observe(rowRef.current);
    }

    return () => {
      observer?.disconnect();
    };
  }, [showSuffix, suffixLanded]);

  return (
    <HoverlessLink
      to="/"
      aria-label="LinkBot home"
      className={cn("pr-brand-lockup", compact && "pr-brand-compact")}
    >
      <img src={logoAsset} alt="" className="pr-brand-logo" />
      <span className="pr-brand-copy">
        <span className="pr-brand-wordmark-row" ref={rowRef}>
          <span
            className={cn(
              "pr-brand-wordmark",
              armed && animateSuffix && "pr-brand-wordmark-armed",
            )}
            aria-hidden="true"
          >
            <span className="pr-brand-wordmark-link">Link</span><span className="pr-brand-wordmark-bot">Bot</span>
          </span>
          {showSuffix ? (
            <span
              className={cn(
                "pr-brand-suffix",
                armed && "pr-brand-suffix-armed",
                !animateSuffix && "pr-brand-suffix-static",
              )}
              aria-hidden="true"
            >
              {Array.from(".Now").map((character, index) => (
                <span
                  key={`suffix-${index}`}
                  className="pr-brand-suffix-character"
                  style={{ animationDelay: `${0.9 + index * 0.62}s` }}
                  onAnimationEnd={
                    index === 3 ? handleSuffixLanded : undefined
                  }
                >
                  {character}
                </span>
              ))}
            </span>
          ) : null}
          <span className="pr-brand-screen-reader">
            {showSuffix ? "LinkBot.Now" : "LinkBot"}
          </span>
        </span>
        <RotatingWords
          nameWidth={nameWidth}
          nameOffset={nameOffset}
          enabled={!showSuffix || (suffixLanded && nameWidth !== null)}
        />
      </span>
    </HoverlessLink>
  );
}
