import { useServerFn } from "@tanstack/react-start";
import { FooterLegalLink } from "@/components/legal/LegalModal";
import { FitLine } from "@/components/FitLine";
import { useEffect, useRef, useState } from "react";
import { useRevealWhenSettled } from "@/lib/boot-reveal";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { finishCheckoutPass, getWelcomeStatus } from "@/lib/welcome.functions";

type Phase = "loading" | "done" | "later";
const POLL_MS = 3000;
const GIVE_UP_MS = 60000;
// The loading state always shows for at least this long, even when the bot is
// already active — the bar fills over exactly this long too.
const MIN_LOAD_MS = 14000;

// Exactly the dead-end page's message style ($slug.ts .pending: 14px, #6b7280,
// normal weight, centered; font-family inherited from the app's --font-sans).
const pendingTextStyle = {
  color: "#6b7280",
  fontSize: "14px",
  fontWeight: 400,
  lineHeight: "normal",
} as const;

// Webmail inbox addresses for providers that have one. Any other provider
// shows the email in brand blue but not clickable.
const INBOX_LINKS: [RegExp, string][] = [
  [/^(gmail|googlemail)\.com$/, "https://mail.google.com/"],
  [/^(outlook|hotmail|live)\.[a-z.]+$|^(msn|passport)\.com$/, "https://outlook.live.com/mail/"],
  [/^(yahoo|ymail|rocketmail)\.[a-z.]+$/, "https://mail.yahoo.com/"],
  [/^(icloud|me|mac)\.com$/, "https://www.icloud.com/mail/"],
];

function inboxHref(email: string): string | null {
  const domain = email.split("@")[1]?.toLowerCase() ?? "";
  for (const [pattern, href] of INBOX_LINKS) if (pattern.test(domain)) return href;
  return null;
}

export function WelcomePage() {
  useRevealWhenSettled();
  const check = useServerFn(getWelcomeStatus);
  const [phase, setPhase] = useState<Phase>("loading");
  const [email, setEmail] = useState<string | null>(null);
  const footerRef = useRef<HTMLElement>(null);
  // Same footer treatment as /claim: on-screen height matches the header, gray top line.
  useFooterMatchHeader(footerRef, "rgb(173, 173, 173)");

  // The shared page frame is a little taller than the phone screen here; keep this page still.
  useEffect(() => {
    const els = [document.documentElement, document.body];
    const prev = els.map((el) => el.style.overflow);
    els.forEach((el) => (el.style.overflow = "hidden"));
    window.scrollTo(0, 0);
    return () => els.forEach((el, i) => (el.style.overflow = prev[i] ?? ""));
  }, []);

  useEffect(() => {
    let stopped = false;
    const started = Date.now();
    let timer: ReturnType<typeof setTimeout> | undefined;
    let minTimer: ReturnType<typeof setTimeout> | undefined;
    let activeSeen = false;
    const finishIfReady = () => {
      // Hold the loading state until the minimum load time has passed, even
      // when the account is already active.
      if (activeSeen && Date.now() - started >= MIN_LOAD_MS) return setPhase("done");
    };
    const tick = async () => {
      let state: string = "waiting";
      try {
        const result = await check();
        state = result.state;
        if (result.email) setEmail(result.email);
      } catch { /* keep waiting */ }
      if (stopped) return;
      // 185: "Almost ready" only after the give-up time since arriving here, never sooner.
      // 185C: no valid checkout pass — go straight back to the homepage.
      if (state === "signed_out") { window.location.replace("/"); return; }
      const elapsed = Date.now() - started;
      if (state === "active") {
        activeSeen = true;
        if (elapsed >= MIN_LOAD_MS) return setPhase("done");
        // Already active: re-check exactly at the 14-second mark.
        minTimer = setTimeout(finishIfReady, MIN_LOAD_MS - elapsed);
        return;
      }
      if (elapsed >= GIVE_UP_MS) return setPhase("later");
      timer = setTimeout(tick, Math.min(POLL_MS, Math.max(0, GIVE_UP_MS - elapsed)));
    };
    void tick();
    return () => {
      stopped = true;
      if (timer) clearTimeout(timer);
      if (minTimer) clearTimeout(minTimer);
    };
  }, [check]);

  // The moment "all set" shows, switch the checkout pass off; 14 seconds later go to /login.
  const finish = useServerFn(finishCheckoutPass);
  useEffect(() => {
    if (phase !== "done") return;
    void finish().catch(() => {});
    for (const key of ["linkbot-claim-contact", "linkbot-claim-order", "linkbot.claim.ghlVisited", "linkbot.claim.voiceSent"]) {
      try { window.sessionStorage.removeItem(key); } catch { /* storage unavailable */ }
    }
    const t = setTimeout(() => window.location.assign("/login"), MIN_LOAD_MS);
    return () => clearTimeout(t);
  }, [phase, finish]);

  return (
    <div
      className="welcome-page-root flex flex-col overflow-hidden bg-surface"
      style={{ height: "calc(100dvh - var(--site-header-height, 80px))" }}
    >
      <main className="flex min-h-0 flex-1 flex-col items-center justify-center overflow-hidden px-6 text-center">
        {phase === "loading" ? (
          <>
            <FitLine style={pendingTextStyle}>Welcome to the LinkBot family...</FitLine>
            <FitLine className="mt-2" style={pendingTextStyle}>Setting up your account now. Please wait.</FitLine>
            {/* Same loading bar as the homepage live demo form's submit button
                while the demo is being created (same classes and animation). */}
            <div
              role="status"
              aria-label="Loading"
              className="linkbot-button mobile-home-cta-native building-agent-button mt-6 h-11 w-full max-w-[300px] text-xs"
              style={{ cursor: "default" }}
            >
              {/* Same bar and fill style as the homepage, stretched to fill
                  over exactly 14 seconds (MIN_LOAD_MS) on this page only. */}
              <span
                className="building-agent-progress"
                aria-hidden
                style={{ animationDuration: `${MIN_LOAD_MS}ms` }}
              >
                <span className="building-agent-swirl" />
                <span className="building-agent-swirl building-agent-swirl-two" />
              </span>
              <span className="building-agent-label">BUILDING YOUR AGENT</span>
            </div>
          </>
        ) : phase === "done" ? (
          <>
            <FitLine style={pendingTextStyle}>You're all set!</FitLine>
            <FitLine className="mt-2" style={pendingTextStyle}>
              Your welcome email was sent to{" "}
              {(() => {
                const shown = email ?? "your email";
                const href = email ? inboxHref(email) : null;
                return href ? (
                  <button
                    type="button"
                    onClick={() => window.open(href, "_blank", "noopener,noreferrer")}
                    style={{ ...pendingTextStyle, fontSize: "inherit", color: "var(--brand)", fontWeight: 700, cursor: "pointer", display: "inline" }}
                  >
                    {shown}
                  </button>
                ) : (
                  <span style={email ? { ...pendingTextStyle, fontSize: "inherit", color: "var(--brand)", fontWeight: 700 } : undefined}>
                    {shown}
                  </span>
                );
              })()}.
            </FitLine>
            <FitLine className="mt-2" style={pendingTextStyle}>
              Access your LinkBot Link with the next steps on how to set it up there.
            </FitLine>
          </>
        ) : (
          <>
            <FitLine className="mt-6" style={pendingTextStyle}>Almost ready... No need to wait!</FitLine>
            <FitLine className="mt-2" style={pendingTextStyle}>We'll email you as soon as your account is set up.</FitLine>
          </>
        )}
      </main>
      <footer ref={footerRef} className="demo-form-footer site-footer-balanced night-panel px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted">
        <p>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>
    </div>
  );
}
