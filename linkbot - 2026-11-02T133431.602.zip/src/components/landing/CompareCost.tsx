import { useEffect, useRef, useState } from "react";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

// Prompt 309: Compare the Cost chart, built exactly from the 309 design code.
// Desktop/iPad are authored at the 1440px design width and scaled as one piece
// by one fixed CSS factor (.cc-frame zoom, container-query math) so the outer
// width equals the previous chart's outer width — verified to the pixel at
// 1280/768/1024. Nothing is measured, calculated or resized while scrolling or
// after the page loads. Phones are authored at the 358px design width and
// scaled as one piece to the previous chart's 1168px canvas width.

function useLinkBotScrollPulse() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    if (!container) return;
    const card = container.firstElementChild;
    if (!(card instanceof HTMLElement)) return;

    let scrollingDown = false;
    let armed = true;
    let windowPosition = window.scrollY;
    const positions = new WeakMap<Element, number>();
    let animation: Animation | undefined;

    const onScroll = (event: Event) => {
      if (event.target instanceof Element) {
        const position = event.target.scrollTop;
        const previous = positions.get(event.target) ?? 0;
        if (position !== previous) scrollingDown = position > previous;
        positions.set(event.target, position);
      } else {
        const position = window.scrollY;
        if (position !== windowPosition) scrollingDown = position > windowPosition;
        windowPosition = position;
      }
    };

    const observer = new IntersectionObserver(([entry]) => {
      if (!entry) return;
      if (!entry.isIntersecting) {
        if (!scrollingDown) armed = true;
        return;
      }
      if (!scrollingDown) {
        armed = false;
        return;
      }
      if (!armed) return;
      armed = false;
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      animation?.cancel();
      // Same 1.04 peak scale as the site's existing blue-action pulse.
      animation = card.animate(
        [
          { transform: "scale(1)" },
          { transform: "scale(1.04)" },
          { transform: "scale(1)" },
          { transform: "scale(1.04)" },
          { transform: "scale(1)" },
        ],
        { duration: 1000, easing: "ease-in-out" },
      );
    }, { rootMargin: "0px 0px -10% 0px" });

    window.addEventListener("scroll", onScroll, { capture: true, passive: true });
    observer.observe(container);
    return () => {
      window.removeEventListener("scroll", onScroll, true);
      observer.disconnect();
      animation?.cancel();
    };
  }, []);

  return ref;
}

/** Desktop and iPad: one wide chart at the 309 design size. */
export function CompareCostDesktop() {
  const linkBotRef = useLinkBotScrollPulse();
  const [firstCompetitor, setFirstCompetitor] = useState(0);
  const competitorSlot = (index: number) => (index - firstCompetitor + 4) % 4;
  return (
    <div className="compare-cost mx-auto max-w-6xl px-6 pb-24">
      <div className="cc-frame">
        <div className="cc-nav">
          <Button variant="outline-night" size="icon" aria-label="Next competitors" title="Next competitors" onClick={() => setFirstCompetitor((current) => (current + 1) % 4)}><ChevronRight /></Button>
        </div>
        <div className="cc-grid">
          <div className="cc-labels">
            <div className="cc-title">Compare<br />The Cost</div>
            <div className="cc-lbl">Talk Time</div>
            <div className="cc-lbl">Monthly Price</div>
            <div className="cc-lbl">Cost Per Hour</div>
          </div>

          <div className="cc-pulse-slot" ref={linkBotRef}>
          <div className="cc-card cc-lk">
            <div className="cc-ban">
              <div className="cc-name">LinkBot</div>
              <div className="cc-price"><span className="s">$</span>359</div>

              <div className="cc-unit">Per Month</div>
            </div>
            <div className="cc-cell">Unlimited Minutes</div>
            <div className="cc-cell">$359 Flat Rate</div>
            <div className="cc-cell">Fixed</div>
            <div></div>
          </div>
          </div>

          <div className="cc-card cc-competitor" data-slot={competitorSlot(2)}>
            <div className="cc-ban">
              <div className="cc-name">Bland</div>
              <div className="cc-price"><span className="s">$</span>779</div>
              <div className="cc-unit">Per Month</div>
            </div>
            <div className="cc-cell">Per Minute</div>
            <div className="cc-cell">$299 + Minutes</div>
            <div className="cc-cell">$11.68</div>
          </div>

          <div className="cc-card cc-competitor" data-slot={competitorSlot(3)}>
            <div className="cc-ban">
              <div className="cc-name">Retell</div>
              <div className="cc-price"><span className="s">$</span>600</div>
              <div className="cc-unit">Per Month</div>
            </div>
            <div className="cc-cell">Per Minute</div>
            <div className="cc-cell">Minutes</div>
            <div className="cc-cell">$9.00</div>
          </div>

          <div className="cc-card cc-competitor" data-slot={competitorSlot(1)}>

            <div className="cc-ban">
              <div className="cc-name">Vapi</div>
              <div className="cc-price"><span className="s">$</span>654</div>
              <div className="cc-unit">Per Month</div>
            </div>
            <div className="cc-cell">Per Minute</div>
            <div className="cc-cell">Plan + Minutes + Lines</div>
            <div className="cc-cell">$9.81</div>
          </div>

          <div className="cc-card cc-competitor" data-slot={competitorSlot(0)}>

            <div className="cc-ban">
              <div className="cc-name">ElevenLabs</div>
              <div className="cc-price rng"><span className="s">$</span><span className="k4">409</span><span className="d">–</span><span className="s">$</span>990</div>
              <div className="cc-unit">Per Month</div>
            </div>
            <div className="cc-cell">Plan + Per Minute</div>
            <div className="cc-cell">Plan + Pay As You Go</div>
            <div className="cc-cell">$6.14–$14.85</div>
          </div>
        </div>
        <div className="cc-foot">
          <div className="cc-m">All Rates Include Latest AI Models + 20 Talk Lines + 4,000 Minutes A Month (Approximately 2 Hours A Day)</div>
          <div className="cc-f">Pricing As Of 2026, From Each Company&apos;s Published Rates.</div>
        </div>
      </div>
    </div>
  );
}

/** Phones: stacked version at the 358px 309 design size, scaled as one piece. */
export function CompareCostPhoneContent() {
  const linkBotRef = useLinkBotScrollPulse();
  return (
    <div className="ccp-frame">
      <div className="ccp-scale">
        <div className="ccp">
          <div className="ccp-title">Compare The Cost</div>

          <div className="ccp-card">
            <div className="ccp-ban">
              <div className="ccp-name">ElevenLabs</div>
              <div className="ccp-price"><span className="s">$</span>409<span className="d">–</span><span className="s">$</span>990</div>
              <div className="ccp-unit">Per Month</div>
            </div>
            <div className="ccp-row"><span className="ccp-l">Talk Time</span><span className="ccp-v">Plan + Per Minute</span></div>
            <div className="ccp-row"><span className="ccp-l">Monthly Price</span><span className="ccp-v">Plan + Pay As You Go</span></div>
            <div className="ccp-row"><span className="ccp-l">Cost Per Hour</span><span className="ccp-v">$6.14–$14.85</span></div>
          </div>

          <div className="ccp-card">
            <div className="ccp-ban">
              <div className="ccp-name">Vapi</div>
              <div className="ccp-price"><span className="s">$</span>654</div>
              <div className="ccp-unit">Per Month</div>
            </div>
            <div className="ccp-row"><span className="ccp-l">Talk Time</span><span className="ccp-v">Per Minute</span></div>
            <div className="ccp-row"><span className="ccp-l">Monthly Price</span><span className="ccp-v">Plan + Minutes + Lines</span></div>
            <div className="ccp-row"><span className="ccp-l">Cost Per Hour</span><span className="ccp-v">$9.81</span></div>
          </div>

          <div className="ccp-card">
            <div className="ccp-ban">
              <div className="ccp-name">Retell</div>
              <div className="ccp-price"><span className="s">$</span>600</div>
              <div className="ccp-unit">Per Month</div>
            </div>
            <div className="ccp-row"><span className="ccp-l">Talk Time</span><span className="ccp-v">Per Minute</span></div>
            <div className="ccp-row"><span className="ccp-l">Monthly Price</span><span className="ccp-v">Minutes</span></div>
            <div className="ccp-row"><span className="ccp-l">Cost Per Hour</span><span className="ccp-v">$9.00</span></div>
          </div>

          <div className="ccp-card">
            <div className="ccp-ban">
              <div className="ccp-name">Bland</div>
              <div className="ccp-price"><span className="s">$</span>779</div>
              <div className="ccp-unit">Per Month</div>
            </div>
            <div className="ccp-row"><span className="ccp-l">Talk Time</span><span className="ccp-v">Per Minute</span></div>
            <div className="ccp-row"><span className="ccp-l">Monthly Price</span><span className="ccp-v">$299 + Minutes</span></div>
            <div className="ccp-row"><span className="ccp-l">Cost Per Hour</span><span className="ccp-v">$11.68</span></div>
          </div>

          <div className="ccp-pulse-slot" ref={linkBotRef}>
          <div className="ccp-card ccp-lk">
            <div className="ccp-ban">
              <div className="ccp-name">LinkBot</div>
              <div className="ccp-price"><span className="s">$</span><span className="lk-d">359</span></div>
              <div className="ccp-unit">Per Month</div>
            </div>
            <div className="ccp-row"><span className="ccp-l">Talk Time</span><span className="ccp-v">Unlimited Minutes</span></div>
            <div className="ccp-row"><span className="ccp-l">Monthly Price</span><span className="ccp-v">$359 Flat Rate</span></div>
            <div className="ccp-row"><span className="ccp-l">Cost Per Hour</span><span className="ccp-v">Fixed</span></div>
          </div>
          </div>

          <div className="ccp-foot">
            <div className="ccp-m">All Rates Include Latest AI Models + 20 Talk Lines 
+ 4,000 Minutes A Month (Approximately 2 Hours A Day)</div>
            <div className="ccp-f">Pricing As Of 2026, From Each Company&apos;s Published Rates.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
