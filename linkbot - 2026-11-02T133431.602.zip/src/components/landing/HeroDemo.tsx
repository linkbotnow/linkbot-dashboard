import { claimBackGap, headerBottom } from "@/lib/back-button-top";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { submitDemoRequest } from "@/lib/demo.functions";
import { ArrowRight, Linkedin, Mic, PhoneOff, Signal, Wifi } from "lucide-react";
import profilePhoto from "@/assets/linkedin-profile.jpg";
import { Button } from "@/components/ui/button";
import { storeClaimContact } from "@/lib/claim-slug";
import { PHONE_COUNTRIES, parsePhone, type PhoneCountry } from "@/lib/phone-countries";
import { cn } from "@/lib/utils";
import { getDesktopScale, isPhoneLandscapeViewport } from "@/lib/desktop-scale";
import { isHeroZoomPaused, pausableInterval, pausableTimeout } from "@/lib/hero-pause";

const DEMO_FORM_DRAFT_KEY = "linkbot:demo-form-draft";

const CTA_CLASSES = "linkbot-button";

const FEATURE_BUBBLES = ["Instant Answers", "Personal Guidance", "Direct Access Links", "Book On Calendar", "Let's Collaborate", "Apply For A Job"] as const;

export const DEMO_LEADS = [
  {
    name: "Jamie Smith",
    email: "jamie@smithconsulting.com",
    company: "Smith Consulting",
    whatTheyDo: "Runs a 5-person consulting firm",
    linksShared: "Starter Offer, Premium Offer",
    summary: "Wants help bringing in more clients and compared the starter and premium offers side by side, asking what each one includes.",
    interest: "Business Services",
  },
  {
    name: "Maria Lopez",
    email: "maria.lopez@gmail.com",
    company: "Lopez Marketing",
    whatTheyDo: "Longtime weekly client",
    linksShared: "This Week's Update, Video",
    summary: "Called in for this week's update and had it walked through step by step. Now really interested in upgrading to the premium offer.",
    interest: "Premium Upgrade",
  },
  {
    name: "Ethan Brooks",
    email: "ethan.brooks@outlook.com",
    company: "Northline Projects",
    whatTheyDo: "Experienced project manager",
    linksShared: "Our Website, Portfolio",
    summary: "Asked about open roles, remote options, and the hiring process. Shared his background and would like his résumé passed along for review.",
    interest: "Job Inquiry",
  },
  {
    name: "Dana Whitlock",
    email: "dana@whitlockpartners.com",
    company: "Whitlock Partners",
    whatTheyDo: "Runs a networking group",
    linksShared: "Podcast Episode, Free Download",
    summary: "Interested in a referral partnership and in having the owner speak at an upcoming event. Asked how referrals are tracked and rewarded.",
    interest: "Partnership",
  },
] as const;

type DemoLead = (typeof DEMO_LEADS)[number];

/** 4L27: shared inside of the hero lead card and its flying copy. The outer card keeps its size. */
function LeadCardContent({ lead }: { lead: DemoLead }) {
  const row = (label: string, value: string, link = false) => (
    <span className="lead-fit-row block text-[11px] leading-[1.35]">
      <span className="font-bold text-muted-foreground">{label}</span>{" "}
      <span className={cn("whitespace-nowrap font-semibold", link ? "lead-contact-text text-brand underline decoration-brand/70 underline-offset-2" : "text-ink")}>{value}</span>
    </span>
  );
  return (
    <>
      <span className="flex items-center justify-between border-b border-border bg-surface-2 px-5 py-3">
        <span className="block text-sm font-extrabold text-ink">LinkBot New Lead</span>
        <span className="inline-flex items-center gap-2 text-[11px] font-bold text-call"><span className="h-2 w-2 rounded-full bg-call" />New Lead</span>
      </span>
      <span className="hero-lead-body flex min-h-0 flex-1 flex-col justify-evenly px-5">
        <span className="block">
          <span className="block text-[10px] font-black uppercase tracking-[0.18em] text-brand">PROSPECT INFO</span>
          <span className="mt-2 flex flex-col gap-1">
            {row("Name:", lead.name)}
            {row("Email:", lead.email, true)}
            {row("Company:", lead.company)}
            {row("What They Do:", lead.whatTheyDo)}
            {row("Links Shared:", lead.linksShared)}
          </span>
        </span>
        <span className="block">
          <span className="block text-[10px] font-black uppercase tracking-[0.18em] text-brand">CONVERSATION SUMMARY</span>
          <span className="hero-lead-summary mt-2 block text-[11px] leading-[1.35] text-ink-soft">{lead.summary}</span>
        </span>
        <span className="flex items-end justify-between border-t border-border pt-4">
          <span className="block">
            <span className="block text-[10px] font-black uppercase tracking-[0.18em] text-brand">INTEREST</span>
            <span className="mt-1 block whitespace-nowrap text-xs font-extrabold">{lead.interest}</span>
          </span>
          <span className="inline-flex items-center justify-center whitespace-nowrap rounded-md bg-brand px-2.5 py-1.5 text-[11px] font-extrabold text-brand-foreground shadow-sm">
            Send follow-up email
          </span>
        </span>
      </span>
    </>
  );
}

/** Shrinks only a row that would not fit on one line (same step loop as the call-screen name fit). */
function fitLeadRows(root: HTMLElement | null) {
  root?.querySelectorAll<HTMLElement>(".lead-fit-row").forEach((r) => {
    r.style.fontSize = "";
    let f = parseFloat(getComputedStyle(r).fontSize) || 11;
    while (r.scrollWidth > r.clientWidth + 0.5 && f > 6) { f -= 0.25; r.style.fontSize = f + "px"; }
  });
}

export function DemoStage({ demoPublicUrl, onOpenForm, pulse, artLayer }: { demoPublicUrl: string | null; onOpenForm: () => void; pulse?: boolean; artLayer?: HTMLElement | null }) {
  const [phoneStep, setPhoneStep] = useState(0);
  const [setupStep, setSetupStep] = useState(0);
  const [leadIndex, setLeadIndex] = useState(0);
  const [cardKey, setCardKey] = useState(0);
  const [flight, setFlight] = useState<{ x: number; y: number; dx: number; dy: number } | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const phoneRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const flightTimer = useRef<(() => void) | null>(null);
  // 264: upright-phone first hero only. The phone mockup, lead card and flying
  // card are drawn in artLayer (outside the shared 0.9244 / 1.25*S / 1.68
  // wrappers) with one combined scale; same-size spacers keep the layout.
  const sep = !!artLayer;
  const phoneSpaceRef = useRef<HTMLDivElement>(null);
  const cardSpaceRef = useRef<HTMLDivElement>(null);
  const phonePieceRef = useRef<HTMLDivElement>(null);
  const cardPieceRef = useRef<HTMLDivElement>(null);
  const flightPieceRef = useRef<HTMLDivElement>(null);
  const art = (piece: "phone" | "card" | "flight", node: ReactNode) => {
    if (!artLayer) return node;
    const ref = piece === "phone" ? phonePieceRef : piece === "card" ? cardPieceRef : flightPieceRef;
    return createPortal(
      <div ref={ref} className="hero-demo-scale mh-art-piece" data-art-piece={piece}>
        {piece === "card" ? <div className="hero-lead-column mh-art-col">{node}</div> : node}
      </div>,
      artLayer,
    );
  };
  const lead = DEMO_LEADS[leadIndex] ?? DEMO_LEADS[0]!;
  const nextLead = DEMO_LEADS[(leadIndex + 1) % DEMO_LEADS.length] ?? DEMO_LEADS[0]!;

  useLayoutEffect(() => {
    fitLeadRows(cardRef.current);
  }, [lead, cardKey]);

  useLayoutEffect(() => {
    const host = artLayer;
    if (!host) return;
    const place = () => {
      if (window.visualViewport && Math.abs(window.visualViewport.scale - 1) > 0.001) return;
      const stage = stageRef.current, phone = phoneRef.current, card = cardRef.current;
      const ps = phoneSpaceRef.current, cs = cardSpaceRef.current;
      const pp = phonePieceRef.current, cp = cardPieceRef.current, fp = flightPieceRef.current;
      if (!stage || !phone || !card || !ps || !cs || !pp || !cp || !fp) return;
      ps.style.width = `${phone.offsetWidth}px`;
      ps.style.height = `${phone.offsetHeight}px`;
      cs.style.height = `${card.offsetHeight}px`;
      const hr = host.getBoundingClientRect();
      const hs = host.offsetWidth ? hr.width / host.offsetWidth : 1;
      const at = (piece: HTMLElement, target: HTMLElement) => {
        const r = target.getBoundingClientRect();
        piece.style.left = `${(r.left - hr.left) / hs}px`;
        piece.style.top = `${(r.top - hr.top) / hs}px`;
      };
      cp.style.width = `${cs.offsetWidth}px`;
      fp.style.width = `${stage.offsetWidth}px`;
      fp.style.height = `${stage.offsetHeight}px`;
      at(pp, ps);
      at(cp, cs);
      at(fp, stage);
    };
    place();
    const ro = new ResizeObserver(place);
    [stageRef.current, phoneRef.current, cardRef.current, host].forEach((el) => el && ro.observe(el));
    window.addEventListener("resize", place);
    document.fonts?.ready.then(place).catch(() => {});
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", place);
    };
  }, [artLayer, cardKey]);

  const launchLead = (onLanded?: () => void) => {
    const stage = stageRef.current;
    const phone = phoneRef.current;
    const card = cardRef.current;
    if (!stage || !phone || !card) {
      onLanded?.();
      return;
    }
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setLeadIndex((i) => (i + 1) % DEMO_LEADS.length);
      setCardKey((k) => k + 1);
      onLanded?.();
      return;
    }
    const s = stage.getBoundingClientRect();
    const scale = s.width && stage.offsetWidth ? s.width / stage.offsetWidth : 1;
    const p = phone.getBoundingClientRect();
    const c = card.getBoundingClientRect();
    const x = (p.left - s.left + p.width / 2) / scale;
    const y = (p.top - s.top + p.height / 2) / scale;
    const tx = (c.left - s.left + c.width / 2) / scale;
    const ty = (c.top - s.top + c.height / 2) / scale;
    setFlight({ x, y, dx: tx - x, dy: ty - y });
    flightTimer.current?.();
    flightTimer.current = pausableTimeout(() => {
      setLeadIndex((i) => (i + 1) % DEMO_LEADS.length);
      setCardKey((k) => k + 1);
      setFlight(null);
      flightTimer.current = pausableTimeout(() => {
        onLanded?.();
      }, 2500);
    }, 1500);
  };

  useEffect(() => () => { flightTimer.current?.(); }, []);

  useEffect(() => {
    if (phoneStep === 3) return;
    const durations = [1700, 2100, 2500, 4200];
    return pausableTimeout(() => {
      setPhoneStep((current) => (current + 1) % 4);
    }, durations[phoneStep] ?? 3200);
  }, [phoneStep]);

  useEffect(() => pausableTimeout(() => setSetupStep((current) => (current + 1) % 4), 5500), [setupStep]);

  const setupSteps = [
    { title: "Start your free demo:", body: "Easy and simple! Click the button below to start creating your Custom LinkedIn AI Voice Employee." },
    { title: "Fill out our form:", body: "All we need is your name, email, company info and website to start cooking up your custom agent." },
    { title: "Test it out:", body: "Test drive your next employee before you hire it! Ask it anything about your company and see how it responds." },
    { title: "Buy and start:", body: <>Add your links. Paste your custom domain into your LinkedIn. Then you<br className="hero-step-break" />{" are done and ready for business!"}</> },
  ];
  const activeSetupStep = setupSteps[setupStep];

  return (
    <div id="live-demo" className="mx-auto mt-10 max-w-4xl scroll-mt-20 max-sm:mt-12 max-sm:w-full max-sm:max-w-none">
      <div className="mx-auto mb-7 grid max-w-3xl grid-cols-4 overflow-hidden rounded-lg border border-night-border bg-dark-card max-sm:mb-12 max-sm:w-[90%] max-sm:max-w-none" style={{ backgroundColor: '#000' }}>
        {setupSteps.map((item, index) => (
          <button
            key={item.title}
            type="button"
            onClick={() => setSetupStep(index)}
            className={`relative min-h-16 border-night-border px-3 py-3 text-center transition-colors max-sm:min-h-[7rem] max-sm:px-1 max-sm:py-3 ${index > 0 ? "border-l" : ""} ${setupStep === index ? "setup-step-active z-10 bg-brand text-brand-foreground" : "text-night-foreground hover:bg-surface/10"}`}
            aria-pressed={setupStep === index}
          >
            <span className={`block whitespace-nowrap text-[10px] font-black uppercase max-sm:text-[1.5rem] max-sm:leading-none ${setupStep === index ? "text-brand-foreground" : "text-brand"}`}>Step {index + 1}</span>
            <span className="mt-1 block whitespace-nowrap text-sm font-bold max-sm:mt-3 max-sm:text-[1.55rem] max-sm:leading-none">{index === 0 ? "Start Demo" : index === 1 ? "Basic Info" : index === 2 ? "Instant Demo" : "Working Employee"}</span>
          </button>
        ))}
      </div>

      <div className="hero-demo-scale mx-auto w-fit">
        <div ref={stageRef} className="relative grid grid-cols-[316px_300px] items-start justify-center gap-7 max-sm:gap-2">
          {art("flight", flight ? (
            <span
              className="lead-flight"
              aria-hidden="true"
              style={{
                left: `${flight.x}px`,
                top: `${flight.y}px`,
                ["--lead-dx" as string]: `${flight.dx}px`,
                ["--lead-dy" as string]: `${flight.dy}px`,
              }}
            >
              <span className="lead-flight__inner">
                <span className="lead-flight__card">
                  <span ref={(n) => fitLeadRows(n)} className="lead-card-fixed flex flex-col overflow-hidden rounded-2xl border border-night-border bg-surface text-left text-ink shadow-elev-3">
                    <LeadCardContent lead={nextLead} />
                  </span>
                </span>
              </span>
            </span>
          ) : null)}
          {sep && <div ref={phoneSpaceRef} className="mx-auto" aria-hidden="true" />}
          {art("phone", <div ref={phoneRef} className="mx-auto">
             <PhoneDemo step={phoneStep} demoPublicUrl={demoPublicUrl} onStart={() => setPhoneStep(3)} onEnd={() => { launchLead(() => {
               setPhoneStep(0);
               if (!window.matchMedia("(max-width: 639px)").matches) setSetupStep(0);
             }); }} />
          </div>)}
          <div className="hero-lead-column mx-0 w-full max-w-[300px] pt-2.5">
            <div className="site-motion-card mb-4 rounded-lg border border-night-border bg-black p-5 text-left text-night-foreground">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand">Step {setupStep + 1} of 4</p>
              <h2 className="mt-2 text-lg font-extrabold">{activeSetupStep?.title}</h2>
              <p className="mt-2 text-sm leading-6 text-night-muted">{activeSetupStep?.body}</p>
            </div>
            <button type="button" onClick={onOpenForm} className={cn(CTA_CLASSES, "w-full max-sm:text-[21px] hero-demo-cta-mobile", pulse && "demo-attention-pulse")}><span className="flex items-center gap-2">Start My Free Live Demo <ArrowRight className="h-4 w-4" /></span></button>

            {sep && <div ref={cardSpaceRef} className="mh-art-space" aria-hidden="true" />}
            {art("card", <div
              ref={cardRef}
              key={cardKey}
              className={cn(
                "lead-card-fixed mt-4 flex flex-col overflow-hidden rounded-2xl border border-night-border bg-surface text-left text-ink shadow-elev-3",
                cardKey > 0 && "lead-card-materialize",
              )}
              aria-label="Example lead activity record"
            >
              <LeadCardContent lead={lead} />
            </div>)}
          </div>
        </div>
      </div>
    </div>
  );
}

export function maxDigitsFor(country: PhoneCountry) {
  return country.na ? 10 : 15;
}

export function isValidPhone(digits: string, country: PhoneCountry) {
  return country.na ? digits.length === 10 : digits.length >= 6 && digits.length <= 15;
}

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
export const WEBSITE_RE = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d{1,5})?(?:[/?#].*)?$/i;

/** Country calling-code dropdown shown inside the phone box (demo form and /claim). */
export function PhoneCountryPicker({ country, onSelect, unscaledPhone = false }: { country: PhoneCountry; onSelect: (c: PhoneCountry) => void; /** Real-size phone pages (not the scaled homepage canvas) drop the phone enlargements. */ unscaledPhone?: boolean }) {
  const [countryOpen, setCountryOpen] = useState(false);
  const [countryQuery, setCountryQuery] = useState("");
  const filteredCountries = PHONE_COUNTRIES.filter((c) =>
    countryQuery.trim() === ""
      ? true
      : c.name.toLowerCase().includes(countryQuery.trim().toLowerCase()) ||
        c.dial.includes(countryQuery.trim()),
  );
  const m = (cls: string) => (unscaledPhone ? cls.split(" ").filter((t) => !t.startsWith("max-sm:")).join(" ") : cls);
  return (
            <div className="relative shrink-0">
              <button
                type="button"
                aria-label="Country calling code"
                aria-haspopup="listbox"
                aria-expanded={countryOpen}
                onClick={() => {
                  setCountryOpen((v) => !v);
                  setCountryQuery("");
                }}
                className="flex h-12 w-20 items-center justify-center gap-1 rounded-xl border border-border bg-surface px-2 text-base font-semibold text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
              >
                <span>{country.short}</span>
                <svg viewBox="0 0 12 8" aria-hidden="true" className="h-[0.4em] w-[0.6em] shrink-0">
                  <path d="M1 1.5 6 6.5l5-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {countryOpen && (
                <div className={m("absolute left-0 top-[calc(100%+0.35rem)] z-30 w-64 overflow-hidden rounded-xl border border-border bg-surface text-left text-base shadow-elev-3 max-sm:w-[42rem] max-sm:rounded-[2rem] max-sm:text-[2.4rem]")}>
                  <div className={m("border-b border-border p-2 max-sm:p-6")}>
                    <input
                      autoFocus
                      value={countryQuery}
                      onChange={(e) => setCountryQuery(e.target.value)}
                      placeholder="Search country"
                      aria-label="Search country"
                      className={m("h-9 w-full rounded-lg border border-border bg-surface px-2 text-sm text-ink placeholder:text-muted focus:border-brand focus:outline-none max-sm:h-24 max-sm:rounded-[1.25rem] max-sm:px-5 max-sm:text-[2.2rem]")}
                    />
                  </div>
                  <ul role="listbox" className={m("max-h-64 overflow-auto py-1 max-sm:max-h-[44rem]")}>
                    {filteredCountries.map((c) => (
                      <li key={c.code}>
                        <button
                          type="button"
                          role="option"
                          aria-selected={c.code === country.code}
                          onClick={() => {
                            onSelect(c);
                            setCountryOpen(false);
                            setCountryQuery("");
                          }}
                          className={cn(m("block w-full px-3 py-2 text-left text-ink hover:bg-brand/10 max-sm:px-8 max-sm:py-5"), c.code === country.code && "font-semibold")}
                        >
                          {c.label}
                        </button>
                      </li>
                    ))}
                    {filteredCountries.length === 0 && (
                      <li className={m("px-3 py-2 text-muted max-sm:px-8 max-sm:py-5")}>No match</li>
                    )}
                  </ul>
                </div>
              )}
            </div>
  );
}

/** 456: drop one leading trunk 0 for non-North-American countries (except IT, SM, VA) before the country code. */
export function sendablePhone(display: string, country: PhoneCountry) {
  if (country.na || ["IT", "SM", "VA"].includes(country.code)) return display;
  return display.replace(/^(\D*)0/, "$1");
}

export function formatPhone(digits: string, country: PhoneCountry) {
  if (country.na) {
    const a = digits.slice(0, 3);
    const b = digits.slice(3, 6);
    const c = digits.slice(6, 10);
    if (digits.length > 6) return `(${a}) ${b}-${c}`;
    if (digits.length > 3) return `(${a}) ${b}`;
    if (digits.length > 0) return `(${a}`;
    return "";
  }
  return digits.replace(/(\d{3})(?=\d)/g, "$1 ").trim();
}

export type DemoFieldName = "firstName" | "lastName" | "email" | "phone" | "companyName" | "website";

const cleanWebsite = (v: string) => {
  let s = v;
  if (/^www\./i.test(s) && /^(https?:\/\/|www\.)/i.test(s.slice(4))) s = s.slice(4);
  return s.replace(/^https?:\/\//i, "");
};
const caretEndIfWww = (e: { currentTarget: HTMLInputElement }) => {
  const el = e.currentTarget;
  if (el.value === "www.") requestAnimationFrame(() => el.setSelectionRange(4, 4));
};

export function DemoRequestForm({ onBack, onComplete }: { onBack: () => void; onComplete: (companyName: string) => void }) {
  const websiteInputRef = useRef<HTMLInputElement>(null);
  const submit = useServerFn(submitDemoRequest);
  const [values, setValues] = useState<Record<DemoFieldName, string>>(() => {
    const empty = { firstName: "", lastName: "", email: "", phone: "", companyName: "", website: "" };
    try {
      const raw = window.sessionStorage.getItem(DEMO_FORM_DRAFT_KEY);
      const saved = raw ? JSON.parse(raw) : null;
      return saved?.values ? { ...empty, ...saved.values } : empty;
    } catch { return empty; }
  });
  const [country, setCountry] = useState<PhoneCountry>(() => {
    try {
      const raw = window.sessionStorage.getItem(DEMO_FORM_DRAFT_KEY);
      const saved = raw ? JSON.parse(raw) : null;
      const found = saved?.country ? PHONE_COUNTRIES.find((c) => c.short === saved.country.short && c.dial === saved.country.dial) : undefined;
      return found ?? PHONE_COUNTRIES[0]!;
    } catch { return PHONE_COUNTRIES[0]!; }
  });
  const [consent, setConsent] = useState(() => {
    try {
      const raw = window.sessionStorage.getItem(DEMO_FORM_DRAFT_KEY);
      return Boolean(raw && JSON.parse(raw)?.consent);
    } catch { return false; }
  });
  useEffect(() => {
    try {
      window.sessionStorage.setItem(
        DEMO_FORM_DRAFT_KEY,
        JSON.stringify({ values, country: { short: country.short, dial: country.dial }, consent }),
      );
    } catch { /* private mode */ }
  }, [values, country, consent]);
  const [touched, setTouched] = useState<Partial<Record<DemoFieldName, boolean>>>({});
  const [status, setStatus] = useState<"idle" | "sending">("idle");
  // Bot protection: hidden trap field, server email check,
  // and (strict mode only) an emailed 6-digit code.
  const [trap, setTrap] = useState("");
  const [emailServerError, setEmailServerError] = useState(false);
  // 171D: the email value the server's real-email check rejected. Repeated
  // Launch clicks with this exact, well-formed email pulse the error.
  const emailBadAtRef = useRef<string | null>(null);
  const [emailPulse, setEmailPulse] = useState(0);
  // 461: second Launch with in-box errors still showing replays the word pulse.
  const [errorPulse, setErrorPulse] = useState(0);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState(false);
  const [requestError, setRequestError] = useState(false);

  const phoneDigits = values.phone.replace(/\D/g, "");
  const mountedRef = useRef(false);
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const fieldErrors: Partial<Record<DemoFieldName, string>> = {};
  if (!values.firstName.trim()) fieldErrors.firstName = "Invalid first name";
  if (!values.lastName.trim()) fieldErrors.lastName = "Invalid last name";
  if (!EMAIL_RE.test(values.email.trim()) || emailServerError) fieldErrors.email = "Invalid email";
  if (!isValidPhone(phoneDigits, country)) fieldErrors.phone = "Invalid phone number";
  if (!values.companyName.trim()) fieldErrors.companyName = "Invalid company name";
  const fullWebsite = values.website.trim();
  if (fullWebsite.toLowerCase() === "www." || !WEBSITE_RE.test(fullWebsite)) fieldErrors.website = "Invalid website";
  const isValid = Object.keys(fieldErrors).length === 0;

  const setField = (name: DemoFieldName, raw: string) => {
    setTouched({});
    setErrorPulse(0);
    if (name === "email") { setEmailServerError(false); setEmailPulse(0); }
    if (pendingId) {
      setPendingId(null);
      setCode("");
      setCodeError(false);
    }
    if (name === "phone") {
      const parsed = parsePhone(raw, country);
      if (parsed.country !== country) setCountry(parsed.country);
      setValues((prev) => ({ ...prev, phone: formatPhone(parsed.digits, parsed.country) }));
      return;
    }
    setValues((prev) => ({ ...prev, [name]: raw }));
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    // 171D: repeat click on Launch with the same well-formed email the server
    // already rejected → pulse the "Invalid email" error. Never for empty or
    // badly formatted emails (server flag is cleared on any email change).
    if (emailServerError && emailBadAtRef.current !== null && values.email.trim() === emailBadAtRef.current && EMAIL_RE.test(values.email.trim())) {
      setEmailPulse((k) => k + 1);
    }
    if (!isValid && Object.keys(touched).length > 0) setErrorPulse((k) => k + 1);
    setCodeError(false);
    setRequestError(false);
    setTouched({ firstName: true, lastName: true, email: true, phone: true, companyName: true, website: true });
    if (!isValid) return;
    setStatus("sending");
    try {
      const buildStartedAt = Date.now();
      const result = await submit({
        data: {
          ...values,
          website: fullWebsite,
          phone: `${country.dial} ${sendablePhone(values.phone, country)}`.trim(),
          smsConsent: consent,
          trap,
          ...(pendingId ? { pendingId, code } : {}),
        },
      });
      if (result.status !== "ok") {
        setStatus("idle");
        if (result.status === "retry") {
          setTrap("");
        } else if (result.status === "bad_email") {
          setEmailServerError(true);
          emailBadAtRef.current = values.email.trim();
        } else if (result.status === "code_required") {
          setPendingId(result.pendingId);
          setCode("");
        } else if (result.status === "bad_code") {
          setCodeError(true);
        }
        return;
      }
      storeClaimContact({
        firstName: values.firstName.trim(),
        lastName: values.lastName.trim(),
        email: values.email.trim().toLowerCase(),
        phone: `${country.dial} ${sendablePhone(values.phone, country)}`.trim(),
        companyName: values.companyName.trim(),
        website: fullWebsite,
      });
      const remainingBuildTime = Math.max(0, 5200 - (Date.now() - buildStartedAt));
      await new Promise<void>((resolve) => window.setTimeout(resolve, remainingBuildTime));
      try { window.sessionStorage.removeItem(DEMO_FORM_DRAFT_KEY); } catch { /* ignore */ }
      if (mountedRef.current) onComplete(values.companyName.trim());
    } catch {
      setStatus("idle");
      setRequestError(true);
    }
  };

  // Back button: match the /claim form Back button's on-screen size. /claim
  // renders the same button classes zoomed by 1.2 (or 1.2 × 1200/1440 × 0.9 on
  // fine-pointer desktops ≥1024) on a canvas scaled to window width / 1440.
  const backBtnRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const btn = backBtnRef.current;
    if (!btn) return;
    const update = () => {
      const landscape = isPhoneLandscapeViewport();
      if (!landscape && (window.visualViewport?.scale ?? 1) !== 1) return;
      // Measure the slot (never transformed) so the button's own scale is not read back.
      const slot = btn.parentElement;
      const vw = Math.max(1, document.documentElement.clientWidth);
      if (!slot || (vw < 640 && !landscape)) {
        btn.style.transform = "";
        return;
      }
      // Product of every ancestor's resting scale (transform × zoom). Elements
      // mid-entrance-animation are skipped; animationend re-runs this.
      let ancestorScale = 1;
      for (let el: HTMLElement | null = slot; el; el = el.parentElement) {
        const cs = getComputedStyle(el);
        const z = parseFloat(cs.zoom);
        if (z && z !== 1) ancestorScale *= z;
        if (cs.transform === "none" || el.getAnimations().some((a) => a.playState === "running")) continue;
        const m = new DOMMatrixReadOnly(cs.transform);
        ancestorScale *= Math.hypot(m.a, m.b);
      }
      if (!ancestorScale) return;
      const desktop = vw >= 1024 && window.matchMedia("(pointer: fine)").matches;
      const formZoom = (1440 / 1200) * (desktop ? (1200 / 1440) * 0.9 : 1);
      const s = landscape ? 1 : (getDesktopScale(vw) * formZoom) / ancestorScale;
      // Horizontal shift so the button's left edge sits under the header logo.
      const logo = [...document.querySelectorAll<HTMLElement>("header img.pr-brand-logo")].find(
        (el) => el.offsetParent !== null,
      );
      const logoLeft = logo?.getBoundingClientRect().left;
      const dx = logoLeft === undefined ? 0 : (logoLeft - slot.getBoundingClientRect().left) / ancestorScale;
      // Size changes apply instantly; hover colors keep their transition.
      btn.style.transitionProperty = "color, background-color, border-color, box-shadow";
      // Vertical shift so the gap below the header matches the /claim Back button.
      const hb = headerBottom();
      const dy = hb === null ? 0 : (hb + claimBackGap() - slot.getBoundingClientRect().top) / ancestorScale;
      const parts = [Math.abs(dx) >= 0.25 || Math.abs(dy) >= 0.25 ? `translate(${dx}px, ${dy}px)` : "", Math.abs(s - 1) >= 0.0005 ? `scale(${s})` : ""].filter(Boolean);
      btn.style.transformOrigin = "left top";
      btn.style.transform = parts.join(" ");
    };
    update();
    const timers = [60, 200, 500, 1000, 1600, 2500].map((t) => window.setTimeout(update, t));
    // The form's fit wrapper sets its scale from script after mount; watch its style.
    const styleObserver = new MutationObserver(update);
    for (let el: HTMLElement | null = btn.parentElement; el; el = el.parentElement) {
      styleObserver.observe(el, { attributes: true, attributeFilter: ["style", "class"] });
    }
    document.fonts?.ready.then(update);
    // Entrance animations scale ancestors briefly; re-measure once they end.
    const onAnim = (e: Event) => {
      if (e.target instanceof Node && e.target !== btn && e.target.contains(btn)) update();
    };
    window.addEventListener("animationend", onAnim, true);
    window.addEventListener("transitionend", onAnim, true);
    window.addEventListener("resize", update);
    window.addEventListener("orientationchange", update);
    return () => {
      timers.forEach((t) => window.clearTimeout(t));
      styleObserver.disconnect();
      window.removeEventListener("animationend", onAnim, true);
      window.removeEventListener("transitionend", onAnim, true);
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);

  const showError = (name: DemoFieldName) => Boolean(touched[name] && fieldErrors[name]);

  const inputClass = (name: DemoFieldName, extra = "px-4") =>
    `h-12 w-full rounded-xl border bg-surface text-base font-medium text-ink placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-brand/30 ${
      showError(name) ? "border-ink" : "border-border focus:border-brand"
    } ${extra}`;

  const fieldError = (name: DemoFieldName) =>
    showError(name) ? (
      // 171E: only the words pulse — the white pill box itself never animates.
      <p className="pointer-events-none absolute inset-px z-10 flex items-center rounded-[11px] bg-surface px-4 text-xl font-black text-ink max-sm:rounded-[11px] max-sm:px-4 max-sm:text-base">
        <span
          key={name === "email" ? `${emailPulse}-${errorPulse}` : errorPulse}
          className={(name === "email" && emailPulse > 0) || errorPulse > 0 ? "demo-email-error-pulse" : undefined}
        >
          {fieldErrors[name]}
        </span>
      </p>
    ) : null;

  const clearFieldError = (_name: DemoFieldName) => {
    setTouched({});
    setErrorPulse(0);
  };

  // 427: form title stays two lines and shrinks as one piece to fit its container.
  const titleRef = useRef<HTMLHeadingElement>(null);
  useLayoutEffect(() => {
    const h2 = titleRef.current;
    const box = h2?.parentElement;
    if (!h2 || !box) return;
    const fit = () => {
      h2.style.removeProperty("font-size");
      const lines = Array.from(h2.children) as HTMLElement[];
      const natural = Math.max(
        ...lines.map((l) => {
          l.style.display = "inline-block";
          const w = l.offsetWidth;
          l.style.removeProperty("display");
          return w;
        }),
      );
      const cw = box.clientWidth;
      if (natural > cw && natural > 0) {
        const fs = parseFloat(getComputedStyle(h2).fontSize);
        h2.style.fontSize = `${(fs * cw) / natural}px`;
      }
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(box);
    window.addEventListener("resize", fit);
    document.fonts?.ready.then(fit).catch(() => {});
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", fit);
      h2.style.removeProperty("font-size");
    };
  }, []);

  // 426: real desktop only — consent line on one line, sized to the submit button's width.
  useLayoutEffect(() => {
    const mqA = window.matchMedia("(hover: hover) and (pointer: fine)");
    const mqB = window.matchMedia("(min-width: 1024px)");
    const span = document.querySelector<HTMLElement>(".consent-label .consent-text");
    const label = span?.closest<HTMLElement>(".consent-label") ?? null;
    const box = label?.querySelector<HTMLElement>('input[type="checkbox"]') ?? null;
    const button = label?.closest("form")?.querySelector<HTMLElement>('button[type="submit"]') ?? null;
    if (!span || !label || !box || !button) return;
    const clear = () => { span.style.fontSize = ""; };
    const fit = () => {
      if (!(mqA.matches && mqB.matches)) { clear(); return; }
      clear();
      const bRect = button.getBoundingClientRect();
      const sRect = span.getBoundingClientRect();
      const scale = button.offsetWidth > 0 ? bRect.width / button.offsetWidth : 1;
      const natural = span.offsetWidth;
      const base = parseFloat(getComputedStyle(span).fontSize) || 13;
      const avail = (bRect.right - sRect.left) / (scale || 1);
      if (natural > 0 && avail > 0) span.style.fontSize = `${(base * avail) / natural}px`;
    };
    fit();
    window.addEventListener("resize", fit);
    mqA.addEventListener("change", fit);
    mqB.addEventListener("change", fit);
    document.fonts?.ready.then(fit).catch(() => {});
    const ro = new ResizeObserver(fit);
    ro.observe(button);
    return () => {
      window.removeEventListener("resize", fit);
      mqA.removeEventListener("change", fit);
      mqB.removeEventListener("change", fit);
      ro.disconnect();
      clear();
    };
  }, []);

  return (
    <div className="relative mx-auto w-full max-w-[900px] px-8 text-left max-sm:h-full max-sm:max-w-none max-sm:px-0">
      {/* Slot keeps the button's original layout box so nothing below moves;
          the button inside uses the /claim Back button's styles and is scaled
          to the /claim button's on-screen size. */}
      <span className="demo-back-slot mb-2 inline-flex h-[38px] items-start max-sm:hidden">
        <button
          ref={backBtnRef}
          type="button"
          onClick={onBack}
          disabled={status === "sending"}
          className="demo-back-btn inline-flex items-center rounded-full border border-border bg-surface-2 px-4 py-2 text-[0.65rem] font-extrabold uppercase tracking-[0.16em] text-ink shadow-elev-1 transition-all hover:border-brand hover:text-brand hover:shadow-elev-2 lg:px-5 lg:py-2.5 lg:text-xs"
        >
          ← Back
        </button>
      </span>
      <div className="text-center">
        <h2 ref={titleRef} className="headline mx-auto max-w-none text-balance text-5xl text-ink max-sm:text-[min(9.05vw,3.4rem,var(--hero-live-fs,3.4rem))] max-sm:leading-[1.05]">
          <span className="block whitespace-nowrap">Turn Profile Views Into</span>
          <span className="block whitespace-nowrap">
            <span className="text-brand">Real Conversations</span>!
          </span>
        </h2>
        <p className="mx-auto mt-3 max-w-none whitespace-nowrap text-sm font-bold leading-6 text-muted-foreground max-sm:mt-2 max-sm:w-full max-sm:max-w-[38ch] max-sm:whitespace-normal max-sm:text-center max-sm:text-[0.8rem] max-sm:leading-5">
          <span className="max-sm:block">Five quick details and in seconds you will get a</span>
          {" "}
          <span className="max-sm:block">fully trained live AI Voice demo for your business.</span>
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="mt-8 grid grid-cols-2 gap-x-6 gap-y-4 max-sm:mt-6">
        <div className="relative col-span-2 sm:col-span-1">
          <input
            id="demo-firstName"
            aria-label="First name"
            name="firstName"
            type="text"
            autoComplete="given-name"
            maxLength={80}
            placeholder="First Name*"
            value={values.firstName}
            onFocus={() => clearFieldError("firstName")}
            onChange={(e) => setField("firstName", e.target.value)}
            className={inputClass("firstName")}
          />
          {fieldError("firstName")}
        </div>

        <div className="relative col-span-2 sm:col-span-1">
          <input
            id="demo-lastName"
            aria-label="Last name"
            name="lastName"
            type="text"
            autoComplete="family-name"
            maxLength={80}
            placeholder="Last Name*"
            value={values.lastName}
            onFocus={() => clearFieldError("lastName")}
            onChange={(e) => setField("lastName", e.target.value)}
            className={inputClass("lastName")}
          />
          {fieldError("lastName")}
        </div>

        <div className="relative col-span-2 sm:col-span-1">
          <div className="relative">
            <input
              id="demo-email"
              aria-label="Email"
              name="email"
              type="email"
              autoComplete="email"
              maxLength={255}
              placeholder="Email Address*"
              value={values.email}
              onFocus={() => clearFieldError("email")}
              onChange={(e) => setField("email", e.target.value)}
              className={inputClass("email")}
            />
            {fieldError("email")}
          </div>
        </div>

        <div className="relative col-span-2 sm:col-span-1">
          <div className="flex gap-2">
            <PhoneCountryPicker
              country={country}
              onSelect={(c) => {
                setCountry(c);
                setValues((prev) => ({ ...prev, phone: formatPhone(prev.phone.replace(/\D/g, "").slice(0, maxDigitsFor(c)), c) }));
              }}
            />
            <div className="relative flex-1">
              <input
                id="demo-phone"
                aria-label="Phone"
                name="phone"
                type="tel"
                inputMode="numeric"
                autoComplete="tel"
                placeholder={country.na ? "(555) 123-4567*" : "Phone Number*"}
                value={values.phone}
                onFocus={() => clearFieldError("phone")}
                onChange={(e) => setField("phone", e.target.value)}
                className={inputClass("phone")}
              />
              {fieldError("phone")}
            </div>
          </div>
        </div>

        <div className="relative col-span-2">
          <input
            id="demo-companyName"
            aria-label="Company name"
            name="companyName"
            type="text"
            autoComplete="organization"
            maxLength={120}
            placeholder="Company Name*"
            value={values.companyName}
            onFocus={() => clearFieldError("companyName")}
            onChange={(e) => setField("companyName", e.target.value)}
            className={inputClass("companyName")}
          />
          {fieldError("companyName")}
        </div>

        <div className="relative col-span-2">
          <label htmlFor="demo-website" className="mb-2 block text-xs font-bold text-ink">
            What’s your company website so we can train your custom AI voice employee?
          </label>
          <div className="relative">
            <input
              ref={websiteInputRef}
              id="demo-website"
              name="website"
              type="text"
              autoComplete="url"
              maxLength={255}
              placeholder="www.yourwebsite.com*"
              value={values.website}
              onFocus={(e) => {
                clearFieldError("website");
                const el = e.currentTarget;
                if (el.value === "") {
                  setField("website", "www.");
                  setTimeout(() => { if (document.activeElement === el) el.setSelectionRange(4, 4); }, 0);
                } else {
                  caretEndIfWww(e);
                }
              }}
              onBlur={(e) => {
                if (e.currentTarget.value.toLowerCase() === "www.") setField("website", "");
              }}
              onChange={(e) => {
                setField("website", cleanWebsite(e.target.value));
              }}
              className={inputClass("website", "px-4")}
            />
            {fieldError("website")}
          </div>
        </div>

        <label className="consent-label col-span-2 flex cursor-pointer items-start gap-3 pl-1 text-[13px] leading-[1.35] text-muted-foreground">
          <input
            type="checkbox"
            checked={consent}
            onChange={(e) => setConsent(e.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 rounded-sm border-border accent-brand"
          />
          <span className="consent-text max-sm:whitespace-normal sm:whitespace-nowrap">I consent to receive text messages from LinkBot.Now about my demo, including follow-ups and offers,{" "}<br className="consent-ipad-br" />at the number provided. Message and data rates may apply.<span className="consent-reply"> Reply STOP to opt out.</span></span>
        </label>

        {/* Trap field: invisible to people, screen readers, keyboard and autofill. */}
        <div aria-hidden="true" style={{ position: "absolute", left: "-10000px", top: "auto", width: 1, height: 1, overflow: "hidden" }}>
          <input
            type="text"
            name="ref_code_confirm"
            tabIndex={-1}
            autoComplete="off"
            data-1p-ignore="true"
            data-lpignore="true"
            data-bwignore="true"
            data-form-type="other"
            value={trap}
            onChange={(e) => setTrap(e.target.value)}
          />
        </div>

        {pendingId && (
          <div className="relative col-span-2">
            <label htmlFor="demo-code" className="mb-2 block text-xs font-bold text-ink">
              We just emailed you a 6-digit code. Enter it to start your demo.
            </label>
            <input
              id="demo-code"
              name="demo-code"
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => {
                setCode(e.target.value.replace(/\D/g, "").slice(0, 6));
                setCodeError(false);
              }}
              className="h-12 w-full rounded-xl border border-border bg-surface px-4 text-base font-medium text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
            />
            {codeError && <p role="alert" className="mt-1 pl-1 text-xs font-bold text-ink">That code didn't work. Please try again.</p>}
          </div>
        )}

        <div className="col-span-2 mt-1 max-sm:mt-2">
          <button
            type="submit"
            disabled={status === "sending"}
            className={cn(
              CTA_CLASSES,
              "mobile-home-cta-native h-11 w-full text-xs disabled:cursor-not-allowed max-sm:text-[0.745rem]",
              status === "sending" && "building-agent-button",
            )}
          >
            {status === "sending" && (
              <span className="building-agent-progress" aria-hidden>
                <span className="building-agent-swirl" />
                <span className="building-agent-swirl building-agent-swirl-two" />
              </span>
            )}
            <span className={status === "sending" ? "building-agent-label" : undefined}>
              {status === "sending" ? "BUILDING YOUR AGENT" : "Launch My Custom Free Demo"}
            </span>
          </button>
          {requestError && <p role="alert" className="mt-1 pl-1 text-xs font-bold text-ink">Something went wrong. Please try again.</p>}
        </div>
      </form>
    </div>
  );
}

export function LiveDemoStage({
  compositionRef,
  companyName,
  getNowCta,
}: {
  compositionRef: React.RefObject<HTMLDivElement | null>;
  companyName: string;
  getNowCta: React.ReactNode;
}) {
  const [callState, setCallState] = useState<"connecting" | "live" | "ended">("live");

  return (
    <div ref={compositionRef} id="live-demo" className="hero-call-stage hero-call-composition animate-fade-up mx-auto grid w-full max-w-5xl grid-cols-[minmax(0,1fr)_360px] items-center gap-16 text-left max-sm:grid-cols-[minmax(0,1fr)_auto] max-sm:max-w-none max-sm:items-start max-sm:gap-10">
      <div className="w-full max-w-xl max-sm:max-w-none">
        <p className="pr-eyebrow max-sm:mr-[-571px] max-sm:text-[1.75rem] max-sm:leading-[1.25]" style={{ fontWeight: 700 }}>YOUR PERSONALIZED LIVE DEMO</p>
        <h2 className="hero-call-title headline mt-4 text-balance text-5xl text-night-foreground max-sm:mr-[-571px] max-sm:mt-6 max-sm:text-[86.46px] max-sm:leading-[1]">
          Meet Your <span className="text-brand">LinkedIn AI Voice Employee</span>
        </h2>
        <p className="mt-7 text-xl font-extrabold text-night-foreground max-sm:mt-28 max-sm:text-[2.5rem] max-sm:leading-[1.25]">
          Talk to it. Test it live.
        </p>
        <p className="mt-6 w-full text-base leading-7 text-night-muted max-sm:mt-8 max-sm:text-[2.5rem] max-sm:leading-[1.25]">
          <span className="block">{"Put your personalized demo to the test. Ask about your company, services, products, process, pricing or anything else someone might look for on your website. Try simple questions, get specific, or ask something completely unexpected. See for yourself what LinkBot learned about your business, from only a website link."}</span>
        </p>
        <p className="mt-6 w-full text-sm italic leading-6 text-night-muted max-sm:mt-6 max-sm:text-[1.6rem] max-sm:leading-[1.4]">
          <span className="block">{"Your finished LinkBot can be trained with everything you want it to know, giving it the knowledge and context to represent you across every conversation."}</span>
        </p>
        <div className="mt-8 w-full max-w-xs [&_a]:w-full [&_a]:justify-center max-sm:mr-[-571px] max-sm:mt-[76px] max-sm:flex max-sm:w-auto max-sm:max-w-none max-sm:justify-center">{getNowCta}</div>
      </div>

      <div className="hero-demo-scale mx-auto w-fit">
        <LiveAgentPhone callState={callState} onEnd={() => setCallState("ended")} onRestart={() => setCallState("live")} />
      </div>
    </div>
  );
}

export function LiveAgentPhone({ callState, onEnd, onRestart }: { callState: "connecting" | "live" | "ended"; onEnd: () => void; onRestart: () => void }) {
  const [phoneTime, setPhoneTime] = useState("");
  const [activeVoice, setActiveVoice] = useState<"agent" | "visitor">("agent");

  useEffect(() => {
    const update = () => setPhoneTime(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    update();
    // 257: the clock holds still while the touch homepage is pinch-zoomed.
    const timer = window.setInterval(() => { if (!isHeroZoomPaused()) update(); }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (callState !== "live") return;
    const timer = window.setInterval(() => {
      if (isHeroZoomPaused()) return;
      setActiveVoice((current) => (current === "agent" ? "visitor" : "agent"));
    }, 1800);
    return () => window.clearInterval(timer);
  }, [callState]);

  return (
    <div className="relative mx-auto h-[640px] max-sm:h-[650px] w-[316px] overflow-hidden rounded-[42px] border-[9px] border-night bg-night shadow-elev-3" aria-live="polite">
      <div className="absolute left-1/2 top-2 z-30 h-6 w-24 -translate-x-1/2 rounded-full bg-night" />
      <div className={cn("absolute inset-x-0 top-0 z-20 flex h-11 items-center justify-between px-6 text-[10px] font-bold", callState === "connecting" ? "text-night-foreground" : "bg-surface text-ink")}>
        <span>{phoneTime || "9:41"}</span>
        <span className="flex items-center gap-1.5">
          <Signal className="h-3.5 w-3.5" />
          <Wifi className="h-3.5 w-3.5" />
          <span className="relative h-2.5 w-5 rounded-[3px] border border-current p-px" aria-label="Full battery">
            <span className="block h-full w-full rounded-[1px] bg-current" />
            <span className="absolute -right-[3px] top-1/2 h-1 w-0.5 -translate-y-1/2 rounded-r bg-current" />
          </span>
        </span>
      </div>

      {callState === "connecting" ? (
        <div className="connection-screen flex h-full flex-col items-center justify-center overflow-hidden px-5 text-center text-night-foreground">
          <div className="connection-vortex" aria-hidden>
            <span className="connection-grid" />
            <span className="connection-halo connection-halo-outer" />
            <span className="connection-halo connection-halo-middle" />
            <span className="connection-halo connection-halo-inner" />
            <span className="connection-axis connection-axis-one" />
            <span className="connection-axis connection-axis-two" />
            <span className="connection-axis connection-axis-three" />
            <span className="connection-node connection-node-one" />
            <span className="connection-node connection-node-two" />
            <span className="connection-node connection-node-three" />
            <span className="connection-core">
              <Mic className="h-10 w-10" />
            </span>
          </div>
          <p className="eyebrow-light mt-8">SECURE VOICE LINK</p>
          <h3 className="mt-3 whitespace-nowrap text-[1.65rem] font-black">Connecting your agent</h3>
          <div className="mt-7 flex items-center gap-2 text-xs font-bold text-night-muted">
            <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
            Training complete · Opening live channel
          </div>
        </div>
      ) : callState === "live" ? (
        <div className="live-voice-screen flex h-full flex-col bg-surface px-5 pb-6 pt-16 text-ink">
          <div className="text-center">
            <span className="relative mx-auto flex h-20 w-20 items-center justify-center">
              <span className="absolute h-20 w-20 animate-pulse-ring rounded-full bg-brand/20" />
              <span className="relative grid h-16 w-16 place-items-center rounded-full bg-brand text-brand-foreground shadow-brand"><Mic className="h-7 w-7" /></span>
            </span>
            <p className="eyebrow mt-5">LIVE · AI VOICE EMPLOYEE</p>
          </div>

          <div className="mt-6 space-y-3 text-left" aria-label="Live voice conversation">
            <div className={cn("voice-turn", activeVoice === "agent" && "voice-turn-active")}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase text-brand">AI Agent</span>
              </div>
              <p className="mt-1.5 text-sm font-semibold leading-5">Hi! What would you like to know about our services?</p>
            </div>
            <div className={cn("voice-turn voice-turn-visitor", activeVoice === "visitor" && "voice-turn-active")}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase text-muted-foreground">You</span>
              </div>
              <p className="mt-1.5 text-sm font-semibold leading-5">How quickly can you help my team capture new leads?</p>
            </div>
          </div>

          <div className="mt-auto w-full">
            <Button type="button" variant="destructive" size="lg" onClick={onEnd} aria-label="End call" className="h-14 w-full rounded-lg text-base font-extrabold shadow-elev-3">
              <PhoneOff className="h-5 w-5" /> End call
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex h-full flex-col items-center justify-center bg-surface px-6 pb-6 pt-16 text-center text-ink">
          <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-brand shadow-elev-2">
            <Mic className="h-10 w-10 text-brand-foreground" />
          </div>
          <p className="mt-8 text-xs font-black uppercase tracking-[0.22em] text-brand">LIVE RECEPTIONIST</p>
          <h3 className="mt-4 text-3xl font-black text-ink">Hi, let's chat.</h3>
          <p className="mt-3 max-w-[16rem] text-base font-medium leading-relaxed text-muted-foreground">I can answer any question and get you to the right person.</p>
          <div className="mt-auto w-full">
            <button type="button" onClick={onRestart} className={cn(CTA_CLASSES, "h-14 w-full text-base")}>
              <span className="flex items-center gap-2"><Mic className="h-5 w-5" /> Start talking</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function PhoneDemo({ step, demoPublicUrl, onStart, onEnd }: { step: number; demoPublicUrl: string | null; onStart: () => void; onEnd: () => void }) {
  const [phoneTime, setPhoneTime] = useState<string>("");
  

  useEffect(() => {
    const formatTime = () => {
      const now = new Date();
      const hour = now.getHours() % 12 || 12;
      const minute = now.getMinutes().toString().padStart(2, "0");
      return `${hour}:${minute}`;
    };
    setPhoneTime(formatTime());
    const timer = window.setInterval(() => { if (!isHeroZoomPaused()) setPhoneTime(formatTime()); }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const handleEnd = () => {
    onEnd();
  };

  return (
    <div className="hero-phone-frame relative h-[650px] w-[316px] overflow-hidden rounded-[42px] border-[9px] border-night bg-surface shadow-elev-3" aria-live="polite">
      <div className="absolute left-1/2 top-2 z-30 h-6 w-24 -translate-x-1/2 rounded-full bg-night" />
      <div className="absolute inset-x-0 top-0 z-20 flex h-11 items-center justify-between bg-surface px-6 text-[10px] font-bold text-ink">
        <span>{phoneTime || "9:41"}</span><span>● ● ●</span>
      </div>

      <div className={`absolute inset-0 h-full bg-surface pt-11 transition-transform duration-700 ${step === 1 ? "-translate-y-[190px]" : step === 2 ? "-translate-y-[335px]" : "translate-y-0"}`}>
          <div className="h-20 bg-brand" />
          <div className="px-4">
            <img src={profilePhoto} alt="Fictional LinkedIn profile" width={768} height={768} className="-mt-11 h-24 w-24 rounded-full border-4 border-surface object-cover" />
            <div className="mt-2 flex items-center gap-1.5">
              <h3 className="text-lg font-extrabold text-ink">Daniel Carter</h3>
              <Linkedin className="h-4 w-4 fill-brand text-brand" aria-hidden />
            </div>
            <p className="mt-1 text-xs leading-4 text-ink">Founder helping service businesses turn LinkedIn attention into booked conversations.</p>
            <p className="mt-2 text-[10px] text-muted-foreground">New York, United States · 500+ connections</p>
            <div className="mt-3 flex gap-2">
              <span className="rounded-full bg-brand px-4 py-1.5 text-[10px] font-bold text-brand-foreground">Connect</span>
              <span className="rounded-full border border-brand px-4 py-1.5 text-[10px] font-bold text-brand">Message</span>
            </div>
          </div>
          <div className="mt-5 border-t border-border px-4 py-4">
            <p className="text-sm font-extrabold text-ink">About</p>
            <p className="mt-2 text-[10px] leading-4 text-muted-foreground">I help growing teams capture more opportunities from the people already visiting their profiles.</p>
          </div>
          <div className="border-t-4 border-surface-2 px-4 py-4">
            <p className="text-sm font-extrabold text-ink">Featured</p>
            <div className="relative mt-3 overflow-hidden rounded-lg border border-border bg-surface">
                <div className="relative aspect-video overflow-hidden">
                  <img src="/customer-preview.png" alt="" draggable={false} className={cn("absolute inset-0 h-full w-full object-cover", step === 2 && "demo-photo-press")} />
                  <button
                    type="button"
                    onClick={onStart}
                    aria-label="Click here to start a live call now."
                    className="absolute left-[51%] top-[35%] z-[2] h-[36%] w-[24%] -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-full bg-transparent outline-none"
                  >
                    <span className="sr-only">Start live call</span>
                  </button>
                </div>
              <div className="px-3 py-3 text-center">
                <p className="whitespace-nowrap text-[9.5px] font-bold text-ink">Get Answers. Access Resources. Connect Faster.</p>
                <p className="whitespace-nowrap text-[9.5px] text-muted-foreground">www.linkbot.now/danielcarter</p>
              </div>
              {step === 2 && <DemoPointer className="demo-pointer-to-feature absolute left-1/2 top-14" />}
            </div>
          </div>
          <div className="border-t-4 border-surface-2 px-4 py-4">
            <p className="text-sm font-extrabold text-ink">Activity</p>
            <p className="mt-1 text-[9px] text-muted-foreground">4,182 followers</p>
            <div className="mt-3 space-y-3">
              <div className="rounded-lg border border-border p-3">
                <p className="text-[10px] font-bold text-ink">Daniel posted this</p>
                <p className="mt-1 text-[10px] leading-4 text-muted-foreground">Most profile visitors never message you. Give them something to talk to instead.</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-[10px] font-bold text-ink">Daniel commented</p>
                <p className="mt-1 text-[10px] leading-4 text-muted-foreground">Speed to lead wins. Answer in seconds, every time.</p>
              </div>
            </div>
          </div>
          <div className="border-t-4 border-surface-2 px-4 py-4">
            <p className="text-sm font-extrabold text-ink">Experience</p>
            <div className="mt-3 space-y-3">
              <div>
                <p className="text-[10px] font-bold text-ink">Founder · Carter Growth Partners</p>
                <p className="text-[9px] text-muted-foreground">2019 – Present · New York, NY</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-ink">Head of Sales · Northline Services</p>
                <p className="text-[9px] text-muted-foreground">2015 – 2019</p>
              </div>
            </div>
          </div>
          <div className="border-t-4 border-surface-2 px-4 py-4">
            <p className="text-sm font-extrabold text-ink">Skills</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Lead generation", "Sales strategy", "Automation", "B2B growth"].map((skill) => (
                <span key={skill} className="rounded-full bg-surface-2 px-3 py-1 text-[9px] font-bold text-ink">{skill}</span>
              ))}
            </div>
          </div>
      </div>

      {step === 3 && (
        <div className="absolute inset-0 z-10 bg-surface">
          {demoPublicUrl ? (
            <iframe src={demoPublicUrl} title="Live LinkBot voice employee demo" className="h-full w-full border-0 bg-surface pt-6" allow="microphone" />
          ) : (
            <PhoneCallPreview onEnd={handleEnd} />
          )}
        </div>
      )}
    </div>
  );
}

// The link buttons flashed one after another in the hero call demo, most important first.
const HERO_UP = '<path d="M7 17 17 7"/><path d="M8 7h9v9"/>';
const HERO_DOWN = '<path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/>';
const HERO_LINK_BUTTONS = [
  { label: "Book A Call Now", icon: "<rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\"/><path d=\"M16 2v4M8 2v4M3 10h18\"/>", arrow: HERO_UP },
  { label: "See Real Results", icon: "<path d=\"M11.5 2.3a.5.5 0 0 1 1 0l2.3 4.7a2 2 0 0 0 1.5 1.1l5.2.8a.5.5 0 0 1 .3.9l-3.8 3.7a2 2 0 0 0-.6 1.8l.9 5.2a.5.5 0 0 1-.8.6l-4.6-2.5a2 2 0 0 0-1.9 0l-4.6 2.5a.5.5 0 0 1-.8-.6l.9-5.2a2 2 0 0 0-.6-1.8L1.7 9.8a.5.5 0 0 1 .3-.9l5.2-.8a2 2 0 0 0 1.5-1.1z\"/>", arrow: HERO_UP },
  { label: "Explore Our Offers", icon: "<rect x=\"3\" y=\"8\" width=\"18\" height=\"4\" rx=\"1\"/><path d=\"M12 8v13\"/><path d=\"M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7\"/><path d=\"M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5\"/>", arrow: HERO_UP },
  { label: "Compare Our Pricing", icon: "<rect width=\"20\" height=\"12\" x=\"2\" y=\"6\" rx=\"2\"/><circle cx=\"12\" cy=\"12\" r=\"2\"/><path d=\"M6 12h.01M18 12h.01\"/>", arrow: HERO_UP },
  { label: "Visit Our Website", icon: "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M2 12h20\"/><path d=\"M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z\"/>", arrow: HERO_UP },
  { label: "Watch Our Videos", icon: "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m10 8 6 4-6 4z\"/>", arrow: HERO_UP },
  { label: "Download Free Guide", icon: "<path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"/><path d=\"M14 2v6h6\"/><path d=\"M8 13h8M8 17h5\"/>", arrow: HERO_DOWN },
  { label: "Get Discount Code", icon: "<path d=\"M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4z\"/><circle cx=\"7.5\" cy=\"7.5\" r=\".5\" fill=\"currentColor\"/>", arrow: HERO_UP },
  { label: "Buy Now", icon: "<circle cx=\"8\" cy=\"21\" r=\"1\"/><circle cx=\"19\" cy=\"21\" r=\"1\"/><path d=\"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12\"/>", arrow: HERO_UP },
  { label: "Join Our Team", icon: "<rect width=\"8\" height=\"4\" x=\"8\" y=\"2\" rx=\"1\"/><path d=\"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2\"/><path d=\"M12 11h4M12 16h4M8 11h.01M8 16h.01\"/>", arrow: HERO_UP },
  { label: "Become A Partner", icon: "<path d=\"m11 17 2 2a1 1 0 1 0 3-3\"/><path d=\"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4\"/><path d=\"m21 3 1 11h-2\"/><path d=\"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3\"/><path d=\"M3 4h8\"/>", arrow: HERO_UP },
  { label: "View My Resume", icon: "<path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"/><path d=\"M14 2v6h6\"/><path d=\"M8 13h8M8 17h5\"/>", arrow: HERO_DOWN },
  { label: "Hire Me To Speak", icon: "<path d=\"M12 19v3\"/><path d=\"M19 10v2a7 7 0 0 1-14 0v-2\"/><rect x=\"9\" y=\"2\" width=\"6\" height=\"13\" rx=\"3\"/>", arrow: HERO_UP },
  { label: "Register For Event", icon: "<path d=\"M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z\"/><path d=\"M13 5v2\"/><path d=\"M13 17v2\"/><path d=\"M13 11v2\"/>", arrow: HERO_UP },
  { label: "Unlock Insider Tips", icon: "<rect width=\"20\" height=\"16\" x=\"2\" y=\"4\" rx=\"2\"/><path d=\"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7\"/>", arrow: HERO_UP },
  { label: "Listen To Our Podcast", icon: "<path d=\"M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3\"/>", arrow: HERO_UP },
  { label: "Join Our Community", icon: "<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><path d=\"M22 21v-2a4 4 0 0 0-3-3.87\"/><path d=\"M16 3.13a4 4 0 0 1 0 7.75\"/>", arrow: HERO_UP },
  { label: "Follow Our Page", icon: "<circle cx=\"18\" cy=\"5\" r=\"3\"/><circle cx=\"6\" cy=\"12\" r=\"3\"/><circle cx=\"18\" cy=\"19\" r=\"3\"/><line x1=\"8.59\" x2=\"15.42\" y1=\"13.51\" y2=\"17.49\"/><line x1=\"15.41\" x2=\"8.59\" y1=\"6.51\" y2=\"10.49\"/>", arrow: HERO_UP },
  { label: "Claim Early Access", icon: "<path d=\"M5 22h14\"/><path d=\"M5 2h14\"/><path d=\"M17 22v-4.2a2 2 0 0 0-.6-1.4L12 12l-4.4 4.4a2 2 0 0 0-.6 1.4V22\"/><path d=\"M7 2v4.2a2 2 0 0 0 .6 1.4L12 12l4.4-4.4a2 2 0 0 0 .6-1.4V2\"/>", arrow: HERO_UP },
] as const;

const HERO_CALL_LINES = [
  { who: "ai", text: "Hi! I can answer any question, guide you to the best option, send you links for anything you need, and get you connected. What are you calling for today?" },
  { who: "you", text: "What links can you send?" },
  { who: "ai", text: "I can send anything. You can add unlimited links! Common links are..." },
] as const;

function HeroSvg({ paths, width }: { paths: string; width: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" aria-hidden dangerouslySetInnerHTML={{ __html: paths }} />;
}

export function PhoneCallPreview({ onEnd }: { onEnd: () => void }) {
  const [listening, setListening] = useState(false);
  const [callDone, setCallDone] = useState(false);
  const [ending, setEnding] = useState(false);
  // Words shown so far in each chat bubble (they come in word by word, like the live captions),
  // and which link button is showing (-1 = none yet).
  const [wordsShown, setWordsShown] = useState<number[]>(() => HERO_CALL_LINES.map(() => 0));
  const [buttonIndex, setButtonIndex] = useState(-1);
  const [leaving, setLeaving] = useState(false);
  const onEndRef = useRef(onEnd);
  const hasEndedRef = useRef(false);

  useEffect(() => {
    onEndRef.current = onEnd;
  }, [onEnd]);

  const finishCall = () => {
    if (hasEndedRef.current) return;
    hasEndedRef.current = true;
    setListening(false);
    setCallDone(true);
    onEndRef.current();
  };

  useEffect(() => {
    // Start Call press shows from 900ms; End Call appears at 1120ms (same as before).
    // From 1500ms the call is live: each chat bubble's words come in one by one,
    // then every link button pops in one after another, 1 second each.
    const WORD_EVERY = 160;
    const PAUSE_BETWEEN_LINES = 450;
    const BUTTON_EVERY = 1200;
    const cancels: (() => void)[] = [pausableTimeout(() => setListening(true), 1120)];
    let at = 1500;
    HERO_CALL_LINES.forEach((line, li) => {
      const count = line.text.split(" ").length;
      for (let w = 1; w <= count; w++) {
        cancels.push(pausableTimeout(() => setWordsShown((prev) => prev.map((n, i) => (i === li ? w : n))), at));
        at += WORD_EVERY;
      }
      at += PAUSE_BETWEEN_LINES;
    });
    HERO_LINK_BUTTONS.forEach((_, i) => cancels.push(pausableTimeout(() => setButtonIndex(i), at + i * BUTTON_EVERY)));
    const endAt = at + HERO_LINK_BUTTONS.length * BUTTON_EVERY + 300;
    cancels.push(pausableTimeout(() => setEnding(true), endAt));
    cancels.push(pausableTimeout(finishCall, endAt + 350));
    return () => cancels.forEach((cancel) => cancel());
  }, []);

  // The links screen stays up, then softly fades away just before the hero restarts
  // (the restart happens 4 seconds after End Call), so the restart is never a harsh jump.
  useEffect(() => {
    if (!callDone) return;
    return pausableTimeout(() => setLeaving(true), 3400);
  }, [callDone]);

  // Live as soon as the first words come in (like the /livedemo page). After End Call the phone
  // fades back to the home screen with every link listed under LINKS SHARED WITH YOU.
  const talking = (wordsShown[0] ?? 0) > 0 && !callDone;
  const btn = buttonIndex >= 0 ? HERO_LINK_BUTTONS[buttonIndex] : undefined;
  // The button before it softly fades out underneath while the new one pops in, so the swap is seamless.
  const prevBtn = buttonIndex >= 1 ? HERO_LINK_BUTTONS[buttonIndex - 1] : undefined;

  return (
    <div className={cn("hero-lb-call relative flex h-full flex-col bg-surface px-6 pb-6 pt-16 text-center text-ink", talking && "hero-lb-on", callDone && "hero-lb-ended", leaving && "hero-lb-leaving")}>
      <div className="text-center">
        <p className="eyebrow">LIVE RECEPTIONIST</p>
        <span className="hero-lb-mic relative mx-auto mt-7 flex h-24 w-24 items-center justify-center">
          <span className="absolute h-24 w-24 rounded-full bg-brand/20 animate-pulse-ring" />
          <span className="relative grid h-20 w-20 place-items-center rounded-full bg-brand text-brand-foreground shadow-brand"><Mic className="h-8 w-8" aria-hidden /></span>
        </span>
      </div>

      <h3 className="hero-lb-title mt-6 text-3xl font-black text-ink">Hi, let's chat.</h3>
      <p className="hero-lb-sub mt-3 text-base font-medium leading-relaxed text-muted-foreground">I can help with anything you need.</p>

      <div className={cn("demo-audio-lines hero-lb-lines mt-8", listening && talking && !callDone && "demo-audio-lines-active")} aria-hidden>
        {Array.from({ length: 17 }, (_, index) => <span key={index} />)}
      </div>

      <div className="hero-lb-captions" aria-hidden>
        <div className="hero-lb-captions-inner">
          {HERO_CALL_LINES.map((line, i) => {
            const n = wordsShown[i] ?? 0;
            return n > 0 ? (
              <p key={i} className={cn("hero-lb-bubble", line.who === "you" ? "hero-lb-you" : "hero-lb-ai")}>{line.text.split(" ").slice(0, n).join(" ")}</p>
            ) : null;
          })}
        </div>
      </div>

      {callDone ? (
        <div className="hero-lb-saved" aria-hidden>
          <p className="hero-lb-saved-label">LINKS SHARED WITH YOU</p>
          <p className="hero-lb-saved-hint">Tap to open and view each link.</p>
          <div className="hero-lb-saved-wrap">
            <div className="hero-lb-saved-list">
              {HERO_LINK_BUTTONS.map((b) => (
                <span key={b.label} className="hero-lb-lbtn">
                  <span className="hero-lb-ic"><HeroSvg paths={b.icon} width="2" /></span>
                  <span className="hero-lb-tx">{b.label}</span>
                  <span className="hero-lb-ar"><HeroSvg paths={b.arrow} width="2.2" /></span>
                </span>
              ))}
            </div>
            <span className="hero-lb-more">Scroll for {HERO_LINK_BUTTONS.length - 2} more links<HeroSvg paths={'<path d="m6 9 6 6 6-6"/>'} width="2.4" /></span>
          </div>
        </div>
      ) : null}

      <div className="hero-lb-links" aria-hidden>
        {prevBtn ? (
          <span key={`out-${buttonIndex}`} className="hero-lb-lbtn hero-lb-out">
            <span className="hero-lb-ic"><HeroSvg paths={prevBtn.icon} width="2" /></span>
            <span className="hero-lb-tx">{prevBtn.label}</span>
            <span className="hero-lb-ar"><HeroSvg paths={prevBtn.arrow} width="2.2" /></span>
          </span>
        ) : null}
        {btn ? (
          <span key={buttonIndex} className="hero-lb-lbtn hero-lb-in">
            <span className="hero-lb-ic"><HeroSvg paths={btn.icon} width="2" /></span>
            <span className="hero-lb-tx">{btn.label}</span>
            <span className="hero-lb-ar"><HeroSvg paths={btn.arrow} width="2.2" /></span>
          </span>
        ) : null}
      </div>

      <div className="relative mt-auto w-full">
        {listening ? (
          <button type="button" aria-label="End Call" onClick={finishCall} className={cn(CTA_CLASSES, "end-call-button w-full", ending && "demo-call-button-press-end")}>
            <span className="flex items-center gap-2"><PhoneOff className="h-4 w-4" /> End Call</span>
          </button>
        ) : (
          <button
            type="button"
            tabIndex={-1}
            aria-hidden
            className={cn(CTA_CLASSES, "w-full", !callDone && "demo-call-button-press-start")}
          >
            <span className="flex items-center gap-2"><Mic className="h-4 w-4" /> Start Call</span>
          </button>
        )}
        <DemoPointer className={cn("demo-pointer-under-label absolute left-1/2 bottom-[3px] -translate-x-1/2", ending && "demo-pointer-end-press")} />
      </div>
    </div>
  );
}

let measureContext: CanvasRenderingContext2D | null | undefined;
function getMeasureContext() {
  if (measureContext === undefined) measureContext = document.createElement("canvas").getContext("2d");
  return measureContext;
}

function CallFeatureWord({ children, className }: { children: string | undefined; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    let disposed = false;
    const fit = () => {
      if (disposed) return;
      const context = getMeasureContext();
      if (!context) return;
      const style = getComputedStyle(el);
      context.font = `${style.fontWeight} 18px ${style.fontFamily}`;
      const width = context.measureText(children ?? "").width;
      if (width > 0) el.style.fontSize = `${15 * el.clientWidth / width}px`;
    };
    fit();
    const observer = new ResizeObserver(fit);
    observer.observe(el);
    void document.fonts.ready.then(fit);
    return () => { disposed = true; observer.disconnect(); };
  }, [children]);
  return <span ref={ref} className={cn("demo-call-word", className)}>{children}</span>;
}

export function DemoPointer({ className }: { className?: string }) {
  const pointerPath = "M2.5 1.5V21.5L8 16L12 23.5L16 21.5L12 14H20.5L2.5 1.5Z";

  return (
    <svg
      viewBox="0 0 24 26"
      className={cn("pointer-events-none h-3 w-3 overflow-visible", className)}
      aria-hidden
      shapeRendering="geometricPrecision"
    >
      <path d={pointerPath} fill="currentColor" className="text-ink" stroke="currentColor" strokeWidth="4.5" strokeLinejoin="miter" />
      <path d={pointerPath} fill="currentColor" className="text-ink" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="miter" />
      <path d={pointerPath} fill="none" className="text-surface" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="miter" />
      <path d={pointerPath} fill="currentColor" className="text-ink" stroke="none" />
    </svg>
  );
}

