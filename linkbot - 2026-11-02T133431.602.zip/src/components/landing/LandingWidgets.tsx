import { useEffect, useRef, useState } from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { isHeroZoomPaused } from "@/lib/hero-pause";
import { REVIEWS, REVIEW_STAGGER, STATS } from "@/components/landing/landing-content";

export function StatsCounter() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reducedMotion) {
      setProgress(1);
      return;
    }

    let animationFrame = 0;
    const observer = new IntersectionObserver(
      ([entry]) => {
        // 257: while the touch homepage is pinch-zoomed, show final values.
        if (isHeroZoomPaused()) {
          cancelAnimationFrame(animationFrame);
          if (entry?.isIntersecting) setProgress(1);
          return;
        }
        if (!entry?.isIntersecting) {
          cancelAnimationFrame(animationFrame);
          setProgress(0);
          return;
        }
        cancelAnimationFrame(animationFrame);
        const startedAt = performance.now();
        const duration = 1400;

        const animate = (now: number) => {
          const elapsed = Math.min((now - startedAt) / duration, 1);
          const eased = 1 - Math.pow(1 - elapsed, 3);
          setProgress(eased);
          if (elapsed < 1) animationFrame = requestAnimationFrame(animate);
        };

        animationFrame = requestAnimationFrame(animate);
      },
      { threshold: 0.35 },
    );

    observer.observe(node);
    return () => {
      observer.disconnect();
      cancelAnimationFrame(animationFrame);
    };
  }, []);

  return (
    <div ref={containerRef} className="cost-stats-container mx-auto mt-12 grid max-w-5xl grid-cols-3 overflow-hidden rounded-3xl border border-border bg-surface text-ink shadow-elev-3">
      {STATS.map((stat, index) => (
        <article key={stat.label} className={cn("relative flex min-h-56 flex-col items-center justify-center px-8 py-10 text-center", index > 0 && "border-l border-border")}>
          <span className="absolute inset-x-10 top-0 h-px bg-brand" aria-hidden="true" />
          <p className="font-display text-[clamp(2.5rem,5vw,4rem)] font-extrabold leading-none text-brand" aria-label={`${stat.value}${stat.suffix}`}>
            {Math.round(stat.value * progress)}{stat.suffix}
          </p>
          <p className="mt-5 max-w-[23ch] text-balance text-sm leading-6 text-ink-soft">{stat.label}</p>
          <button
            type="button"
            onClick={() => window.open(stat.href, "_blank", "noopener,noreferrer")}
            className="mt-5 cursor-pointer text-xs leading-5 text-muted-foreground/70 transition-colors hover:text-muted-foreground"
          >
            Source: {stat.source}
          </button>
        </article>
      ))}
    </div>
  );
}

export function ReviewCarousel() {
  return (
    <section className="overflow-hidden px-6 py-[clamp(4rem,8vw,6rem)]" aria-labelledby="reviews-heading" style={{ backgroundColor: 'var(--surface-2)' }}>
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(28rem,1.18fr)_minmax(0,0.82fr)] items-center gap-20 px-6">
        <div className="review-window relative h-[500px] overflow-hidden" aria-label="Illustrative review carousel">
          <div className="review-track">
            {[0, 1].map((copy) => (
              <div key={copy} className="space-y-5 pb-5" aria-hidden={copy === 1}>
                {REVIEWS.map((review, index) => (
                  <article
                    key={`${copy}-${review.name}`}
                    className={`review-card rounded-lg border border-border bg-surface p-5 text-ink shadow-elev-2 ${REVIEW_STAGGER[index % REVIEW_STAGGER.length]}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex min-w-0 items-center gap-3">
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brand text-sm font-extrabold text-brand-foreground">{review.name.charAt(0)}</span>
                        <p className="truncate text-sm font-bold">{review.name}</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <div className="flex gap-0.5 text-warning" aria-label="Five stars">
                          {[0, 1, 2, 3, 4].map((star) => <Star key={star} className="h-3.5 w-3.5 fill-current" aria-hidden />)}
                        </div>
                        <p className="mt-1 text-[10px] text-muted-foreground">{review.timeAgo}</p>
                      </div>
                    </div>
                    <blockquote className="mt-4 text-[13px] leading-5 text-ink-soft">“{review.quote}”</blockquote>
                  </article>
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className="mx-auto max-w-xl text-right">
          <p className="pr-eyebrow">FOUNDERS LOVE US</p>
          <h2 id="reviews-heading" className="headline mt-4 text-balance text-5xl text-ink">
            <span className="block">When attention becomes <span className="text-brand">a lead</span></span>
            <span className="block">
              <span className="text-brand">you can </span>
              <span className="text-brand">actually follow-up with</span>
              <span>.</span>
            </span>
          </h2>
          <p className="mt-6 w-full text-base font-semibold leading-7 text-ink-soft">
            <span className="block">Your profile already gets attention. LinkBot gives visitors a reason to stop, engage, and start a real conversation. Your social presence should never be static. Our LinkBot users turn everyday profile traffic into more meaningful connections.</span>
            <span className="mt-7 block">Your website gives visitors multiple ways to take action. Why should your profile be any different?</span>
          </p>
        </div>
      </div>
    </section>
  );
}

export function ScrollReveal({ children, className, delay = 0, id, from, style, repeat = false, downOnly = false }: { children: React.ReactNode; className?: string; delay?: number; id?: string; from?: "left" | "right"; style?: React.CSSProperties; repeat?: boolean; downOnly?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [snap, setSnap] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    let lastY = window.scrollY;
    let dir: "down" | "up" = "down";
    let armed = true;
    const onScroll = () => {
      const y = window.scrollY;
      if (y > lastY) dir = "down";
      else if (y < lastY) dir = "up";
      lastY = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry) return;
        if (repeat && downOnly) {
          // Decided by scroll direction only, never by measured positions:
          // leaving the screen while scrolling UP means the card went out the
          // bottom (back to the section above) — only that re-arms it.
          if (!entry.isIntersecting) {
            if (dir === "up") {
              armed = true;
              setSnap(true);
              setVisible(false);
            }
            return;
          }
          // Any appearance while scrolling up shows the card instantly, no motion.
          if (dir === "up") {
            armed = false;
            setSnap(true);
            setVisible(true);
            return;
          }
          // Scrolling down from the section above: the only time it animates.
          if (armed && entry.intersectionRatio >= 0.18) {
            armed = false;
            setSnap(false);
            setVisible(true);
          }
          return;
        }
        if (!entry?.isIntersecting) {
          if (repeat) setVisible(false);
          return;
        }
        setVisible(true);
        if (!repeat) observer.disconnect();
      },
      { threshold: repeat && downOnly ? [0, 0.18] : 0.18 },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, [repeat, downOnly]);

  const content = (
    <div
      ref={repeat ? undefined : ref}
      id={id}
      className={cn("scroll-reveal", from === "left" && "scroll-reveal-from-left", from === "right" && "scroll-reveal-from-right", visible && "scroll-reveal-visible", snap && "scroll-reveal-snap", className)}
      style={{ transitionDelay: `${delay}ms`, ...style }}
    >
      {children}
    </div>
  );
  // Observe stationary layout, not the transform that can trigger itself.
  return repeat ? <div ref={ref}>{content}</div> : content;
}

