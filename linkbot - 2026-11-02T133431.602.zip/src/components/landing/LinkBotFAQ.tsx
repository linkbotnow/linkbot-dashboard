import { useState } from "react";

const FAQ_ITEMS = [
  {
    question: "How do links work?",
    answer:
      "Add unlimited links, documents and videos through url's, with custom labels for each button. Your labels tell your LinkBot what to share and when, so it comes up naturally. Asking about cost? It sends your pricing. Torn between two programs? It recommends the best fit and sends that link. Looking for a job? It shares your application. Each link pops up as a button they can open without ending the call, and documents save automatically to their device. Everything stays saved on their home screen for next time, where they can rename, delete, rearrange, or sort it into folders.",
  },

  {
    question: "Can I share to other social media profiles?",
    answer:
      "Not yet, for two reasons. First, other social media apps block voice inside their built-in browsers, so visitors who tap your link there won't be able to talk with your AI. Second, LinkBot's link protection is built for LinkedIn, where your private link stays hidden behind a visual card instead of showing as plain text. On other platforms it would show as a plain link anyone could copy and use to pretend to be you on a fake account. We're building that same protection for other platforms, and each one will be added as soon as it's ready.",
  },
  {
    question: "Can I put my LinkBot link in a LinkedIn post?",
    answer:
      "Yes. Sharing it in a post is a great way to get more people talking with your AI. Before you post, you must follow the post steps in your welcome guide exactly. If you skip them, your private link shows as plain text that anyone can copy and use. Also keep in mind that a popular post can bring many visitors at once, so if all 20 lines are in use at the same moment, new callers will see that the line is unavailable and will have to wait for a line to open up. Currently, we are building a new backup feature to fix this issue, so visitors can keep the conversation going even when every line is busy. We are excited to share that with you soon!",
  },
  {
    question: "Can I put LinkBot anywhere?",
    answer:
      "Not yet. We're currently building the ability to place LinkBot anywhere. Until the encrypted link protection for it is ready, we do not recommend it, since your link could be copied and used by others in identity fraud without your permission or knowledge.",
  },
  {
    question: "Can one LinkBot cover different websites?",
    answer:
      "Yes. You can add as many websites and documents as you'd like, so a single LinkBot can speak confidently about every company, brand, offer, service, and project you have, all from one bot. That way, it can give each visitor personal guidance on which option is the best fit for them.",
  },
  {
    question: "How many people can talk to my LinkBot at once?",
    answer:
      "Every voice AI service limits how many live conversations can happen at once, and most allow between 4 and 20 on standard plans. Your LinkBot handles up to 20, which is far more than it sounds: with a typical three minute conversation, around 400 people would need to start talking within one hour to fill every line. Even busy profiles usually don't hit the limit.",
  },
  {
    question: "Do visitors need to download anything or create an account?",
    answer:
      "No. Visitors just tap your link and start talking. There's nothing to install, no account to create, and no number to dial, so the conversation begins the moment they click on it.",
  },
  {
    question: "What happens when a visitor asks something it doesn't know?",
    answer:
      "Your LinkBot lets the visitor know you'll follow up with them personally, and their question is included in your conversation recap, so you can answer it yourself afterward.",
  },
  {
    question: "What gets sent to visitors, and when am I notified?",
    answer:
      "If a visitor asks for a recap during conversation, they receive an email with a summary and all their links shared. Since we captured their contact details, only then do we notify you. So every alert is a real lead, and you can send a personalized follow-up in one click to start the conversation and capture the lead. Nothing from you is ever sent without your approval.",
  },
  {
    question: "How does calendar booking work?",
    answer:
      "If your calendar connects with LinkBot, your AI books the meeting for them right in the conversation, just like a human assistant would, finding a time that works, confirming the details, and sending them a confirmation. If not, it shares your booking link so visitors can still book with you directly in that moment.",
  },
  {
    question: "Which calendars does LinkBot work with?",
    answer:
      "LinkBot connects with Google Calendar, Microsoft Outlook, Apple iCloud, and Calendly, and meetings can include Zoom or Microsoft Teams links. If you use a different calendar, your AI shares your booking link so visitors can still book with you directly on their own.",
  },
  {
    question: "Can I choose or change my AI's voice?",
    answer:
      "Yes. You choose a female or male voice when you sign up, and you can switch between them anytime from your dashboard, as often as you'd like, whenever you want a change.",
  },
  {
    question: "Can I use my own voice?",
    answer:
      "Not at this time. To keep setup seamless for every client, LinkBot offers a carefully selected female and male voice, so your AI sounds natural and professional from day one.",
  },
  {
    question: "Can I change my link name later?",
    answer:
      "Yes. You can change your link name or get a brand new private link anytime from your dashboard, and your updated link is sent to you right away, ready to place on your profile.",
  },
  {
    question: "Can I connect my own AI bot instead?",
    answer:
      "LinkBot works as one complete system: the AI, your private link, your dashboard, and your follow-ups are all built to work together, with dedicated capacity reserved for every visitor. That connection is what makes it work so well, so LinkBot runs only on its own AI.",
  },
  {
    question: "Can I have more than one LinkBot?",
    answer:
      "Yes. You can add as many AI employees as you'd like under the same login. Each one comes with its own easy to read dashboard, analytics, link, voice, and training, and each is billed as its own separate monthly subscription.",
  },
  {
    question: "Can I use one LinkBot on more than one account?",
    answer:
      "No. Each LinkBot comes with its own set of live talk lines, and sharing one across several profiles would split that capacity between all of them. We recommend a dedicated LinkBot for each account, so every profile has its full set of lines available and every visitor can start a conversation the moment they arrive.",
  },
  {
    question: "What happens if I cancel?",
    answer:
      "You can cancel anytime from your account. Your LinkBot keeps working through the end of the month you've already paid for, and you will not be charged again after that.",
  },
];

function ChevronIcon() {
  return (
    <svg className="pr-faq__chevron" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="m6 9 6 6 6-6"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function LinkBotFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
  <section id="faq" className="pr-faq">
      <div className="pr-faq__container">
        <p className="pr-faq__eyebrow">FAQ</p>
        <h2 className="pr-faq__title">
          Questions <span className="text-brand">Real CEOs Ask</span>
        </h2>

        <div className="pr-faq__list">
          {FAQ_ITEMS.map((item, index) => {
            const isOpen = openIndex === index;
            const triggerId = `pr-faq-trigger-${index}`;
            const panelId = `pr-faq-panel-${index}`;

            return (
              <article
                key={item.question}
                className={`pr-faq__item ${isOpen ? "pr-faq__item--open" : ""}`}
              >
                <h3 className="pr-faq__question-heading">
                  <button
                    id={triggerId}
                    type="button"
                    className="pr-faq__trigger"
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                  >
                    <span className="pr-faq__question">{item.question}</span>
                    <ChevronIcon />
                  </button>
                </h3>

                <div
                  id={panelId}
                  role="region"
                  aria-labelledby={triggerId}
                  aria-hidden={!isOpen}
                  className="pr-faq__panel"
                >
                  <div className="pr-faq__panel-inner">
                    <p className="pr-faq__answer">{item.answer}</p>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}