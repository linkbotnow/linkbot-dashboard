import { useLayoutEffect, useRef } from "react";
import { Check, FileText, MessageSquareText, Mic, Send, ShieldCheck, Signal } from "lucide-react";

interface Feature { title: string; body: string; ipadBody?: string; desktopBody?: string; mobileBody: string; }

export const FEATURES: Feature[] = [
  { title: "Unlimited Voice AI ", body: "Unlimited talk time lets every conversation flow naturally, giving visitors the freedom to talk for as long as they need.", desktopBody: "Unlimited talk time lets every conversation\nflow naturally, giving visitors the freedom to\ntalk for as long as they need.", mobileBody: "Unlimited talk time lets every conversation flow naturally, giving visitors the freedom to talk for as long as they need to get answers." },
  { title: "AI That Gets Noticed", body: "Our AI stands out visually with a large clear invitation to talk instead of another easy-to-miss link.", ipadBody: "Our AI stands out\nvisually with a large clear\ninvitation to talk instead\nof another easy-to-miss link.", desktopBody: "Our AI stands out visually with a large\nclear invitation to talk instead of another\neasy-to-miss link.", mobileBody: "Our AI stands out visually with a large clear invitation to talk instead of another easy-to-miss link, so visitors actually start talking to it." },
  { title: "Feels Like a Real Call", body: "More Human Than Bot! Realistic voice, natural reactions and fluid conversation make visitors forget they're talking to AI.", desktopBody: "More Human Than Bot! Realistic voice,\nnatural reactions and fluid conversation\nmake visitors forget they're talking to AI.", mobileBody: "More Human Than Bot! Realistic voice, natural reactions and fluid conversation make visitors forget they're talking to AI." },
  { title: "Smart Conversations", body: "Understands why each visitor is there and naturally adapts the conversation around exactly what they need.", desktopBody: "Understands why each visitor is there\nand naturally adapts the conversation\naround exactly what they need.", mobileBody: "Understands why each visitor is there and naturally adapts the conversation around exactly what they need from you." },
  { title: "Trained On You", body: "Automatically learns from any website and portfolio, then builds knowledge from your company and offers plus anything else you upload and want it to know.", ipadBody: "Automatically learns from any website\nand portfolio, then builds knowledge from\nyour company and offers plus anything\nelse you upload and want it to know.", desktopBody: "Automatically learns from any website and portfolio,\nthen builds knowledge from your company and offers \nplus anything else you upload and want it to know.", mobileBody: "Automatically learns from any website and portfolio, then builds knowledge from your company and offers plus anything else you upload and want it to know." },
  { title: "Interactive Sharing", body: "Shares relevant links for offers, videos, documents, portfolios, case studies, and more naturally throughout the conversation.", desktopBody: "Shares relevant links for offers, videos, \ndocuments, portfolios, case studies, and \nmore naturally throughout the conversation.", mobileBody: "Shares relevant links for offers, videos, documents, portfolios, case studies, and more naturally throughout the conversation." },
  { title: "Speaks Their Language", body: "Multilingual voice agent that automatically adapts to different languages, for conversations with visitors around the world.", desktopBody: "Multilingual voice agent that automatically\nadapts to different languages, for conversations\nwith visitors around the world.", mobileBody: "Multilingual voice agent that automatically adapts to different languages, for conversations with visitors around the world." },
  { title: "Automatic Lead Capture", body: "Turns every conversation into a contact with their details and conversation history saved and ready when you need it.", desktopBody: "Turns every conversation into a contact\nwith their details and conversation history\nsaved and ready when you need it.", mobileBody: "Turns every conversation into a contact with their details and conversation history saved and ready when you need it." },
  { title: "Qualified Pipeline", body: "Places every lead into a clear pipeline stage, so the conversations worth your time naturally rise to the top.", desktopBody: "Places every lead into a clear pipeline\nstage, so the conversations worth your\ntime naturally rise to the top.", mobileBody: "Places every lead into a clear pipeline stage, so the conversations worth your time naturally rise to the top." },
  { title: "Calendar Integration", body: "Moves qualified prospects directly from conversation to your calendar, so they can book without waiting for you.", ipadBody: "Moves qualified prospects directly\nfrom conversation to your calendar, so\nthey can book without waiting for you.", desktopBody: "Moves qualified prospects directly from\nconversation to your calendar, so they can\nbook without waiting for you.", mobileBody: "Moves qualified prospects directly from conversation to your calendar, so they can book without waiting for your reply." },
  { title: "Instant Notifications", body: "Notifies you after each lead with the visitor's info, interest and a quick recap.", desktopBody: "Notifies you after each lead\nwith the visitor's info,\ninterest and a quick recap.", mobileBody: "Notifies you after each lead with the visitor's info, interest and a quick recap." },
  { title: "Conversation Summaries", body: "Shows what was asked, answered and discussed, so every follow-up starts with real context instead of a guess.", desktopBody: "Shows what was asked, answered and\ndiscussed, so every follow-up starts\nwith real context instead of a guess.", mobileBody: "Shows what was asked, answered and discussed, so every follow-up starts with real context instead of a blind guess." },
  { title: "One Tap Follow Up", body: "Creates a personalized message from the actual conversation, so you can review it and send it in seconds.", ipadBody: "Creates a personalized\nmessage from the actual\nconversation, so you can\nreview it and send it in seconds.", desktopBody: "Creates a personalized\nmessage from the actual\nconversation, so you can\nreview it and send it in seconds.", mobileBody: "Creates a personalized message from the actual conversation, so you can review and send it in just seconds, no typing needed." },
  { title: "Always Working", body: "Keeps conversations moving and your pipeline filling while you're busy in meetings, on calls, offline or asleep.", desktopBody: "Keeps conversations moving and your pipeline filling\nwhile you're busy in meetings, on calls, offline or asleep.", mobileBody: "Keeps conversations moving and your pipeline filling while you're busy in meetings, on calls, offline or asleep." },
  { title: "Automated Setup", body: "Answer a few simple questions and you're ready to go, with no developers, complicated integrations or learning curve.", ipadBody: "Answer a few simple questions and you're\nready to go, with no developers, complicated\nintegrations or learning curve.", desktopBody: "Answer a few simple questions and you're ready to\ngo, with no developers, complicated integrations or\nlearning curve.", mobileBody: "Answer a few simple questions and you're ready to go, with no developers, complicated integrations or learning curve." },
];

export const FEATURE_STAGGER = [
  { justify: "center", width: "w-[78%]", offset: "" },
  { justify: "end", width: "w-[72%]", offset: "mr-[6%]" },
  { justify: "start", width: "w-[76%]", offset: "ml-[4%]" },
  { justify: "end", width: "w-[70%]", offset: "mr-[10%]" },
  { justify: "start", width: "w-[80%]", offset: "ml-[8%]" },
  { justify: "end", width: "w-[74%]", offset: "mr-[3%]" },
  { justify: "start", width: "w-[68%] sm:w-[76%]", offset: "ml-[12%]" },
  { justify: "end", width: "w-[78%]", offset: "mr-[5%]" },
  { justify: "start", width: "w-[82%]", offset: "ml-[2%]" },
  { justify: "end", width: "w-[66%] sm:w-[76%]", offset: "mr-[14%]" },
  { justify: "start", width: "w-[74%]", offset: "ml-[9%]" },
  { justify: "end", width: "w-[76%]", offset: "mr-[7%]" },
  { justify: "start", width: "w-[78%]", offset: "ml-[5%]" },
  { justify: "start", width: "w-[80%]", offset: "ml-[3%]" },
  { justify: "end", width: "w-[74%]", offset: "mr-[9%]" },
];

export const FEATURE_LABELS = [
  "LIVE VOICE", "HIGH VISIBILITY", "NATURAL VOICE", "ADAPTIVE DIALOGUE", "BUSINESS INTELLIGENCE",
  "RESOURCE ENGINE", "GLOBAL REACH", "LEAD CAPTURE", "PIPELINE READY", "DIRECT BOOKING",
  "INSTANT ALERT", "FULL CONTEXT", "READY TO SEND", "ALWAYS ON", "DONE FOR YOU",
];

export function FeatureBannerGraphic({ index }: { index: number }) {
  const art = [
    <div className="feature-scene scene-plancard"><div className="plan-card"><span className="plan-head">VOICE PLAN</span><p><small>Talk time</small><b>∞</b></p><p><small>Conversations</small><b>∞</b></p><p><small>Overage fees</small><b>None</b></p></div></div>,
    <div className="feature-scene scene-invite"><div className="invite-rings"><i /><i /><i /></div><div className="invite-pill"><Mic /><span>TALK TO MY AI</span></div></div>,
    <div className="feature-scene scene-quote"><div className="quote-bubble"><span>“Wait — am I talking to a real person?”</span><small>— actual visitor</small></div></div>,
    <div className="feature-scene scene-bubbles"><span className="bubble-in">What do you charge?</span><span className="bubble-out">Depends on your goal — tell me more.</span></div>,
    <div className="feature-scene scene-brand"><div className="brand-ring"><ShieldCheck /></div><span className="scene-label">YOUR BUSINESS</span></div>,
    <div className="feature-scene scene-sources"><div className="source-list"><p><FileText />Website<b><Check /></b></p><p><FileText />Documents<b><Check /></b></p><p><FileText />Case studies<b><Check /></b></p></div></div>,
    <div className="feature-scene scene-langs"><span>Hello</span><span className="lang-live">Hola</span><span>Bonjour</span></div>,
    <div className="feature-scene scene-lead"><div className="lead-card"><p><small>Name</small><b>Jordan M.</b></p><p><small>Email</small><b>jordan@acme.com</b></p><p><small>Interest</small><b>Job Hire</b></p><i className="lead-saved"><Check />SAVED</i></div></div>,
    <div className="feature-scene scene-chips"><span>New</span><span>Qualified</span><span className="chip-live">Ready to book</span></div>,
    <div className="feature-scene scene-calendar"><div className="calendar-sheet"><span>OCTOBER</span><b>18</b><small>10:30 AM</small></div><div className="calendar-confirm"><Check /><span>BOOKED</span></div></div>,
    <div className="feature-scene scene-ping"><div className="ping-bubble"><MessageSquareText /><span>New lead</span><i /></div></div>,
    <div className="feature-scene scene-notes"><div className="note-card"><p><Check />Asked pricing</p><p><Check /><span className="note-ready-keep">Ready this month</span><span className="note-ready-new">Ready to buy</span></p><p><Check />Follow up</p></div></div>,
    <div className="feature-scene scene-send"><div className="send-circle"><Send /></div><span className="scene-label">ONE TAP</span></div>,
    <div className="feature-scene scene-always"><div className="always-clock"><span>24</span><i>/</i><span>7</span></div><div className="always-status"><i /><b>ONLINE</b><small>Every visitor covered</small></div><div className="always-orbit"><i /><i /></div></div>,
    <div className="feature-scene scene-steps"><i className="step-line" /><span><Check /></span><span><Check /></span><span className="step-live"><Signal /></span></div>,
  ][index];

  return <div className="feature-banner-art" aria-hidden="true">{art}</div>;
}

export const REVIEWS = [
  { name: "Alex", timeAgo: "Verified", quote: "I was not expecting this much usage, but it is a lead magnet. Was easy to set up, and knowing what happened with every lead is a game changer! I'm loving it!" },
  { name: "Jordan", timeAgo: "Verified", quote: "My LinkedIn profile used to get some leads, but not this many. This AI has truly impressed me. How human it sounds is unreal! You need to try it." },
  { name: "Maya", timeAgo: "Verified", quote: "I was getting profile views but no dm conversations. Now this feels like a personal dm conversation, but with less pressure." },
  { name: "Chris", timeAgo: "Verified", quote: "The best part is how easy it is to find. It sits right there on my profile. Someone can click, ask a question, and boom, I have a qualified lead." },
  { name: "Taylor", timeAgo: "Verified", quote: "I posted my link on my LinkedIn post and got three qualified conversations that same day. Very happy with my bot." },
  { name: "Sam", timeAgo: "Verified", quote: "My profile feels alive now. Instead of just reading about me, people actually can get answers right away. The interaction alone makes me memorable." },
  { name: "Morgan", timeAgo: "Verified", quote: "I used to rely on DMs that went nowhere. Now when someone visits my profile they get instant answers and I get their contact info. Game changer." },
  { name: "Jamie", timeAgo: "Verified", quote: "The LinkedIn app browser thing actually works. It is not just a random link sitting there like others, the call to action is in your face, and I actually get people clicking it." },
  { name: "Casey", timeAgo: "Verified", quote: "Profile views that felt wasted, can now turn into a real conversation. I am getting leads from traffic I already had." },
  { name: "Riley", timeAgo: "Verified", quote: "I sound more accessible without doing more work. My link does the talking, captures the intent, and tells me who is serious. It paid for itself!" },
];

export const REVIEW_STAGGER = [
  "ml-0 w-[94%]",
  "ml-[3%] w-[94%]",
  "ml-[6%] w-[94%]",
  "ml-[3%] w-[94%]",
  "ml-0 w-[94%]",
  "ml-[3%] w-[94%]",
  "ml-[6%] w-[94%]",
  "ml-[3%] w-[94%]",
  "ml-0 w-[94%]",
  "ml-[3%] w-[94%]",
];

/**
 * Mobile-only: keeps a line of text on a single row by shrinking its font size
 * until it fits the space beside the check icon. Desktop is untouched.
 */
export function FitOneLine({ text, className }: { text: string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fit = () => {
      if (window.visualViewport && window.visualViewport.scale !== 1) return;
      if (window.innerWidth >= 640) {
        el.style.fontSize = "";
        el.style.whiteSpace = "";
        el.style.flex = "";
        el.style.minWidth = "";
        return;
      }
      el.style.fontSize = "";
      el.style.whiteSpace = "nowrap";
      el.style.flex = "1 1 0%";
      el.style.minWidth = "0";
      const base = parseFloat(getComputedStyle(el).fontSize);
      const avail = el.clientWidth;
      const w = el.scrollWidth;
      if (avail > 0 && w > avail) el.style.fontSize = `${(base * avail) / w}px`;
    };
    fit();
    // One refinement pass once the new size has settled.
    const raf = requestAnimationFrame(() => {
      if (window.innerWidth >= 640) return;
      const avail = el.clientWidth;
      const w = el.scrollWidth;
      const cur = parseFloat(el.style.fontSize || "");
      if (avail > 0 && w > avail && cur) el.style.fontSize = `${(cur * avail) / w}px`;
    });
    window.addEventListener("resize", fit);
    document.fonts?.ready.then(fit).catch(() => {});
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", fit);
    };
  }, [text]);
  return <span ref={ref} className={className}>{text}</span>;
}

export const STATS = [
  { value: 39, suffix: "%", label: "of buying conversations start outside normal business hours.", source: "Salesloft", href: "https://www.salesloft.com/resources/guides/conversational-ai-marketing-trends-report" },
  { value: 41, suffix: "%", label: "of booked meetings come from chats held outside normal business hours.", source: "Salesloft", href: "https://www.salesloft.com/resources/guides/conversational-ai-marketing-trends-report" },
  { value: 7, suffix: "×", label: "more leads qualify when answers arrive inside the first hour.", source: "Harvard Business Review", href: "https://hbr.org/2011/03/the-short-life-of-online-sales-leads" },
];
