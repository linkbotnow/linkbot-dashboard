import { HoverlessLink } from "@/components/navigation/HoverlessLink";

const ITEMS: Array<[string, string]> = [
  ["File & Resource Uploads", "Upload files & resources for your AI to learn from and use in real time."],
  ["Calendar Integration", "Turns qualified conversations into a real appointment on your calendar."],
  ["Automated Follow-Up", "One click ready to send personalized follow-ups after each real lead."],
  ["Central Dashboard", "Manage conversations, leads and activity together all in one simple place."],
  ["No-Code Updates", "Update your AI anytime without coding or rebuilding anything, we do the hard stuff."],
  ["App + Desktop", "Works seamlessly whether visitors arrive from their phone, iPad or computer."],
];

/** White pricing card (prompt 303). Desktop/iPad design width 480px, phone 358px. */
export function PricingCardNew({ phone = false }: { phone?: boolean }) {
  return (
    <div className={phone ? "pc2 pc2--phone" : "pc2"}>
      <div className="pc2-frame">
        <div className="pc2-mark"><b>NO</b>Contract</div>
        <div className="pc2-card">
          <div className="pc2-ban">
            <div className="pc2-eyebrow">PRICING</div>
            <div className="pc2-title">AI Voice Employee</div>
            <div className="pc2-priceRow">
              <div className="pc2-price"><span className="pc2-s">$</span>359</div>
              <div className="pc2-per">/month</div>
            </div>
          </div>
          <ul className="pc2-list">
            {ITEMS.map(([t, b]) => (
              <li key={t}>
                <span className="pc2-chk">
                  <svg viewBox="0 0 12 12" fill="none" stroke="#1a54f0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2.5 6.3 5 8.6 9.6 3.5" /></svg>
                </span>
                <span><b>{t}</b>: {!phone && t === "No-Code Updates" ? "Update your AI anytime without coding or rebuilding anything, we do the hard stuff." : b}</span>
              </li>
            ))}
          </ul>
          <div className="pc2-cta">
            <HoverlessLink to="/claim" className="linkbot-button pc2-btn">
              <span>Get My AI Voice Employee <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 8h10M9 4l4 4-4 4" /></svg></span>
            </HoverlessLink>
          </div>
        </div>
      </div>
    </div>
  );
}
