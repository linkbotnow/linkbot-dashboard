import { motion } from "motion/react";
import { useEffect, useRef, useState, type RefObject } from "react";
import {
  ArrowDown,
  ArrowRight,
  Bell,
  Check,
  FileText,
  Globe2,
  MessageCircleMore,
  Mic2,
  Search,
  Send,
  UserRoundX,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { useZoomLightMotion } from "@/lib/zoom-light-motion";

const STANDARD_STEPS = [
  { icon: Globe2, title: "Lands on a website", detail: "Another page to navigate" },
  { icon: Search, title: "Searches for an answer", detail: "Interest starts to cool" },
  { icon: FileText, title: "Finds a form or inbox", detail: "The conversation waits" },
];

const LINKBOT_STEPS = [
  { icon: Mic2, title: "Starts talking", detail: "A natural voice conversation" },
  { icon: MessageCircleMore, title: "Gets clear answers", detail: "Trained on your business" },
  { icon: Check, title: "Becomes a qualified lead", detail: "Details captured automatically" },
];

/**
 * Down-scroll-only reveal: the element animates in only when it enters the
 * viewport while the user is scrolling DOWN. Entering while scrolling up
 * snaps it visible instantly (never blank, never replayed).
 */
function useDownScrollShow<T extends HTMLElement>(threshold: number): { ref: RefObject<T | null>; state: "hidden" | "show" | "snap" } {
  const ref = useRef<T>(null);
  const [state, setState] = useState<"hidden" | "show" | "snap">("hidden");

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    let lastY = window.scrollY;
    let dir: "down" | "up" = "down";
    const onScroll = () => {
      const y = window.scrollY;
      if (y > lastY) dir = "down";
      else if (y < lastY) dir = "up";
      lastY = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) {
          setState("hidden");
          return;
        }
        setState(dir === "up" ? "snap" : "show");
      },
      { threshold },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, [threshold]);

  return { ref, state };
}

export function LinkBotQuestions({
  onStartDemo,
  sectionRef,
}: {
  onStartDemo: () => void;
  sectionRef?: RefObject<HTMLElement | null>;
}) {
  useZoomLightMotion();
  const headerReveal = useDownScrollShow<HTMLElement>(0.7);
  const originReveal = useDownScrollShow<HTMLDivElement>(0.2);
  const standardReveal = useDownScrollShow<HTMLElement>(0.08);
  const linkbotReveal = useDownScrollShow<HTMLElement>(0.08);

  return (
    <section ref={sectionRef} className="pr-questions-section layer-scroll-next" aria-labelledby="link-comparison-heading">
      <div className="section-banner-strip">
        <span className="section-banner-strip-text">Why LinkBot</span>
      </div>
      <div className="pr-questions-container pr-comparison-container">
        <motion.header
          ref={headerReveal.ref}
          className="pr-comparison-header"
          initial={{ opacity: 0, y: 18 }}
          animate={headerReveal.state === "hidden" ? { opacity: 0, y: 18 } : { opacity: 1, y: 0 }}
          transition={headerReveal.state === "snap" ? { duration: 0 } : { duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="pr-questions-eyebrow">THE LINKBOT DIFFERENCE</p>
          <h2 id="link-comparison-heading" className="headline mt-3 text-balance text-5xl text-ink">
            <span className="block">One profile click.</span>
            <span className="block">Two <span className="text-brand">very different outcomes</span>.</span>
          </h2>
          
        </motion.header>

        <motion.div
          ref={originReveal.ref}
          className="pr-comparison-origin"
          aria-hidden="true"
          initial={{ opacity: 0, y: 18 }}
          animate={originReveal.state === "hidden" ? { opacity: 0, y: 18 } : { opacity: 1, y: 0 }}
          transition={originReveal.state === "snap" ? { duration: 0 } : { duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <span>LinkedIn profile</span>
          <ArrowDown className="" />
        </motion.div>

        <div className="pr-comparison-grid">
          <motion.article
            ref={standardReveal.ref}
            className="pr-comparison-card pr-comparison-card-standard"
            initial="hidden"
            animate={standardReveal.state}
            variants={{
              hidden: { opacity: 0, x: -52 },
              show: { opacity: 1, x: 0, transition: { duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] } },
              snap: { opacity: 1, x: 0, transition: { duration: 0 } },
            }}
          >
            <div className="pr-comparison-card-head">
              <span className="pr-comparison-label">Normal link</span>
              <span className="pr-comparison-status pr-comparison-status-muted"><span /> Passive Visit</span>
            </div>
            <div className="pr-comparison-journey">
              {STANDARD_STEPS.map((step, index) => (
                <motion.div
                  className="pr-comparison-step"
                  key={step.title}
                  variants={{
                    hidden: { opacity: 0, y: 12 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.4, delay: 0.38 + index * 0.14 } },
                    snap: { opacity: 1, y: 0, transition: { duration: 0 } },
                  }}
                >
                  <span className="pr-comparison-step-icon"><step.icon aria-hidden="true" /></span>
                  <span><strong>{step.title}</strong><small>{step.detail}</small></span>
                  {index < STANDARD_STEPS.length - 1 && <ArrowDown className="pr-comparison-arrow" aria-hidden="true" />}
                </motion.div>
              ))}
            </div>
            <div className="pr-comparison-outcome pr-comparison-outcome-muted">
              <UserRoundX aria-hidden="true" />
              <span><strong>Visitor Leaves Unknown</strong><small>No context. No captured conversation.</small></span>
            </div>
          </motion.article>

          <div className="pr-comparison-vs" aria-hidden="true"><span>VS</span></div>

          <motion.article
            ref={linkbotReveal.ref}
            className="pr-comparison-card pr-comparison-card-linkbot"
            initial="hidden"
            animate={linkbotReveal.state}
            variants={{
              hidden: { opacity: 0, x: 52 },
              show: { opacity: 1, x: 0, transition: { duration: 0.72, delay: 0.2, ease: [0.16, 1, 0.3, 1] } },
              snap: { opacity: 1, x: 0, transition: { duration: 0 } },
            }}
          >
            <div className="pr-comparison-glow" aria-hidden="true" />
            <div className="pr-comparison-card-head">
              <span className="pr-comparison-label pr-comparison-label-brand">LinkBot link</span>
              <span className="pr-comparison-status pr-comparison-status-live"><span /> Live Conversation</span>
            </div>
            <div className="pr-comparison-journey pr-comparison-journey-live">
              {LINKBOT_STEPS.map((step, index) => (
                <motion.div
                  className="pr-comparison-step"
                  key={step.title}
                  variants={{
                    hidden: { opacity: 0, y: 12 },
                    show: { opacity: 1, y: 0, transition: { duration: 0.4, delay: 0.38 + index * 0.14 } },
                    snap: { opacity: 1, y: 0, transition: { duration: 0 } },
                  }}
                >
                  <span className="pr-comparison-step-icon"><step.icon aria-hidden="true" /></span>
                  <span><strong>{step.title}</strong><small>{step.detail}</small></span>
                  {index < LINKBOT_STEPS.length - 1 && <ArrowDown className="pr-comparison-arrow" aria-hidden="true" />}
                </motion.div>
              ))}
            </div>
            <div className="pr-comparison-outcome pr-comparison-outcome-live">
              <span className="pr-comparison-rings" aria-hidden="true"><Bell /></span>
              <span><strong>Real Conversation &amp; Lead Capture</strong><small>Contact details, full summary and a message ready to send.</small></span>
              <Send aria-hidden="true" />
            </div>
          </motion.article>
        </div>
        <button
          type="button"
          className={cn(
            "linkbot-button",
            "mobile-home-cta-questions mt-12",
          )}
          onClick={onStartDemo}
        >
          <span className="flex items-center gap-2">Hear My Live Demo <ArrowRight className="h-4 w-4" aria-hidden="true" /></span>
        </button>
      </div>
    </section>
  );
}
