import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { pinPhoneTop } from "@/lib/phone-top-pin";
import { createPortal } from "react-dom";
import { FooterLegalLink } from "@/components/legal/LegalModal";
import { FitLine } from "@/components/FitLine";
import { Button } from "@/components/ui/button";
import { ClaimOrderAside } from "@/components/claim/ClaimOrderAside";
import { BadgeCheck, Check, Clock, CreditCard, Lock } from "lucide-react";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { useServerFn } from "@tanstack/react-start";
import { storeClaimVoice, type ClaimOrder } from "@/lib/claim-order";
import { checkVoiceAccess, submitVoiceChoice } from "@/lib/voice-choice.functions";
import { releasePassHold } from "@/lib/claim.functions";

type Voice = "female" | "male";

// GHL checkout page the voice step sends customers to (same tab).
const GHL_CHECKOUT_URL = "https://connect.linkbot.now/payment-link/6aade7a2f426560dbc2f11dd";

const GHL_VISITED_KEY = "linkbot.claim.ghlVisited";
function markGhlVisited() {
  try {
    window.sessionStorage.setItem(GHL_VISITED_KEY, "1");
  } catch {
    /* storage unavailable */
  }
}

// Last voice + account details the GHL webhook was successfully sent for, kept
// for this browser tab only (same storage as the "been to GHL" note). Used to
// skip re-sending the webhook when the customer picks the same voice again
// with unchanged details after returning from the GHL checkout page.
const VOICE_SENT_KEY = "linkbot.claim.voiceSent";
type VoiceSentRecord = { voice: Voice; details: string };
function readVoiceSent(): VoiceSentRecord | null {
  try {
    const raw = window.sessionStorage.getItem(VOICE_SENT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<VoiceSentRecord>;
    if ((parsed.voice === "female" || parsed.voice === "male") && typeof parsed.details === "string") {
      return parsed as VoiceSentRecord;
    }
    return null;
  } catch {
    return null;
  }
}
function markVoiceSent(record: VoiceSentRecord) {
  try {
    window.sessionStorage.setItem(VOICE_SENT_KEY, JSON.stringify(record));
  } catch {
    /* storage unavailable */
  }
}

const VOICE_CARDS: Array<{ voice: Voice; title: string }> = [
  { voice: "male", title: "Male Voice" },
  { voice: "female", title: "Female Voice" },
];
const VOICE_SAMPLES = {
  female: "/api/public/voice-sample/female",
  male: "/api/public/voice-sample/male",
};
const VOICE_WAVE = [30,55,80,45,95,60,35,70,100,50,75,40,85,55,30,65,90,45,70,35,55,80];

// Bars keep 4px width + 4px gap; count fills the play bar up to the text gap and ends on a short bar.
function waveBarCount(waveWidth: number, phone: boolean) {
  const room = waveWidth - (phone ? 12 : 24) + 8;
  let n = Math.max(1, Math.floor((room + 4) / 8));
  while (n > 1 && (VOICE_WAVE[(n - 1) % VOICE_WAVE.length] ?? 0) >= 50) n--;
  return n;
}

const VC_BUBBLE_CSS = `
.vc-page{min-height:calc((100dvh - var(--site-header-height,72px))/var(--desktop-page-scale,1));}
.vc-row{padding:22px 24px;border:2px solid transparent;border-radius:1rem;background:var(--surface-2);display:grid;grid-template-columns:28px 260px minmax(0,1fr);align-items:center;gap:20px;cursor:pointer;min-height:152px;}
.vc-row[aria-checked="true"]{border-color:var(--linkbot-blue);background:color-mix(in oklab,var(--surface-2) 94%,var(--linkbot-blue));}
.vc-select{width:28px;height:28px;flex:none;border-radius:50%;border:2px solid var(--vc-select-border);background:var(--surface);display:flex;align-items:center;justify-content:center;padding:0;}
.vc-row[aria-checked="true"] .vc-select{border-color:var(--linkbot-blue);background:var(--linkbot-blue);color:var(--surface);}
.vc-name{font-size:21px;font-weight:900;white-space:nowrap;}
.vc-text{width:260px;min-width:0;}
.vc-desc{margin-top:4px;font-size:15px;color:var(--muted-foreground);white-space:nowrap;}
.vc-player{min-width:0;}
.vc-play{position:relative;display:flex;align-items:center;gap:8px;width:100%;height:52px;padding:0 18px 0 6px;border-radius:999px;background:var(--surface);border:1px solid var(--vc-player-border);box-shadow:var(--shadow-elev-1);cursor:pointer;}
.vc-play-ic{flex:none;width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--surface);background:linear-gradient(180deg,var(--brand-bright),var(--linkbot-blue));}
.vc-play-ic svg{width:15px;height:15px;}
.vc-wave{flex:1;min-width:0;display:flex;align-items:center;gap:4px;height:22px;overflow:hidden;}
.vc-wave i{flex:0 0 4px;border-radius:9px;background:var(--brand-light);transform-origin:center;}
@keyframes vc-wave-move{0%,100%{transform:scaleY(1);}50%{transform:scaleY(.4);}}
.vc-wave.is-playing i{animation:vc-wave-move .9s ease-in-out infinite;}
.vc-wave.is-playing i:nth-child(3n+1){animation-delay:-.3s;}
.vc-wave.is-playing i:nth-child(3n+2){animation-delay:-.6s;}
.vc-play-tx{flex:none;font:700 11px/1 var(--font-sans);text-transform:uppercase;letter-spacing:.08em;color:var(--muted-foreground);}
.vc-congrats{grid-column:1/-1;width:100%;text-align:center;font-size:32px;line-height:.95;}
.vc-congrats-line{display:inline-block;white-space:nowrap;}
.vc-congrats-letter{display:inline-block;animation:vc-letter-wave .5s ease-in-out var(--vc-letter-delay) 1 both!important;}
@keyframes vc-letter-wave{0%,100%{transform:translateY(0) scale(1);}50%{transform:translateY(-.22em) scale(1.22);}}
.vc-congrats-word{display:inline-block;transform-origin:50% 60%;animation:vc-word-pop .55s cubic-bezier(.3,1.5,.5,1) .85s 1 both!important;}
.vc-congrats-step{animation-delay:1.25s!important;}
@keyframes vc-word-pop{0%,100%{transform:scale(1);}50%{transform:scale(1.32);}}
.vc-confirm[disabled]{opacity:.55;cursor:not-allowed;transform:none;filter:none;pointer-events:auto;}
body.claim-ipad-layout .vc-confirm,body.claim-desktop-layout .vc-confirm{height:3.11875rem;min-height:3.11875rem;font-size:.84875rem;}
body.claim-ipad-layout .vc-bottom-row,body.claim-desktop-layout .vc-bottom-row{position:absolute;left:2.5rem;right:2.5rem;bottom:1.75rem;margin-top:0;padding-top:1.75rem;}
body.claim-desktop-layout .vc-bottom-row{bottom:4.05rem;padding-top:3rem;}
.vc-actions{margin-top:34px;}
.vc-lock-note{margin-top:16px;}
@media(min-width:640px){.vc-phone-back{display:none;}}
@media(max-width:639px){
.vc-page{min-height:calc(100dvh - 72px)!important;}
.vc-page .claim-grid{padding-top:28px;padding-bottom:32px;}
.vc-page .claim-grid>aside,.vc-bottom-row{display:none;}
.vc-phone-back{display:flex;justify-content:flex-end;}
.vc-heading{margin-top:28px;}
.vc-rows{margin-top:44px;}
.vc-row{min-height:0;grid-template-columns:28px minmax(0,1fr);}
.vc-text{width:100%;}
.vc-player{grid-column:1/-1;}
.vc-lock-note{justify-content:flex-start;text-align:left;align-items:flex-start;}
.vc-lock-note svg{flex:none;margin-top:2px;}
.vc-lock-text{flex:1;line-height:1.4;}
.vc-congrats{font-size:32px;}
.vc-congrats-line{display:block;width:max-content;margin-inline:auto;}
.vc-congrats-space{display:none;}
}
`;

function CongratsWave() {
  const ref = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const box = ref.current;
    if (!box) return;
    const fit = () => {
      box.style.fontSize = "";
      const lines = Array.from(box.querySelectorAll<HTMLElement>(".vc-congrats-line"));
      const phone = window.matchMedia("(max-width:639px)").matches;
      let size = parseFloat(getComputedStyle(box).fontSize);
      const width = () => phone
        ? Math.max(...lines.map(line => line.offsetWidth))
        : lines.reduce((sum, line) => sum + line.offsetWidth, 0) + (box.querySelector<HTMLElement>(".vc-congrats-space")?.offsetWidth ?? 0);
      while (width() * 1.32 > box.clientWidth && size > 1) {
        size -= .1;
        box.style.fontSize = `${size}px`;
      }
    };
    fit();
    const observer = new ResizeObserver(fit);
    observer.observe(box);
    let mounted = true;
    document.fonts.ready.then(() => { if (mounted) fit(); });
    return () => { mounted = false; observer.disconnect(); };
  }, []);
  return <div ref={ref} className="vc-congrats font-display font-black uppercase text-brand" aria-label="CONGRATS! LAST STEP.">
    <span className="vc-congrats-line" aria-hidden="true">{Array.from("CONGRATS", (character, index) => <span key={index} className="vc-congrats-letter" style={{ "--vc-letter-delay": `${index * .05}s` } as React.CSSProperties}>{character}</span>)}!</span>
    <span className="vc-congrats-space" aria-hidden="true"> </span>
    <span className="vc-congrats-line" aria-hidden="true"><span className="vc-congrats-word">LAST</span>{" "}<span className="vc-congrats-word vc-congrats-step">STEP</span>.</span>
  </div>;
}

/** Approved "Double firework" canvas, portaled beyond the scaled page canvas. */
type FireworkPart = { x: number; y: number; vx: number; vy: number; color: string; shape: string; w: number; h: number; rot: number; vr: number; tilt: number; vt: number; wob: number; vw: number; g: number; age: number; life: number };
function FireworkCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const colors = ['#1a54f0','#5b82f5','#22c55e','#f59e0b','#ef4444','#a855f7','#ec4899'];
    const parts: FireworkPart[] = [];
    let raf = 0;
    const size = () => { const dpr = window.devicePixelRatio || 1; canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr; };
    size();
    window.addEventListener("resize", size);
    function burst(count: number, speed: number) {
      const cx = innerWidth / 2, cy = innerHeight / 2;
      const k = Math.max(innerWidth, innerHeight) / 844;
      const n = Math.round(count * Math.max(1, k));
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2, v = speed * k * (0.55 + Math.random() * 0.85);
        const shape = Math.random() < 0.5 ? 'sq' : 'strip';
        parts.push({ x: cx, y: cy, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 3 * k, color: colors[i % colors.length]!, shape,
          w: shape === 'strip' ? 4.5 : 6.5, h: shape === 'strip' ? 17 : 6.5,
          rot: Math.random() * Math.PI * 2, vr: (Math.random() - .5) * 0.35,
          tilt: Math.random() * Math.PI * 2, vt: 0.08 + Math.random() * 0.18,
          wob: Math.random() * 10, vw: 0.05 + Math.random() * 0.08, g: 0.3 * k, age: 0, life: 190 * (0.8 + Math.random() * 0.4) });
      }
    }
    const frame = () => {
      const dpr = window.devicePixelRatio || 1;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]!;
        p.age++; p.vx *= 0.965; p.vy = p.vy * 0.965 + p.g; p.wob += p.vw;
        p.x += p.vx + Math.cos(p.wob) * 0.6; p.y += p.vy; p.rot += p.vr; p.tilt += p.vt;
        if (p.age >= p.life || p.y > innerHeight + 60) { parts.splice(i, 1); continue; }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.globalAlpha = Math.max(0, Math.min(1, (p.life - p.age) / 30));
        ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.scale(1, Math.cos(p.tilt));
        ctx.fillStyle = p.color; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      }
      ctx.globalAlpha = 1;
      raf = parts.length ? requestAnimationFrame(frame) : 0;
    };
    const run = () => { if (!raf) raf = requestAnimationFrame(frame); };
    burst(120, 22); run();
    const second = window.setTimeout(() => { burst(120, 27); run(); }, 350);
    return () => { window.clearTimeout(second); cancelAnimationFrame(raf); window.removeEventListener("resize", size); };
  }, []);
  return <canvas ref={canvasRef} aria-hidden="true" style={{ position: "fixed", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 20 }} />;
}

/** Full-page voice choice shown inside /claim after the account is confirmed. */
export function VoiceChoice({ order, onBack, ready: claimReady, gridRef, gridStyle }: { order: ClaimOrder; onBack: () => void; ready?: Promise<ClaimOrder | null> | null; gridRef: React.RefObject<HTMLDivElement | null>; gridStyle: React.CSSProperties | undefined }) {
  const props_order = order;
  const submit = useServerFn(submitVoiceChoice);
  const [selected, setSelected] = useState<Voice | null>(null);
  const rowRefs = useRef<Partial<Record<Voice, HTMLDivElement>>>({});
  const noteRef = useRef<HTMLSpanElement>(null);
  const [selecting, setSelecting] = useState<Voice | null>(null);
  const [playing, setPlaying] = useState<Voice | null>(null);
  const [barCount, setBarCount] = useState(VOICE_WAVE.length);
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const measure = () => {
      const waves = Array.from(root.querySelectorAll<HTMLElement>(".vc-wave"));
      const widths = waves.map(w => w.clientWidth).filter(w => w > 0);
      if (!widths.length) return;
      const next = waveBarCount(Math.min(...widths), window.matchMedia("(max-width:639px)").matches);
      setBarCount(prev => (prev === next ? prev : next));
    };
    measure();
    const ro = new ResizeObserver(measure);
    root.querySelectorAll(".vc-wave").forEach(w => ro.observe(w));
    return () => ro.disconnect();
  });
  const sampleRef = useRef<HTMLAudioElement | null>(null);
  const stopSample = () => {
    const sample = sampleRef.current;
    sampleRef.current = null;
    if (sample) { sample.pause(); sample.currentTime = 0; }
    setPlaying(null);
  };
  const playSample = (voice: Voice) => {
    const same = playing === voice;
    stopSample();
    if (same) return;
    const sample = new Audio(VOICE_SAMPLES[voice]);
    sampleRef.current = sample;
    const finish = () => { if (sampleRef.current === sample) stopSample(); };
    sample.onended = finish;
    sample.onerror = finish;
    setPlaying(voice);
    void sample.play().catch(finish);
  };
  useEffect(() => () => { sampleRef.current?.pause(); sampleRef.current = null; }, []);
  const checkAccess = useServerFn(checkVoiceAccess);
  const [expired, setExpired] = useState(false);
  useEffect(() => {
    if (selecting || expired) stopSample();
  }, [selecting, expired]);
  const checkingRef = useRef(false);
  // 441: Back or leaving the page cancels an in-progress pick.
  const activeRef = useRef(true);
  const [checking, setChecking] = useState(false);
  useLayoutEffect(() => {
    activeRef.current = true;
    return () => { activeRef.current = false; };
  }, []);
  const handleBack = () => { activeRef.current = false; onBack(); };
  const rootRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLElement>(null);
  useFooterMatchHeader(footerRef, "rgb(173, 173, 173)");
  // Keep the step hidden until fonts and two layout frames are ready. This is
  // only a paint gate; page geometry never depends on viewport height.
  const [ready, setReady] = useState(false);
  useEffect(() => (ready ? pinPhoneTop() : undefined), [ready]);
  useLayoutEffect(() => {
    const note = noteRef.current;
    if (!note) return;
    const fitNote = () => {
      note.style.fontSize = "";
      if (!window.matchMedia("(max-width:639px)").matches) return;
      let size = parseFloat(getComputedStyle(note).fontSize);
      while (note.offsetHeight > parseFloat(getComputedStyle(note).lineHeight) * 2 + 1 && size > 1) {
        size -= .1;
        note.style.fontSize = `${size}px`;
      }
    };
    let previousWidth = 0;
    const observer = new ResizeObserver(() => {
      if (note.offsetWidth === previousWidth) return;
      previousWidth = note.offsetWidth;
      fitNote();
    });
    observer.observe(note);
    document.fonts.ready.then(fitNote);
    fitNote();
    return () => observer.disconnect();
  }, []);
  const selectVoice = (voice: Voice) => {
    if (selecting || checking) return;
    setSelected(voice);
  };
  const confirmVoice = () => {
    if (!selected || selecting || checking) return;
    const row = rowRefs.current[selected];
    if (row && window.matchMedia("(max-width:639px)").matches) row.style.height = `${row.offsetHeight}px`;
    stopSample();
    void choose(selected);
  };
  // Prompt 161: reset the cards when the browser restores this page from its
  // back-forward cache after the customer returns from the GHL page.
  useLayoutEffect(() => {
    const onShow = (e: PageTransitionEvent) => {
      if (!e.persisted) return;
      setSelecting(null);
      setSelected(null);
      for (const row of Object.values(rowRefs.current)) row?.style.removeProperty("height");
    };
    window.addEventListener("pageshow", onShow);
    return () => window.removeEventListener("pageshow", onShow);
  }, []);
  useLayoutEffect(() => {
    let cancelled = false;
    let raf = 0;
    let emergencyTimer = 0;
    const reveal = () => {
      raf = window.requestAnimationFrame(() => {
        raf = window.requestAnimationFrame(() => {
          if (!cancelled) setReady(true);
        });
      });
    };
    const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
    (fonts?.ready ?? Promise.resolve()).then(reveal);
    emergencyTimer = window.setTimeout(() => {
      if (!cancelled) setReady(true);
    }, 1200);
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(emergencyTimer);
    };
  }, []);

  async function choose(voice: Voice) {
    if (selecting || checkingRef.current) return;
    // An expired checkout pass (unpaid) shows the expired page instead of checkout.
    checkingRef.current = true;
    activeRef.current = true;
    setChecking(true);
    // 250: phones arrive from /sign while the claim is still saving; wait for it.
    const order = claimReady ? await claimReady : props_order;
    if (!order) { checkingRef.current = false; setChecking(false); return; }
    let allowed = true;
    let paid = false;
    try {
      const access = order.botId ? await checkAccess({ data: { botId: order.botId } }) : { ok: false };
      allowed = access.ok;
      paid = "paid" in access && !!access.paid;
    } catch { /* network trouble: continue as before */ }
    checkingRef.current = false;
    setChecking(false);
    if (!activeRef.current) return;
    if (paid) { window.location.assign("/welcome"); return; }
    if (!allowed) { setExpired(true); return; }
    setSelecting(voice);
    try {
      // Fingerprint of everything the webhook carries; compared against the
      // last successfully sent one so an unchanged repeat pick skips the send.
      const details = JSON.stringify([
        order.firstName,
        order.lastName ?? "",
        order.email,
        order.phone ?? "",
        order.companyName ?? "",
        order.website ?? "",
        order.slug,
        order.botId ?? "",
      ]);
      const lastSent = readVoiceSent();
      const alreadySent = lastSent !== null && lastSent.voice === voice && lastSent.details === details;
      // One POST through the server function. The customer never waits more
      // than 3 seconds in total: the webhook gets 1 second to confirm, and the
      // congrats + confetti always show for 2 seconds. If GoHighLevel has not
      // confirmed within that second, checkout opens anyway and the webhook
      // keeps sending on the server (no retries).
      const webhookSend =
        alreadySent
          ? Promise.resolve({ ok: true as const, delivered: false })
          : submit({
              data: {
                firstName: order.firstName,
                ...(order.lastName ? { lastName: order.lastName } : {}),
                email: order.email,
                ...(order.phone ? { phone: order.phone } : {}),
                ...(order.companyName ? { companyName: order.companyName } : {}),
                ...(order.website ? { website: order.website } : {}),
                linkbotLink: `linkbot.now/${order.slug}`,
                ...(order.botId ? { botId: order.botId } : {}),
                voice,
              },
            });
      const cappedSend = Promise.race([
        webhookSend,
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 1000)),
      ]);
      const [result] = await Promise.all([
        cappedSend,
        // Congratulation + confetti stay on screen for 2 seconds before checkout.
        new Promise((resolve) => setTimeout(resolve, 2000)),
      ]);
      // Remember only a send that actually reached GHL; a failed, timed-out or
      // skipped send leaves the record untouched so the next pick tries again.
      if (result?.delivered) markVoiceSent({ voice, details });
    } catch (error) {
      console.error("[voice] choice could not be delivered; continuing", error);
    }
    if (!activeRef.current) return;
    storeClaimVoice(voice);
    markGhlVisited();
    // Go straight to the GHL checkout in the same tab (no pop-up, works in in-app browsers).
    if (order.email) {
      const url = new URL(GHL_CHECKOUT_URL);
      url.searchParams.set("email", order.email);
      window.location.assign(url.toString());
    } else {
      window.location.assign(GHL_CHECKOUT_URL);
    }
  }

  if (expired) return <VoiceExpired />;

  return (
    <div ref={rootRef} className="claim-page-root vc-page relative flex min-h-screen flex-col bg-night" style={{ visibility: ready ? "visible" : "hidden" }}>
      <main className="flex-1 bg-surface text-ink">
        <div>
          <div ref={gridRef} className="claim-grid grid w-full min-w-0 gap-6 overflow-hidden px-4 py-8 lg:grid-cols-[30rem_minmax(0,1fr)] lg:gap-14 lg:overflow-visible lg:px-10 lg:py-16 xl:px-16" style={gridStyle}>
            <ClaimOrderAside onBack={handleBack} />
            <div className="min-w-0 animate-fade-up">
              <div className="relative min-w-0 w-full text-left">
                <button type="button" onClick={handleBack} className="hidden items-center rounded-full border border-border bg-surface-2 px-4 py-2 text-[0.65rem] font-extrabold uppercase tracking-[0.16em] text-ink shadow-elev-1 transition-all hover:border-brand hover:text-brand hover:shadow-elev-2 lg:inline-flex lg:px-5 lg:py-2.5 lg:text-xs">← Back</button>
                <div className="vc-phone-back"><button type="button" onClick={handleBack} className="inline-flex items-center rounded-full border border-border bg-surface-2 px-3 py-1.5 text-[0.6rem] font-extrabold uppercase tracking-[0.16em] text-ink shadow-elev-1 transition-all hover:border-brand hover:text-brand">← Back</button></div>
                <div className="vc-heading mt-6 text-center">
                  <h2 className="headline mx-auto whitespace-nowrap text-[clamp(1.15rem,5.4vw,1.95rem)] font-black leading-[1.05] tracking-tight text-ink lg:text-[clamp(1.35rem,2.4vw,1.95rem)]">SELECT YOUR VOICE:</h2>
                  <p className="mx-auto mt-2 max-w-[38ch] text-[0.8rem] font-bold leading-5 text-muted-foreground lg:mt-3 lg:max-w-none lg:text-sm lg:leading-6">Press play to hear each voice, then select the one you want. You can change this anytime later.</p>
                </div>
                <div className="vc-rows mt-6">
                  <p id="vc-label" className="block whitespace-nowrap text-[clamp(0.68rem,3vw,0.75rem)] font-bold text-ink">Who Callers Will Hear:</p>
                  <div className="mt-2 grid gap-5" role="radiogroup" aria-labelledby="vc-label">
                    {VOICE_CARDS.map(({ voice, title }) => (
                      <div key={voice} ref={node => { if (node) rowRefs.current[voice] = node; }} role="radio" aria-checked={selected === voice} aria-label={title} aria-disabled={selecting !== null || checking} tabIndex={selecting || checking ? -1 : 0} className="vc-row" onClick={() => selectVoice(voice)} onKeyDown={event => { if (event.target !== event.currentTarget) return; if (event.key === " " || event.key === "Enter") { event.preventDefault(); selectVoice(voice); } }}>
                        {selecting === voice ? <CongratsWave /> : <>
                          <span className="vc-select" aria-hidden="true">{selected === voice && <Check className="h-4 w-4" strokeWidth={3} />}</span>
                          <div className="vc-text"><p className="vc-name">{title}</p><p className="vc-desc">{voice === "male" ? "Warm, clear and confident." : "Calm, clear and friendly."}</p></div>
                          <div className="vc-player"><Button type="button" variant="ghost" className="vc-play" aria-label={`Play ${voice} voice sample`} onClick={event => { event.stopPropagation(); playSample(voice); }} disabled={selecting !== null || checking}>
                            <span className="vc-play-ic" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor">{playing === voice ? <path d="M6 4h4v16H6zm8 0h4v16h-4z" /> : <path d="M7 4v16l14-8z" />}</svg></span>
                            <span className={playing === voice ? "vc-wave is-playing" : "vc-wave"} aria-hidden="true">{Array.from({ length: barCount }, (_, i) => <i key={i} style={{ height: `${VOICE_WAVE[i % VOICE_WAVE.length]}%` }} />)}</span><span className="vc-play-tx">{playing === voice ? "PLAYING" : "TAP TO PLAY"}</span>
                          </Button></div>
                        </>}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="vc-actions">
                  <Button type="button" variant="ghost" onClick={confirmVoice} disabled={!selected || selecting !== null || checking} className="vc-confirm linkbot-button w-full disabled:cursor-not-allowed"><span>Confirm and continue to checkout</span></Button>
                  <p className="vc-lock-note mt-4 flex items-center justify-center gap-2 text-[11px] font-semibold text-muted-foreground"><Lock className="h-3.5 w-3.5 text-brand" /><span ref={noteRef} className="vc-lock-text">Your custom domain link is reserved for 30 minutes from the moment you click confirm until payment is received.</span></p>
                  <div className="vc-bottom-row mt-8 grid grid-cols-1 justify-items-center gap-3 border-t border-border pt-6 sm:mt-10 sm:flex sm:flex-wrap sm:items-center sm:justify-center sm:gap-x-10 sm:gap-y-4 sm:pt-8">
                    {[{ icon: CreditCard, label: "Card charged at checkout only", order: "order-1" }, { icon: Clock, label: "Your link is held for 30 minutes", order: "order-2" }, { icon: BadgeCheck, label: "No contract", order: "order-3 sm:order-none" }].map(({ icon: Icon, label, order }) => <span key={label} className={`${order} flex items-center gap-2.5`}><Icon className="h-4 w-4 shrink-0 text-brand" strokeWidth={2} /><span className="whitespace-nowrap text-[clamp(0.58rem,2.5vw,0.68rem)] font-black uppercase tracking-[0.14em] text-ink-soft">{label}</span></span>)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      {selecting && createPortal(<FireworkCanvas />, document.body)}
      <style>{VC_BUBBLE_CSS}</style>
      <footer ref={footerRef} className="demo-form-footer site-footer-balanced night-panel px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted"><p><span className="footer-stack"><FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span></span></p></footer>
    </div>
  );
}

// Same look as the /welcome states (text style, footer, layout), no loading bar.
const expiredTextStyle = { color: "#6b7280", fontSize: "14px", fontWeight: 400, lineHeight: "normal" } as const;
export function VoiceExpired() {
  const footerRef = useRef<HTMLElement>(null);
  useFooterMatchHeader(footerRef, "rgb(173, 173, 173)");
  return (
    <div
      className="welcome-page-root flex flex-col overflow-hidden bg-surface"
      style={{ height: "calc(100dvh - var(--site-header-height, 80px))" }}
    >
      <main className="flex min-h-0 flex-1 flex-col items-center justify-center overflow-hidden px-6 text-center">
        <FitLine style={expiredTextStyle}>This page is expired.</FitLine>
        <FitLine className="mt-2" style={expiredTextStyle}>Please try again.</FitLine>
        <button
          type="button"
          className="linkbot-button mt-6"
          onClick={() => {
            // 190: release this browser's own unpaid hold so the same name can be claimed again.
            void releasePassHold().catch(() => {}).finally(() => window.location.assign("/claim"));
          }}
        >
          <span>Start Over</span>
        </button>
      </main>
      <footer ref={footerRef} className="demo-form-footer site-footer-balanced night-panel px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted">
        <p>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>
    </div>
  );
}
