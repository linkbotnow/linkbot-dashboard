import { Check, Lock, ShieldCheck, Zap } from "lucide-react";

export function ClaimOrderAside({ onBack }: { onBack: () => void }) {
  return (
          <aside className="relative order-first flex h-fit min-w-0 flex-col rounded-3xl border border-border bg-surface-2 p-6 shadow-elev-1 lg:order-none lg:h-full lg:p-10">
            <button
              type="button"
              onClick={onBack}
              className="absolute right-4 top-4 inline-flex items-center rounded-full border border-border bg-surface-2 px-3 py-1.5 text-[0.6rem] font-extrabold uppercase tracking-[0.16em] text-ink shadow-elev-1 transition-all hover:border-brand hover:text-brand lg:hidden"
            >
              ← Back
            </button>
            <p className="pr-eyebrow text-brand" style={{ fontWeight: 900 }}>
              Your order
            </p>
            <h1 className="headline mt-2 whitespace-nowrap text-[clamp(1.15rem,5.2vw,1.75rem)] font-black leading-tight text-ink lg:whitespace-normal lg:text-3xl">
              LinkedIn AI Voice Employee
            </h1>
            <div className="mt-5 flex items-end gap-2">
              <span className="font-display text-[2.6rem] font-black tracking-tighter text-ink lg:text-7xl">$359</span>
              <span className="pb-1 text-lg font-semibold text-muted-foreground">/month</span>
            </div>

            <ul className="mt-8 space-y-2.5 border-t border-border pt-8">
              {[
                "24/7 AI Voice Employee",
                "Unlimited Talk Minutes Included",
                "Shares Unlimited Custom Links",
                "Custom Trained on Your Business",
                "Automatic Lead Qualification",
                "Link Calendar for Booking Integration",
                "Personal linkbot.now Domain",
                "Privacy-Protected Technology",
                "Secure Private Client Dashboard",
                "Automatic CRM Lead Capture",
                "Real-Time Performance Analytics",
                "Call Transcript Breakdown",
                "Automated Personalized Follow-Ups",
                "No Contracts. Cancel Anytime",
              ].map((item) => (
                <li
                  key={item}
                  className="flex min-w-0 items-center gap-3 whitespace-nowrap text-[clamp(0.61rem,2.65vw,0.95rem)] font-bold leading-6 text-ink-soft lg:gap-3.5 lg:text-[0.82rem]"
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand/12 lg:h-5 lg:w-5">
                    <Check className="h-3.5 w-3.5 text-brand lg:h-3 lg:w-3" strokeWidth={3} />
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 divide-y divide-border border-t border-border">
              {[
                { icon: ShieldCheck, title: "SOC 2 Type II audited", copy: "Independently reviewed every year." },
                { icon: Lock, title: "AES 256 encryption", copy: "Conversations encrypted at rest." },
                { icon: Zap, title: "Live in minutes", copy: "Your link works right after checkout." },
              ].map(({ icon: Icon, title, copy }) => (
                <div key={title} className="flex min-w-0 items-center gap-4 py-5">
                  <Icon className="h-7 w-7 shrink-0 text-brand lg:h-6 lg:w-6" strokeWidth={1.8} />
                  <span className="min-w-0">
                    <span className="block whitespace-nowrap text-[clamp(0.64rem,2.75vw,0.75rem)] font-black uppercase tracking-[0.1em] text-ink lg:text-[0.7rem] lg:tracking-[0.14em]">
                      {title}
                    </span>
                    <span className="mt-0.5 block whitespace-nowrap text-[clamp(0.66rem,2.85vw,0.875rem)] font-semibold leading-4 text-muted-foreground lg:text-xs">
                      {copy}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </aside>
  );
}
