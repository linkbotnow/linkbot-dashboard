import type { CSSProperties, ReactNode } from "react";
import { useFitLine } from "@/lib/fit-line";

/** A message line that never wraps; its text shrinks just enough to fit. */
export function FitLine({ className, style, children, ...rest }: { className?: string; style?: CSSProperties; children: ReactNode; role?: string; "aria-live"?: "polite" }) {
  const ref = useFitLine<HTMLParagraphElement>([children]);
  return (
    <p ref={ref} {...rest} className={className} style={{ ...style, whiteSpace: "nowrap", maxWidth: "100%" }}>
      {children}
    </p>
  );
}
