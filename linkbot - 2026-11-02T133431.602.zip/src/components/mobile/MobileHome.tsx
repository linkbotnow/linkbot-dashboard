import { PricingCardNew } from "@/components/landing/PricingCardNew";
import { CompareCostPhoneContent } from "@/components/landing/CompareCost";
import { pinDemoViewToTop, useDemoViewTop } from "@/lib/scroll-top";
import { FooterLegalLink } from "@/components/legal/LegalModal";
import { isHeroZoomPaused, setHeroPaused } from "@/lib/hero-pause";
import { useZoomLightMotion } from "@/lib/zoom-light-motion";
import { lockedResizeObserver, phoneLayoutUnstable } from "@/lib/phone-layout-lock";
import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode, type RefObject } from "react";
import { useHomeFooterFit } from "@/lib/home-footer-fit";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { useQuery } from "@tanstack/react-query";
import { DemoRequestForm, DemoStage, LiveAgentPhone } from "@/components/landing/HeroDemo";
import { FEATURES, FEATURE_LABELS, FEATURE_STAGGER, FeatureBannerGraphic, REVIEWS, REVIEW_STAGGER, STATS } from "@/components/landing/landing-content";
import { ArrowRight, Check, ChevronDown, Star } from "lucide-react";
import { HoverlessLink } from "@/components/navigation/HoverlessLink";
import { ScrollReveal } from "@/components/landing/LandingWidgets";
import { motion } from "motion/react";
import { ArrowDown, Bell, FileText, Globe2, MessageCircleMore, Mic2, Search, Send, UserRoundX } from "lucide-react";
import { getCheckoutConfig } from "@/lib/site-config.functions";
import { cn } from "@/lib/utils";

/** Phone-only switch: "/" on a real phone held upright (portrait, touch), or in any window narrower than 640px that is not a real phone. The old mobile homepage layout no longer exists. Client-only, defaults to false. */
export function isMobileHomeSwitchActive() {
  if (typeof window === "undefined") return false;
  const portrait = !window.matchMedia("(orientation: landscape)").matches;
  if (window.location.pathname !== "/") return false;
  const realPhone =
    Math.min(window.screen.width, window.screen.height) <= 600 &&
    portrait &&
    window.matchMedia("(pointer: coarse)").matches;
  return realPhone || isNarrowDesktopWindow();
}

/** Any sub-640px window that is not a real upright phone (a narrowed desktop
 *  window, a tiny screen, a small tablet) gets the new phone homepage instead
 *  of the old mobile layout. */
export function isNarrowDesktopWindow() {
  if (typeof window === "undefined") return false;
  const portrait = !window.matchMedia("(orientation: landscape)").matches;
  const realPhone =
    Math.min(window.screen.width, window.screen.height) <= 600 &&
    portrait &&
    window.matchMedia("(pointer: coarse)").matches;
  return !realPhone && window.matchMedia("(max-width: 639px)").matches;
}

export function useMobileHomeSwitch(pathname: string, search: unknown) {
  const [active, setActive] = useState(false);
  useLayoutEffect(() => {
    // 421: Chrome switching from the sideways page to the phone page shows one
    // black frame first, so the squeezed sideways view is never flashed.
    let currentActive = active;
    let frameA = 0;
    let frameB = 0;
    const lateTimers: number[] = [];
    const frames: number[] = [];
    const check = () => {
      const next = isMobileHomeSwitchActive();
      if (navigator.userAgent.includes("CriOS") && next && !currentActive) {
        document.documentElement.classList.add("pg-boot");
        frameA = requestAnimationFrame(() => {
          frameB = requestAnimationFrame(() => {
            currentActive = isMobileHomeSwitchActive();
            setActive(currentActive);
          });
          frames.push(frameB);
        });
        frames.push(frameA);
      } else {
        currentActive = next;
        setActive(next);
      }
    };
    check();
    const late = () => {
      check();
      for (const d of [100, 300, 600]) lateTimers.push(window.setTimeout(check, d));
    };
    window.addEventListener("resize", check);
    window.addEventListener("orientationchange", late);
    return () => {
      cancelAnimationFrame(frameA);
      cancelAnimationFrame(frameB);
      frames.forEach((f) => cancelAnimationFrame(f));
      lateTimers.forEach((t) => window.clearTimeout(t));
      window.removeEventListener("resize", check);
      window.removeEventListener("orientationchange", late);
    };
  }, [pathname, search]);
  return active;
}

// Values copied from the current portrait-phone homepage on the 1440px canvas.
// The current hero inner column is 1152px wide and scaled 1.25 (max-sm:scale-125).
const S = "var(--mobile-scale)";
const HERO_SCALE = 1.25;
const px = (v: number) => `calc(${v}px * ${HERO_SCALE} * ${S})`;
const INNER_WIDTH = 1152; // max-sm:w-4/5 of 1440
const DEMO_STAGE_FALLBACK_HEIGHT = 298; // demo zoom layout (650 * 1.68) at 393px, screen px
const FEATURES_FALLBACK_HEIGHT = 9000; // natural height of the 1440px-wide features inner, canvas px
const DEMO_SESSION_KEY = "linkbot:live-demo-company";
const DEMO_FORM_OPEN_KEY = "linkbot:demo-form-open";
// Prompt 80: the first hero's widest line (subheadline) spans ~1350 of the
// 1440 canvas; this fixed width-based scale fits it inside 96px side margins.
const MH_FIRST_FIT = 1248 / 1350;

function atUnzoomedScale() {
  return (window.visualViewport?.scale ?? 1) === 1;
}

// Re-measure only on first load, fonts ready, window load, and a real WIDTH
// change. Height-only resizes (the iOS toolbar collapsing while scrolling)
// must never trigger layout writes.
function onMeasureTriggers(rawSync: () => void) {
  let waitingForScaleOne = !atUnzoomedScale();
  const sync = () => {
    if (phoneLayoutUnstable()) return;
    if (!atUnzoomedScale()) {
      waitingForScaleOne = true;
      return;
    }
    waitingForScaleOne = false;
    rawSync();
  };
  let lastWidth = document.documentElement.clientWidth;
  const onResize = () => {
    const w = document.documentElement.clientWidth;
    if (w === lastWidth) return;
    lastWidth = w;
    sync();
  };
  window.addEventListener("load", sync);
  document.fonts?.ready.then(sync).catch(() => {});
  window.addEventListener("resize", onResize);
  window.addEventListener("orientationchange", onResize);
  const visualViewport = window.visualViewport;
  const onVisualViewportResize = () => {
    if (!waitingForScaleOne || !atUnzoomedScale()) return;
    sync();
  };
  visualViewport?.addEventListener("resize", onVisualViewportResize);
  return () => {
    window.removeEventListener("load", sync);
    window.removeEventListener("resize", onResize);
    window.removeEventListener("orientationchange", onResize);
    visualViewport?.removeEventListener("resize", onVisualViewportResize);
  };
}

export function MobileHome() {
  const { data: checkout } = useQuery({ queryKey: ["checkout-config"], queryFn: () => getCheckoutConfig(), staleTime: 300_000 });
  const rootRef = useRef<HTMLDivElement>(null);
  const mainRef = useRef<HTMLElement>(null);
  const heroRef = useRef<HTMLElement>(null);
  const featuresRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [stageHeight, setStageHeight] = useState(DEMO_STAGE_FALLBACK_HEIGHT);
  const heroInnerRef = useRef<HTMLDivElement>(null);
  const [heroInnerHeight, setHeroInnerHeight] = useState(463);
  const featureRefs = useRef<(HTMLDivElement | null)[]>([]);
  const featureTargetRef = useRef<number | null>(null);
  const [activeFeature, setActiveFeature] = useState<number | null>(null);
  const [faqOpen, setFaqOpen] = useState(false);
  const homeFooterRef = useRef<HTMLElement>(null);
  const [demoView, setDemoView] = useState<"hero" | "form" | "call">("hero");
  useDemoViewTop(demoView);
  useHomeFooterFit(homeFooterRef, [demoView, faqOpen]);
  const demoFooterRef = useRef<HTMLElement>(null);
  useFooterMatchHeader(demoFooterRef, "rgb(173, 173, 173)", [demoView]);
  const [demoCompany, setDemoCompany] = useState("Your Business");
  const [demoLocked, setDemoLocked] = useState(false);
  const demoFormRef = useRef<HTMLDivElement>(null);
  const liveDemoRef = useRef<HTMLDivElement>(null);

  // Match the current homepage's per-tab demo lock and initial live-demo view.
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = window.sessionStorage.getItem(DEMO_SESSION_KEY);
    } catch {
      saved = null;
    }
    if (!saved) {
      let formOpen = false;
      try { formOpen = window.sessionStorage.getItem(DEMO_FORM_OPEN_KEY) === "1"; } catch { formOpen = false; }
      if (formOpen) setDemoView("form");
      return;
    }
    setDemoCompany(saved);
    setDemoLocked(true);
    setDemoView("call");
  }, []);

  const formFlagReadyRef = useRef(false);
  useEffect(() => {
    if (!formFlagReadyRef.current) { formFlagReadyRef.current = true; return; }
    try {
      if (demoView === "form") window.sessionStorage.setItem(DEMO_FORM_OPEN_KEY, "1");
      else window.sessionStorage.removeItem(DEMO_FORM_OPEN_KEY);
    } catch { /* private mode */ }
  }, [demoView]);

  // Match the current homepage's header swap and both Back controls while
  // preserving /?mobile=1 because the form opens in this component.
  useEffect(() => {
    window.dispatchEvent(new CustomEvent("linkbot:demo-form-active", { detail: demoView === "form" }));
    const onBack = () => setDemoView(demoLocked ? "call" : "hero");
    const goHome = () => {
      setDemoView(demoLocked ? "call" : "hero");
      window.scrollTo({ top: 0, behavior: "auto" });
    };
    window.addEventListener("linkbot:demo-form-back", onBack);
    window.addEventListener("linkbot:home-nav", goHome);
    return () => {
      window.dispatchEvent(new CustomEvent("linkbot:demo-form-active", { detail: false }));
      window.removeEventListener("linkbot:demo-form-back", onBack);
      window.removeEventListener("linkbot:home-nav", goHome);
    };
  }, [demoView, demoLocked]);

  // Prompt 67: while two fingers are down, the embedded demo ignores touches
  // so the browser owns the pinch gesture. Pinching never changes page layout.
  useEffect(() => {
    const html = document.documentElement;
    const onTouchStart = (event: TouchEvent) => {
      if (event.touches.length >= 2) html.classList.add("mh-two-fingers");
    };
    const onTouchEnd = (event: TouchEvent) => {
      if (event.touches.length < 2) html.classList.remove("mh-two-fingers");
    };
    document.addEventListener("touchstart", onTouchStart, { passive: true });
    document.addEventListener("touchend", onTouchEnd, { passive: true });
    document.addEventListener("touchcancel", onTouchEnd, { passive: true });
    return () => {
      document.removeEventListener("touchstart", onTouchStart);
      document.removeEventListener("touchend", onTouchEnd);
      document.removeEventListener("touchcancel", onTouchEnd);
      html.classList.remove("mh-two-fingers");
    };
  }, []);

  // Prompt 68: a section fully covered by the one stacked on it is not drawn
  // (hidden with visibility, so layout and positions never change).
  // 1px markers (IntersectionObserver only, no scroll listeners):
  //  - top/bottom edges of Features: the hero is covered once the Features
  //    top has passed above the screen and its bottom is still below it;
  //  - 1px before Why LinkBot's top edge: its marker is fully above exactly
  //    when Why reaches the viewport top and fully covers pinned Features.
  useEffect(() => {
    const root = rootRef.current;
    if (!root || typeof IntersectionObserver === "undefined") return;
    const get = (name: string) => root.querySelector<HTMLElement>(`[data-mh-cover="${name}"]`);
    const fTop = get("features-top");
    const fBottom = get("features-bottom");
    const wTop = get("why-top");
    if (!fTop || !fBottom || !wTop) return;
    const state = { fTopAbove: false, fBottomBelow: false, wTopAbove: false };
    const apply = () => {
      const hero = root.querySelector<HTMLElement>(".mh-layer-hero");
      const features = root.querySelector<HTMLElement>(".mh-layer-features");
      hero?.classList.toggle("mh-covered", state.fTopAbove && state.fBottomBelow);
      setHeroPaused(state.fTopAbove && state.fBottomBelow);
      features?.classList.toggle("mh-covered", state.wTopAbove);
    };
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) {
        const r = e.boundingClientRect;
        const vh = e.rootBounds?.bottom ?? window.innerHeight;
        if (e.target === fTop) state.fTopAbove = !e.isIntersecting && r.bottom <= 0;
        else if (e.target === fBottom) state.fBottomBelow = !e.isIntersecting && r.top >= vh;
      }
      apply();
    });
    // Extend only the observer's lower detection area to the end of the page.
    // The 1px marker therefore stays intersecting while it is below the screen
    // and becomes non-intersecting exactly as it crosses the top, even when a
    // fast scroll skips over the visible viewport between rendered frames.
    const whyIo = new IntersectionObserver(([entry]) => {
      if (!entry) return;
      state.wTopAbove = !entry.isIntersecting && entry.boundingClientRect.bottom <= 0;
      apply();
    }, { rootMargin: "0px 0px 100000px 0px" });
    io.observe(fTop);
    io.observe(fBottom);
    whyIo.observe(wTop);
    return () => {
      io.disconnect();
      whyIo.disconnect();
      root.querySelectorAll(".mh-covered").forEach((el) => el.classList.remove("mh-covered"));
      setHeroPaused(false);
    };
  }, [demoView]);

  // 257: on touch phones, every homepage section pauses its animations while it
  // is off screen and resumes as it returns. IntersectionObserver reports
  // visibility without measuring the page during scroll.
  useEffect(() => {
    const root = rootRef.current;
    if (!root || typeof IntersectionObserver === "undefined") return;
    if (!window.matchMedia("(pointer: coarse)").matches) return;
    const targets = Array.from(root.querySelectorAll<HTMLElement>(":scope > main > *, :scope > :not(main)"));
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) e.target.classList.toggle("mh-offscreen", !e.isIntersecting);
    }, { rootMargin: "20% 0px" });
    targets.forEach((el) => io.observe(el));
    return () => {
      io.disconnect();
      targets.forEach((el) => el.classList.remove("mh-offscreen"));
    };
  }, [demoView]);



  // Copied from DesktopHome: scrolling back to the very top closes the FAQ.
  useEffect(() => {
    const onScroll = () => {
      if (window.scrollY <= 0 && faqOpen) setFaqOpen(false);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [faqOpen]);

  useLayoutEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    // 351: real upright phones scale from the physical screen width (same
    // value the head script uses) so the first painted size is final; other
    // devices keep the clientWidth behavior exactly.
    const isRealUprightPhone = () =>
      Math.min(window.screen.width, window.screen.height) <= 600 &&
      window.matchMedia("(pointer: coarse)").matches &&
      !window.matchMedia("(orientation: landscape)").matches;
    let lastWidth = document.documentElement.clientWidth;
    let wasLandscape = !isRealUprightPhone();
    const sync = () => {
      if (isRealUprightPhone()) {
        if (!wasLandscape) return; // upright and was already upright = scroll/toolbar resize: never rescale
        wasLandscape = false; // a real rotation back to upright: run the existing logic once
      } else {
        wasLandscape = true;
      }
      const w = isRealUprightPhone() ? Math.min(window.screen.width, window.screen.height) : document.documentElement.clientWidth;
      if (w === lastWidth) return;
      lastWidth = w;
      root.style.setProperty("--mobile-scale", String(w / 1440));
    };
    root.style.setProperty("--mobile-scale", String(lastWidth / 1440));
    window.addEventListener("resize", sync);
    window.addEventListener("orientationchange", sync);
    return () => {
      window.removeEventListener("resize", sync);
      window.removeEventListener("orientationchange", sync);
    };
  }, []);

  // Keep the first visible frame behind the boot guard until the real fonts
  // and the layout effects/ResizeObservers that depend on them have settled.
  // The pre-paint script remains the 2500ms emergency escape hatch.
  useEffect(() => {
    let cancelled = false;
    let frame = 0;
    let stableFrames = 0;
    let lastHeight = -1;
    const root = rootRef.current;
    // Arriving on the homepage from another page skips the head script's
    // first-load sizing, so set --mh-screen-h here with the same 100lvh
    // measurement — but never overwrite a value that is already set.
    try {
      const d = document.documentElement;
      if (!d.style.getPropertyValue("--mh-screen-h")) {
        const mhS = Math.max(window.screen.width, window.screen.height);
        let mhV = 0;
        const mhP = document.createElement("div");
        mhP.style.cssText = "position:absolute;top:0;left:0;width:0;height:100lvh;visibility:hidden;pointer-events:none";
        d.appendChild(mhP);
        mhV = mhP.getBoundingClientRect().height;
        d.removeChild(mhP);
        d.style.setProperty("--mh-screen-h", `${mhV >= mhS * 0.8 && mhV <= mhS ? mhV : mhS}px`);
      }
    } catch { /* keep the CSS fallback */ }
    const reveal = () => {
      if (!cancelled) document.documentElement.classList.remove("mh-boot");
    };
    const waitForStableLayout = () => {
      if (cancelled || !root) return;
      const height = root.getBoundingClientRect().height;
      stableFrames = Math.abs(height - lastHeight) <= 0.5 ? stableFrames + 1 : 0;
      lastHeight = height;
      if (stableFrames >= 4) {
        reveal();
        return;
      }
      frame = window.requestAnimationFrame(waitForStableLayout);
    };
    void document.fonts.ready.then(() => {
      if (cancelled) return;
      frame = window.requestAnimationFrame(waitForStableLayout);
    }).catch(() => reveal());
    return () => {
      cancelled = true;
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);


  // The hero texts' rendered height (eyebrow through subheadline). The
  // current phone hero's layout counts them unscaled (its inner column is
  // scale-125 transformed), so the wrapper reserves this / 1.25, plus the
  // demo's zoomed layout height which already excludes the 1.25.
  useLayoutEffect(() => {
    const inner = heroInnerRef.current;
    if (!inner || demoView !== "hero") return;
    let last = 0;
    const sync = () => {
      if (!atUnzoomedScale()) return;
      const box = inner.children[3]; // the demo box, first element after the texts
      const stage = stageRef.current;
      if (!box || !stage) return;
      // Include the demo root's top margin (mt-12), which the current phone
      // hero counts in its layout above the demo.
      const root = stage.firstElementChild as HTMLElement | null;
      const mt = root ? parseFloat(getComputedStyle(root).marginTop) || 0 : 0;
      const s = document.documentElement.clientWidth / 1440;
      const h = box.getBoundingClientRect().top - inner.getBoundingClientRect().top + mt * HERO_SCALE * s;
      if (h > 0 && Math.abs(h - last) > 0.5) {
        last = h;
        setHeroInnerHeight(h);
      }
    };
    sync();
    const off = onMeasureTriggers(sync);
    return () => {
      off();
    };
  }, [demoView]);

  // Older iOS Safari zooms boxes but not text, so the demo's 1.68 zoom is
  // replaced by a scale transform (see the .mobile-home-root rules in
  // styles.css). Measure each affected element's natural size and hand it to
  // those rules so they can reserve the space the zoom used to take.
  useLayoutEffect(() => {
    const stage = stageRef.current;
    if (!stage || demoView !== "hero") return;
    const lastDemoH = new Map<HTMLElement, number>();
    let lastStage = 0;
    const sync = () => {
      if (!atUnzoomedScale()) return;
      let first = 0;
      let firstEl: HTMLElement | null = null;
      stage.querySelectorAll<HTMLElement>(".hero-demo-scale").forEach((el) => {
        // offsetHeight includes the reserved padding-bottom, so subtract it
        // to get the natural height (otherwise each re-measure grows it).
        const pad = parseFloat(getComputedStyle(el).paddingBottom) || 0;
        const natural = el.offsetHeight - pad;
        if (Math.abs(natural - (lastDemoH.get(el) ?? -1)) > 0.5) {
          lastDemoH.set(el, natural);
          el.style.setProperty("--mh-demo-h", `${natural}px`);
        }
        if (!first) {
          first = natural;
          firstEl = el;
        }
      });
      // Read the reserved padding AFTER setting --mh-demo-h so the stage
      // height below never counts the new reservation twice.
      const firstPad = firstEl ? parseFloat(getComputedStyle(firstEl).paddingBottom) || 0 : 0;
      // The current phone hero's layout counts the demo root at its zoomed
      // height: everything around .hero-demo-scale stays natural, the scaled
      // element counts natural * 1.68, and the scaled element overlaps the
      // step bar by 43 canvas px (all measured from the current phone
      // homepage). Reserve exactly that, at canvas scale (no 1.25).
      if (first > 0) {
        const rootNatural = stage.offsetHeight - firstPad;
        const layoutCanvas = rootNatural - first + first * 1.68 - 43;
        const next = layoutCanvas * (document.documentElement.clientWidth / 1440);
        if (Math.abs(next - lastStage) > 0.5) {
          lastStage = next;
          setStageHeight(next);
        }
      }
    };
    sync();
    const off = onMeasureTriggers(sync);
    return () => {
      off();
    };
  }, [demoView]);

  // Prompt 80: no screen-height fitting. Only the hero's own layout height
  // (eyebrow space through the Start button + T) feeds the sticky top.
  useLayoutEffect(() => {
    const section = heroRef.current;
    const inner = heroInnerRef.current;
    const stage = stageRef.current;
    if (!section || !inner || !stage || demoView === "call") return;
    const sync = () => {
      if (!atUnzoomedScale()) return;
      const button = stage.querySelector<HTMLElement>(".hero-demo-cta-mobile");
      if (!button) return;
      const T = 192 * (document.documentElement.clientWidth / 1440);
      const h = button.getBoundingClientRect().bottom - section.getBoundingClientRect().top + T;
      if (h > 0) section.style.setProperty("--mh-live-h", `${h}px`);
    };
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(inner);
    ro.observe(stage);
    const off = onMeasureTriggers(sync);
    return () => {
      ro.disconnect();
      off();
    };
  }, [demoView]);


  // Hero -> Features stacking, ported from DesktopHome's phone layered-stack
  // effect with canvas-pixel values converted to screen pixels (the mobile
  // homepage renders at scale 1, so --mobile-scale replaces the canvas scale).
  useLayoutEffect(() => {
    const main = mainRef.current;
    const hero = heroRef.current;
    const features = featuresRef.current;
    if (!main || !hero || !features) return;
    let measureFrame = 0;
    // Screen height is captured once at load and refreshed only on a real
    // width change — never read live during scrolling.
    let viewportHeight = window.innerHeight;
    let lastFeaturesHeight = 0;
    let lastViewportHeight = 0;

    const measure = () => {
      measureFrame = 0;
      const featuresContentHeight = features.offsetHeight;
      if (
        Math.abs(featuresContentHeight - lastFeaturesHeight) <= 0.5 &&
        lastFeaturesHeight > 0 &&
        Math.abs(viewportHeight - lastViewportHeight) <= 0.5
      ) return;
      lastFeaturesHeight = featuresContentHeight;
      lastViewportHeight = viewportHeight;
      // Same bottom space as the current phone homepage (33rem + 9svh, pinned
      // as plain pixels there): 132 + innerHeight * 0.0225, in canvas px.
      features.style.setProperty(
        "padding-bottom",
        `calc(${132 + Math.round(viewportHeight * 0.0225)}px * var(--mobile-scale))`,
        "important",
      );
      // The hero is exactly one screen tall and its content is fitted, so it
      // always pins directly under the header.
      const requiredReveal = 0;
      main.style.setProperty("--mh-header-top", `${72 - requiredReveal}px`);
      // Only write a travel distance once the section has a real measured
      // height, so Features cannot pin the instant it arrives.
      if (featuresContentHeight > 0) {
        main.style.setProperty("--mh-feature-top", `${Math.min(0, viewportHeight - featuresContentHeight)}px`);
      }
    };

    const queueMeasure = () => {
      if (measureFrame) return;
      measureFrame = window.requestAnimationFrame(measure);
    };

    // 370: right after a rotation the browser is still resetting its zoom, so
    // the height read when this view mounts can be wrong. Re-read it at a few
    // settle points (only at normal zoom) and re-measure if it changed — but
    // only when the WIDTH actually changed (a rotation). A height-only change
    // while scrolling (the browser toolbar collapsing/expanding) must never
    // re-size the hero.
    let lastSettleWidth = document.documentElement.clientWidth;
    const settleTimers: number[] = [];
    const refreshHeight = () => {
      const scale = window.visualViewport?.scale ?? 1;
      if (Math.abs(scale - 1) > 0.01) return;
      const w = document.documentElement.clientWidth;
      if (w === lastSettleWidth) return;
      lastSettleWidth = w;
      const h = window.innerHeight;
      if (Math.abs(h - viewportHeight) > 1) {
        viewportHeight = h;
        queueMeasure();
      }
    };
    const scheduleSettle = () => {
      for (const delay of [150, 400, 800, 1500, 2500]) {
        settleTimers.push(window.setTimeout(refreshHeight, delay));
      }
    };

    let lastWidth = document.documentElement.clientWidth;
    const handleResize = () => {
      if ((window.visualViewport?.scale ?? 1) !== 1) return;
      const w = document.documentElement.clientWidth;
      if (w === lastWidth) return;
      lastWidth = w;
      viewportHeight = window.innerHeight;
      queueMeasure();
    };

    queueMeasure();
    scheduleSettle();
    // Images, fonts and the staggered card layout all settle after the first
    // frame. Re-measure whenever the Features section's own height changes so
    // its scroll travel always matches the cards actually rendered.
    const observer = lockedResizeObserver(queueMeasure);
    observer.observe(features);
    window.addEventListener("load", queueMeasure);
    document.fonts?.ready.then(queueMeasure).catch(() => {});
    window.addEventListener("resize", handleResize);
    const handleOrientation = () => { handleResize(); scheduleSettle(); };
    window.addEventListener("orientationchange", handleOrientation);
    return () => {
      if (measureFrame) window.cancelAnimationFrame(measureFrame);
      settleTimers.forEach((t) => window.clearTimeout(t));
      observer.disconnect();
      window.removeEventListener("load", queueMeasure);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("orientationchange", handleOrientation);
      main.style.removeProperty("--mh-header-top");
      main.style.removeProperty("--mh-feature-top");
      features.style.removeProperty("padding-bottom");
    };
  }, [demoView]);

  // 390: once Why LinkBot reaches the top of the screen, the pinned hero and
  // Features are fully covered for the rest of the page. Hide them and give the
  // stack a light background so a section painted a frame late never shows the
  // dark hero behind it. Restored before they could be seen when scrolling up.
  useEffect(() => {
    const main = mainRef.current;
    if (!main) return;
    let frame = 0;
    const update = () => {
      frame = 0;
      const next = main.querySelector<HTMLElement>(".mh-layer-next");
      if (!next) return;
      main.classList.toggle("mh-past-stack", next.getBoundingClientRect().top <= 0);
      // 412: publish the dark pricing section's position in the stack's own
      // coordinates so the behind-stack backdrop turns dark only over it.
      const stack = main;
      const pricing = main.querySelector<HTMLElement>(".mh-pricing-section");
      if (!stack || !pricing) return;
      const stackRect = stack.getBoundingClientRect();
      const sectionRect = pricing.getBoundingClientRect();
      const ratio = stackRect.height / stack.offsetHeight;
      const safeRatio = Number.isFinite(ratio) && ratio !== 0 ? ratio : 1;
      stack.style.setProperty("--mh-dark-top", `${Math.round((sectionRect.top - stackRect.top) / safeRatio) + 2}px`);
      stack.style.setProperty("--mh-dark-bottom", `${Math.round((sectionRect.bottom - stackRect.top) / safeRatio) - 2}px`);
    };
    // 423: re-run whenever the stack or the pricing section itself resizes.
    const ro = new ResizeObserver(() => update());
    ro.observe(main);
    const pricingForRo = main.querySelector<HTMLElement>(".mh-pricing-section");
    if (pricingForRo) ro.observe(pricingForRo);
    // HOMEPAGE-2B: iPhone Safari's address bar showing/hiding fires scroll and
    // height-only resize events; there, scrolling only flips the cover class and
    // the dark backdrop is re-published only when the sections really resize
    // (ResizeObserver) or the width changes.
    const ua = navigator.userAgent;
    const safari = /Safari/i.test(ua) && !/Chrome|CriOS|Chromium|FxiOS|EdgiOS|Edg\/|OPR|Android/i.test(ua);
    const flipCover = () => {
      frame = 0;
      const next = main.querySelector<HTMLElement>(".mh-layer-next");
      if (next) main.classList.toggle("mh-past-stack", next.getBoundingClientRect().top <= 0);
    };
    let lastResizeWidth = document.documentElement.clientWidth;
    const onScroll = safari
      ? () => { if (!frame) frame = window.requestAnimationFrame(flipCover); }
      : () => { if (!frame) frame = window.requestAnimationFrame(update); };
    const onResize = safari
      ? () => {
          const w = document.documentElement.clientWidth;
          if (w === lastResizeWidth) return;
          lastResizeWidth = w;
          if (!frame) frame = window.requestAnimationFrame(update);
        }
      : onScroll;
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onResize);
    const lateA = window.setTimeout(update, 500);
    const lateB = window.setTimeout(update, 1500);
    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      ro.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
      window.clearTimeout(lateA);
      window.clearTimeout(lateB);
      main.classList.remove("mh-past-stack");
      main.style.removeProperty("--mh-dark-top");
      main.style.removeProperty("--mh-dark-bottom");
    };
  }, [demoView]);

  // Feature-card highlight tracker, copied unchanged from DesktopHome.
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const nodes = featureRefs.current.filter(Boolean) as HTMLDivElement[];
      if (nodes.length === 0) return;
      const center = window.innerHeight / 2;
      const first = nodes[0]!.getBoundingClientRect();
      const last = nodes[nodes.length - 1]!.getBoundingClientRect();
      // Before the list reaches the viewport center, nothing is highlighted.
      if (first.top + first.height / 2 > center + window.innerHeight / 2) {
        featureTargetRef.current = null;
        return;
      }
      // Past the list, keep the last card lit instead of dropping the highlight.
      if (last.top + last.height / 2 < center) {
        featureTargetRef.current = nodes.length - 1;
        return;
      }
      let best = 0;
      let bestDistance = Number.POSITIVE_INFINITY;
      nodes.forEach((node, index) => {
        const rect = node.getBoundingClientRect();
        const distance = Math.abs(rect.top + rect.height / 2 - center);
        if (distance < bestDistance) {
          bestDistance = distance;
          best = index;
        }
      });
      featureTargetRef.current = best;
    };
    const onScroll = () => {
      if (frame) return;
      frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Advance on one persistent clock. Scroll events only move the destination,
  // so rapid scrolling cannot cancel a card's turn or jump across indices.
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (isHeroZoomPaused()) return; // 257: hold while pinch-zoomed
      setActiveFeature((current) => {
        const target = featureTargetRef.current;
        if (target === null) return current === null ? null : null;
        if (current === null) return 0;
        if (current === target) return current;
        return current + (target > current ? 1 : -1);
      });
    }, 320);
    return () => window.clearInterval(timer);
  }, []);

  const openForm = () => {
    if (demoLocked) {
      setDemoView("call");
      pinDemoViewToTop();
      return;
    }
    setDemoView("form");
  };

  // 264: separate hero artwork layer, upright touch phones only.
  const [artOn, setArtOn] = useState(false);
  const [artHost, setArtHost] = useState<HTMLDivElement | null>(null);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 639px) and (orientation: portrait) and (pointer: coarse)");
    const sync = () => setArtOn(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);

  return (
    <div
      ref={rootRef}
      className={cn("mobile-home-root min-h-screen bg-background text-foreground", demoView === "form" && "demo-form-focus")}
      style={{ "--mobile-scale": "0.2729" } as CSSProperties}
    >
      {demoView === "form" ? (
        <main>
          <section className="night-panel demo-form-focus-hero relative overflow-hidden px-0 pb-40 pt-40">
            <div ref={demoFormRef} id="live-demo" className="mx-auto w-full max-w-none scroll-mt-20">
              <div className="demo-form-focus-card rounded-[2rem] border border-border bg-surface px-10 pb-12 pt-8 shadow-elev-3">
                <DemoRequestForm
                  onBack={() => setDemoView("hero")}
                  onComplete={(companyName) => {
                    setDemoCompany(companyName);
                    setDemoLocked(true);
                    try {
                      window.sessionStorage.setItem(DEMO_SESSION_KEY, companyName);
                    } catch {
                      /* private mode — the lock simply lasts for this view */
                    }
                    setDemoView("call");
                  }}
                />
              </div>
            </div>
          </section>
        </main>
      ) : (
      <main ref={mainRef} className="mh-stack">
        {demoView === "call" ? (
          <MhLiveDemo
            sectionRef={heroRef}
            compositionRef={liveDemoRef}
            companyName={demoCompany}
            cta={<HoverlessLink to="/claim" className="linkbot-button hero-demo-cta-mobile"><span>Buy Now</span></HoverlessLink>}
          />
        ) : (
        <section
          ref={heroRef}
          className="night-panel mh-layer-hero mh-live-hero relative overflow-hidden text-center"
          style={{
            // Prompt 80: same top space as the live demo (T = 192 canvas px).
            paddingTop: `calc(192px * ${S})`,
            // Header + hero = full physical screen height (+1px for Features'
            // -1px seam), fixed once at boot, so Features starts at the screen edge.
            paddingBottom: 0,
            boxSizing: "border-box",
            minHeight: "max(calc(var(--mh-screen-h, 852px) - 71px), var(--mh-live-h, 0px))",
          }}
        >
          <div
            className="pointer-events-none absolute left-1/2 -translate-x-1/2 rounded-full"
            style={{
              top: `calc(-160px * ${S})`,
              width: `calc(960px * ${S})`,
              height: `calc(640px * ${S})`,
              // Prompt 64: same soft halo as the blur, painted as a gradient so
              // pinch-zoom never rasterizes a huge filtered layer.
              background: "radial-gradient(closest-side, rgba(37, 99, 235, 0.22), rgba(37, 99, 235, 0) 70%)",
            }}
          />
          {/* The current phone hero's inner column is scale-125 transformed, so
              the section's layout height excludes the extra 25% — it overflows
              into the stacking spacer. Reserve the unscaled height here too. */}
          <div className="relative mx-auto" style={{ width: px(INNER_WIDTH), height: `${(heroInnerHeight / HERO_SCALE + stageHeight) * MH_FIRST_FIT}px` }}>
          {/* Prompt 80: one fixed width-based scale so the widest line spans
              exactly the live demo's side margins (96 canvas px each side). */}
          <div ref={heroInnerRef} style={{ position: "absolute", top: 0, left: 0, width: px(INNER_WIDTH), transform: `scale(${MH_FIRST_FIT})`, transformOrigin: "top center" }}>
            <p
              style={{
                margin: 0,
                color: "var(--brand)",
                fontSize: px(28),
                lineHeight: px(35),
                letterSpacing: px(7),
                fontWeight: 700,
                textTransform: "uppercase",
                whiteSpace: "nowrap",
              }}
            >
              BUILT EXCLUSIVELY FOR YOUR LINKEDIN PROFILE
            </p>
            <h1
              style={{
                marginTop: px(24),
                marginBottom: 0,
                color: "var(--night-foreground)",
                fontFamily: "Manrope, ui-sans-serif, system-ui, sans-serif",
                fontWeight: 800,
                fontSize: px(86.46),
                lineHeight: px(86.46),
                letterSpacing: px(-3.0261),
                whiteSpace: "nowrap",
              }}
            >
              Instant{" "}
              <span style={{ display: "inline-block", color: "var(--brand)", lineHeight: px(88.1892) }}>AI Voice Employee</span>
            </h1>
            <p
              style={{
                marginTop: px(24),
                marginBottom: 0,
                color: "var(--night-foreground)",
                fontSize: px(40),
                lineHeight: px(50),
                fontWeight: 600,
                whiteSpace: "nowrap",
              }}
            >
              <span style={{ display: "block" }}>Turn static profile visits into live voice conversations</span>
              <span style={{ display: "block" }}> that answers, qualifies and captures leads for you.</span>
            </p>

            {/* Reused DemoStage, rendered at its current 1152px phone-canvas width
                and scaled as a unit (its own internal phone styles are unchanged). */}
            <div
              style={{
                width: px(INNER_WIDTH),
                height: `${stageHeight}px`,
                position: "relative",
                textAlign: "center",
              }}
            >
              <div
                ref={stageRef}
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: `${INNER_WIDTH}px`,
                  transform: `scale(calc(${HERO_SCALE} * ${S}))`,
                  transformOrigin: "top left",
                }}
              >
                <div className="mh-hero-gap-host" style={{ ["--mh-step-extra" as string]: "0px" }}>
                  <DemoStage demoPublicUrl={checkout?.demoPublicUrl ?? null} onOpenForm={openForm} pulse artLayer={artOn ? artHost : null} />
                </div>
              </div>
            </div>
          </div>
          {/* 264: upright phones only — the phone mockup, lead card and flying
              card render here with one combined scale (0.9244 x 1.25 x 1.68 x S). */}
          {artOn && (
            <div
              ref={setArtHost}
              className="mh-art-layer"
              style={{ ["--mh-art-k" as string]: `calc(${MH_FIRST_FIT} * ${HERO_SCALE} * 1.68 * ${S})` }}
            />
          )}
          </div>
        </section>
        )}

        <section ref={featuresRef} id="features" className="feature-section mh-layer-features mh-features night-panel -mt-px">
          <span aria-hidden="true" className="mh-cover-mark" data-mh-cover="features-top" style={{ top: 0 }} />
          <span aria-hidden="true" className="mh-cover-mark" data-mh-cover="features-bottom" style={{ bottom: -1 }} />
          {/* Native markup: every size is calc(canvas px * 2.1431 * --mobile-scale)
              (see styles.css). Only each card's small artwork is scaled, in its
              own reserved box that is never larger than one card. */}
          <div className="section-banner-strip feature-banner-strip">
            <span className="section-banner-strip-text">Features</span>
          </div>
          <div className="mh-features-body">
            <div className="feature-puzzle">
              {FEATURES.map((f, i) => {
                const s = FEATURE_STAGGER[i]!;
                const from = s.justify === "end" ? "right" : "left";
                const active = activeFeature === i;
                return (
                  <ScrollReveal
                    key={f.title}
                    from={from}
                    delay={60}
                    className={cn("feature-puzzle-slot flex w-full", `feature-slot-${i + 1}`)}
                  >
                    <div
                      ref={(node) => { featureRefs.current[i] = node; }}
                      className={cn(
                        "feature-banner relative h-full overflow-hidden border",
                        active ? "border-brand feature-card-active" : "border-white/10",
                      )}
                      data-feature={i}
                    >
                      <div className="feature-banner-copy">
                        <div className="feature-banner-copy-lock">
                          <span className="feature-banner-kicker">{i === 4 ? "INTELLIGENCE" : FEATURE_LABELS[i]}</span>
                          <h3 className="feature-banner-title w-full font-display font-extrabold text-night-foreground">{f.title}</h3>
                          <p className="feature-banner-body w-full text-night-muted" data-mobile-body={f.mobileBody}>{f.body}</p>
                        </div>
                      </div>
                      <div className="mh-art-slot">
                        <div className="mh-art-inner">
                          <FeatureBannerGraphic index={i} />
                        </div>
                      </div>
                    </div>
                  </ScrollReveal>
                );
              })}
            </div>
            <ScrollReveal delay={100} className="pr-featured-reveal">
              <article className="pr-featured-card">
                <div className="pr-featured-copy">
                  <span className="pr-featured-kicker">Hidden by design</span>
                  <h3 className="pr-featured-title">Protected Identity</h3>
                  <p className="pr-featured-text">
                    <span className="pr-featured-text-desktop">Your AI speaks for you, so we lock it like it matters! If anyone copies or types your custom domain into a url directly, it leads nowhere. A secret code hidden behind your link is the only way in, so strangers can&apos;t drain your bot, misuse it, or pretend to be you with it.</span>
                    <span className="pr-featured-text-mobile">If anyone copies or types your custom domain into a url directly, it leads nowhere. A secret code hidden behind your link is the only way in.</span>
                  </p>
                </div>
                <div className="pr-featured-icon" aria-hidden="true">
                  <svg viewBox="0 0 120 120" fill="none">
                    <g className="pr-ad-unit">
                      <path className="pr-ad-bracket" d="M4 18 V4 H18 M102 4 H116 V18 M116 102 V116 H102 M18 116 H4 V102" />
                      <circle className="pr-ad-core" cx="60" cy="46" r="27" />
                      <path className="pr-ad-ring" pathLength={1} d="M60 19 A27 27 0 1 1 59.99 19" />
                      <path className="pr-ad-slash" pathLength={1} d="M41 27 L79 65" />
                      <rect className="pr-ad-scan" x="8" y="8" width="104" height="2" rx="1" />
                      <g className="pr-ad-label">
                        <rect className="pr-ad-plate" x="10" y="90" width="100" height="18" rx="3" />
                        <text className="pr-ad-text" x="60" y="102.6" textAnchor="middle" textLength="86" lengthAdjust="spacingAndGlyphs">ACCESS DENIED</text>
                      </g>
                    </g>
                  </svg>
                </div>
              </article>
            </ScrollReveal>
          </div>
        </section>

        {/* Why LinkBot: native section box; only small pieces (each under
            1440 x 1200 natural px) are scaled. */}
        <MhQuestions onStartDemo={openForm} />


        {/* ---- Remaining phone sections: native section boxes; only small
            pieces (each well under 1440 x 1200 natural px) are scaled. ---- */}
        <section className="cost-of-waiting-section mh-layer-rest border-y border-border bg-surface">
          <div className="mh-rest-container text-center" style={{ padding: `calc(239px * ${S}) calc(64px * ${S})` }}>
            <ScrollReveal repeat>
              <MhPiece>
                <p className="eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">The cost of waiting</p>
                <h2 className="headline mx-auto mt-3 max-w-[26ch] text-balance text-5xl text-ink max-sm:text-[7rem] max-sm:leading-[1.05]">
                  The <span className="text-brand">best time to answer</span> is while interest is still high.
                </h2>
                <p className="mx-auto mt-4 max-w-[62ch] text-balance text-base font-semibold leading-7 text-muted-foreground max-sm:!mb-12 max-sm:!mt-8 max-sm:text-[3rem] max-sm:leading-[1.4]">While you are in meetings, on calls, or asleep, your AI is handling conversations, capturing leads, and keeping your pipeline moving. You build the business, let LinkBot handle the first impression for you.</p>
              </MhPiece>
              <MhStats />
            </ScrollReveal>
          </div>
        </section>

        <section className="mh-layer-rest overflow-hidden" aria-labelledby="reviews-heading" style={{ backgroundColor: "var(--surface-2)", padding: `calc(239px * ${S}) 0` }}>
          <div className="mh-rest-container flex flex-col" style={{ padding: `0 calc(64px * ${S})`, gap: `calc(96px * ${S})` }}>
            <MhPiece>
              <div className="text-right">
                <p className="pr-eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">FOUNDERS LOVE US</p>
                <h2 id="reviews-heading" className="headline mt-4 text-balance text-5xl text-ink max-sm:text-[7rem] max-sm:leading-[1.05]">
                  <span className="block">When attention becomes <span className="text-brand">a lead</span></span>
                  <span className="block">
                    <span className="text-brand">you can </span>
                    <span className="text-brand">actually follow-up with</span>
                    <span>.</span>
                  </span>
                </h2>
                <p className="mt-6 w-full text-base font-semibold leading-7 text-ink-soft max-sm:!mb-0 max-sm:!mt-8 max-sm:text-[3rem] max-sm:leading-[1.4]">
                  <span className="block">Your profile already gets attention. LinkBot gives visitors a reason to stop, engage, and start a real conversation. Your social presence should never be static. Our LinkBot users turn everyday profile traffic into more meaningful connections.</span>
                  <span className="mt-7 block max-sm:!mt-[4.2rem]">Your website gives visitors multiple ways to take action. Why should your profile be any different?</span>
                </p>
              </div>
            </MhPiece>
            <div className="mh-review-window" aria-label="Illustrative review carousel" style={{ height: `calc(1600px * ${S})` }}>
              <div className="mh-review-track">
                {[0, 1].map((copy) => (
                  <div key={copy} style={{ paddingBottom: `calc(20px * ${S})` }} aria-hidden={copy === 1}>
                    {REVIEWS.map((review, index) => (
                      <MhPiece key={`${copy}-${review.name}`} className={cn("mh-review-slot", REVIEW_STAGGER[index % REVIEW_STAGGER.length])}>
                        <article className="review-card rounded-lg border border-border bg-surface p-5 text-ink shadow-elev-2 max-sm:!rounded-[2rem] max-sm:!p-10">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex min-w-0 items-center gap-3">
                              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-brand text-sm font-extrabold text-brand-foreground max-sm:h-20 max-sm:w-20 max-sm:text-[2.5rem]">{review.name.charAt(0)}</span>
                              <p className="truncate text-sm font-bold max-sm:text-[3rem]">{review.name}</p>
                            </div>
                            <div className="shrink-0 text-right">
                              <div className="flex gap-0.5 text-warning" aria-label="Five stars">
                                {[0, 1, 2, 3, 4].map((star) => <Star key={star} className="h-3.5 w-3.5 fill-current max-sm:h-8 max-sm:w-8" aria-hidden />)}
                              </div>
                              <p className="mt-1 text-[10px] text-muted-foreground max-sm:text-[2rem]">{review.timeAgo}</p>
                            </div>
                          </div>
                          <blockquote className="mt-4 text-[13px] leading-5 text-ink-soft max-sm:mt-8 max-sm:text-[2.75rem] max-sm:leading-[1.4]">“{review.quote}”</blockquote>
                        </article>
                      </MhPiece>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="night-panel mh-layer-rest mh-pricing-section overflow-hidden">
          <div className="mh-rest-container flex flex-col" style={{ padding: `calc(239px * ${S}) calc(64px * ${S})`, gap: `calc(96px * ${S})` }}>
            <MhPiece>
              <p className="eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">From chat to close</p>
              <h2 className="headline mt-4 text-balance text-5xl text-night-foreground max-sm:text-[7rem] max-sm:leading-[1.05]">
                <span className="block">Runs like your best employee,</span>
                <span className="block"><span className="text-brand">without the high payroll costs</span>.</span>
              </h2>
              <p className="mt-4 max-w-[60ch] text-base font-semibold leading-7 text-night-muted max-sm:!mb-12 max-sm:!mt-8 max-sm:text-[3rem] max-sm:leading-[1.4]">
                No sick or vacation days! Get another set of hands for your business without another salary, schedule, or person to manage. LinkBot is ready to work around the clock for one simple monthly price with no long-term contract.
              </p>
              <ul className="mt-8 space-y-5 max-sm:!mt-0">
                {["Turn your profile into another call to action", "No salary, benefits, training, or employee overhead", "Be there for every opportunity without answering yourself"].map((t) => (
                  <li key={t} className="flex items-start gap-4 text-night-foreground/90 max-sm:gap-6">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-brand/30 bg-brand/10 max-sm:h-14 max-sm:w-14">
                      <Check className="h-3.5 w-3.5 text-brand max-sm:h-8 max-sm:w-8" strokeWidth={3} />
                    </span>
                    <MhFitOneLine text={t} className="text-[15px] font-medium tracking-tight max-sm:text-[3rem] max-sm:leading-[1.35]" />
                  </li>
                ))}
              </ul>
            </MhPiece>
            <div className="pricing-mobile-frame mh-pricing-frame">
              <MhPricingReveal>
              <div className="pricing-fit-desktop relative">
                <PricingCardNew phone />
              </div>
              </MhPricingReveal>
            </div>
            <MhPiece>
              <CompareCostPhoneContent />
            </MhPiece>
          </div>
        </section>

        <section className="security-graphic-section mh-layer-rest">
          <div className="mh-rest-container flex flex-col" style={{ padding: `calc(239px * ${S}) calc(64px * ${S})`, gap: `calc(48px * ${S})` }}>
            <MhPiece>
              <div className="relative z-10">
                <p className="eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">Security</p>
                <h2 className="headline mt-3 text-balance text-5xl text-ink max-sm:text-[7rem] max-sm:leading-[1.05]">
                  <span className="block">Your business always</span>
                  <span className="block">stays <span className="text-brand">your business</span>.</span>
                </h2>
                <p className="mt-5 max-w-[58ch] text-base font-semibold leading-7 text-ink-soft max-sm:!mb-0 max-sm:!mt-8 max-sm:text-[3rem] max-sm:leading-[1.4]">
                  Conversations, lead details, and personal data<br className="hidden max-sm:block" /> are encrypted, independently audited, and<br className="hidden max-sm:block" /> continuously tested against threats.
                </p>
              </div>
            </MhPiece>
            <div className="flex flex-col" style={{ gap: `calc(112px * ${S})` }}>
              <MhPiece>
                <div className="security-promises col-span-2 border-t max-sm:order-2 max-sm:col-span-1 max-sm:!grid-cols-1 max-sm:!border-x-0 max-sm:!border-y-2 max-sm:!border-[color-mix(in_oklab,var(--ink)_18%,transparent)] max-sm:[&_.security-promise]:!min-h-0 max-sm:[&_.security-promise]:!border-0 max-sm:[&_.security-promise]:!border-[color-mix(in_oklab,var(--ink)_18%,transparent)] max-sm:[&_.security-promise]:!py-10 max-sm:[&_.security-promise]:!pl-0 max-sm:[&_.security-promise]:!pr-0 max-sm:[&_.security-promise+.security-promise]:!border-l-0 max-sm:[&_.security-promise+.security-promise]:!border-t-2 max-sm:[&_.security-promise_p]:!whitespace-normal max-sm:[&_.security-promise_p]:!text-[3.25rem] max-sm:[&_.security-promise_span]:!mt-4 max-sm:[&_.security-promise_span]:!text-[2rem]">
                  {[
                    { meaning: <>Independent experts verify it.</>, key: "independent", proof: "SOC 2 Type II | Audited every year" },
                    { meaning: <>Conversations unreadable.</>, key: "conversations", proof: "AES 256 at rest | TLS 1.2+ in transit" },
                    { meaning: <>Security threats get caught early.</>, key: "threats", proof: "PEN TESTING | CONTINUOUS SCANNING" },
                  ].map((item) => (
                    <div key={item.key} className="security-promise">
                      <p>{item.meaning}</p>
                      <span>{item.proof}</span>
                    </div>
                  ))}
                </div>
              </MhPiece>
              <MhPiece>
                <div
                  className="security-lockup max-sm:order-3 max-sm:mx-auto max-sm:[&_.security-feed_span]:!bottom-6 max-sm:[&_.security-feed_span]:!text-[1.5rem] max-sm:[&_.security-seal]:!w-[32rem] max-sm:[&_.security-seal-kicker]:!text-[1.5rem] max-sm:[&_.security-seal-number]:!text-[11rem] max-sm:[&_.security-seal_strong]:!text-[4rem] max-sm:[&_.security-seal-footer]:!text-[1.5rem]"
                  aria-label="Conversation and lead data protected by audited encryption"
                >
                  <div className="security-orbit security-orbit-outer !left-1/2 !top-1/2 hidden max-sm:block" aria-hidden="true"><i /><i /><i /><i /></div>
                  <div className="security-orbit security-orbit-inner !left-1/2 !top-1/2 hidden max-sm:block" aria-hidden="true"><i /><i /><i /><i /></div>
                  <div className="security-feed security-feed-top" aria-hidden="true"><span>Conversation</span></div>
                  <div className="security-feed security-feed-bottom" aria-hidden="true"><span>Lead data</span></div>
                  <div className="security-seal">
                    <span className="security-seal-kicker">Protected by</span>
                    <strong>AES</strong>
                    <span className="security-seal-number">256</span>
                    <span className="security-seal-footer">Encrypted at rest</span>
                  </div>
                </div>
              </MhPiece>
            </div>
          </div>
        </section>

        <div className={`faq-drawer mh-faq-drawer ${faqOpen ? "faq-drawer--open" : ""}`} aria-hidden={!faqOpen} inert={!faqOpen}>
          <MhFAQ />
        </div>
      </main>
      )}

      {demoView !== "form" && <footer
        ref={homeFooterRef}
        className="night-panel mh-footer relative border-t border-night-border text-center text-night-muted"
        style={{ padding: `calc(176.112px * ${S} + 53.248px) calc(24px * ${S}) 26px`, fontSize: "11.2px" }}
      >
        <button
          type="button"
          onClick={() => setFaqOpen((open) => !open)}
          aria-expanded={faqOpen}
          aria-controls="faq"
          className="faq-pull-tab mh-faq-tab"
        >
          <span className="faq-pull-tab__cord" aria-hidden="true">
            <span />
          </span>
          <span className="faq-pull-tab__tag">
            <span className="faq-pull-tab__copy">
              <small>{faqOpen ? "CLICK TO CLOSE" : "Have questions?"}</small>
              <strong>{faqOpen ? "CLOSE FAQ" : "CLICK FOR ANSWERS"}</strong>
            </span>
            <span className="faq-pull-tab__action" aria-hidden="true">
              <ChevronDown className={`faq-pull-tab__chevron ${faqOpen ? "faq-pull-tab__chevron--open" : ""}`} />
            </span>
          </span>
        </button>
        <p style={{ fontSize: "11.2px", lineHeight: 1.5 }}>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>}
      {demoView === "form" && (
        <footer ref={demoFooterRef} className="demo-form-footer site-footer-balanced night-panel border-t border-night-border px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted">
          <p>
            <span className="footer-stack">
              <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
            </span>
          </p>
        </footer>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Remaining sections (below Why LinkBot).

/** A small canvas-authored piece: fills its parent's width, renders its
 * children at canvas size (width / --mobile-scale) and scales them down.
 * Its reserved height is measured only on first load, fonts ready, window
 * load, a real width change, or the piece's own (guarded) size change. */
/** A canvas-authored piece scaled by `factor` (a CSS expression) with its
 * scaled size reserved. Measured only on load, fonts ready, a real width
 * change, or its own guarded size change — never during scroll. */
function MhCallPiece({ factor, fitWidth, children }: { factor: string; fitWidth?: boolean; children: ReactNode }) {
  const innerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  useLayoutEffect(() => {
    const inner = innerRef.current;
    if (!inner) return;
    let lw = -1;
    let lh = -1;
    const sync = () => {
      const w = inner.offsetWidth;
      const h = inner.offsetHeight;
      if (Math.abs(w - lw) <= 0.5 && Math.abs(h - lh) <= 0.5) return;
      lw = w;
      lh = h;
      setSize({ w, h });
    };
    sync();
    const ro = lockedResizeObserver(sync);
    ro.observe(inner);
    const off = onMeasureTriggers(sync);
    return () => {
      ro.disconnect();
      off();
    };
  }, []);
  return (
    <div style={{ position: "relative", width: fitWidth ? `calc(${size.w}px * ${factor})` : "100%", height: `calc(${size.h}px * ${factor})` }}>
      <div
        ref={innerRef}
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          display: "flow-root",
          width: fitWidth ? "max-content" : `calc(100% / (${factor}))`,
          transform: `scale(calc(${factor}))`,
          transformOrigin: "top left",
        }}
      >
        {children}
      </div>
    </div>
  );
}

/** Hero view 3 (live demo), rebuilt from LiveDemoStage without CSS zoom.
 * K = the current phone's inner scale-125 times the canvas scale. */
function MhLiveDemo({ sectionRef, compositionRef, companyName, cta }: { sectionRef: RefObject<HTMLElement | null>; compositionRef: RefObject<HTMLDivElement | null>; companyName: string; cta: ReactNode }) {
  const K = `1.25 * ${S}`;
  const P = `1.68 * ${K}`;
  const T = `calc(192px * ${S})`;
  const [callState, setCallState] = useState<"connecting" | "live" | "ended">("live");
  void companyName;
  // Prompt 78: no screen measuring. The browser fits the column (flex/grid +
  // svh); only the column's own layout height feeds the sticky top, so a
  // taller-than-screen hero scrolls until Buy Now + T is visible, then pins.
  useLayoutEffect(() => {
    const section = sectionRef.current;
    const column = compositionRef.current;
    if (!section || !column) return;
    const ro = new ResizeObserver(() => {
      section.style.setProperty("--mh-live-h", `${column.offsetHeight}px`);
    });
    ro.observe(column);
    return () => ro.disconnect();
  }, [compositionRef, sectionRef]);
  // 424: hero-local --mobile-scale so every size inside this section derives
  // from its real width and the whole composition scales as one piece.
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;
    let last = -1;
    const apply = () => {
      const value = section.clientWidth / 1440;
      if (Math.abs(value - last) > 0.0001) {
        last = value;
        section.style.setProperty("--mobile-scale", `${Number(value.toFixed(6))}`);
      }
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(section);
    return () => {
      ro.disconnect();
      section.style.removeProperty("--mobile-scale");
    };
  }, [sectionRef]);
  const col1 = { gridColumn: 1, minWidth: 0 } as const;
  return (
    <section
      ref={sectionRef}
      className="night-panel demo-form-focus-hero mh-layer-hero mh-live-hero relative overflow-hidden text-left"
      style={{
        paddingTop: 0,
        paddingLeft: `calc(96px * ${S})`,
        paddingRight: `calc(96px * ${S})`,
        paddingBottom: 0,
        boxSizing: "border-box",
        // Prompt 60: never shorter than the tallest possible screen (toolbars hidden).
        minHeight: "max(calc(var(--mh-screen-h, 852px) - 71px), calc(100lvh - 71px))",
      }}
    >
      <div
        className="pointer-events-none absolute left-1/2 -translate-x-1/2 rounded-full"
        style={{ top: `calc(-160px * ${S})`, width: `calc(960px * ${S})`, height: `calc(640px * ${S})`, background: "radial-gradient(closest-side, rgba(37, 99, 235, 0.22), rgba(37, 99, 235, 0) 70%)" }}
      />
      <div
        ref={compositionRef}
        id="live-demo"
        className="mh-live-column animate-fade-up"
        style={{
          position: "relative",
          display: "grid",
          gridTemplateColumns: "minmax(0,1fr) auto",
          gridTemplateRows: "auto auto auto auto",
          alignContent: "space-between",
          alignItems: "start",
          columnGap: `calc(40px * ${K})`,
          boxSizing: "border-box",
          paddingTop: T,
          paddingBottom: T,
        }}
      >
        <div style={{ ...col1, gridRow: 1 }}>
          <MhCallPiece factor={K}>
            <p className="pr-eyebrow mr-[-571px] text-[1.75rem] leading-[1.25]" style={{ fontWeight: 700 }}>YOUR PERSONALIZED LIVE DEMO</p>
          </MhCallPiece>
        </div>
        <div style={{ ...col1, gridRow: 2 }}>
          <MhCallPiece factor={K}>
            <h2 className="hero-call-title headline mr-[-571px] text-balance text-[86.46px] leading-[1] text-night-foreground" style={{ marginTop: 24 }}>
              Meet Your <span className="text-brand">LinkedIn{" "}<span style={{ display: "inline-block" }}>AI Voice Employee</span></span>
            </h2>
          </MhCallPiece>
        </div>
        <div style={{ ...col1, gridRow: 3, marginTop: `calc(112px * ${K})` }}>
          <MhCallPiece factor={K}>
            <p className="text-[2.5rem] font-extrabold leading-[1.25] text-night-foreground" style={{ marginTop: 0 }}>Talk to it. Test it live.</p>
            <p className="w-full text-[2.5rem] leading-[1.25] text-night-muted" style={{ marginTop: 32 }}>
              <span className="block">{mhForcedBreaks("Put your personalized demo to the test. Ask about your company, services, products, process, pricing or anything else someone might look for on your website. Try simple questions, get specific, or ask something completely unexpected. See for yourself what LinkBot learned about your business, from only a website link.")}</span>
            </p>
            <p className="w-full text-[1.6rem] italic leading-[1.4] text-night-muted" style={{ marginTop: 24 }}>
              <span className="block">{"Your finished LinkBot can be trained with everything you want it to know, giving it the knowledge and context to represent you across every conversation."}</span>
            </p>
          </MhCallPiece>
        </div>
        <div className="mh-hero-buy-row" style={{ ...col1, gridRow: 4, marginTop: `calc(76px * ${K})`, marginRight: `calc(-571px * ${K})`, display: "flex", justifyContent: "center" }}>
          <MhCallPiece factor={P} fitWidth>
            <div style={{ width: 295 }}>{cta}</div>
          </MhCallPiece>
        </div>
        {/* Prompt 80: phone shares the text row, so its top lines up with
            "Talk to it. Test it live." by layout, however the headline wraps. */}
        <div style={{ gridColumn: 2, gridRow: "3 / span 2", marginTop: `calc(112px * ${K})` }}>
          <MhCallPiece factor={P} fitWidth>
            <LiveAgentPhone callState={callState} onEnd={() => setCallState("ended")} onRestart={() => setCallState("live")} />
          </MhCallPiece>
        </div>
      </div>
    </section>
  );
}

/** Pricing reveal on its own wrapper around the scaled card (translate +
 *  opacity only). Plays once on the way down, never hides while any part is
 *  on screen, and resets only when fully below the viewport. */
function MhPricingReveal({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    node.dataset['reveal'] = "hidden";
    const clear = (e: Event) => {
      if (e.target === node) node.style.willChange = "";
    };
    node.addEventListener("transitionend", clear);
    node.addEventListener("animationend", clear);
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry) return;
        if (entry.isIntersecting) {
          if (node.dataset['reveal'] !== "hidden") return;
          if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            node.style.willChange = "";
            node.dataset['reveal'] = "snap";
          } else {
            node.style.willChange = "transform, opacity";
            node.dataset['reveal'] = "show";
          }
          return;
        }
        // Fully below the viewport → reset to hidden so it can replay.
        if (entry.boundingClientRect.top > 0) {
          node.style.willChange = "";
          node.dataset['reveal'] = "hidden";
        }
        // Above the viewport → keep it revealed.
      },
      { threshold: 0 },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      node.removeEventListener("transitionend", clear);
      node.removeEventListener("animationend", clear);
    };
  }, []);
  return (
    <div ref={ref} className="mh-reveal mh-reveal-pricing" data-reveal="hidden">
      {children}
    </div>
  );
}


function MhPiece({ children, className }: { children: ReactNode; className?: string }) {
  const innerRef = useRef<HTMLDivElement>(null);
  const [h, setH] = useState(0);
  useLayoutEffect(() => {
    const inner = innerRef.current;
    if (!inner) return;
    let last = -1;
    const sync = () => {
      const v = inner.offsetHeight;
      if (Math.abs(v - last) <= 0.5) return;
      last = v;
      setH(v);
    };
    sync();
    const ro = lockedResizeObserver(sync);
    ro.observe(inner);
    const off = onMeasureTriggers(sync);
    return () => {
      ro.disconnect();
      off();
    };
  }, []);
  return (
    <div className={cn("mh-piece", className)} style={{ height: `calc(${h}px * ${S})` }}>
      <div ref={innerRef} className="mh-piece-inner">{children}</div>
    </div>
  );
}

/** FitOneLine, re-fitted only on the width-only measurement triggers. */
function MhFitOneLine({ text, className }: { text: string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fit = () => {
      el.style.fontSize = "";
      el.style.whiteSpace = "nowrap";
      el.style.flex = "1 1 0%";
      el.style.minWidth = "0";
      const base = parseFloat(getComputedStyle(el).fontSize);
      const avail = el.clientWidth;
      const w = el.scrollWidth;
      if (avail > 0 && w > avail) el.style.fontSize = `${(base * avail) / w}px`;
    };
    fit();
    const raf = requestAnimationFrame(() => {
      const avail = el.clientWidth;
      const w = el.scrollWidth;
      const cur = parseFloat(el.style.fontSize || "");
      if (avail > 0 && w > avail && cur) el.style.fontSize = `${(cur * avail) / w}px`;
    });
    const off = onMeasureTriggers(fit);
    return () => {
      cancelAnimationFrame(raf);
      off();
    };
  }, [text]);
  return <span ref={ref} className={className}>{text}</span>;
}

/** StatsCounter with the same counter logic; the frame is native and each
 * stat is its own small scaled piece. */
function MhStats() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setProgress(1);
      return;
    }
    let animationFrame = 0;
    const observer = new IntersectionObserver(
      ([entry]) => {
        // 257: while pinch-zoomed the counters do not animate; show final values.
        if (isHeroZoomPaused()) {
          cancelAnimationFrame(animationFrame);
          if (entry?.isIntersecting) setProgress(1);
          return;
        }
        if (!entry?.isIntersecting) {
          cancelAnimationFrame(animationFrame);
          setProgress(0);
          return;
        }
        cancelAnimationFrame(animationFrame);
        const startedAt = performance.now();
        const duration = 1400;
        const animate = (now: number) => {
          const elapsed = Math.min((now - startedAt) / duration, 1);
          setProgress(1 - Math.pow(1 - elapsed, 3));
          if (elapsed < 1) animationFrame = requestAnimationFrame(animate);
        };
        animationFrame = requestAnimationFrame(animate);
      },
      { threshold: 0.35 },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      cancelAnimationFrame(animationFrame);
    };
  }, []);
  return (
    <div ref={containerRef} className="mh-stats overflow-hidden border border-border bg-surface text-ink">
      {STATS.map((stat, index) => (
        <MhPiece key={stat.label}>
          <article className={cn("relative flex min-h-56 flex-col items-center justify-center px-8 py-10 text-center max-sm:min-h-[24rem] max-sm:px-12 max-sm:py-16", index > 0 && "mh-stat-divider border-border max-sm:border-l-0 max-sm:border-t")}>
            <span className="absolute inset-x-10 top-0 h-px bg-brand" aria-hidden="true" />
            <p className="font-display text-[clamp(2.5rem,5vw,4rem)] font-extrabold leading-none text-brand max-sm:!text-[8rem]" aria-label={`${stat.value}${stat.suffix}`}>
              {Math.round(stat.value * progress)}{stat.suffix}
            </p>
            <p className="mt-5 max-w-[23ch] text-balance text-sm leading-6 text-ink-soft max-sm:mt-10 max-sm:max-w-[26ch] max-sm:text-[3rem] max-sm:leading-[1.35]">{mhForcedBreaks(stat.label)}</p>
            <button type="button" onClick={() => window.open(stat.href, "_blank", "noopener,noreferrer")} className="mt-5 cursor-pointer text-xs leading-5 text-muted-foreground/70 transition-colors hover:text-muted-foreground max-sm:mt-10 max-sm:text-[2rem]">
              Source: {stat.source}
            </button>
          </article>
        </MhPiece>
      ))}
    </div>
  );
}

function MhChevronIcon() {
  return (
    <svg className="pr-faq__chevron" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="m6 9 6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/** LinkBotFAQ with the same content and accordion behaviour; the list is
 * native and each item is its own small scaled piece. */
function MhFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  return (
    <section id="faq" className="pr-faq">
      <div className="mh-rest-container" style={{ padding: `calc(239px * ${S}) calc(64px * ${S}) calc(338.5px * ${S})` }}>
        <MhPiece>
          <p className="pr-faq__eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">FAQ</p>
          <h2 className="pr-faq__title max-sm:text-[7rem] max-sm:leading-[1.05]">
            Questions
            <br />
            <span className="text-brand">Real CEOs Ask</span>
          </h2>
        </MhPiece>
        <div className="flex flex-col" style={{ gap: `calc(12px * 1312 / 720 * ${S})`, marginTop: `calc(80px * ${S})` }}>
          {MH_FAQ_ITEMS.map((item, index) => {
            const isOpen = openIndex === index;
            const triggerId = `pr-faq-trigger-${index}`;
            const panelId = `pr-faq-panel-${index}`;
            return (
              <div key={item.question}>
                <article className={`pr-faq__item mh-faq-item ${isOpen ? "pr-faq__item--open" : ""}`}>
                  <h3 className="pr-faq__question-heading">
                    <button
                      id={triggerId}
                      type="button"
                      className="pr-faq__trigger"
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      onClick={() => setOpenIndex(isOpen ? null : index)}
                    >
                      <span className="pr-faq__question">{item.question}</span>
                      <MhChevronIcon />
                    </button>
                  </h3>
                  <div id={panelId} role="region" aria-labelledby={triggerId} aria-hidden={!isOpen} className="pr-faq__panel">
                    <div className="pr-faq__panel-inner">
                      <p className="pr-faq__answer">{item.answer}</p>
                    </div>
                  </div>
                </article>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}


const MH_FAQ_ITEMS = [
  {
    question: "How do links work?",
    answer:
      "Add unlimited links, documents and videos through url's, with custom labels for each button. Your labels tell your LinkBot what to share and when, so it comes up naturally. Asking about cost? It sends your pricing. Torn between two programs? It recommends the best fit and sends that link. Looking for a job? It shares your application. Each link pops up as a button they can open without ending the call, and documents save to their device. Everything stays saved on their home screen for next time, where they can rename, delete, rearrange, or sort it into folders.",
  },

  {
    question: "Can I share to other social media profiles?",
    answer:
      "Not yet, for two reasons. First, other social media apps block voice inside their built-in browsers, so visitors who tap your link there won't be able to talk with your AI. Second, LinkBot's link protection is built for LinkedIn, where your private link stays hidden behind a visual card instead of showing as plain text. On other platforms it would show as a plain link anyone could copy and use to pretend to be you on a fake account. We're building that same protection for other platforms, and each one will be added as soon as it's ready.",
  },
  {
    question: "Can I put my LinkBot link in a LinkedIn post?",
    answer:
      "Yes. Sharing it in a post is a great way to get more people talking with your AI. Before you post, you must follow the post steps in your welcome guide exactly. If you skip them, your private link shows as plain text that anyone can copy and use. Also keep in mind that a popular post can bring many visitors at once, so if all 20 lines are in use at the same moment, new callers will see that the line is unavailable and will have to wait for a line to open up. Currently, we are building a new backup feature to fix this issue, so visitors can keep the conversation going even when every line is busy. We are excited to share that with you soon!",
  },
  {
    question: "Can I put LinkBot anywhere?",
    answer:
      "Not yet. We're currently building the ability to place LinkBot anywhere. Until the encrypted link protection for it is ready, we do not recommend it, since your link could be copied and used by others in identity fraud without your permission or knowledge.",
  },
  {
    question: "Can one LinkBot cover different websites?",
    answer:
      "Yes. You can add as many websites and documents as you'd like, so a single LinkBot can speak confidently about every company, brand, offer, service, and project you have, all from one bot. That way, it can give each visitor personal guidance on which option is the best fit for them.",
  },
  {
    question: "How many people can talk to my LinkBot at once?",
    answer:
      "Every voice AI service limits how many live conversations can happen at once, and most allow between 4 and 20 on standard plans. Your LinkBot handles up to 20, which is far more than it sounds: with a typical three minute conversation, around 400 people would need to start talking within one hour to fill every line. Even busy profiles usually don't hit the limit.",
  },
  {
    question: "Do visitors need to download anything or create an account?",
    answer:
      "No. Visitors just tap your link and start talking. There's nothing to install, no account to create, and no number to dial, so the conversation begins the moment they click on it.",
  },
  {
    question: "What happens when a visitor asks something it doesn't know?",
    answer:
      "Your LinkBot lets the visitor know you'll follow up with them personally, and their question is included in your conversation recap, so you can answer it yourself afterward.",
  },
  {
    question: "What gets sent to visitors, and when am I notified?",
    answer:
      "If a visitor asks for a recap during conversation, they receive an email with a summary and all their links shared. Since we captured their contact details, only then do we notify you. So every alert is a real lead, and you can send a personalized follow-up in one click to start the conversation and capture the lead. Nothing from you is ever sent without your approval.",
  },
  {
    question: "How does calendar booking work?",
    answer:
      "If your calendar connects with LinkBot, your AI books the meeting for them right in the conversation, just like a human assistant would, finding a time that works, confirming the details, and sending them a confirmation. If not, it shares your booking link so visitors can still book with you directly in that moment.",
  },
  {
    question: "Which calendars does LinkBot work with?",
    answer:
      "LinkBot connects with Google Calendar, Microsoft Outlook, Apple iCloud, and Calendly, and meetings can include Zoom or Microsoft Teams links. If you use a different calendar, your AI shares your booking link so visitors can still book with you directly on their own.",
  },
  {
    question: "Can I choose or change my AI's voice?",
    answer:
      "Yes. You choose a female or male voice when you sign up, and you can switch between them anytime from your dashboard, as often as you'd like, whenever you want a change.",
  },
  {
    question: "Can I use my own voice?",
    answer:
      "Not at this time. To keep setup seamless for every client, LinkBot offers a carefully selected female and male voice, so your AI sounds natural and professional from day one.",
  },
  {
    question: "Can I change my link name later?",
    answer:
      "Yes. You can change your link name or get a brand new private link anytime from your dashboard, and your updated link is sent to you right away, ready to place on your profile.",
  },
  {
    question: "Can I connect my own AI bot instead?",
    answer:
      "LinkBot works as one complete system: the AI, your private link, your dashboard, and your follow-ups are all built to work together, with dedicated capacity reserved for every visitor. That connection is what makes it work so well, so LinkBot runs only on its own AI.",
  },
  {
    question: "Can I have more than one LinkBot?",
    answer:
      "Yes. You can add as many AI employees as you'd like under the same login. Each one comes with its own easy to read dashboard, analytics, link, voice, and training, and each is billed as its own separate monthly subscription.",
  },
  {
    question: "Can I use one LinkBot on more than one account?",
    answer:
      "No. Each LinkBot comes with its own set of live talk lines, and sharing one across several profiles would split that capacity between all of them. We recommend a dedicated LinkBot for each account, so every profile has its full set of lines available and every visitor can start a conversation the moment they arrive.",
  },
  {
    question: "What happens if I cancel?",
    answer:
      "You can cancel anytime from your account. Your LinkBot keeps working through the end of the month you've already paid for, and you will not be charged again after that.",
  },
];

/* ---------------- Why LinkBot (native rebuild) ----------------
   Content, classes and reveal timing copied unchanged from LinkBotQuestions.
   The section box and its padding are native screen pixels; the banner,
   header, each card, the VS badge and the button are separate scaled pieces. */

const MH_STANDARD_STEPS = [
  { icon: Globe2, title: "Lands on a website", detail: "Another page to navigate" },
  { icon: Search, title: "Searches for an answer", detail: "Interest starts to cool" },
  { icon: FileText, title: "Finds a form or inbox", detail: "The conversation waits" },
];

const MH_LINKBOT_STEPS = [
  { icon: Mic2, title: "Starts talking", detail: "A natural voice conversation" },
  { icon: MessageCircleMore, title: "Gets clear answers", detail: "Trained on your business" },
  { icon: Check, title: "Becomes a qualified lead", detail: "Details captured automatically" },
];

const MH_Q_GRID_CLASS =
  "pr-comparison-grid max-sm:!grid-cols-1 max-sm:!gap-0 max-sm:[&_.pr-comparison-card]:!min-h-0 max-sm:[&_.pr-comparison-card]:!p-12 max-sm:[&_.pr-comparison-label]:!text-[2.25rem] max-sm:[&_.pr-comparison-status]:!text-[2.25rem] max-sm:[&_.pr-comparison-status>span]:!h-5 max-sm:[&_.pr-comparison-status>span]:!w-5 max-sm:[&_.pr-comparison-vs]:!relative max-sm:[&_.pr-comparison-vs]:!left-auto max-sm:[&_.pr-comparison-vs]:!top-auto max-sm:[&_.pr-comparison-vs]:!mx-auto max-sm:[&_.pr-comparison-vs]:!text-[2rem] max-sm:[&_.pr-comparison-vs]:!h-[14rem] max-sm:[&_.pr-comparison-vs]:!w-[6rem] max-sm:[&_.pr-comparison-vs]:!translate-x-0 max-sm:[&_.pr-comparison-vs]:!translate-y-0 max-sm:[&_.pr-comparison-step]:!min-h-[10rem] max-sm:[&_.pr-comparison-step]:!gap-6 max-sm:[&_.pr-comparison-step]:!px-8 max-sm:[&_.pr-comparison-step-icon]:!h-[5.5rem] max-sm:[&_.pr-comparison-step-icon]:!w-[5.5rem] max-sm:[&_.pr-comparison-step-icon]:!flex-[0_0_5.5rem] max-sm:[&_.pr-comparison-step-icon_svg]:!h-[2.75rem] max-sm:[&_.pr-comparison-step-icon_svg]:!w-[2.75rem] max-sm:[&_strong]:!text-[3rem] max-sm:[&_strong]:!leading-[1.2] max-sm:[&_small]:!mt-2 max-sm:[&_small]:!text-[2.5rem] max-sm:[&_small]:!leading-[1.35] max-sm:[&_.pr-comparison-outcome]:!min-h-[12rem] max-sm:[&_.pr-comparison-outcome]:!gap-6 max-sm:[&_.pr-comparison-outcome]:!px-8 max-sm:[&_.pr-comparison-outcome>svg]:!h-10 max-sm:[&_.pr-comparison-outcome>svg]:!w-10 max-sm:[&_.pr-comparison-outcome>svg]:!flex-[0_0_2.5rem]";

/** Copied unchanged from LinkBotQuestions (down-scroll-only reveal). */
function useMhDownScrollShow<T extends HTMLElement>(threshold: number): { ref: RefObject<T | null>; state: "hidden" | "show" | "snap" } {
  const ref = useRef<T>(null);
  const [state, setState] = useState<"hidden" | "show" | "snap">("hidden");
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    let lastY = window.scrollY;
    let dir: "down" | "up" = "down";
    const onScroll = () => {
      const y = window.scrollY;
      if (y > lastY) dir = "down";
      else if (y < lastY) dir = "up";
      lastY = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) {
          setState("hidden");
          return;
        }
        setState(dir === "up" ? "snap" : "show");
      },
      { threshold },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, [threshold]);
  return { ref, state };
}

/** The wrapper sits outside MhPiece. A single observer changes its DOM state;
 *  neither the scaled box nor React participates in animation frames. */
function useMhRevealWrapper(threshold: number): RefObject<HTMLDivElement | null> {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    node.dataset['reveal'] = "hidden";
    let lastY = window.scrollY;
    let dir: "down" | "up" = "down";
    const onScroll = () => {
      const y = window.scrollY;
      if (y > lastY) dir = "down";
      else if (y < lastY) dir = "up";
      lastY = y;
    };
    const clear = (e: Event) => {
      if (e.target === node) node.style.willChange = "";
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    node.addEventListener("transitionend", clear);
    node.addEventListener("animationend", clear);
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting || node.dataset['reveal'] !== "hidden") return;
        if (dir === "up" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
          node.style.willChange = "";
          node.dataset['reveal'] = "snap";
        } else {
          node.style.willChange = "transform, opacity";
          node.dataset['reveal'] = "show";
        }
      },
      { threshold },
    );
    observer.observe(node);
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
      node.removeEventListener("transitionend", clear);
      node.removeEventListener("animationend", clear);
    };
  }, [threshold]);
  return ref;
}

/** Recreates the section/container ancestors each piece's rules rely on. */
function MhQWrap({ children }: { children: ReactNode }) {
  return (
    <div className="pr-questions-section">
      <div className="pr-questions-container pr-comparison-container mh-q-wrap">{children}</div>
    </div>
  );
}

function MhQuestions({ onStartDemo }: { onStartDemo: () => void }) {
  useZoomLightMotion();
  const headerReveal = useMhDownScrollShow<HTMLElement>(0.7);
  const originReveal = useMhDownScrollShow<HTMLDivElement>(0.2);
  const standardReveal = useMhRevealWrapper(0.08);
  const linkbotReveal = useMhRevealWrapper(0.08);

  return (
    <section className="mh-layer-next pr-questions-section" aria-labelledby="link-comparison-heading">
      <span aria-hidden="true" className="mh-cover-mark" data-mh-cover="why-top" style={{ top: -1 }} />
      <MhPiece>
        <div className="pr-questions-section">
          <div className="section-banner-strip">
            <span className="section-banner-strip-text max-sm:!text-[7rem] max-sm:!tracking-[0.32em] max-sm:!indent-[0.32em]">Why LinkBot</span>
          </div>
        </div>
      </MhPiece>
      <div className="mh-rest-container" style={{ padding: `calc(239px * ${S}) calc(64px * ${S})` }}>
        <MhPiece>
          <MhQWrap>
            <motion.header
              ref={headerReveal.ref}
              className="pr-comparison-header max-sm:w-full max-sm:max-w-none"
              initial={{ opacity: 0, y: 18 }}
              animate={headerReveal.state === "hidden" ? { opacity: 0, y: 18 } : { opacity: 1, y: 0 }}
              transition={headerReveal.state === "snap" ? { duration: 0 } : { duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            >
              <p className="pr-questions-eyebrow max-sm:text-[2.5rem] max-sm:leading-[1.2]">THE LINKBOT DIFFERENCE</p>
              <h2 id="link-comparison-heading" className="headline mt-3 text-balance text-5xl text-ink">
                <span className="block max-sm:text-[7rem] max-sm:leading-[1.05]">One profile click.</span>
                <span className="block max-sm:text-[7rem] max-sm:leading-[1.05]">Two <span className="text-brand">very different outcomes</span>.</span>
              </h2>
            </motion.header>
            <motion.div
              ref={originReveal.ref}
              className="pr-comparison-origin max-sm:text-[2.5rem] max-sm:leading-[1.2]"
              aria-hidden="true"
              initial={{ opacity: 0, y: 18 }}
              animate={originReveal.state === "hidden" ? { opacity: 0, y: 18 } : { opacity: 1, y: 0 }}
              transition={originReveal.state === "snap" ? { duration: 0 } : { duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            >
              <span>LinkedIn profile</span>
              <ArrowDown className="max-sm:h-8 max-sm:w-8" />
            </motion.div>
          </MhQWrap>
        </MhPiece>

        <div ref={standardReveal} className="mh-reveal mh-reveal-standard" data-reveal="hidden">
        <MhPiece>
          <MhQWrap>
            <div className={MH_Q_GRID_CLASS}>
              <article className="pr-comparison-card pr-comparison-card-standard">
                <div className="pr-comparison-card-head">
                  <span className="pr-comparison-label">Normal link</span>
                  <span className="pr-comparison-status pr-comparison-status-muted"><span /> Passive Visit</span>
                </div>
                <div className="pr-comparison-journey">
                  {MH_STANDARD_STEPS.map((step, index) => (
                    <div className="pr-comparison-step" key={step.title}>
                      <span className="pr-comparison-step-icon"><step.icon aria-hidden="true" /></span>
                      <span><strong>{step.title}</strong><small>{step.detail}</small></span>
                      {index < MH_STANDARD_STEPS.length - 1 && <ArrowDown className="pr-comparison-arrow" aria-hidden="true" />}
                    </div>
                  ))}
                </div>
                <div className="pr-comparison-outcome pr-comparison-outcome-muted">
                  <UserRoundX aria-hidden="true" />
                  <span><strong>Visitor Leaves Unknown</strong><small>No context. No captured conversation.</small></span>
                </div>
              </article>
            </div>
          </MhQWrap>
        </MhPiece>
        </div>

        <MhPiece>
          <MhQWrap>
            <div className={cn(MH_Q_GRID_CLASS, "mh-q-grid-next")}>
              <div className="pr-comparison-vs" aria-hidden="true"><span>VS</span></div>
            </div>
          </MhQWrap>
        </MhPiece>

        <div ref={linkbotReveal} className="mh-reveal mh-reveal-linkbot" data-reveal="hidden">
        <MhPiece>
          <MhQWrap>
            <div className={cn(MH_Q_GRID_CLASS, "mh-q-grid-next")}>
              <article className="pr-comparison-card pr-comparison-card-linkbot">
                <div className="pr-comparison-glow" aria-hidden="true" />
                <div className="pr-comparison-card-head">
                  <span className="pr-comparison-label pr-comparison-label-brand">LinkBot link</span>
                  <span className="pr-comparison-status pr-comparison-status-live"><span /> Live Conversation</span>
                </div>
                <div className="pr-comparison-journey pr-comparison-journey-live">
                  {MH_LINKBOT_STEPS.map((step, index) => (
                    <div className="pr-comparison-step" key={step.title}>
                      <span className="pr-comparison-step-icon"><step.icon aria-hidden="true" /></span>
                      <span><strong>{step.title}</strong><small>{step.detail}</small></span>
                      {index < MH_LINKBOT_STEPS.length - 1 && <ArrowDown className="pr-comparison-arrow" aria-hidden="true" />}
                    </div>
                  ))}
                </div>
                <div className="pr-comparison-outcome pr-comparison-outcome-live">
                  <span className="pr-comparison-rings" aria-hidden="true"><Bell /></span>
                  <span><strong>Real Conversation &amp; Lead Capture</strong><small>Contact details, full summary and a message ready to send.</small></span>
                  <Send aria-hidden="true" />
                </div>
              </article>
            </div>
          </MhQWrap>
        </MhPiece>
        </div>

        <MhPiece>
          <MhQWrap>
            <button
              type="button"
              className="linkbot-button mobile-home-cta-questions mt-12 max-sm:!h-[131.65px] max-sm:!px-12 max-sm:!text-[50.74px]"
              onClick={onStartDemo}
            >
              <span className="flex items-center gap-2 max-sm:gap-4">Hear My Live Demo <ArrowRight className="h-4 w-4 max-sm:h-7 max-sm:w-7" aria-hidden="true" /></span>
            </button>
          </MhQWrap>
        </MhPiece>
      </div>
    </section>
  );
}

/** Line breaks fixed at the words where the current phone homepage breaks
    these texts at 393x852, so they break the same way at every phone width. */
const MH_FORCED_BREAKS: Record<string, string[]> = {
  "more leads qualify when answers arrive inside the first hour.": ["more leads qualify", "when answers arrive", "inside the first hour."],
  "What can visitors ask the AI voice employee?": ["What can visitors ask the AI voice", "employee?"],
  "Put your personalized demo to the test. Ask about your company, services, products, process, pricing or anything else someone might look for on your website. Try simple questions, get specific, or ask something completely unexpected. See for yourself what LinkBot learned about your business, from only a website link.": [
    "Put your personalized",
    "demo to the test. Ask",
    "about your company,",
    "services, products,",
    "process, pricing or",
    "anything else",
    "someone might look",
    "for on your website.",
    "Try simple questions,",
    "get specific, or ask",
    "something completely",
    "unexpected. See for",
    "yourself what LinkBot",
    "learned about your",
    "business, from only a",
    "website link.",
  ],
};

function mhForcedBreaks(text: string): ReactNode {
  const parts = MH_FORCED_BREAKS[text];
  if (!parts) return text;
  return parts.map((part, i) => (
    <span key={i}>
      {i > 0 && <br />}
      {part}
    </span>
  ));
}
