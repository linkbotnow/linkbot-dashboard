import { useNavigate, useRouter } from "@tanstack/react-router";
import { useEffect, type ComponentPropsWithoutRef, type MouseEvent } from "react";

type AppPath = "/" | "/claim" | "/login" | "/forgot-password";

type HoverlessLinkProps = Omit<ComponentPropsWithoutRef<"button">, "onClick" | "type"> & {
  to: AppPath;
  onClick?: (event: MouseEvent<HTMLButtonElement>) => void;
};

export function HoverlessLink({ to, onClick, children, ...props }: HoverlessLinkProps) {
  const navigate = useNavigate();
  const router = useRouter();

  // Load the destination page ahead of time so a click swaps pages in a single
  // step, with no intermediate frame of the current page at a different scroll.
  useEffect(() => {
    void router.preloadRoute({ to }).catch(() => undefined);
  }, [router, to]);

  return (
    <button
      type="button"
      {...props}
      onClick={async (event) => {
        onClick?.(event);
        if (event.defaultPrevented) return;
        const samePage = typeof window !== "undefined" && window.location.pathname === to;
        if (samePage) {
          if (to === "/") {
            window.dispatchEvent(new CustomEvent("linkbot:home-nav"));
            window.scrollTo({ top: 0, behavior: "auto" });
          }
          return;
        }
        try {
          await router.preloadRoute({ to });
        } catch {
          /* navigate anyway */
        }
        await navigate({ to, resetScroll: true });
      }}
    >
      {children}
    </button>
  );
}
