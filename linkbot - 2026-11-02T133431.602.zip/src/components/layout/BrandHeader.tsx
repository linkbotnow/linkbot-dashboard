import type { ReactNode } from "react";

import { LinkBotBrand } from "@/components/brand/LinkBotBrand";

/**
 * Desktop/tablet site header. On mobile the shared MobileHeader in the root
 * route is used instead, so this one is hidden below the `sm` breakpoint.
 * Stickiness is handled by DesktopHeaderMount, which lives outside the scaled
 * page canvas.
 */
export function BrandHeader({
  actions,
  tone = "dark",
  transparent = false,
}: {
  actions: ReactNode;
  /** "dark" = page below is dark, "light" = page below is light. */
  tone?: "dark" | "light" | undefined;
  /** Renders the logo without any background or hairline. */
  transparent?: boolean;
}) {
  return (
    <header
      className={`${transparent ? "" : tone === "light" ? "site-header-hairline-on-light" : "site-header-hairline"} w-full ${transparent ? "" : "bg-black"} max-sm:hidden`}
    >
      <div className="mx-auto grid min-h-[72px] max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-3 py-3 sm:min-h-[88px] sm:gap-3 sm:px-6 sm:py-4">
        <LinkBotBrand compact />
        {actions}
      </div>
    </header>
  );
}
