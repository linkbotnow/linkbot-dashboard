import { Fragment, type ReactNode } from "react";

import { LinkBotBrand } from "@/components/brand/LinkBotBrand";

/**
 * Mobile-only site header. Rendered outside the desktop scaling wrapper so it is
 * always native mobile size and identical in height on every page.
 */
export function MobileHeader({
  actions,
  tone = "dark",
  transparent = false,
  inPageFlow = false,
}: {
  actions: ReactNode;
  /** "dark" = page below is dark, "light" = page below is light. */
  tone?: "dark" | "light";
  /** Renders the logo without any background or hairline. */
  transparent?: boolean;
  /** Claim phones only; CSS keeps the existing fixed treatment at 640px and above. */
  inPageFlow?: boolean;
}) {
  return (
    <Fragment>
      <header
        className={`${transparent ? "" : tone === "light" ? "site-header-hairline-on-light" : "site-header-hairline"} fixed ${inPageFlow ? "claim-phone-flow-header" : ""} inset-x-0 top-0 z-50 h-[72px] w-full ${transparent ? "" : "bg-black"} sm:hidden`}
      >
        <div className="grid h-[72px] grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-3">
          <LinkBotBrand compact />
          {actions}
        </div>
      </header>
      <div aria-hidden="true" className={`h-[72px] shrink-0 sm:hidden ${inPageFlow ? "claim-phone-flow-spacer" : ""} ${transparent ? "site-header-fade-dark" : ""}`} />
    </Fragment>
  );
}
