import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";

import { DESKTOP_CANVAS_WIDTH, getDesktopViewport, waitForStableWidth } from "@/lib/desktop-scale";
import { attachSizeHealing } from "@/lib/size-healing";

/**
 * Keeps every route on one fixed desktop canvas and scales that composition to
 * the viewport. A single transform scales the entire site, while the outer
 * frame tracks the visual height for scrolling.
 */
export function DesktopScale({
  children,
  nativeBelow,
  phoneLayoutZoom = false,
}: {
  children: ReactNode;
  nativeBelow?: number | undefined;
  phoneLayoutZoom?: boolean;
}) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const [layout, setLayout] = useState<{
    scale: number;
    height: number;
    width: number;
    frameWidth: number;
    offsetLeft: number;
    useLayoutZoom: boolean;
    measuredFor: number | undefined;
    modeMatches: boolean;
    measured: boolean;
  }>({
    scale: 1,
    height: 0,
    width: DESKTOP_CANVAS_WIDTH,
    frameWidth: DESKTOP_CANVAS_WIDTH,
    offsetLeft: 0,
    useLayoutZoom: false,
    measuredFor: undefined,
    modeMatches: false,
    measured: false,
  });

  // Any pending measurement belongs to the previous route mode; keep the canvas
  // hidden until it is re-measured so no oversized frame can flash into view.
  const ready = layout.measured && layout.measuredFor === nativeBelow && layout.modeMatches;
  const [legacyZoom, setLegacyZoom] = useState(false);
  useLayoutEffect(() => {
    const outer = document.createElement("div");
    outer.style.cssText = "position:absolute;visibility:hidden;pointer-events:none;zoom:0.5;";
    const inner = document.createElement("div");
    inner.style.cssText = "width:100px;height:10px;";
    outer.appendChild(inner);
    document.body.appendChild(outer);
    const measuredWidth = inner.getBoundingClientRect().width;
    document.body.removeChild(outer);
    setLegacyZoom(measuredWidth > 75);
  }, []);
  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !ready || !layout.useLayoutZoom) return;
    const previousDisplay = canvas.style.display;
    canvas.style.display = "none";
    void canvas.offsetHeight;
    canvas.style.display = previousDisplay;
  }, [ready, layout.useLayoutZoom, layout.scale]);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const pendingTimers = new Set<number>();
    let pendingFrame = 0;
    let rotating = false;
    let cancelWait = () => {};
    let applied: { width: number; scale: number; native: boolean } | undefined;

    const updateLayout = () => {
      const viewport = getDesktopViewport();
      document.documentElement.classList.toggle("phone-landscape-layout", viewport.phoneLandscape);
      const layoutWidth = viewport.phoneLandscape ? viewport.width : document.documentElement.clientWidth || viewport.width;
      // On phones, derive the sizing mode from the page that is actually in the
      // canvas. Router location updates can precede the Outlet swap; using the
      // incoming route prop during that gap resizes the outgoing page and causes
      // a visible flash. iPad/desktop retain the existing authored breakpoint.
      const renderedPageIsNative = Boolean(
        canvas.querySelector(".login-page-root, .claim-page-root, .demo-form-focus, .mobile-home-root, .welcome-page-root, .vc-page"),
      );
      const requestedPageIsNative = nativeBelow !== undefined && layoutWidth < nativeBelow;
      const nativeMobile = layoutWidth < 640
        ? renderedPageIsNative
        : requestedPageIsNative;
      const canvasWidth = DESKTOP_CANVAS_WIDTH;
      const scale = nativeMobile ? 1 : viewport.width / canvasWidth;
      applied = { width: viewport.width, scale, native: nativeMobile };
      if (!nativeMobile) document.documentElement.style.setProperty("--canvas-fallback-scale", String(scale));
      const nextLayout = {
        scale,
        height: canvas.scrollHeight * scale,
        width: nativeMobile ? layoutWidth : canvasWidth,
        frameWidth: nativeMobile ? layoutWidth : viewport.width,
        offsetLeft: nativeMobile ? 0 : viewport.offsetLeft,
        useLayoutZoom: layoutWidth < 640 && !nativeMobile && phoneLayoutZoom,
        measuredFor: nativeBelow,
        modeMatches: layoutWidth >= 640 || renderedPageIsNative === requestedPageIsNative,
        measured: true,
      };
      // Desktop only: apply the new geometry to the page immediately, in the
      // same frame as the window resize, so the right edge never lags behind
      // the window (no gap, no overflow, no shake while resizing).
      const frame = frameRef.current;
      if (frame && layoutWidth >= 1024 && !nativeMobile && !nextLayout.useLayoutZoom) {
        frame.style.width = "100vw";
        frame.style.height = `${nextLayout.height}px`;
        canvas.style.transform = `scale(${scale})`;
      }
      setLayout((current) =>
        current.scale === nextLayout.scale &&
        current.height === nextLayout.height &&
        current.width === nextLayout.width &&
        current.frameWidth === nextLayout.frameWidth &&
        current.offsetLeft === nextLayout.offsetLeft &&
        current.useLayoutZoom === nextLayout.useLayoutZoom &&
        current.measuredFor === nextLayout.measuredFor &&
          current.modeMatches === nextLayout.modeMatches &&
        current.measured === nextLayout.measured
          ? current
          : nextLayout,
      );
    };

    const updateAfterRotation = () => {
      rotating = true;
      cancelWait();
      cancelWait = waitForStableWidth(() => { rotating = false; updateLayout(); });
    };

    const scheduleLayout = () => {
      if (rotating) return;
      // A sideways phone deliberately switches its viewport to the authored
      // desktop canvas. That browser-level change can report a non-1 visual
      // scale, but it is not user pinch zoom and must still be re-measured.
      if (
        !!window.visualViewport &&
        window.visualViewport.scale !== 1 &&
        !getDesktopViewport().phoneLandscape &&
        // 256: upright phones also ignore pinch-zoom (zoomed > 1); rotation uses its own path.
        (Math.min(window.screen.width, window.screen.height) > 600 || window.visualViewport.scale > 1.01)
      ) return;
      if ((document.documentElement.clientWidth || window.innerWidth) >= 1024) {
        updateLayout();
        return;
      }
      window.cancelAnimationFrame(pendingFrame);
      pendingFrame = window.requestAnimationFrame(updateLayout);
    };

    updateLayout();
    const detachHealing = attachSizeHealing(() => {
      if (!applied || applied.native) return false;
      const width = getDesktopViewport().width;
      return Math.abs(applied.width - width) > 1 || Math.abs(applied.scale - width / DESKTOP_CANVAS_WIDTH) > 0.002;
    }, scheduleLayout);
    const observer = new ResizeObserver(() => { if (rotating) return; scheduleLayout(); });
    observer.observe(canvas);
    const contentObserver = new MutationObserver(() => { if (rotating) return; scheduleLayout(); });
    contentObserver.observe(canvas, { childList: true, subtree: true });
    window.addEventListener("resize", scheduleLayout);
    window.addEventListener("orientationchange", updateAfterRotation);
    const portraitQuery = window.matchMedia("(orientation: portrait)");
    portraitQuery.addEventListener?.("change", updateAfterRotation);
    return () => {
      detachHealing();
      cancelWait();
      portraitQuery.removeEventListener?.("change", updateAfterRotation);
      document.documentElement.classList.remove("phone-landscape-layout");
      observer.disconnect();
      contentObserver.disconnect();
      window.cancelAnimationFrame(pendingFrame);
      pendingTimers.forEach((timer) => window.clearTimeout(timer));
      window.removeEventListener("resize", scheduleLayout);
      window.removeEventListener("orientationchange", updateAfterRotation);
    };
  }, [nativeBelow, phoneLayoutZoom]);

  return (
    <div
      ref={frameRef}
      className={`desktop-scale-frame${ready ? " is-measured" : ""}${nativeBelow !== undefined ? " has-native-phone-layout" : ""}${phoneLayoutZoom ? " has-phone-layout-zoom" : ""}${layout.useLayoutZoom ? " phone-landscape-frame" : ""}`}
      style={{
        height: ready && layout.height > 0 ? `${layout.height}px` : "100vh",
        width: "100vw",
        maxWidth: "100%",
        marginLeft: ready ? `${layout.offsetLeft}px` : undefined,
      }}
    >
      <div
        ref={canvasRef}
        className={`desktop-scale-canvas${layout.useLayoutZoom ? " layered-scroll-phone-canvas" : ""}${layout.useLayoutZoom && legacyZoom ? " legacy-zoom-canvas" : ""}`}
        style={{
          width: ready ? `${layout.width}px` : `${nativeBelow !== undefined ? "100%" : `${DESKTOP_CANVAS_WIDTH}px`}`,
          transform: ready && !layout.useLayoutZoom
            ? `scale(${layout.scale})`
            : ready
              ? "none"
              : "scale(var(--canvas-fallback-scale, calc(100vw / 1440px)))",
          zoom: ready && layout.useLayoutZoom ? layout.scale : undefined,
          ...(ready && layout.useLayoutZoom
            ? { ["--layer-mobile-canvas-scale" as string]: String(layout.scale) }
            : {}),
          ...(ready ? { ["--desktop-page-scale" as string]: String(layout.scale) } : {}),
        }}
      >
        {children}
      </div>
    </div>
  );
}
