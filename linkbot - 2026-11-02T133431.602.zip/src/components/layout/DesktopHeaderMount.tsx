import { useLayoutEffect, useRef, useState, type ReactNode } from "react";

import { BrandHeader } from "@/components/layout/BrandHeader";
import { DESKTOP_CANVAS_WIDTH, DESKTOP_HEADER_HEIGHT, getDesktopScale, getDesktopViewport, waitForStableWidth } from "@/lib/desktop-scale";

const AUTHORED_HEADER_HEIGHT = DESKTOP_HEADER_HEIGHT;
const IPAD_AUTHORED_HEADER_HEIGHT = 122.297;

/**
 * Mounts the desktop/tablet header OUTSIDE the scaled page canvas so `sticky`
 * resolves against the viewport (inside a transformed ancestor it drifts on
 * scroll). The header is still authored on the 1440px canvas and scaled by the
 * exact same factor, so its visual size is unchanged.
 */
export function DesktopHeaderMount({
  actions,
  tone,
  transparent = false,
}: {
  actions: ReactNode;
  /** "dark" = page below is dark, "light" = page below is light. */
  tone?: "dark" | "light";
  /** Renders the logo strip without any background or hairline. */
  transparent?: boolean;
}) {
  const frameRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [height, setHeight] = useState(0);
  const [frame, setFrame] = useState({
    width: 0,
    offsetLeft: 0,
    authoredWidth: DESKTOP_CANVAS_WIDTH,
    useLayoutZoom: false,
    measured: false,
  });

  useLayoutEffect(() => {
    const inner = innerRef.current;
    if (!inner) return;
    const pendingTimers = new Set<number>();
    let pendingFrame = 0;
    let rotating = false;
    let cancelWait = () => {};

    const update = () => {
      const viewport = getDesktopViewport();
      const authoredWidth = DESKTOP_CANVAS_WIDTH;
      const nextScale = getDesktopScale(viewport.width);
      const ipadHeader = viewport.width >= 640 && viewport.width < 1024;
      // The authored header is always 92px tall. Reading its live height here
      // made the first ResizeObserver pass feed a scaled measurement back into
      // the next pass, so the header visibly resized after it was already on
      // screen. Use the fixed authored value from the first frame onward.
      const nextHeight = (ipadHeader ? IPAD_AUTHORED_HEADER_HEIGHT : AUTHORED_HEADER_HEIGHT) * nextScale;
      const outer = frameRef.current;
      if (outer && viewport.width >= 1024) {
        outer.style.width = "100vw";
        outer.style.height = `${nextHeight}px`;
        outer.style.marginLeft = `${viewport.offsetLeft}px`;
        inner.style.transform = `scale(${nextScale})`;
      }
      setScale((current) => current === nextScale ? current : nextScale);
      setHeight((current) => current === nextHeight ? current : nextHeight);
      const nextFrame = {
        width: viewport.width,
        offsetLeft: viewport.offsetLeft,
        authoredWidth,
        useLayoutZoom: false,
        measured: true,
      };
      setFrame((current) =>
        current.width === nextFrame.width &&
        current.offsetLeft === nextFrame.offsetLeft &&
        current.authoredWidth === nextFrame.authoredWidth &&
        current.useLayoutZoom === nextFrame.useLayoutZoom &&
        current.measured === nextFrame.measured
          ? current
          : nextFrame,
      );
    };

    const updateAfterRotation = () => {
      rotating = true;
      cancelWait();
      cancelWait = waitForStableWidth(() => { rotating = false; update(); });
    };

    const scheduleUpdate = () => {
      if (rotating) return;
      // A sideways phone's fitted 1440 viewport always reports a non-1 scale;
      // that is not a pinch, so it must still re-measure.
      if (window.visualViewport && window.visualViewport.scale !== 1 && !getDesktopViewport().phoneLandscape) return;
      if ((document.documentElement.clientWidth || window.innerWidth) >= 1024) {
        update();
        return;
      }
      window.cancelAnimationFrame(pendingFrame);
      pendingFrame = window.requestAnimationFrame(update);
    };

    update();
    const observer = new ResizeObserver(() => { if (rotating) return; scheduleUpdate(); });
    observer.observe(inner);
    window.addEventListener("resize", scheduleUpdate);
    window.addEventListener("orientationchange", updateAfterRotation);
    const portraitQuery = window.matchMedia("(orientation: portrait)");
    portraitQuery.addEventListener?.("change", updateAfterRotation);
    return () => {
      cancelWait();
      portraitQuery.removeEventListener?.("change", updateAfterRotation);
      observer.disconnect();
      window.cancelAnimationFrame(pendingFrame);
      pendingTimers.forEach((timer) => window.clearTimeout(timer));
      window.removeEventListener("resize", scheduleUpdate);
      window.removeEventListener("orientationchange", updateAfterRotation);
    };
  }, []);

  // Committed as a layout effect (not a passive one) so the CSS var is
  // available to any sibling that reads it inside its own layout effect on
  // the same commit (e.g. the iPad hero fit calc) instead of one tick later.
  useLayoutEffect(() => {
    document.documentElement.style.setProperty("--site-header-height", `${height}px`);
  }, [height]);

  return (
    <div
      className={`desktop-header-spacer${frame.measured && height > 0 ? " is-measured" : ""}`}
      style={{ height: height > 0 ? `${height}px` : undefined }}
    >
      <div
        ref={frameRef}
        className={`desktop-header-frame fixed inset-x-0 top-0 z-50 w-full overflow-hidden ${
          transparent
            ? "site-header-fade-dark"
            : tone === "light"
              ? "bg-[#adadad]"
              : "bg-black"
        }`}
        style={{
          height: height > 0 ? `${height}px` : undefined,
          width: "100vw",
          maxWidth: "100%",
          marginLeft: `${frame.offsetLeft}px`,
        }}
      >
        <div
          ref={innerRef}
          className={frame.measured ? "is-measured" : ""}
          style={{
            width: `${frame.authoredWidth}px`,
            transform: frame.measured
              ? frame.useLayoutZoom
                ? "none"
                : `scale(${scale})`
              : "scale(var(--canvas-fallback-scale, 1))",
            transformOrigin: "top left",
            zoom: frame.useLayoutZoom ? scale : undefined,
          }}
        >
          <BrandHeader actions={actions} tone={tone} transparent={transparent} />
        </div>
      </div>
    </div>
  );
}
