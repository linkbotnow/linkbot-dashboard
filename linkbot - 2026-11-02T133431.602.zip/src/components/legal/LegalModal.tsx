import { useEffect, useLayoutEffect, useRef, useState, type ReactNode, type MouseEvent as ReactMouseEvent } from "react";
import { createPortal } from "react-dom";
import { Menu, X } from "lucide-react";
import { FitLine } from "@/components/FitLine";
import { fitLine, useFitLine } from "@/lib/fit-line";
import { LEGAL_SECTIONS, SENSITIVE_USE } from "@/lib/legal-terms";

/** Convert visual measurements back to the unchanged desktop document coordinates. */
function legalCoordinateScale(el: HTMLElement) {
  const overlay = el.closest<HTMLElement>('.legal-overlay[data-ipad-fit="true"]');
  return overlay ? Number.parseFloat(overlay.style.getPropertyValue("--legal-ipad-scale")) || 1 : 1;
}

/** Menu icon (three lines) that opens the section list; choosing one scrolls to it. */
function SectionMenu({ scrollRef }: { scrollRef: React.RefObject<HTMLElement | null> }) {
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const off = (e: MouseEvent | TouchEvent) => {
      if (!wrap.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", off);
    document.addEventListener("touchstart", off);
    return () => {
      document.removeEventListener("mousedown", off);
      document.removeEventListener("touchstart", off);
    };
  }, [open]);
  const jump = (id: string) => {
    setOpen(false);
    const box = scrollRef.current;
    const el = box?.querySelector<HTMLElement>(`[data-legal-section="${id}"]`);
    if (!box || !el) return;
    box.scrollTo({ top: box.scrollTop + (el.getBoundingClientRect().top - box.getBoundingClientRect().top) / legalCoordinateScale(box) - 24, behavior: "smooth" });
  };
  return (
    <div ref={wrap} className="legal-menu">
      <button type="button" className="legal-close" aria-label="Sections" aria-expanded={open} onClick={() => setOpen((v) => !v)}>
        <Menu className="h-5 w-5" />
      </button>
      {open ? (
        <ul className="legal-menu__list" role="menu">
          {LEGAL_SECTIONS.map((s) => (
            <li key={s.id}>
              <button type="button" role="menuitem" onClick={() => jump(s.id)}>
                {s.label}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

/** "Questions regarding Legal Terms..." line, one line, email links to a new message. */
export function LegalContactLine() {
  return (
    <FitLine className="legal-contact">
      Questions regarding Legal Terms may be directed to{" "}
      <button type="button" className="cursor-pointer" onClick={() => { window.location.href = "mailto:support@linkbot.now"; }}>support@linkbot.now</button>
    </FitLine>
  );
}

/** The full Legal Terms document. Scrolls inside its parent scroll box. */
export function LegalDocument({ withContact = false }: { withContact?: boolean }) {
  return (
    <div className="legal-doc">
      {LEGAL_SECTIONS.map((s) => (
        <section key={s.id} data-legal-section={s.id} className="legal-doc__section">
          <h2>{s.title}</h2>
          {s.items.map((i) => (
            <p key={i.n}>
              <strong>
                {i.n}. {i.heading}.
              </strong>{" "}
              {i.text}
            </p>
          ))}
        </section>
      ))}
      {withContact ? (
        <div className="legal-doc__contact">
          <LegalContactLine />
        </div>
      ) : null}
    </div>
  );
}

type Props = {
  open: boolean;
  onClose: () => void;
  /** "view": document only. "sign": page 1 (section 7 + I agree) then page 2 (document + signing). */
  mode: "view" | "sign";
  onSign?: (fullName: string) => Promise<void> | void;
  signing?: boolean;
  signError?: string | null;
  /** First and last name from /claim; the typed signature must match it. */
  expectedName?: string;
};

const cleanName = (v: string) => v.trim().replace(/\s+/g, " ").toLowerCase();

/** Native box clicks use onChange; other phone taps toggle once without label forwarding. */
function phoneAgreementTap(event: ReactMouseEvent<HTMLElement>, toggle: () => void) {
  if (!window.matchMedia("(max-width:639px)").matches ||
      event.currentTarget.closest('.legal-overlay[data-ipad-fit="true"]')) return;
  const target = event.target;
  if (!(target instanceof Element) || target.closest("button") || target instanceof HTMLInputElement) return;
  const action = event.currentTarget.querySelector(".legal-action");
  if (action && event.clientY >= action.getBoundingClientRect().top) return;
  event.preventDefault();
  toggle();
}

/** Checkbox text that always stays on one line, shrinking just enough to fit. */
function OneLineCheckText({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useFitLine<HTMLSpanElement>([children]);
  return (
    <span ref={ref} className={`legal-check__oneline ${className}`}>
      {children}
    </span>
  );
}

/** Page-1 agreement fits in authored coordinates, including uniformly scaled iPad portals. */
function AgreementCheckLines() {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const box = ref.current;
    const label = box?.parentElement;
    const paragraph = box?.closest(".legal-panel")?.querySelector<HTMLElement>(".legal-sign-page1__text");
    const primary = box?.querySelector<HTMLElement>(".legal-agreement-primary");
    const secondary = box?.querySelector<HTMLElement>(".legal-agreement-secondary");
    if (!box || !label || !paragraph || !primary || !secondary) return;
    const width = (el: HTMLElement) => {
      const range = document.createRange();
      range.selectNodeContents(el);
      return range.getBoundingClientRect().width / legalCoordinateScale(el);
    };
    const fit = () => {
      if (label.clientWidth <= 16) return;
      const base = parseFloat(getComputedStyle(paragraph).fontSize) * .71;
      const measure = (size: number) => {
        primary.style.fontSize = `${size}px`;
        secondary.style.fontSize = `${size}px`;
        const target = width(primary);
        for (let i = 0; i < 3; i++) {
          const measured = width(secondary);
          if (measured <= 0) break;
          secondary.style.fontSize = `${parseFloat(getComputedStyle(secondary).fontSize) * target / measured}px`;
        }
        const square = (parseFloat(getComputedStyle(primary).lineHeight) + parseFloat(getComputedStyle(secondary).lineHeight)) / 2;
        label.style.setProperty("--legal-agreement-size", `${square}px`);
        return target + square + 16 <= label.clientWidth;
      };
      if (!measure(base)) {
        let low = 0, high = base;
        for (let i = 0; i < 20; i++) {
          const middle = (low + high) / 2;
          if (measure(middle)) low = middle;
          else high = middle;
        }
        measure(low);
      }
      // Keep the original fitted doubled square; only phone text fills the
      // remaining track after that square and the exact 16px gap.
      if (window.matchMedia("(max-width:639px)").matches &&
          !label.closest('.legal-overlay[data-ipad-fit="true"]')) {
        const square = parseFloat(label.style.getPropertyValue("--legal-agreement-size")) * 2;
        const available = label.clientWidth - square - 16;
        if (available <= 0) return;
        primary.style.fontSize = `${base}px`;
        secondary.style.fontSize = `${base}px`;
        const longest = Math.max(width(primary), width(secondary));
        if (longest <= 0) return;
        const size = base * available / longest;
        primary.style.fontSize = `${size}px`;
        secondary.style.fontSize = `${size}px`;
      }
    };
    let frame = 0, mounted = true;
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(fit);
    };
    fit();
    const observer = new ResizeObserver(schedule);
    observer.observe(label);
    observer.observe(paragraph);
    const styles = new MutationObserver(schedule);
    styles.observe(paragraph, { attributes: true, attributeFilter: ["style"] });
    window.addEventListener("resize", schedule);
    document.fonts.addEventListener("loadingdone", schedule);
    void document.fonts.ready.then(() => { if (mounted) schedule(); });
    return () => {
      mounted = false;
      cancelAnimationFrame(frame);
      observer.disconnect();
      styles.disconnect();
      window.removeEventListener("resize", schedule);
      document.fonts.removeEventListener("loadingdone", schedule);
    };
  }, []);
  return <span ref={ref} className="legal-check__lines">
    <span className="legal-check__oneline legal-agreement-primary">I have read and agree to the Prohibited Uses above.</span>
    <span className="legal-check__oneline legal-agreement-secondary">I accept full responsibility for how I use LinkBot.Now.</span>
  </span>;
}

/** 228: phone-only two-line checkbox text; both lines share the largest size that fits each on one line. */
function BalancedCheckLines({ lines }: { lines: string[] }) {
  const ref = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const box = ref.current;
    if (!box) return;
    const run = () => {
      const els = Array.from(box.children) as HTMLElement[];
      if (box.clientWidth <= 0) return;
      els.forEach((el) => (el.style.fontSize = ""));
      els.forEach((el) => fitLine(el));
      const min = Math.min(...els.map((el) => parseFloat(getComputedStyle(el).fontSize)));
      els.forEach((el) => (el.style.fontSize = `${min}px`));
    };
    run();
    const ro = new ResizeObserver(run);
    ro.observe(box);
    void document.fonts?.ready.then(run);
    return () => ro.disconnect();
  }, [lines]);
  return (
    <span ref={ref} className="legal-check__lines legal-check__pair">
      {lines.map((l) => (
        <span key={l} className="legal-check__oneline">{l}</span>
      ))}
    </span>
  );
}

/**
 * Page-1 paragraph: largest font that fills its box without scrolling, justified,
 * preferring a size whose last line is close to full width (never one or two words).
 */
function FillText({ text, className }: { text: string; className?: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fit = () => {
      const box = el.parentElement;
      if (!box) return;
      const availW = el.clientWidth;
      const availH = el.clientHeight;
      if (availW < 40 || availH < 40) return;
      const max = Math.min(64, availH / 2.2);
      const fits = (size: number) => {
        el.style.fontSize = `${size}px`;
        return el.scrollHeight <= availH + 1;
      };
      const lastLineRatio = () => {
        const node = el.firstChild;
        if (!node) return 1;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rects = range.getClientRects();
        if (!rects.length) return 1;
        const last = rects[rects.length - 1]!;
        const lineTops = new Set(Array.from(rects, (r) => Math.round(r.top)));
        if (lineTops.size <= 1) return 1;
        return last.width / (availW * legalCoordinateScale(el));
      };
      // 238: fit only the phone page-1 paragraph to its available body area.
      const isPhone = window.matchMedia("(max-width: 640px)").matches &&
        !el.closest('.legal-overlay[data-ipad-fit="true"]');
      if (isPhone) {
        el.style.lineHeight = "";
        const phoneFits = (size: number) => fits(size) &&
          el.scrollHeight <= availH && el.scrollWidth <= availW;
        let low = 1;
        let high = availH;
        for (let i = 0; i < 20; i++) {
          const size = (low + high) / 2;
          if (phoneFits(size)) low = size;
          else high = size;
        }
        // Choose the largest fitting size with a nearly full final line.
        let chosen = low;
        for (let size = low; size >= 1; size -= 0.05) {
          if (phoneFits(size) && lastLineRatio() >= 0.8) {
            chosen = size;
            break;
          }
        }
        el.style.fontSize = `${chosen}px`;
        const range = document.createRange();
        range.selectNodeContents(el);
        const lines = new Set(Array.from(range.getClientRects(), (r) => Math.round(r.top))).size;
        if (lines > 0) el.style.lineHeight = `${availH / lines}px`;
      } else {
       el.style.lineHeight = "";
      let largest = 12;
      for (let size = max; size >= 12; size -= 0.5) {
        if (fits(size)) {
          largest = size;
          break;
        }
      }
      // Fill wins: keep the largest size. Only step down (a little) when it
      // leaves both a real gap at the bottom and a very short last line.
      const contentHeight = () => {
        const node = el.firstChild;
        if (!node) return 0;
        const range = document.createRange();
        range.selectNodeContents(node);
        const rects = range.getClientRects();
        if (!rects.length) return 0;
        const last = rects[rects.length - 1];
        const first = rects[0];
        if (!last || !first) return 0;
        return (last.bottom - first.top) / legalCoordinateScale(el);
      };
      let chosen = largest;
      el.style.fontSize = `${largest}px`;
      const gap = availH - contentHeight();
      if (largest > 15 && gap > largest * 1.5 * 1.5 && lastLineRatio() < 0.3) {
        for (let size = largest - 0.5; size >= largest - 3 && size >= 12; size -= 0.5) {
          if (!fits(size)) continue;
          if (lastLineRatio() >= 0.5) {
            chosen = size;
            break;
          }
        }
      }
      el.style.fontSize = `${chosen}px`;
      }
      // 227: center the fitted phone paragraph's actual text, not its full-height box.
      if (window.matchMedia("(max-width: 640px)").matches &&
          !el.closest('.legal-overlay[data-ipad-fit="true"]')) {
        el.style.setProperty("--legal-phone-text-offset", "0px");
        const node = el.firstChild;
        if (node) {
          const range = document.createRange();
          range.selectNodeContents(node);
          const rects = range.getClientRects();
          const first = rects[0];
          const last = rects[rects.length - 1];
          if (first && last) {
            const offset = (availH - (last.bottom - first.top)) / 2 -
              (first.top - el.getBoundingClientRect().top);
            el.style.setProperty("--legal-phone-text-offset", `${offset}px`);
          }
        }
      }
    };
    fit();
    const observer = new ResizeObserver(fit);
    if (el.parentElement) observer.observe(el.parentElement);
    observer.observe(el);
    window.addEventListener("resize", fit);
    void document.fonts.ready.then(fit);
    const timers = [120, 400, 1000, 2000].map((ms) => window.setTimeout(fit, ms));
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", fit);
      timers.forEach(window.clearTimeout);
    };
  }, [text]);
  return (
    <p ref={ref} className={className}>
      {text}
    </p>
  );
}

/** Centered legal pop-up; one fixed size, the document scrolls inside it, never the page behind. */
export function LegalModal({ open, onClose, mode, onSign, signing = false, signError, expectedName }: Props) {
  const overlayRef = useRef<HTMLDivElement>(null);
  // 240: phones — pin the signing overlay to the visible area above the keyboard.
  useEffect(() => {
    const overlay = overlayRef.current;
    const vv = window.visualViewport;
    if (!overlay || !vv || mode !== "sign") return;
    const sync = () => {
      if (!window.matchMedia("(max-width: 640px)").matches || overlay.dataset["ipadFit"] === "true") {
        overlay.style.removeProperty("--legal-vv-top");
        overlay.style.removeProperty("--legal-vv-h");
        return;
      }
      overlay.style.setProperty("--legal-vv-top", `${vv.offsetTop}px`);
      overlay.style.setProperty("--legal-vv-h", `${vv.height}px`);
    };
    sync();
    vv.addEventListener("resize", sync);
    vv.addEventListener("scroll", sync);
    return () => {
      vv.removeEventListener("resize", sync);
      vv.removeEventListener("scroll", sync);
    };
  }, [mode]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [page, setPage] = useState<1 | 2>(1);
  const [agreeSensitive, setAgreeSensitive] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [name, setName] = useState("");
  const [nameError, setNameError] = useState<"" | "last" | "invalid">("");
  // 461: tapping Sign again with the same name error showing replays the word pulse.
  const [namePulse, setNamePulse] = useState(0);
  useEffect(() => { if (!nameError) setNamePulse(0); }, [nameError]);
  // 246: closing the signing pages before signing first asks for confirmation.
  const [leaveAsk, setLeaveAsk] = useState(false);
  useEffect(() => {
    if (!open) setLeaveAsk(false);
  }, [open]);
  const checkRef = useRef<HTMLInputElement>(null);

  // 226: iPad-only portal fitting; shared page/viewport scaling stays untouched.
  useEffect(() => {
    const overlay = overlayRef.current;
    const isIPad = /iPad/i.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    if (!open || !overlay || !isIPad) return;
    const fit = () => {
      const css = getComputedStyle(overlay);
      const desktopWidth = parseFloat(css.getPropertyValue("--legal-desktop-viewport-width"));
      const desktopHeight = parseFloat(css.getPropertyValue("--legal-desktop-viewport-height"));
      const panelWidth = parseFloat(css.getPropertyValue("--legal-desktop-panel-width"));
      const maxHeight = parseFloat(css.getPropertyValue("--legal-desktop-panel-max-height"));
      const inset = parseFloat(css.getPropertyValue("--legal-desktop-viewport-inset"));
      const panelHeight = Math.min(maxHeight, desktopHeight - inset);
      const scale = Math.min(1, window.innerWidth / desktopWidth,
        (window.innerWidth - inset) / panelWidth, (window.innerHeight - inset) / panelHeight);
      overlay.style.setProperty("--legal-ipad-scale", String(Math.max(0.01, scale)));
      overlay.dataset["ipadFit"] = "true";
    };
    fit();
    window.addEventListener("resize", fit);
    window.addEventListener("orientationchange", fit);
    return () => {
      window.removeEventListener("resize", fit);
      window.removeEventListener("orientationchange", fit);
      delete overlay.dataset["ipadFit"];
      overlay.style.removeProperty("--legal-ipad-scale");
    };
  }, [open]);

  // 191: reset before the pop-up paints so the previous attempt never flashes.
  useLayoutEffect(() => {
    if (!open) return;
    setPage(1);
    setAgreeSensitive(false);
    setAgreeTerms(false);
    setName("");
    setNameError("");
  }, [open]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [page, open]);

  // Keep the page behind still: block wheel/touch scrolling that starts outside the document.
  useEffect(() => {
    const overlay = overlayRef.current;
    if (!open || !overlay) return;
    const block = (e: Event) => {
      const box = scrollRef.current;
      if (!box || !box.contains(e.target as Node)) e.preventDefault();
    };
    // Touch: taps (10px or less) are never cancelled; only real drags outside the document are blocked.
    let startX = 0, startY = 0, startInBox = false;
    const onTouchStart = (e: TouchEvent) => {
      const t = e.touches[0];
      startX = t?.clientX ?? 0; startY = t?.clientY ?? 0;
      startInBox = !!scrollRef.current?.contains(e.target as Node);
    };
    const onTouchMove = (e: TouchEvent) => {
      if (startInBox) return;
      const t = e.touches[0];
      if (!t) return;
      if (Math.hypot(t.clientX - startX, t.clientY - startY) > 10) e.preventDefault();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { if (mode === "sign") setLeaveAsk((v) => !v); else onClose(); }
    };
    overlay.addEventListener("wheel", block, { passive: false });
    overlay.addEventListener("touchstart", onTouchStart, { passive: true });
    overlay.addEventListener("touchmove", onTouchMove, { passive: false });
    window.addEventListener("keydown", onKey);
    return () => {
      overlay.removeEventListener("wheel", block);
      overlay.removeEventListener("touchstart", onTouchStart);
      overlay.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose, mode]);

  // 186/188: keep keyboard focus inside the pop-up (or its Signature Required box) while open.
  const leaveAskRef = useRef(false);
  leaveAskRef.current = leaveAsk;
  const FOCUS_SEL = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
  const panelEl = () => overlayRef.current?.querySelector<HTMLElement>(".legal-panel") ?? null;
  useEffect(() => {
    if (!open) return;
    const opener = document.activeElement as HTMLElement | null;
    const scope = () => {
      const o = overlayRef.current;
      if (!o) return null;
      return (leaveAskRef.current ? o.querySelector<HTMLElement>(".legal-leave") : null) ?? o;
    };
    const items = () => {
      const sc = scope();
      if (!sc) return [] as HTMLElement[];
      return Array.from(sc.querySelectorAll<HTMLElement>(FOCUS_SEL)).filter((el) => el.getClientRects().length > 0);
    };
    // 188: focus the pop-up container itself, never the close (X) button.
    const raf = requestAnimationFrame(() => {
      const o = overlayRef.current;
      if (o && !o.contains(document.activeElement)) panelEl()?.focus({ preventScroll: true });
    });
    const onTab = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const list = items();
      if (list.length === 0) { e.preventDefault(); return; }
      const first = list[0]!, last = list[list.length - 1]!;
      const active = document.activeElement as HTMLElement | null;
      const inside = !!active && !!scope()?.contains(active) && list.includes(active);
      if (e.shiftKey && (!inside || active === first)) { e.preventDefault(); last.focus({ preventScroll: true }); }
      else if (!e.shiftKey && (!inside || active === last)) { e.preventDefault(); first.focus({ preventScroll: true }); }
    };
    document.addEventListener("keydown", onTab, true);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("keydown", onTab, true);
      if (!opener || !opener.isConnected) return;
      // 188: on touch devices never refocus a text field (it would reopen the keyboard).
      const textField = opener.matches("input,textarea,select");
      const fine = window.matchMedia("(pointer: fine)").matches;
      if (!textField || fine) opener.focus({ preventScroll: true });
    };
  }, [open]);

  // 188: Signature Required box takes focus while open; the pop-up gets it back after.
  const leaveWasOpen = useRef(false);
  useEffect(() => {
    if (!open) { leaveWasOpen.current = false; return; }
    if (leaveAsk) {
      leaveWasOpen.current = true;
      const raf = requestAnimationFrame(() => {
        overlayRef.current?.querySelector<HTMLElement>(".legal-leave")?.querySelector<HTMLElement>(FOCUS_SEL)?.focus({ preventScroll: true });
      });
      return () => cancelAnimationFrame(raf);
    }
    if (leaveWasOpen.current) {
      leaveWasOpen.current = false;
      panelEl()?.focus({ preventScroll: true });
    }
    return undefined;
  }, [leaveAsk, open]);

  // 191: page 2 takes focus at its first control; while saving, focus stays on the panel.
  useEffect(() => {
    if (!open || page !== 2) return;
    const raf = requestAnimationFrame(() => {
      const panel = overlayRef.current?.querySelector<HTMLElement>(".legal-panel .legal-bar--sign") ?? overlayRef.current?.querySelector<HTMLElement>(".legal-panel .legal-scroll");
      const first = Array.from(panel?.querySelectorAll<HTMLElement>(FOCUS_SEL) ?? []).find((el) => el.getClientRects().length > 0);
      first?.focus({ preventScroll: true });
    });
    return () => cancelAnimationFrame(raf);
  }, [page, open]);
  useEffect(() => {
    if (open && signing) overlayRef.current?.querySelector<HTMLElement>(".legal-panel")?.focus({ preventScroll: true });
  }, [signing, open]);

  const isPage1 = mode === "sign" && page === 1;
  const isSignPage2 = open && mode === "sign" && page === 2;
  // Same matching rules as before (case and extra spaces ignored); also tells
  // apart "first name only, no last name" from any other mismatch.
  const nameErrorFor = (v: string): "" | "last" | "invalid" => {
    if (expectedName === undefined) return "";
    const typed = cleanName(v);
    const expected = cleanName(expectedName);
    if (typed === expected) return "";
    const first = expected.split(" ")[0] ?? "";
    if (first && typed === first) return "last";
    return "invalid";
  };
  const nameMatches = (v: string) => nameErrorFor(v) === "";

  // Check the typed name about one second after typing pauses.
  useEffect(() => {
    if (!isSignPage2 || !name.trim()) return;
    const t = window.setTimeout(() => setNameError(nameErrorFor(name)), 1000);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, isSignPage2, expectedName]);

  // Scroll progress bar (signing page 2): track sits between the top and bottom bars.
  const [progress, setProgress] = useState(0);
  const [track, setTrack] = useState<{ top: number; height: number } | null>(null);
  useEffect(() => {
    if (!isSignPage2) return;
    const box = scrollRef.current;
    if (!box) return;
    const measure = () => {
      setTrack({ top: box.offsetTop, height: box.clientHeight });
      const max = box.scrollHeight - box.clientHeight;
      setProgress(max <= 0 ? 1 : Math.min(1, Math.max(0, box.scrollTop / max)));
    };
    measure();
    box.addEventListener("scroll", measure, { passive: true });
    const ro = new ResizeObserver(measure);
    ro.observe(box);
    if (box.firstElementChild) ro.observe(box.firstElementChild);
    window.addEventListener("resize", measure);
    return () => {
      box.removeEventListener("scroll", measure);
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [isSignPage2]);

  if (!open || typeof document === "undefined") return null;

  const canSign = name.trim().length > 0 && agreeTerms && !signing;
  const pulseCheckbox = () => {
    const el = checkRef.current;
    if (!el) return;
    el.classList.remove("legal-check-pulse");
    void el.offsetWidth;
    el.classList.add("legal-check-pulse");
  };

  let body: ReactNode;
  let footer: ReactNode = null;
  if (isPage1) {
    body = (
      <div className="legal-doc legal-sign-page1">
        <FillText className="legal-sign-page1__text" text={SENSITIVE_USE.text} />
      </div>
    );
    footer = (
      <div className="legal-bar legal-bar--bottom legal-bar--page1" onClick={event => phoneAgreementTap(event, () => setAgreeSensitive(value => !value))}>
        <label className="legal-check legal-check--row">
          <input type="checkbox" checked={agreeSensitive} onChange={(e) => setAgreeSensitive(e.target.checked)} />
          <AgreementCheckLines />
        </label>
        <button type="button" className="linkbot-button legal-action" disabled={!agreeSensitive} onClick={() => setPage(2)}>
          <span>Continue</span>
        </button>
      </div>
    );
  } else {
    body = <LegalDocument withContact={mode === "sign"} />;
    if (mode !== "sign") {
      footer = (
        <div className="legal-bar legal-bar--contact">
          <LegalContactLine />
        </div>
      );
    } else {
      footer = (
        <div className="legal-bar legal-bar--bottom legal-bar--sign">
          <label className="legal-check legal-check--row" onClick={event => phoneAgreementTap(event, () => setAgreeTerms(value => !value))}>
            <input ref={checkRef} onAnimationEnd={(e) => e.currentTarget.classList.remove("legal-check-pulse")} type="checkbox" checked={agreeTerms} onChange={(e) => setAgreeTerms(e.target.checked)} />
            <span className="legal-check__single">
              <OneLineCheckText>I am at least 18 years old, and I have read, understood, and agree to the LinkBot.Now Legal Terms.</OneLineCheckText>
            </span>
            {/* 228: phones show the same sentence on two balanced lines. */}
            <BalancedCheckLines lines={["I am at least 18 years old, and I have read,", "understood, and agree to the LinkBot.Now Legal Terms."]} />
          </label>
          <div className="legal-sign-row">
            {/* 232: name box + button as one piece on iPad/desktop (display: contents on phones). */}
            <div className="legal-sign-combo">
            <div className="legal-sign-namecol">
              <input
                id="legal-sign-input"
                type="text"
                name="legal-sign-line"
                autoComplete="off"
                maxLength={120}
                placeholder="Type first and last name to sign."
                aria-label="Full Name"
                value={name}
                onFocus={() => setNameError("")}
                onPointerDown={() => setNameError("")}
                onChange={(e) => {
                  setName(e.target.value);
                  setNameError("");
                }}
                className="legal-sign-box__input"
              />
              {nameError ? <p className="legal-sign-box__error"><span key={namePulse} className={namePulse > 0 ? "demo-email-error-pulse" : undefined} style={namePulse > 0 ? { display: "inline-block" } : undefined}>{nameError === "last" ? "Please add your last name." : "Invalid Name. Try Again."}</span></p> : signError ? <p className="legal-sign-box__error">{signError}</p> : <p className="legal-sign-box__error legal-sign-box__error--slot" aria-hidden="true">&nbsp;</p>}
            </div>
            <button
              type="button"
              className="linkbot-button legal-action"
              disabled={!canSign && agreeTerms}
              aria-disabled={!canSign}
              onClick={() => {
                if (!agreeTerms) {
                  pulseCheckbox();
                  return;
                }
                const kind = nameErrorFor(name);
                if (kind) {
                  if (kind === nameError) setNamePulse((k) => k + 1);
                  setNameError(kind);
                  return;
                }
                void onSign?.(name.trim());
              }}
            >
              <span>{signing ? "Signing…" : "Sign and Continue"}</span>
            </button>
            </div>
          </div>
        </div>
      );
    }
  }

  return createPortal(
    <div ref={overlayRef} className="legal-overlay" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && (mode === "sign" ? setLeaveAsk(true) : onClose())}>
      <div className="legal-panel" data-legal-mode={mode} data-legal-page={isPage1 ? "1" : "2"} role="dialog" aria-modal="true" aria-label="LinkBot.Now Legal Terms" tabIndex={-1} style={{ outline: "none" }}>
        <div className="legal-bar legal-bar--top">
          <span aria-hidden="true" />
          <h1 className="legal-bar__title">{isPage1 ? "Prohibited Uses" : "LinkBot.Now Legal Terms"}</h1>
          <div className="legal-bar__right">
            {isPage1 ? null : <SectionMenu scrollRef={scrollRef} />}
            <button type="button" className="legal-close" aria-label="Close" onClick={mode === "sign" ? () => setLeaveAsk(true) : onClose}>
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div ref={scrollRef} className={`legal-scroll${isPage1 ? " legal-scroll--center" : ""}${isSignPage2 ? " legal-scroll--progress" : ""}`}>
          {body}
        </div>
        {isSignPage2 && track ? (
          <div className="legal-progress" aria-hidden="true" style={{ top: track.top, height: track.height }}>
            <div className="legal-progress__fill" style={{ transform: `scaleY(${progress})` }} />
          </div>
        ) : null}
        {footer}
        {mode === "sign" && leaveAsk ? (
          <div className="legal-leave" role="alertdialog" aria-modal="true" aria-labelledby="legal-leave-title">
            <div className="legal-leave__card">
              <h2 id="legal-leave-title" className="legal-leave__title">Signature Required</h2>
              <p className="legal-leave__text">To continue to checkout, please agree to the Legal Terms and sign at the bottom of the page.</p>
              <button type="button" className="linkbot-button legal-action legal-leave__return" onClick={() => setLeaveAsk(false)}>Return to Sign</button>
              <button type="button" className="legal-leave__exit" onClick={() => { setLeaveAsk(false); onClose(); }}>Leave Without Signing</button>
            </div>
          </div>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}

/** "Legal Terms" footer link that opens the document-only pop-up. */
const LEGAL_VIEW_OPEN_KEY = "linkbot:legal-view-open";
let legalRestoreClaimed = false;

export function FooterLegalLink() {
  const [open, setOpen] = useState(false);
  const linkRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const stack = linkRef.current?.parentElement;
    const footer = stack?.closest("footer");
    if (!stack || !footer) return;
    // One centered line: shrink the font only when the line would overflow.
    const align = () => {
      const line = stack.parentElement;
      if (!line) return;
      const width = line.clientWidth;
      if (!width) return;
      stack.style.fontSize = "inherit";
      const base = parseFloat(getComputedStyle(stack).fontSize);
      const needed = Array.from(stack.children).reduce((sum, el) => sum + el.scrollWidth, 0) + base;
      if (needed > width) stack.style.fontSize = `${base * width / needed}px`;
    };
    align();
    const observer = new ResizeObserver(align);
    observer.observe(footer);
    window.addEventListener("resize", align);
    void document.fonts.ready.then(align);
    const timers = [120, 400, 1000, 2000, 3500].map((ms) => window.setTimeout(align, ms));
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", align);
      timers.forEach(window.clearTimeout);
    };
  }, []);
  // 398: a rotation on the homepage swaps the page (and its footer); reopen the
  // Legal Terms popup in the new footer if it was open. Only right after a
  // rotation (pg-rotate-fade is present), only once, and only from a visible footer.
  useEffect(() => {
    let open = false;
    try { open = sessionStorage.getItem(LEGAL_VIEW_OPEN_KEY) === "1"; } catch { open = false; }
    if (!open) return;
    if (!document.documentElement.classList.contains("pg-rotate-fade")) {
      try { sessionStorage.removeItem(LEGAL_VIEW_OPEN_KEY); } catch { /* ignore */ }
      return;
    }
    // The old footer's claim from its click must not block the new footer.
    legalRestoreClaimed = false;
    const timer = window.setTimeout(() => {
      if (legalRestoreClaimed) return;
      const link = linkRef.current;
      if (!link || link.getClientRects().length === 0) return;
      legalRestoreClaimed = true;
      setOpen(true);
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  return (
    <>
      <button
        ref={linkRef}
        type="button"
        className="footer-legal-link"
        onClick={() => {
          try { sessionStorage.setItem(LEGAL_VIEW_OPEN_KEY, "1"); } catch { /* ignore */ }
          legalRestoreClaimed = true;
          setOpen(true);
        }}
      >
        Legal Terms
      </button>
      <LegalModal
        open={open}
        onClose={() => {
          try { sessionStorage.removeItem(LEGAL_VIEW_OPEN_KEY); } catch { /* ignore */ }
          legalRestoreClaimed = false;
          setOpen(false);
        }}
        mode="view"
      />
    </>
  );
}
