import { useRevealWhenSettled } from "@/lib/boot-reveal";
import { FooterLegalLink } from "@/components/legal/LegalModal";
import { FitLine } from "@/components/FitLine";
import { useEffect, useLayoutEffect, useRef, useState, type FormEvent } from "react";
import { useFooterMatchHeader } from "@/lib/footer-match-header";
import { Check, Eye, Lock } from "lucide-react";
import { PasswordEye } from "@/components/auth/PasswordEye";
import { Button } from "@/components/ui/button";
import { HoverlessLink } from "@/components/navigation/HoverlessLink";
import { useServerFn } from "@tanstack/react-start";
import { loginCustomer, requestPasswordReset, resetPassword } from "@/lib/account.functions";

// ===== Caps Lock hint — the exact same code /claim uses (src/routes/claim.tsx).
// Safari shows its own native Caps Lock arrow inside password fields; Chrome
// and other browsers show nothing. This custom hint fills that gap, so it is
// rendered only where the native indicator does not exist. Touch devices
// (iPad/iPhone) are the exception: Safari there draws only an unstyleable
// native blue pill (hidden in CSS), no inline arrow, so the custom hint shows
// there too — pinned to the bottom-left corner where the blue pill sat.
const HAS_NATIVE_CAPS_INDICATOR =
  typeof navigator !== "undefined" && /^((?!chrome|chromium|android).)*safari/i.test(navigator.userAgent);

function isCoarsePointer(): boolean {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(pointer: coarse)").matches;
}

// Focus events carry no modifier state, so remember the last Caps Lock state
// seen on any key/pointer event anywhere on the page (capture phase).
let lastCapsState = false;
if (typeof window !== "undefined") {
  const track = (e: Event) => {
    const m = e as KeyboardEvent;
    if (typeof m.getModifierState === "function") lastCapsState = m.getModifierState("CapsLock");
  };
  for (const type of ["keydown", "keyup", "mousedown", "pointerdown", "mousemove"]) {
    window.addEventListener(type, track, { capture: true, passive: true });
  }
}

function capsLockOn(event: React.SyntheticEvent<HTMLInputElement>): boolean {
  const native = event.nativeEvent as KeyboardEvent;
  if (typeof native.getModifierState === "function") {
    lastCapsState = native.getModifierState("CapsLock");
    return lastCapsState;
  }
  return lastCapsState;
}

function CapsLockHint({ visible, corner = "right", rightOffsetPx }: { visible: boolean; corner?: "right" | "left"; rightOffsetPx?: number }) {
  if (!visible) return null;
  return (
    <span
      className={corner === "left" ? "claim-caps-hint claim-caps-hint--left" : "claim-caps-hint"}
      aria-hidden="true"
      style={corner !== "left" && rightOffsetPx !== undefined ? { right: `${rightOffsetPx}px` } : undefined}
    >
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="0" y="0" width="24" height="24" rx="6" fill="#8e8e93" />
        <path d="M12 5.5l4.5 5.5h-2.7v5h-3.6v-5H7.5L12 5.5z" fill="#ffffff" />
        <rect x="9" y="17.5" width="6" height="2" rx="1" fill="#ffffff" />
      </svg>
    </span>
  );
}
// ===== end Caps Lock hint

type WaveDot = {
  x: number;
  y: number;
  revealAt: number;
  strength: number;
};

type WaveBar = {
  x: number;
  half: number;
  revealAt: number;
};

const BASE_DOT_SPACING = 26;
const DESKTOP_BACKGROUND_SCALE = 0.5;
// Radius of each gray dot in the login background grid (.login-dot-pattern).
const GRAY_DOT_RADIUS = 1.25;
const WAVE_SWEEP_DURATION = 3600;
const WAVE_DOT_FADE = 1700;
const WAVE_BAR_FADE = 900;
const DESKTOP_STORY_WIDTH = 596;
const DESKTOP_CARD_WIDTH = 448;
const DESKTOP_SECTION_INSET = 24;
const IPAD_LOGIN_QUERY = "(min-width: 40rem) and (max-width: 63.999rem)";

function LoginSignalTrail() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext("2d");
    if (!context) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let width = 0;
    let height = 0;
    let signalRight = 0;
    let waveDots: WaveDot[] = [];
    let waveBars: WaveBar[] = [];
    let cycleStartedAt = 0;
    let spikeP = 0.86;
    let backgroundScale = 1;
    let trailVisible = true;
    let dotSpacing = BASE_DOT_SPACING;
    // Origin of the gray dot grid in canvas coordinates, so every blue dot
    // sits exactly on a gray dot's center.
    let dotOriginX = 0;
    let dotOriginY = 0;
    let barStep = 13;
    const dotMask = document.createElement("canvas");
    // iPad only: less glow bloom so the dots and bars read crisp.
    let glowScale = 1;
    const brandColor = getComputedStyle(document.documentElement)
      .getPropertyValue("--color-brand")
      .trim() || "#168cff";
    // Illuminated dots use the exact bright blue used by the site's buttons.
    const dotColor = getComputedStyle(document.documentElement)
      .getPropertyValue("--color-brand-bright")
      .trim() || brandColor;

    // Cells covered by text or the sign-in card are off-limits, so the signal
    // only ever travels through the open background space.
    let blocked = new Set<string>();
    // Horizontal span of the sign-in card: the sweep jumps straight across it
    // instead of pausing while it travels behind it.
    let cardSpans: Array<[number, number]> = [];
    const key = (x: number, y: number) => `${x}:${y}`;

    const buildBlocked = () => {
      blocked = new Set<string>();
      cardSpans = [];
      const rect = canvas.getBoundingClientRect();
      const targets = document.querySelectorAll<HTMLElement>(
        ".login-premium-card, .login-card-column, .login-footer-line, footer",
      );
      targets.forEach((element) => {
        const box = element.getBoundingClientRect();
        if (!box.width || !box.height) return;
        const isCard = element.classList.contains("login-premium-card");
        // The sign-in card gets no padding so the bars run right up to its edge.
        const pad = isCard ? 0 : 14;
        const left = box.left - rect.left - pad;
        const top = box.top - rect.top - pad;
        const right = box.right - rect.left + pad;
        const bottom = box.bottom - rect.top + pad;
        if (isCard) {
          cardSpans.push([left, right]);
        }
        // Only block grid cells that actually fall inside the box, so no extra
        // empty row or column is carved out around it.
        const startX = isCard
          ? Math.ceil((left - dotOriginX) / dotSpacing) * dotSpacing + dotOriginX
          : Math.floor((left - dotOriginX) / dotSpacing) * dotSpacing + dotOriginX;
        const startY = isCard
          ? Math.ceil((top - dotOriginY) / dotSpacing) * dotSpacing + dotOriginY
          : Math.floor((top - dotOriginY) / dotSpacing) * dotSpacing + dotOriginY;
        for (let x = startX; x <= right; x += dotSpacing) {
          for (let y = startY; y <= bottom; y += dotSpacing) {
            blocked.add(key(x, y));
          }
        }
      });
    };

    const isOpen = (x: number, y: number) =>
      x >= dotOriginX &&
      x <= signalRight &&
      y >= dotOriginY + dotSpacing &&
      y <= height - dotSpacing &&
      !blocked.has(key(x, y));

    // A real audio-meter waveform: mirrored vertical bars around the middle of
    // the page, whose heights rise and fall like a voice level meter. The sweep
    // moves left to right and every grid dot inside a bar lights up, then fades.
    const centerY = () => height * 0.5;

    const barHalfHeight = (x: number) => {
      const p = x / Math.max(width, 1);
      // One tall spike at the right edge of the open background space.
      const spike = 0.95 * Math.exp(-Math.pow((p - spikeP) / 0.03, 2));
      const envelope =
        0.55 +
        0.45 * Math.sin(p * Math.PI * 2.2 + 0.6) * Math.sin(p * Math.PI * 0.9 + 1.4) +
        spike;
      const detail =
        Math.sin(p * Math.PI * 26) * 0.28 +
        Math.sin(p * Math.PI * 47 + 1.1) * 0.18 +
        Math.sin(p * Math.PI * 71 + 2.3) * 0.11;
      const level = Math.abs(envelope) * (0.62 + Math.abs(detail));
      const spikeLine = Math.round((x - spikeP * width) / Math.max(barStep, 1));
      const spikeVariation = [0.7, 0.9, 0.76, 1, 0.64, 0.84];
      const spikeIndex = spikeLine + 3;
      const authoredHalf =
        height *
        0.42 *
        level *
        (spikeIndex >= 0 && spikeIndex < spikeVariation.length
          ? (spikeVariation[spikeIndex] ?? 1)
          : 1);
      // Preserve the original varied levels. Only pull back the few extreme
      // peaks, with a slightly different ceiling per bar so no tops line up.
      const softLimit = height * (0.455 + 0.012 * Math.sin(x * 0.371 + 0.8));
      if (authoredHalf <= softLimit) return authoredHalf;
      return softLimit + (authoredHalf - softLimit) * 0.08;
    };

    const findSpikePosition = () => {
      // Keep the spike inside the left panel, leaving a short tail that fades
      // naturally into the black right-side background.
      const targetX = width * 0.39;
      for (let x = Math.floor(targetX / barStep) * barStep; x > dotSpacing; x -= barStep) {
        const mid = Math.round(height * 0.5);
        let open = false;
        for (const frac of [0.3, 0.5, 0.7]) {
          const y = Math.round(height * frac);
          if (isOpen(x, mid) || isOpen(x, y)) {
            open = true;
            break;
          }
        }
        if (open) {
          spikeP = x / Math.max(width, 1);
          return;
        }
      }
      spikeP = 0.86;
    };

    const buildWaveDots = () => {
      findSpikePosition();
      const bars: WaveBar[] = [];
      const dots: WaveDot[] = [];
      const mid = centerY();

      // The sweep clock only advances over visible space: columns hidden behind
      // the sign-in card cost no time, so the signal reappears on the far side
      // of the card the instant it reaches the near side.
      const behindCard = (x: number) =>
        cardSpans.some(([left, right]) => x >= left && x <= right);

      const travelStep = Math.max(barStep, 1);
      let visibleColumns = 0;
      for (let x = 0; x <= signalRight; x += travelStep) {
        if (!behindCard(x)) visibleColumns += 1;
      }
      const stepTime = WAVE_SWEEP_DURATION / Math.max(visibleColumns, 1);
      const timeline: Array<[number, number]> = [];
      let clock = 0;
      for (let x = 0; x <= signalRight; x += travelStep) {
        timeline.push([x, clock]);
        if (!behindCard(x)) clock += stepTime;
      }

      const timeAt = (x: number) => {
        const index = Math.min(
          timeline.length - 1,
          Math.max(0, Math.round(x / travelStep)),
        );
        return timeline[index]?.[1] ?? 0;
      };

      for (const [x, revealAt] of timeline) {
        if (behindCard(x)) continue;
        bars.push({ x, half: barHalfHeight(x), revealAt });
      }

      for (let x = dotOriginX; x <= signalRight; x += dotSpacing) {
        if (behindCard(x)) continue;
        const half = barHalfHeight(x);
        const revealAt = timeAt(x);
        for (let y = dotOriginY + dotSpacing; y <= height - dotSpacing; y += dotSpacing) {
          if (!isOpen(x, y)) continue;
          const offset = Math.abs(y - mid);
          if (offset > half) continue;
          dots.push({
            x,
            y,
            revealAt,
            strength: 0.9 + 0.1 * (1 - offset / Math.max(half, 1)),
          });
        }
      }

      waveBars = bars;
      waveDots = dots;
      cycleStartedAt = 0;
    };

    // The sweep only begins once the layout has settled, so it never has to
    // restart mid-pass.
    let ready = false;

    const resize = () => {
      // Mobile only: the signal trail never draws — plain black background.
      const desktopWindow = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
      trailVisible = window.matchMedia("(min-width: 64rem)").matches ||
        (desktopWindow && document.documentElement.clientWidth >= 640);
      if (!trailVisible) {
        waveBars = [];
        waveDots = [];
        context.clearRect(0, 0, width, height);
        return;
      }
      const rect = canvas.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio || 1, 3);
      glowScale = trailVisible ? 1 : 0.4;
      backgroundScale = DESKTOP_BACKGROUND_SCALE;
      dotSpacing = BASE_DOT_SPACING * backgroundScale;
      // Each gray dot is centered in its tile. With background-attachment:
      // fixed the tiles start at the viewport corner — but inside a
      // transformed ancestor (the desktop scale wrapper) browsers anchor them
      // to the dot layer's own box instead. The canvas shares that box, so
      // pick the matching origin and land on the exact gray dot centers.
      const dotLayer = canvas.parentElement?.querySelector<HTMLElement>(".login-dot-pattern");
      let anchoredToBox = true;
      if (dotLayer && getComputedStyle(dotLayer).backgroundAttachment === "fixed") {
        anchoredToBox = false;
        for (let el = dotLayer.parentElement; el; el = el.parentElement) {
          const style = getComputedStyle(el);
          if (style.transform !== "none" || style.perspective !== "none" ||
              (style.filter && style.filter !== "none") || style.willChange.includes("transform")) {
            anchoredToBox = true;
            break;
          }
        }
      }
      const tileLeft = anchoredToBox ? 0 : -rect.left;
      const tileTop = anchoredToBox ? 0 : -rect.top;
      dotOriginX = (((dotSpacing / 2 + tileLeft) % dotSpacing) + dotSpacing) % dotSpacing;
      dotOriginY = (((dotSpacing / 2 + tileTop) % dotSpacing) + dotSpacing) % dotSpacing;
      barStep = 13 * backgroundScale;
      width = rect.width;
      height = rect.height;
       // The signal continues beneath the right-side card while fading, so its
       // visible edge dissolves into that background instead of stopping at the
       // center seam or the card boundary.
       signalRight = width * 0.78;
      canvas.width = Math.round(width * ratio);
      canvas.height = Math.round(height * ratio);
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      // Stencil of the gray dots themselves: the same centers and the same
      // 1.25px radius as the gray grid, so light only shows on gray dots.
      dotMask.width = canvas.width;
      dotMask.height = canvas.height;
      const maskContext = dotMask.getContext("2d");
      if (maskContext) {
        maskContext.setTransform(ratio, 0, 0, ratio, 0, 0);
        maskContext.clearRect(0, 0, width, height);
        maskContext.fillStyle = "#fff";
        maskContext.beginPath();
        for (let x = dotOriginX; x <= width + dotSpacing; x += dotSpacing) {
          for (let y = dotOriginY; y <= height + dotSpacing; y += dotSpacing) {
            maskContext.moveTo(x + GRAY_DOT_RADIUS, y);
            maskContext.arc(x, y, GRAY_DOT_RADIUS, 0, Math.PI * 2);
          }
        }
        maskContext.fill();
      }
      buildBlocked();
      buildWaveDots();
    };

    // iPad only: while the sign-in card is enlarged the signal bars hold
    // their current frame; the sweep clock is shifted by the paused time so
    // they resume exactly where they stopped, with no jump.
    const pageRoot = canvas.closest(".login-page-root");
    let pausedAt = 0;

    const draw = (time: number) => {
      if (pageRoot?.classList.contains("login-ipad-expanded")) {
        if (!pausedAt) pausedAt = time;
        frame = window.requestAnimationFrame(draw);
        return;
      }
      if (pausedAt) {
        if (cycleStartedAt) cycleStartedAt += time - pausedAt;
        pausedAt = 0;
      }
      context.clearRect(0, 0, width, height);
      if (document.hidden || document.documentElement.classList.contains("mobile-zoom-active")) {
        frame = window.requestAnimationFrame(draw);
        return;
      }
      if (reducedMotion.matches) {
        frame = window.requestAnimationFrame(draw);
        return;
      }

      if (!trailVisible || !ready) {
        context.clearRect(0, 0, width, height);
        frame = window.requestAnimationFrame(draw);
        return;
      }


      if (!cycleStartedAt) cycleStartedAt = time;
      // The sweep restarts on the left the moment it reaches the right edge:
      // trailing dots from the previous pass keep fading into the new one.
      const cycleDuration = WAVE_SWEEP_DURATION;
      // First pass starts from a truly empty canvas: nothing is revealed on
      // the right until the sweep has actually travelled there. Only after a
      // full cycle may ages wrap around from the previous pass.
      const hasWrapped = time - cycleStartedAt >= cycleDuration;
      const elapsed = (time - cycleStartedAt) % cycleDuration;
      const ageOf = (revealAt: number) => {
        const age = elapsed - revealAt;
        if (age < 0) return hasWrapped ? age + cycleDuration : Number.POSITIVE_INFINITY;
        return age;
      };
      const mid = centerY();

      // Vertical meter bars, translucent so all text stays readable.
      context.lineCap = "round";
      const dotTailColor = context.createLinearGradient(0, 0, signalRight, 0);
      const tailStart = Math.min(1, (spikeP + 0.018) / Math.max(signalRight / width, 0.001));
      const tailDark = Math.min(1, tailStart + (1 - tailStart) * 0.56);
      const lineTailColor = context.createLinearGradient(0, 0, signalRight, 0);
      lineTailColor.addColorStop(0, dotColor);
      lineTailColor.addColorStop(tailStart, dotColor);
      lineTailColor.addColorStop(tailDark, "#000000");
      lineTailColor.addColorStop(1, "#000000");
      dotTailColor.addColorStop(0, dotColor);
      dotTailColor.addColorStop(tailStart, dotColor);
      dotTailColor.addColorStop(tailDark, "#000000");
      dotTailColor.addColorStop(1, "#000000");
      // Lit gray dots first, clipped to the exact gray dots.
      context.shadowBlur = 0;
      for (const dot of waveDots) {
        const age = ageOf(dot.revealAt);
        if (age > WAVE_DOT_FADE) continue;
        const fade = 1 - age / WAVE_DOT_FADE;
        const headGlow = Math.min(1, age / 120);
        // Brighter pop: the blue ramps to full brightness faster and stays
        // brighter through the fade, without touching color, size or timing.
        context.globalAlpha = Math.min(1, Math.min(1, fade * headGlow) * 1.6) * dot.strength;
        context.fillStyle = dotTailColor;
        // A light patch centered on the gray dot. The gray-dot stencil clips
        // it to exactly that gray dot, so the gray dot itself lights up blue.
        context.beginPath();
        context.arc(dot.x, dot.y, dotSpacing * 0.45, 0, Math.PI * 2);
        context.fill();
      }
      context.globalAlpha = 1;
      // Keep only the light that falls on a gray dot.
      context.save();
      context.globalCompositeOperation = "destination-in";
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.drawImage(dotMask, 0, 0);
      context.restore();

      // Audio lines, drawn unclipped beneath the lit dots exactly as before.
      context.save();
      context.globalCompositeOperation = "destination-over";
      for (const bar of waveBars) {
        const age = ageOf(bar.revealAt);
        if (age > WAVE_BAR_FADE) continue;
        const fade = 1 - age / WAVE_BAR_FADE;
        const grow = Math.min(1, age / 90);
        const tailProgress = Math.max(
          0,
          Math.min(1, (bar.x / signalRight - tailStart) / Math.max(tailDark - tailStart, 0.001)),
        );
        context.strokeStyle = lineTailColor;
        context.globalAlpha = fade * 0.3;
        context.shadowColor =
          tailProgress > 0
            ? `color-mix(in srgb, ${dotColor} ${(1 - tailProgress) * 100}%, #000000)`
            : dotColor;
        context.lineWidth = 4 * backgroundScale;
        context.shadowBlur = 14 * backgroundScale * glowScale * fade;
        context.beginPath();
        context.moveTo(bar.x, mid - bar.half * grow);
        context.lineTo(bar.x, mid + bar.half * grow);
        context.stroke();
      }
      context.restore();
      context.globalAlpha = 1;
      context.shadowBlur = 0;

      frame = window.requestAnimationFrame(draw);
    };

    resize();
    // Re-measure once the layout has settled so the blocked zones match the
    // final text and card positions.
    const settle = window.setTimeout(() => {
      resize();
      ready = true;
    }, 500);
    frame = window.requestAnimationFrame(draw);
    // Only re-measure when the canvas box actually changed, so a resize event
    // that arrives without a real size change never restarts the sweep.
    let lastWidth = canvas.getBoundingClientRect().width;
    let lastHeight = canvas.getBoundingClientRect().height;
    const resizeIfChanged = () => {
      const box = canvas.getBoundingClientRect();
      if (Math.abs(box.width - lastWidth) > 1 || Math.abs(box.height - lastHeight) > 1) {
        lastWidth = box.width;
        lastHeight = box.height;
        resize();
      }
    };
    // The canvas is absolutely positioned, so the window resize event does not
    // always fire for it — watch its own box too.
    const canvasObserver = new ResizeObserver(resizeIfChanged);
    canvasObserver.observe(canvas);
    // After a turn into sideways the layout settles in stages: keep the canvas
    // blank through each settle step, re-measure, then start the sweep once.
    let orientA = 0;
    let orientB = 0;
    let orientC = 0;
    const onOrientationChange = () => {
      ready = false;
      resize();
      window.clearTimeout(orientA);
      window.clearTimeout(orientB);
      window.clearTimeout(orientC);
      orientA = window.setTimeout(resize, 400);
      orientB = window.setTimeout(resize, 900);
      orientC = window.setTimeout(() => {
        resize();
        ready = true;
      }, 1500);
    };
    window.addEventListener("orientationchange", onOrientationChange);
    window.addEventListener("resize", resizeIfChanged);
    return () => {
      window.cancelAnimationFrame(frame);
      window.clearTimeout(settle);
      canvasObserver.disconnect();
      window.clearTimeout(orientA);
      window.clearTimeout(orientB);
      window.clearTimeout(orientC);
      window.removeEventListener("orientationchange", onOrientationChange);
      window.removeEventListener("resize", resizeIfChanged);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="login-signal-trail pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden="true"
    />
  );
}

const LOGIN_EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;

export type LoginView = "login" | "forgot" | "reset";

type LoginNotice = { ok: boolean; text: string; locked?: boolean; lockedMinutes?: number };
export function LoginPage({ view = "login" }: { view?: LoginView }) {
  // Keep the page hidden until its final layout has settled (first load).
  useRevealWhenSettled();
  const footerRef = useRef<HTMLElement>(null);
  useFooterMatchHeader(footerRef, null);
  // Height of the footer, so the bottom fade ends exactly at the footer's top edge.
  const [footerH, setFooterH] = useState(0);
  useLayoutEffect(() => {
    const f = footerRef.current;
    if (!f) return;
    const read = () => setFooterH(f.offsetHeight);
    read();
    const ro = new ResizeObserver(read);
    ro.observe(f);
    return () => ro.disconnect();
  }, []);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [remember, setRemember] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const mainRef = useRef<HTMLElement>(null);
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  // 185: shown again from the back/forward cache: re-enable Sign In, like the voice page.
  useEffect(() => {
    const onShow = (e: PageTransitionEvent) => { if (e.persisted) setBusy(false); };
    window.addEventListener("pageshow", onShow);
    return () => window.removeEventListener("pageshow", onShow);
  }, []);
  const [notice, setNoticeState] = useState<LoginNotice | null>(null);
  const setNotice = setNoticeState;
  // 461: the same error notice returned again replays the word pulse.
  const [noticePulse, setNoticePulse] = useState(0);
  const [capsHint, setCapsHint] = useState<{ password: boolean; confirm: boolean }>({
    password: false,
    confirm: false,
  });

  // Keep the Caps Lock hint in sync from any keyboard/mouse/touch event on the
  // page while a password field is focused — including the click/tap that
  // focuses it (mousedown/pointerup/click fire after focus in Chrome).
  // Same pattern /claim uses; only the field ids differ.
  useEffect(() => {
    const sync = (e: Event) => {
      const m = e as KeyboardEvent;
      if (typeof m.getModifierState === "function") lastCapsState = m.getModifierState("CapsLock");
      const id = (document.activeElement as HTMLElement | null)?.id;
      if (id === "login-password") setCapsHint((p) => (p.password === lastCapsState ? p : { ...p, password: lastCapsState }));
      else if (id === "login-password-confirm") setCapsHint((p) => (p.confirm === lastCapsState ? p : { ...p, confirm: lastCapsState }));
    };
    const types = ["keydown", "keyup", "pointerdown", "pointerup", "mousedown", "mouseup", "click", "mousemove", "touchend", "focusin"];
    for (const t of types) document.addEventListener(t, sync, { capture: true, passive: true });
    return () => {
      for (const t of types) document.removeEventListener(t, sync, { capture: true });
    };
  }, []);
  // After a password reset the person lands here and signs in themselves.
  useEffect(() => {
    if (view === "login" && new URLSearchParams(window.location.search).get("reset") === "1") {
      setNotice({ ok: true, text: "Password Updated. Please Sign In." });
    }
  }, [view]);
  const login = useServerFn(loginCustomer);
  const forgot = useServerFn(requestPasswordReset);
  const reset = useServerFn(resetPassword);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    const params = new URLSearchParams(window.location.search);
    const next = params.get("next") ?? undefined;
    const prevNotice = notice;
    const setNotice = (n: LoginNotice | null) => {
      if (n && !n.ok && prevNotice && !prevNotice.ok && prevNotice.text === n.text && !!prevNotice.locked === !!n.locked) {
        setNoticePulse((k) => k + 1);
      } else if (n) {
        setNoticePulse(0);
      }
      setNoticeState(n);
    };
    setNoticeState(null);
    if (view === "forgot" && !LOGIN_EMAIL_RE.test(email.trim())) {
      setNotice({ ok: false, text: "Please enter a valid email." });
      return;
    }
    setBusy(true);
    let leaving = false;
    try {
      if (view === "login") {
        const r = await login({ data: { email: email.trim().toLowerCase(), password, remember, ...(next ? { next } : {}) } });
        if (r.ok) { leaving = true; window.location.assign(r.redirectTo); return; }
        setNotice(r.locked ? { ok: false, text: "", locked: true, ...(r.lockedMinutes !== undefined ? { lockedMinutes: r.lockedMinutes } : {}) } : { ok: false, text: "That email or password is incorrect." });
      } else if (view === "forgot") {
        const r = await forgot({ data: { email: email.trim().toLowerCase() } });
        void r;
        setNotice({ ok: true, text: "Reset Link Sent To Email." });
      } else {
        const rule = [
          [password.length >= 8, "Password must be at least 8 characters."],
          [/[A-Z]/.test(password), "Password must include an uppercase letter."],
          [/[0-9]/.test(password), "Password must include a number."],
          [/[^A-Za-z0-9]/.test(password), "Password must include a special character."],
          [password === confirm, "Passwords don't match."],
        ].find(([ok]) => !ok);
        if (rule) { setNotice({ ok: false, text: String(rule[1]) }); return; }
        const code = params.get("code") ?? "";
        const r = await reset({ data: { code, password, ...(next ? { next } : {}) } });
        if (r.ok) { leaving = true; window.location.assign(r.redirectTo); return; }
        setNotice({ ok: false, text: "This reset link is invalid or has expired." });
      }
    } catch {
      setNotice({ ok: false, text: view === "login" ? "Something went wrong. Please try again." : view === "forgot" ? "Something went wrong. Try again." : "This reset link is invalid or has expired." });
    } finally {
      if (!leaving) setBusy(false);
    }
  }

  // The header strip above this page is transparent, so the document itself
  // must wear the page background for the color to continue to the top.
  useLayoutEffect(() => {
    document.body.classList.add("login-body-night");
    document.documentElement.classList.add("login-outer-black");
    document.body.classList.add("login-outer-black");
    return () => {
      document.body.classList.remove("login-body-night", "login-outer-black");
      document.documentElement.classList.remove("login-outer-black");
    };
  }, []);


  // Fill the space below the shared header without scaling the sign-in card.
  // On unusually short windows the page can scroll rather than making the
  // form microscopic.
  useLayoutEffect(() => {
    const update = () => {
      const root = rootRef.current;
      const main = mainRef.current;
      if (!root || !main) return;
      // Pinch zoom must never trigger a relayout.
      if ((window.visualViewport?.scale ?? 1) > 1.01) return;
      const layoutWidth = document.documentElement.clientWidth;
      // The login page uses its actual viewport width so its split layout can
      // reflow naturally between desktop and iPad instead of shrinking as one
      // fixed canvas. The shared header keeps its existing independent scale.
      const scale = 1;
      root.style.setProperty("--login-page-scale", String(scale));
      root.style.minHeight = "";
      (root.style as unknown as { zoom: string }).zoom = "1";
      const mainTop = main.getBoundingClientRect().top / scale;
      const viewportHeight = window.innerHeight / scale;
      const available = Math.max(viewportHeight - mainTop, 0);

      root.style.minHeight = `${available}px`;

      // Mobile: the whole sign-in card scales down as one piece so it always
      // fits the screen exactly as it looks on every other phone — the page
      // itself never scrolls.
      const column = main.querySelector<HTMLElement>(".login-card-column");
      const card = main.querySelector<HTMLElement>(".login-premium-card");
      if (layoutWidth < 640 && column && card) {
        root.style.setProperty("--login-mobile-fit", "1");
        column.style.height = "";
        const natural = card.offsetHeight;
        const mainStyles = window.getComputedStyle(main);
        const verticalPadding =
          Number.parseFloat(mainStyles.paddingTop) +
          Number.parseFloat(mainStyles.paddingBottom);
        const footer = root.querySelector<HTMLElement>("footer");
        const footerHeight = footer?.offsetHeight ?? 0;
        const room = Math.max(0, available - verticalPadding - footerHeight);
        const fit = natural > 0 ? Math.min(1, room / natural) : 1;
        root.style.setProperty("--login-mobile-fit", String(fit));
        column.style.height = `${Math.round(natural * fit)}px`;
      } else if (column) {
        root.style.removeProperty("--login-mobile-fit");
        column.style.height = "";
      }

      // Desktop keeps the exact authored layout and scales both halves together
      // only when the available width becomes too small. This runs solely on
      // the initial layout and real viewport changes, never on a delayed pass.
      const desktopWindow = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
      if (layoutWidth >= 1024 || (desktopWindow && layoutWidth >= 640)) {
        const mainStyles = window.getComputedStyle(main);
        const horizontalPadding =
          Number.parseFloat(mainStyles.paddingLeft) +
          Number.parseFloat(mainStyles.paddingRight);
        const halfWidth = Math.max(0, (main.clientWidth - horizontalPadding) / 2);
        const usableHalfWidth = Math.max(0, halfWidth - DESKTOP_SECTION_INSET);
        const desktopScale = Math.min(
          1,
          usableHalfWidth / DESKTOP_STORY_WIDTH,
          usableHalfWidth / DESKTOP_CARD_WIDTH,
        );
        root.style.setProperty("--login-desktop-zoom", String(desktopScale));
      } else {
        root.style.removeProperty("--login-desktop-zoom");
      }
    };
    update();
    const observer = new ResizeObserver(update);
    const main = mainRef.current;
    if (main) observer.observe(main);
    window.addEventListener("resize", update);
    // After a rotation the layout needs two extra passes to settle, so the
    // card measures correctly once the turn is finished.
    let settleA = 0;
    let settleB = 0;
    // Hide the sign-in area at the first sign of a rotation, re-measure, and
    // reveal once the 900ms pass has measured the settled layout.
    const onOrientationChange = () => {
      rootRef.current?.classList.add("login-rotating");
      update();
      window.clearTimeout(settleA);
      window.clearTimeout(settleB);
      settleA = window.setTimeout(update, 400);
      settleB = window.setTimeout(() => {
        update();
        rootRef.current?.classList.remove("login-rotating");
      }, 900);
    };
    window.addEventListener("orientationchange", onOrientationChange);
    window.screen.orientation?.addEventListener?.("change", onOrientationChange);
    const portraitQuery = window.matchMedia("(orientation: portrait)");
    portraitQuery.addEventListener?.("change", onOrientationChange);
    window.visualViewport?.addEventListener("resize", update);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", onOrientationChange);
      window.screen.orientation?.removeEventListener?.("change", onOrientationChange);
      portraitQuery.removeEventListener?.("change", onOrientationChange);
      window.clearTimeout(settleA);
      window.clearTimeout(settleB);
      rootRef.current?.classList.remove("login-rotating");
      window.visualViewport?.removeEventListener("resize", update);
    };
  }, []);



  return (
    <div
      ref={rootRef}
      className={`login-page-root login-view-${view} night-panel relative flex flex-col overflow-clip bg-night`}
    >
      {/* Faint gray dot pattern across the whole background — purely
          decorative, sits under the content and fades with the page. */}
      <div
        className="login-dot-pattern pointer-events-none absolute inset-0"
        aria-hidden="true"
      />
      <LoginSignalTrail />

      {/* Soft fades into pure black behind the header and footer — no hard
          edges, the page color itself stays exactly as it is. */}
      <div
        className="login-top-fade pointer-events-none absolute inset-x-0 top-0 h-44"
        style={{ background: "linear-gradient(180deg, #000000, transparent)" }}
        aria-hidden="true"
      />
      <div
        className="login-bottom-fade pointer-events-none absolute inset-x-0 bottom-0 h-36"
        style={{ background: "linear-gradient(0deg, #000000, transparent)" }}
        aria-hidden="true"
      />

      {/* Seamless edges: the header's black and the footer's color fade into the
          middle section, over its dots, glow and blue, with no hard line. */}
      <div
        className="login-seam-top pointer-events-none absolute inset-x-0 top-0"
        style={{ zIndex: 2, background: "linear-gradient(180deg, #000 0%, rgb(0 0 0 / 0.6) 35%, transparent 100%)" }}
        aria-hidden="true"
      />
      <div
        className="login-seam-bottom pointer-events-none absolute inset-x-0"
        style={{ zIndex: 2, bottom: footerH, background: "linear-gradient(0deg, rgb(5 7 15) 0%, rgb(5 7 15 / 0.6) 35%, transparent 100%)" }}
        aria-hidden="true"
      />

      <main
        ref={mainRef}
        className="login-split relative z-10 flex flex-1 items-center justify-center px-4 py-12 max-sm:py-5 sm:px-12 sm:py-10 lg:px-20"
      >
        {/* Story column — desktop only; iPad and mobile show just the card. */}
        <section className="login-story hidden lg:block">
          <p className="pr-eyebrow text-brand" style={{ fontWeight: 700 }}>
            LinkBot AI voice employees
          </p>
          <h2 className="headline mt-5 text-[clamp(1.75rem,3.1vw,2.9rem)] font-black leading-[1.08] tracking-tight text-night-foreground">
            Your LinkedIn profile,{"\u00a0"}
            <br />
            now with its own voice.
          </h2>
          <p
            className="mt-5 max-w-xl text-sm font-bold leading-relaxed sm:text-base"
            style={{
              color: "oklch(0.72 0.02 255)",
              textShadow:
                "0 1px 2px rgba(2, 6, 20, 0.9), 0 0 14px rgba(2, 6, 20, 0.85), 0 0 30px rgba(2, 6, 20, 0.7)",
            }}
          >
            Your LinkBot answers any questions, qualifies them in a real
            conversation, sends personalized links based on their needs, books
            meetings and handles prospects the way a real receptionist would.
          </p>

          <div className="login-story-cards mt-8">
            <div className="login-story-card">
              <p className="login-story-card-title">Capture</p>
            </div>
            <div className="login-story-card">
              <p className="login-story-card-title">Convert</p>
            </div>
          </div>

          <ul className="login-story-list mt-8">
            {[
              "Turns quiet Profile Visitors into Real Leads",
              "Warm Handoff to you with the Full Context",
              "Calendar, CRM, and Analytics all in One Place",
            ].map((item) => (
              <li key={item}>
                <Check className="login-story-check" strokeWidth={3} />
                {item}
              </li>
            ))}
          </ul>
        </section>

        <div
          className="login-card-column w-full max-w-md"
          onPointerDownCapture={(event) => {
            // iPad only (touch, 640–1023px): enlarge the card and center it
            // after the first tap. Phones and desktop never match this query.
            if (!window.matchMedia(IPAD_LOGIN_QUERY).matches) return;
            const root = rootRef.current;
            const main = mainRef.current;
            const column = event.currentTarget;
            const card = column.querySelector<HTMLElement>(".login-premium-card");
            if (!root || !main || !card || root.classList.contains("login-ipad-expanded")) return;
            root.style.removeProperty("--login-ipad-zoom");
            root.classList.add("login-ipad-expanded");
            const naturalW = card.offsetWidth;
            const naturalH = card.offsetHeight;
            const fit = () => {
              if (!window.matchMedia(IPAD_LOGIN_QUERY).matches) {
                detachIpadCollapse();
                root.classList.remove("login-ipad-expanded");
                root.style.removeProperty("--login-ipad-zoom");
                return;
              }
              const styles = window.getComputedStyle(main);
              const roomW = main.clientWidth - 48;
              const roomH =
                main.clientHeight -
                Number.parseFloat(styles.paddingTop) -
                Number.parseFloat(styles.paddingBottom);
              const rawZoom = Math.max(1, Math.min(roomW / naturalW, roomH / naturalH));
              // iPad only: apply roughly half of the available enlargement so
              // the card grows noticeably but never dominates the screen.
              const zoom = Math.max(1, 1 + (rawZoom - 1) * 0.5);
              root.style.setProperty("--login-ipad-zoom", String(zoom));
            };
            const detachIpadCollapse = () => {
              document.removeEventListener("pointerdown", collapseIpadExpand, true);
              window.removeEventListener("resize", fit);
              window.removeEventListener("orientationchange", fit);
            };
            const collapseIpadExpand = (event: PointerEvent) => {
              // iPad only: a tap anywhere outside the card restores the
              // original split layout. Taps inside the card are ignored.
              if (event && column.contains(event.target as Node | null)) return;
              detachIpadCollapse();
              root.classList.remove("login-ipad-expanded");
              root.style.removeProperty("--login-ipad-zoom");
            };
            document.addEventListener("pointerdown", collapseIpadExpand, true);
            fit();
            window.addEventListener("resize", fit);
            window.addEventListener("orientationchange", fit);
          }}
        >
          <div className="login-premium-card login-responsive-card login-light-card">
            <div className="login-premium-card-inner max-sm:px-5 p-8 sm:p-10">
              <div className="text-center">
                <p className="pr-eyebrow text-brand" style={{ fontWeight: 800 }}>
                  {view === "login" ? "Welcome back" : "Account help"}
                </p>
                <h1 className="headline login-title-heavy mt-3 whitespace-nowrap font-black text-[clamp(1.1rem,4.5vw,1.5rem)] text-night-foreground">
                  {view === "login" ? "Client Portal Sign In" : view === "forgot" ? "Forgot Password" : "Choose A New Password"}
                </h1>
                <p className={`mt-3 text-sm font-medium leading-relaxed text-night-muted ${view === "reset" ? "login-reset-subtitle" : ""}`}>
                  {view === "login" ? "Access Your AI Dashboard." : view === "forgot" ? "Enter your account email." : "Use a strong password you don't use elsewhere."}
                </p>
              </div>


              <form
                className="mt-7 space-y-5"
                onSubmit={onSubmit}
              >
                {view !== "reset" && (
                <div className="space-y-2">
                  <label
                    htmlFor="login-email"
                    className="block text-night-foreground"
                  >
                    <span className="login-crisp-label">
                      Email address <span className="text-white">*</span>
                    </span>
                  </label>
                  <input
                    id="login-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@yourcompany.com"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    className="h-12 w-full rounded-xl border border-black/15 bg-white px-4 text-base font-semibold text-black shadow-[inset_0_1px_0_rgba(255,255,255,0.8)] placeholder:text-black/40 focus:border-brand/70 focus:outline-none focus:ring-2 focus:ring-brand/25"
                  />
                </div>
                )}


                {view !== "forgot" && (
                <div className="space-y-2">
                  <div className="flex items-baseline justify-between gap-2">
                    <label
                      htmlFor="login-password"
                      className="block text-night-foreground"
                    >
                      <span className="login-crisp-label">
                        {view === "reset" ? "New password" : "Password"} <span className="text-white">*</span>
                      </span>
                    </label>
                    {view === "login" && (
                    <HoverlessLink
                      to="/forgot-password"
                      className="text-xs font-semibold text-night-muted transition-colors hover:text-brand"
                    >
                      Forgot password?
                    </HoverlessLink>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      id="login-password"
                      type={showPassword ? "text" : "password"}
                      autoComplete={view === "reset" ? "new-password" : "current-password"}
                      placeholder={view === "reset" ? "Create a password" : "Enter your password"}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      onKeyDown={(event) => setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) }))}
                      onKeyUp={(event) => setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) }))}
                      onFocus={(event) => setCapsHint((prev) => ({ ...prev, password: capsLockOn(event) }))}
                      onBlur={() => setCapsHint((prev) => ({ ...prev, password: false }))}
                      className="h-12 w-full rounded-xl border border-black/15 bg-white px-4 pr-12 text-base font-semibold text-black shadow-[inset_0_1px_0_rgba(255,255,255,0.8)] placeholder:text-black/40 focus:border-brand/70 focus:outline-none focus:ring-2 focus:ring-brand/25"
                    />
                    <CapsLockHint
                      visible={(!HAS_NATIVE_CAPS_INDICATOR || isCoarsePointer()) && capsHint.password}
                      rightOffsetPx={44}
                    />
                    <PasswordEye shown={showPassword} onToggle={() => setShowPassword((current) => !current)} />
                  </div>
                  {view === "login" && (
                    <label htmlFor="login-remember" className="flex items-center gap-2 text-xs font-semibold text-night-muted">
                      <input
                        id="login-remember"
                        type="checkbox"
                        checked={remember}
                        onChange={(event) => setRemember(event.target.checked)}
                        className="h-3.5 w-3.5 accent-brand"
                      />
                      Keep me signed in
                    </label>
                  )}
                </div>
                )}

                {view === "reset" && (
                <div className="space-y-2">
                  <label htmlFor="login-password-confirm" className="block text-night-foreground">
                    <span className="login-crisp-label">
                      Confirm password <span className="text-white">*</span>
                    </span>
                  </label>
                  <div className="relative">
                    <input
                      id="login-password-confirm"
                      type={showConfirm ? "text" : "password"}
                      autoComplete="new-password"
                      placeholder="Re-enter your password"
                      value={confirm}
                      onChange={(event) => setConfirm(event.target.value)}
                      onKeyDown={(event) => setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) }))}
                      onKeyUp={(event) => setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) }))}
                      onFocus={(event) => setCapsHint((prev) => ({ ...prev, confirm: capsLockOn(event) }))}
                      onBlur={() => setCapsHint((prev) => ({ ...prev, confirm: false }))}
                      className="h-12 w-full rounded-xl border border-black/15 bg-white px-4 pr-12 text-base font-semibold text-black shadow-[inset_0_1px_0_rgba(255,255,255,0.8)] placeholder:text-black/40 focus:border-brand/70 focus:outline-none focus:ring-2 focus:ring-brand/25"
                    />
                    <CapsLockHint
                      visible={(!HAS_NATIVE_CAPS_INDICATOR || isCoarsePointer()) && capsHint.confirm}
                      rightOffsetPx={44}
                    />
                    <PasswordEye shown={showConfirm} onToggle={() => setShowConfirm((current) => !current)} />
                  </div>
                </div>
                )}

                {notice && (
                  <FitLine role="status" className={notice.ok ? "text-center text-sm font-bold text-brand" : "text-center text-xs font-bold text-destructive"}>
                    <span key={noticePulse} className={noticePulse > 0 && !notice.ok ? "demo-email-error-pulse" : undefined} style={noticePulse > 0 && !notice.ok ? { display: "inline-block" } : undefined}>
                    {notice.locked ? (
                      <>
                        Your Account Is Locked. Try again in{" "}
                        {(notice.lockedMinutes ?? 15) === 1 ? "1 minute" : `${notice.lockedMinutes ?? 15} minutes`}, or{" "}
                        <HoverlessLink to="/forgot-password" className="underline">reset your password</HoverlessLink>{" "}
                        to unlock it now.
                      </>
                    ) : notice.text}
                    </span>
                  </FitLine>
                )}

                <button
                  type="submit"
                  disabled={busy}
                  className="linkbot-button w-full"
                >
                  <span>{view === "login" ? "Sign In" : view === "forgot" ? "Send Reset Link" : "Save Password"}</span>
                </button>

                {view !== "login" && (
                  <div className="text-center">
                    <HoverlessLink
                      to="/login"
                      className="text-xs font-semibold text-night-muted transition-colors hover:text-brand"
                    >
                      Back to Sign In
                    </HoverlessLink>
                  </div>
                )}

                <p className="login-security-line flex items-center justify-center gap-2 whitespace-nowrap font-semibold text-night-muted">
                  <Lock className="h-3.5 w-3.5 text-brand" />
                  Your account is protected.
                </p>

                {/* Reset view: the /login card grew by its "Keep me signed in"
                    row (16px line + 8px gap). The reset card's own fields are
                    otherwise identical in height, so this invisible spacer
                    plus the form's 20px gap returns exactly those 24px, all
                    of it under "Your account is protected.", above the
                    divider. It renders nothing visible. */}
                {view === "reset" && (
                  <div className="invisible" aria-hidden="true" style={{ height: "4px" }} />
                )}

                {/* Forgot view: invisible structural twin of /login's password
                    field plus its "Keep me signed in" row, placed last so the
                    card is exactly the same height as /login's card on every
                    device, with all of the extra blank space under "Your
                    account is protected." It renders nothing visible. */}
                {view === "forgot" && (
                <div className="invisible space-y-2" aria-hidden="true">
                  <div className="flex items-baseline justify-between gap-2">
                    <label className="block text-night-foreground">
                      <span className="login-crisp-label">
                        Password <span className="text-white">*</span>
                      </span>
                    </label>
                    <span className="text-xs font-semibold text-night-muted">
                      Forgot password?
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="password"
                      aria-label="Password"
                      tabIndex={-1}
                      className="h-12 w-full rounded-xl border border-black/15 bg-white px-4 pr-12 text-base font-semibold text-black shadow-[inset_0_1px_0_rgba(255,255,255,0.8)] placeholder:text-black/40 focus:border-brand/70 focus:outline-none focus:ring-2 focus:ring-brand/25"
                    />
                    <button
                      type="button"
                      aria-label="Show password"
                      tabIndex={-1}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-black/50 transition-colors hover:text-black"
                    >
                      <Eye className="login-crisp-eye" strokeWidth={2} />
                    </button>
                  </div>
                  <label className="flex items-center gap-2 text-xs font-semibold text-night-muted">
                    <input
                      type="checkbox"
                      tabIndex={-1}
                      className="h-3.5 w-3.5 accent-brand"
                    />
                    Keep me signed in
                  </label>
                </div>
                )}
              </form>

              <div className="mt-8 pt-6 text-center">
                <hr className="login-premium-divider mb-6" />
                <p className="login-account-line whitespace-nowrap font-semibold text-night-muted">
                  Don't have a LinkBot account yet?{" "}
                  <HoverlessLink
                    to="/claim"
                    className="font-bold text-brand transition-colors hover:text-brand-light"
                  >
                    Get Yours Now
                  </HoverlessLink>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer ref={footerRef} className="login-page-footer site-footer-color site-footer-balanced relative z-10 px-6 pb-5 pt-5 text-center text-[0.7rem] text-night-muted">
        <p>
          <span className="footer-stack">
            <FooterLegalLink /><span>&nbsp;· © {new Date().getFullYear()} LinkBot · <span>support@linkbot.now</span></span>
          </span>
        </p>
      </footer>
    </div>
  );
}
