import { Eye, EyeOff } from "lucide-react";

/**
 * Show/hide eye used inside every password box (same icon and look as /login).
 * Tap area is a 44x44 invisible zone centered on the icon; pressing it never
 * takes focus from the password box, so the keyboard stays open and the cursor stays put.
 */
export function PasswordEye({ shown, onToggle }: { shown: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onPointerDown={(e) => e.preventDefault()}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onToggle}
      aria-label={shown ? "Hide password" : "Show password"}
      aria-pressed={shown}
      style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
      className="absolute right-3 top-1/2 z-10 -translate-y-1/2 text-black/50 transition-colors hover:text-black before:absolute before:left-1/2 before:top-1/2 before:h-11 before:w-11 before:-translate-x-1/2 before:-translate-y-1/2 before:content-['']"
    >
      {shown ? <EyeOff className="login-crisp-eye pointer-events-none" strokeWidth={2} /> : <Eye className="login-crisp-eye pointer-events-none" strokeWidth={2} />}
    </button>
  );
}
