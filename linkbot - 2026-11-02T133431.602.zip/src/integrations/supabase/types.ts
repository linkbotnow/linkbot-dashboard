export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.17"
  }
  public: {
    Tables: {
      billing_events: {
        Row: {
          archived_bot_email: string | null
          archived_bot_id: string | null
          archived_bot_slug: string | null
          client_id: string | null
          event_type: string
          external_event_id: string
          ghl_company_id: string | null
          ghl_location_id: string | null
          id: string
          processed_at: string | null
          processing_error: string | null
          processing_status: string
          provider: string
          received_at: string
          safe_payload: Json
        }
        Insert: {
          archived_bot_email?: string | null
          archived_bot_id?: string | null
          archived_bot_slug?: string | null
          client_id?: string | null
          event_type: string
          external_event_id: string
          ghl_company_id?: string | null
          ghl_location_id?: string | null
          id?: string
          processed_at?: string | null
          processing_error?: string | null
          processing_status?: string
          provider?: string
          received_at?: string
          safe_payload?: Json
        }
        Update: {
          archived_bot_email?: string | null
          archived_bot_id?: string | null
          archived_bot_slug?: string | null
          client_id?: string | null
          event_type?: string
          external_event_id?: string
          ghl_company_id?: string | null
          ghl_location_id?: string | null
          id?: string
          processed_at?: string | null
          processing_error?: string | null
          processing_status?: string
          provider?: string
          received_at?: string
          safe_payload?: Json
        }
        Relationships: [
          {
            foreignKeyName: "billing_events_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "client_slugs"
            referencedColumns: ["id"]
          },
        ]
      }
      call_share_debug: {
        Row: {
          created_at: string
          id: string
          raw_request: Json
          share_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          raw_request?: Json
          share_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          raw_request?: Json
          share_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "call_share_debug_share_id_fkey"
            columns: ["share_id"]
            isOneToOne: false
            referencedRelation: "call_shares"
            referencedColumns: ["id"]
          },
        ]
      }
      call_shares: {
        Row: {
          account: string
          button_name: string
          call_key: string | null
          created_at: string
          excluded_ids: string[]
          id: string
          ids: string[]
          link_id: string
          page: string | null
        }
        Insert: {
          account: string
          button_name: string
          call_key?: string | null
          created_at?: string
          excluded_ids?: string[]
          id?: string
          ids?: string[]
          link_id: string
          page?: string | null
        }
        Update: {
          account?: string
          button_name?: string
          call_key?: string | null
          created_at?: string
          excluded_ids?: string[]
          id?: string
          ids?: string[]
          link_id?: string
          page?: string | null
        }
        Relationships: []
      }
      checkout_passes: {
        Row: {
          bot_id: string
          created_at: string
          disabled_at: string | null
          id: string
          token_hash: string
        }
        Insert: {
          bot_id: string
          created_at?: string
          disabled_at?: string | null
          id?: string
          token_hash: string
        }
        Update: {
          bot_id?: string
          created_at?: string
          disabled_at?: string | null
          id?: string
          token_hash?: string
        }
        Relationships: [
          {
            foreignKeyName: "checkout_passes_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "client_slugs"
            referencedColumns: ["id"]
          },
        ]
      }
      client_slugs: {
        Row: {
          activated_at: string | null
          activated_payment_id: string | null
          allowed_domains: string[]
          call_screen_business_text: string | null
          call_screen_name_text: string | null
          company_name: string | null
          created_at: string
          email: string
          full_name: string | null
          ghl_location_id: string | null
          ghl_widget_id: string | null
          greeting_business_text: string | null
          greeting_choice: string
          greeting_name_text: string | null
          hold_expires_at: string | null
          id: string
          last_name: string | null
          link_code: string | null
          linkedin_url: string | null
          links_sent_at: string | null
          owner_account_id: string | null
          page_title_choice: string
          phone: string | null
          slug: string
          status: string
          updated_at: string
          voice_choice: string | null
          voice_sent: string | null
          voice_sent_hash: string | null
          website: string | null
        }
        Insert: {
          activated_at?: string | null
          activated_payment_id?: string | null
          allowed_domains?: string[]
          call_screen_business_text?: string | null
          call_screen_name_text?: string | null
          company_name?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          ghl_location_id?: string | null
          ghl_widget_id?: string | null
          greeting_business_text?: string | null
          greeting_choice?: string
          greeting_name_text?: string | null
          hold_expires_at?: string | null
          id?: string
          last_name?: string | null
          link_code?: string | null
          linkedin_url?: string | null
          links_sent_at?: string | null
          owner_account_id?: string | null
          page_title_choice?: string
          phone?: string | null
          slug: string
          status?: string
          updated_at?: string
          voice_choice?: string | null
          voice_sent?: string | null
          voice_sent_hash?: string | null
          website?: string | null
        }
        Update: {
          activated_at?: string | null
          activated_payment_id?: string | null
          allowed_domains?: string[]
          call_screen_business_text?: string | null
          call_screen_name_text?: string | null
          company_name?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          ghl_location_id?: string | null
          ghl_widget_id?: string | null
          greeting_business_text?: string | null
          greeting_choice?: string
          greeting_name_text?: string | null
          hold_expires_at?: string | null
          id?: string
          last_name?: string | null
          link_code?: string | null
          linkedin_url?: string | null
          links_sent_at?: string | null
          owner_account_id?: string | null
          page_title_choice?: string
          phone?: string | null
          slug?: string
          status?: string
          updated_at?: string
          voice_choice?: string | null
          voice_sent?: string | null
          voice_sent_hash?: string | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "client_slugs_owner_account_id_fkey"
            columns: ["owner_account_id"]
            isOneToOne: false
            referencedRelation: "customer_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_accounts: {
        Row: {
          created_at: string
          email: string
          failed_attempts: number
          id: string
          locked_until: string | null
          password_hash: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          failed_attempts?: number
          id?: string
          locked_until?: string | null
          password_hash: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          failed_attempts?: number
          id?: string
          locked_until?: string | null
          password_hash?: string
          updated_at?: string
        }
        Relationships: []
      }
      customer_sessions: {
        Row: {
          account_id: string
          created_at: string
          expires_at: string
          id: string
          token_hash: string
        }
        Insert: {
          account_id: string
          created_at?: string
          expires_at: string
          id?: string
          token_hash: string
        }
        Update: {
          account_id?: string
          created_at?: string
          expires_at?: string
          id?: string
          token_hash?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_sessions_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "customer_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      demo_codes: {
        Row: {
          code_hash: string
          created_at: string
          email: string
          expires_at: string
          failed_attempts: number
          id: string
          payload: Json
          used_at: string | null
        }
        Insert: {
          code_hash: string
          created_at?: string
          email: string
          expires_at: string
          failed_attempts?: number
          id?: string
          payload: Json
          used_at?: string | null
        }
        Update: {
          code_hash?: string
          created_at?: string
          email?: string
          expires_at?: string
          failed_attempts?: number
          id?: string
          payload?: Json
          used_at?: string | null
        }
        Relationships: []
      }
      demo_requests: {
        Row: {
          company_name: string
          created_at: string
          delivered_at: string | null
          delivery_error: string | null
          email: string
          first_name: string
          id: string
          last_name: string | null
          phone: string
          repeat_of: string | null
          sms_consent: boolean
          source: string
          website: string
        }
        Insert: {
          company_name: string
          created_at?: string
          delivered_at?: string | null
          delivery_error?: string | null
          email: string
          first_name: string
          id?: string
          last_name?: string | null
          phone: string
          repeat_of?: string | null
          sms_consent?: boolean
          source?: string
          website: string
        }
        Update: {
          company_name?: string
          created_at?: string
          delivered_at?: string | null
          delivery_error?: string | null
          email?: string
          first_name?: string
          id?: string
          last_name?: string | null
          phone?: string
          repeat_of?: string | null
          sms_consent?: boolean
          source?: string
          website?: string
        }
        Relationships: [
          {
            foreignKeyName: "demo_requests_repeat_of_fkey"
            columns: ["repeat_of"]
            isOneToOne: false
            referencedRelation: "demo_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      follow_up_sends: {
        Row: {
          contact_id: string
          location_id: string
          sent_at: string | null
          started_at: string
          state: string
        }
        Insert: {
          contact_id: string
          location_id: string
          sent_at?: string | null
          started_at?: string
          state?: string
        }
        Update: {
          contact_id?: string
          location_id?: string
          sent_at?: string | null
          started_at?: string
          state?: string
        }
        Relationships: []
      }
      legal_signatures: {
        Row: {
          account_id: string | null
          agreed_sensitive_use: boolean
          agreed_terms: boolean
          created_at: string
          email: string
          full_name: string
          id: string
          ip_address: string | null
          signed_at: string
          terms_version: string
          user_agent: string | null
        }
        Insert: {
          account_id?: string | null
          agreed_sensitive_use: boolean
          agreed_terms: boolean
          created_at?: string
          email: string
          full_name: string
          id?: string
          ip_address?: string | null
          signed_at?: string
          terms_version: string
          user_agent?: string | null
        }
        Update: {
          account_id?: string | null
          agreed_sensitive_use?: boolean
          agreed_terms?: boolean
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          ip_address?: string | null
          signed_at?: string
          terms_version?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "legal_signatures_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "customer_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      linkbot_app_tokens: {
        Row: {
          access_token: string | null
          company_id: string
          expires_at: string | null
          refresh_token: string | null
          updated_at: string | null
        }
        Insert: {
          access_token?: string | null
          company_id: string
          expires_at?: string | null
          refresh_token?: string | null
          updated_at?: string | null
        }
        Update: {
          access_token?: string | null
          company_id?: string
          expires_at?: string | null
          refresh_token?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      linkbot_location_tokens: {
        Row: {
          access_token: string | null
          expires_at: string | null
          location_id: string
          updated_at: string | null
        }
        Insert: {
          access_token?: string | null
          expires_at?: string | null
          location_id: string
          updated_at?: string | null
        }
        Update: {
          access_token?: string | null
          expires_at?: string | null
          location_id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      my_links: {
        Row: {
          ai_summary: string | null
          button_name: string
          category: string | null
          created_at: string
          details: string
          extra_notes: string | null
          full_title: string
          ghl_location_id: string
          id: string
          is_main_website: boolean
          is_on: boolean
          price: string | null
          site_info: string | null
          site_info_failed: boolean
          site_info_read_at: string | null
          snapshot_blocked_at: string | null
          snapshot_captured_at: string | null
          snapshot_path: string | null
          snapshot_url_source: string | null
          type: string
          updated_at: string
          url: string
          who_its_for: string
        }
        Insert: {
          ai_summary?: string | null
          button_name: string
          category?: string | null
          created_at?: string
          details: string
          extra_notes?: string | null
          full_title: string
          ghl_location_id: string
          id?: string
          is_main_website?: boolean
          is_on?: boolean
          price?: string | null
          site_info?: string | null
          site_info_failed?: boolean
          site_info_read_at?: string | null
          snapshot_blocked_at?: string | null
          snapshot_captured_at?: string | null
          snapshot_path?: string | null
          snapshot_url_source?: string | null
          type?: string
          updated_at?: string
          url: string
          who_its_for: string
        }
        Update: {
          ai_summary?: string | null
          button_name?: string
          category?: string | null
          created_at?: string
          details?: string
          extra_notes?: string | null
          full_title?: string
          ghl_location_id?: string
          id?: string
          is_main_website?: boolean
          is_on?: boolean
          price?: string | null
          site_info?: string | null
          site_info_failed?: boolean
          site_info_read_at?: string | null
          snapshot_blocked_at?: string | null
          snapshot_captured_at?: string | null
          snapshot_path?: string | null
          snapshot_url_source?: string | null
          type?: string
          updated_at?: string
          url?: string
          who_its_for?: string
        }
        Relationships: []
      }
      my_links_devices: {
        Row: {
          account_id: string | null
          created_at: string
          credential_version: string
          expires_at: string
          ghl_location_id: string
          id: string
          revoked_at: string | null
          token_hash: string
        }
        Insert: {
          account_id?: string | null
          created_at?: string
          credential_version: string
          expires_at: string
          ghl_location_id: string
          id?: string
          revoked_at?: string | null
          token_hash: string
        }
        Update: {
          account_id?: string | null
          created_at?: string
          credential_version?: string
          expires_at?: string
          ghl_location_id?: string
          id?: string
          revoked_at?: string | null
          token_hash?: string
        }
        Relationships: [
          {
            foreignKeyName: "my_links_devices_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "customer_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      my_links_settings: {
        Row: {
          business_info: string | null
          business_info_sent_at: string | null
          ghl_location_id: string
          setup_guide_seen_at: string | null
          website_prompt_shown_at: string | null
        }
        Insert: {
          business_info?: string | null
          business_info_sent_at?: string | null
          ghl_location_id: string
          setup_guide_seen_at?: string | null
          website_prompt_shown_at?: string | null
        }
        Update: {
          business_info?: string | null
          business_info_sent_at?: string | null
          ghl_location_id?: string
          setup_guide_seen_at?: string | null
          website_prompt_shown_at?: string | null
        }
        Relationships: []
      }
      password_resets: {
        Row: {
          account_id: string
          attempts: number
          code_hash: string
          created_at: string
          expires_at: string
          id: string
          type: string
          used_at: string | null
        }
        Insert: {
          account_id: string
          attempts?: number
          code_hash: string
          created_at?: string
          expires_at: string
          id?: string
          type?: string
          used_at?: string | null
        }
        Update: {
          account_id?: string
          attempts?: number
          code_hash?: string
          created_at?: string
          expires_at?: string
          id?: string
          type?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "password_resets_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "customer_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      retired_link_codes: {
        Row: {
          link_code: string
          retired_at: string
        }
        Insert: {
          link_code: string
          retired_at?: string
        }
        Update: {
          link_code?: string
          retired_at?: string
        }
        Relationships: []
      }
      security_audit_log: {
        Row: {
          created_at: string
          details: Json
          event_type: string
          id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          details?: Json
          event_type: string
          id?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          details?: Json
          event_type?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      snapshot_usage: {
        Row: {
          month: string
          requests: number
        }
        Insert: {
          month: string
          requests?: number
        }
        Update: {
          month?: string
          requests?: number
        }
        Relationships: []
      }
      widget_page_hits: {
        Row: {
          created_at: string
          hits: number
          ip_hash: string
          updated_at: string
          window_start: string
        }
        Insert: {
          created_at?: string
          hits?: number
          ip_hash: string
          updated_at?: string
          window_start: string
        }
        Update: {
          created_at?: string
          hits?: number
          ip_hash?: string
          updated_at?: string
          window_start?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      business_website_match_key: { Args: { value: string }; Returns: string }
      claim_account_is_leftover: {
        Args: { p_account_id: string }
        Returns: boolean
      }
      cleanup_call_share_debug: { Args: never; Returns: undefined }
      daily_auth_cleanup: { Args: never; Returns: Json }
      find_recent_demo_request: {
        Args: { p_email: string; p_since: string; p_website: string }
        Returns: {
          id: string
          repeat_of: string
        }[]
      }
      generate_link_code: { Args: never; Returns: string }
      linkbot_claim_token_refresh: {
        Args: { p_claim: string; p_company_id: string; p_version: string }
        Returns: boolean
      }
      match_call_shares: {
        Args: { p_account: string; p_ids: string[] }
        Returns: {
          button_name: string
          link_id: string
        }[]
      }
      my_links_url_key: { Args: { raw_url: string }; Returns: string }
      my_links_website_host: { Args: { raw_url: string }; Returns: string }
      new_bot_link_code: { Args: { p_bot_id: string }; Returns: Json }
      register_demo_code_attempt: {
        Args: { p_id: string; p_max?: number }
        Returns: number
      }
      register_failed_login: {
        Args: { p_account_id: string; p_lock_minutes: number; p_max: number }
        Returns: string
      }
      register_widget_page_hit: {
        Args: { p_ip_hash: string; p_limit?: number }
        Returns: Json
      }
      release_expired_holds: { Args: { p_slug?: string }; Returns: number }
      remove_leftover_accounts: {
        Args: { p_account_id?: string }
        Returns: number
      }
      rename_bot_slug: {
        Args: { p_bot_id: string; p_new_slug: string }
        Returns: Json
      }
      reserve_client_slug: {
        Args: {
          p_company?: string
          p_domains?: string[]
          p_email: string
          p_full_name?: string
          p_last_name?: string
          p_owner_account_id?: string
          p_phone?: string
          p_slug: string
          p_website?: string
        }
        Returns: Json
      }
      take_snapshot_request: { Args: { p_limit?: number }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
