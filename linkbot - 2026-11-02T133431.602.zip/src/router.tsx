import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import { scrollToTopSettled } from "./lib/scroll-top";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    // Prompt 138: never reopen a page at a remembered position.
    scrollRestoration: false,
    defaultPreloadStaleTime: 0,
  });

  if (typeof window !== "undefined") {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";
    router.subscribe("onResolved", (event) => {
      if (event.pathChanged) scrollToTopSettled();
    });
  }

  return router;
};
