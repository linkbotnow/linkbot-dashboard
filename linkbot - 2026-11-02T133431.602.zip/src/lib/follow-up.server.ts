import { z } from 'zod';
import { checkAccess, handleMyLinks } from './my-links.server';
import { getLocationToken } from './linkbot/app.server';
import { completeEmail, contactField, emailHtml, followUpMessage, sameLocation } from './follow-up-rules';

const base = 'https://services.leadconnectorhq.com';
const identity = z.object({ account: z.string().min(1).max(255).regex(/^[a-zA-Z0-9_-]+$/), contact: z.string().min(1).max(255).regex(/^[a-zA-Z0-9_-]+$/) });
const inputSchema = identity.extend({ action: z.enum(['login', 'load', 'send', 'request_reset_code', 'reset_with_code']), password: z.string().max(128).optional(), token: z.string().max(2000).optional(), subject: z.string().max(1000).optional(), message: z.string().max(100000).optional(), email: z.string().max(255).optional(), code: z.string().max(12).optional(), new_password: z.string().max(128).optional() });
const contactSchema = z.object({ contact: z.object({ id: z.string(), locationId: z.string(), firstName: z.string().nullish(), lastName: z.string().nullish(), email: z.string().nullish(), customFields: z.array(z.object({ id: z.string().optional(), key: z.string().optional(), fieldKey: z.string().optional(), value: z.unknown().optional(), fieldValue: z.unknown().optional() })).optional() }) });
async function db() { return (await import('@/integrations/supabase/client.server')).supabaseAdmin; }
export async function followUpBot(account: string) {
  if (!identity.shape.account.safeParse(account).success) return null;
  const database = await db();
  const { data, error } = await database.from('client_slugs').select('full_name').eq('ghl_location_id', account).order('created_at', { ascending: true }).limit(1);
  if (error) throw new Error('Follow-up bot lookup failed');
  return data?.[0] ?? null;
}
export function validFollowUpQuery(url: URL) { return identity.safeParse(Object.fromEntries(url.searchParams)); }
class ProviderError extends Error {
  constructor(readonly stage: string, readonly status?: number) { super('GoHighLevel request failed'); }
}
async function ghl(token: string, path: string, init?: RequestInit) {
  const response = await fetch(`${base}${path}`, { ...init, headers: { Authorization: `Bearer ${token}`, Version: '2021-07-28', 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new ProviderError(path.startsWith('/contacts/') ? 'contact' : path.startsWith('/locations/') ? 'custom fields' : 'send', response.status);
  return response;
}
export async function handleFollowUp(request: Request) {
  const reply = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store', 'x-robots-tag': 'noindex, nofollow' } });
  try {
    const raw = await request.text();
    if (raw.length > 120000) return reply({ error: 'Invalid request' }, 400);
    const input = inputSchema.parse(JSON.parse(raw));
    const bot = await followUpBot(input.account);
    if (!bot) return reply({ invalid: true }, 404);
    if (input.action === 'login') {
      // Reuse the existing verifier, account lockout, alerts and token without modifying My Links.
      return handleMyLinks(new Request(request.url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'login', loc: input.account, password: input.password ?? '' }) }));
    }
    if (input.action === 'request_reset_code' || input.action === 'reset_with_code') {
      // Same in-box reset codes as My Links, scoped to this page's account.
      return handleMyLinks(new Request(request.url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: input.action, loc: input.account, email: input.email, code: input.code, new_password: input.new_password }) }));
    }
    if (!input.token || !checkAccess(input.token, input.account)) return reply({ error: 'Please enter your password again.' }, 401);
    const token = await getLocationToken(input.account);
    if (!token) throw new ProviderError('location token');
    let response: Response;
    try { response = await ghl(token, `/contacts/${encodeURIComponent(input.contact)}`); }
    catch (error) { if (error instanceof ProviderError && error.status === 404) return reply({ invalid: true }, 404); throw error; }
    const { contact } = contactSchema.parse(await response.json());
    if (contact.id !== input.contact || !sameLocation(contact, input.account)) return reply({ invalid: true }, 404);
    const database = await db();
    const { data: record, error: readError } = await database.from('follow_up_sends').select('state,sent_at').eq('location_id', input.account).eq('contact_id', input.contact).maybeSingle();
    if (readError) throw new Error('Follow-up send lookup failed');
    const recipient = { firstName: contact.firstName ?? '', lastName: contact.lastName ?? '', email: contact.email ?? '' };
    if (record?.state === 'sent') return reply({ alreadySent: true, recipient });
    if (input.action === 'load') {
      const fields = contact.customFields ?? [];
      const needed = ['linkbot_follow_up_subject', 'linkbot_follow_up_draft'];
      let definitions: { id: string; fieldKey: string }[] = [];
      if (needed.some(key => !fields.some(field => [field.key, field.fieldKey].includes(key) || [field.key, field.fieldKey].includes(`contact.${key}`)))) {
        const fieldsResponse = await ghl(token, `/locations/${encodeURIComponent(input.account)}/customFields?model=contact`);
        definitions = z.object({ customFields: z.array(z.object({ id: z.string(), fieldKey: z.string() })) }).parse(await fieldsResponse.json()).customFields;
      }
      return reply({ recipient, subject: contactField(fields, needed[0] ?? '', definitions), message: followUpMessage(contactField(fields, needed[1] ?? '', definitions), bot.full_name ?? '') });
    }
    if (!completeEmail(input.subject ?? '', input.message ?? '')) return reply({ error: 'Please add a subject and message.' }, 400);
    if (record) return reply({ error: "Couldn't send your email. Please try again." }, 409);
    const { error: reserveError } = await database.from('follow_up_sends').insert({ location_id: input.account, contact_id: input.contact });
    if (reserveError?.code === '23505') return reply({ error: "Couldn't send your email. Please try again." }, 409);
    if (reserveError) throw new Error('Follow-up reservation failed');
    try {
      await ghl(token, '/conversations/messages', { method: 'POST', body: JSON.stringify({ type: 'Email', contactId: input.contact, subject: input.subject, html: emailHtml(input.message ?? '') }) });
    } catch (error) {
      // A confirmed rejection can retry; an uncertain timeout must not risk emailing twice.
      if (error instanceof ProviderError) {
        const { error: releaseError } = await database.from('follow_up_sends').delete().eq('location_id', input.account).eq('contact_id', input.contact).eq('state', 'sending');
        if (releaseError) console.error('LinkBot follow-up reservation release failed');
      }
      throw error;
    }
    const { error: saveError } = await database.from('follow_up_sends').update({ state: 'sent', sent_at: new Date().toISOString() }).eq('location_id', input.account).eq('contact_id', input.contact).eq('state', 'sending');
    if (saveError) console.error('LinkBot follow-up delivery record failed');
    return reply({ sent: true, recipient });
  } catch (error) {
    if (error instanceof z.ZodError || error instanceof SyntaxError) return reply({ error: 'Invalid request' }, 400);
    console.error('LinkBot follow-up failed', error instanceof ProviderError ? error.stage : 'request', error instanceof ProviderError ? error.status ?? 'unavailable' : 'unavailable');
    return reply({ error: "Couldn't send your email. Please try again." }, 502);
  }
}