/**
 * Pausable timers for the hero demo loop. Only the upright phone homepage
 * flips the paused flag (while its hero is fully covered); everywhere else it
 * stays false, so these behave exactly like setTimeout/setInterval.
 */
type Entry = { fn: () => void; remaining: number; start: number; id: number | null };

let paused = false;
// Two independent reasons: the covered hero (setHeroPaused) and the 257 pinch
// light mode (setHeroZoomPaused). Timers run only when neither applies.
let coverPaused = false;
let zoomPaused = false;
const entries = new Set<Entry>();

const arm = (e: Entry) => {
  e.start = Date.now();
  e.id = window.setTimeout(() => {
    entries.delete(e);
    e.fn();
  }, e.remaining);
};

export function setHeroPaused(next: boolean) {
  coverPaused = next;
  applyPaused(coverPaused || zoomPaused);
}

export function setHeroZoomPaused(next: boolean) {
  zoomPaused = next;
  applyPaused(coverPaused || zoomPaused);
}

function applyPaused(next: boolean) {
  if (next === paused) return;
  paused = next;
  for (const e of entries) {
    if (paused) {
      if (e.id !== null) {
        window.clearTimeout(e.id);
        e.id = null;
        e.remaining = Math.max(0, e.remaining - (Date.now() - e.start));
      }
    } else if (e.id === null) {
      arm(e);
    }
  }
}

export function pausableTimeout(fn: () => void, ms: number): () => void {
  const e: Entry = { fn, remaining: ms, start: 0, id: null };
  entries.add(e);
  if (!paused) arm(e);
  return () => {
    if (e.id !== null) window.clearTimeout(e.id);
    entries.delete(e);
  };
}

export function pausableInterval(fn: () => void, ms: number): () => void {
  let cancel = () => {};
  const tick = () => {
    cancel = pausableTimeout(tick, ms);
    fn();
  };
  cancel = pausableTimeout(tick, ms);
  return () => cancel();
}

/** 257: true while the touch homepage is in pinch light mode. */
export function isHeroZoomPaused() {
  return zoomPaused;
}
