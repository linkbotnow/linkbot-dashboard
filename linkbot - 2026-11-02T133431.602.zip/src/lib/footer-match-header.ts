import { useLayoutEffect, type RefObject } from "react";
import { getDesktopScale, isPhoneLandscapeViewport } from "@/lib/desktop-scale";

/**
 * On-screen size of the homepage footer text at the current window, mirroring
 * the homepage: upright phones 11.2px; sideways phones 14px unscaled; otherwise
 * 16px below 1024 / 14px from 1024, on the page canvas scaled to width / 1440.
 */
function homeFooterTextPx() {
  if (isPhoneLandscapeViewport()) return 14;
  const vw = Math.max(1, document.documentElement.clientWidth);
  if (vw < 640) return 11.2;
  return (vw < 1024 ? 16 : 14) * getDesktopScale(vw);
}

/**
 * Non-homepage footers: makes the footer's on-screen height equal to the
 * on-screen header height and draws a top line matching the header line's
 * on-screen thickness (or none). Runs on mount, resize and rotation — never on scroll.
 */
export function useFooterMatchHeader(
  footerRef: RefObject<HTMLElement | null>,
  lineColor: string | null,
  deps: unknown[] = [],
) {
  useLayoutEffect(() => {
    const footer = footerRef.current;
    if (!footer) return;

    const findHeader = () =>
      Array.from(document.querySelectorAll<HTMLElement>(".desktop-header-frame, header")).find((el) => {
        if (footer.contains(el)) return false;
        const r = el.getBoundingClientRect();
        return r.height > 0 && r.width > 0 && getComputedStyle(el).position === "fixed";
      }) ??
      Array.from(document.querySelectorAll<HTMLElement>("header")).find(
        (el) => !footer.contains(el) && el.getBoundingClientRect().height > 0,
      );

    const lineVisual = (header: HTMLElement) => {
      for (const el of [header, ...Array.from(header.querySelectorAll<HTMLElement>("*"))]) {
        const w = parseFloat(getComputedStyle(el).borderBottomWidth);
        if (w > 0) {
          const k = el.offsetHeight > 0 ? el.getBoundingClientRect().height / el.offsetHeight : 1;
          return w * k;
        }
      }
      return 1;
    };

    const set = (name: string, v: string) => {
      if (footer.style.getPropertyValue(name) !== v) footer.style.setProperty(name, v);
    };

    let good = ""; // last footer height that looked right
    const apply = () => {
      const header = findHeader();
      if (!header || footer.offsetHeight === 0) return;
      footer.classList.add("footer-match-header");
      set("--fm-color", lineColor ?? "transparent");
      let k = footer.getBoundingClientRect().height / footer.offsetHeight || 1;
      set("--fm-line", `${(lineColor ? lineVisual(header) / k : 0).toFixed(4)}px`);
      // Footer text: same on-screen size as the homepage footer text at this window.
      const p = footer.querySelector<HTMLElement>(":scope > p");
      if (p) {
        const fs = `${(homeFooterTextPx() / k).toFixed(4)}px`;
        if (p.style.getPropertyValue("font-size") !== fs) p.style.setProperty("font-size", fs, "important");
      }
      let h = parseFloat(footer.style.getPropertyValue("--fm-h")) || header.getBoundingClientRect().height / k;
      for (let i = 0; i < 5; i++) {
        set("--fm-h", `${h.toFixed(3)}px`);
        const fr = footer.getBoundingClientRect().height;
        if (footer.offsetHeight > 0) k = fr / footer.offsetHeight || k;
        const dH = header.getBoundingClientRect().height - fr;
        if (Math.abs(dH) < 0.02) break;
        h = Math.max(0, h + dH / k);
      }
      // Never keep a wild result (e.g. measured mid-scroll or mid-animation): go back to the last good height instead.
      const maxPx = Math.max(600, (header.getBoundingClientRect().height / k) * 6);
      const cur = parseFloat(footer.style.getPropertyValue("--fm-h"));
      if (![h, cur].every((v) => Number.isFinite(v) && v >= 0 && v <= maxPx)) {
        if (good) set("--fm-h", good);
        else { footer.classList.remove("footer-match-header"); footer.style.removeProperty("--fm-h"); }
        return;
      }
      good = footer.style.getPropertyValue("--fm-h");
    };

    apply();
    // Re-fit ONLY for real changes: the window gets wider or narrower, the phone is turned, the page finishes loading,
    // or the fonts finish loading. Never on a timer, never on scroll, never for a sliding address bar or pinch-zoom.
    let lastW = window.innerWidth;
    const refit = () => {
      if ((window.visualViewport?.scale ?? 1) <= 1.01) apply();
    };
    const onResize = () => {
      const w = window.innerWidth;
      if (w === lastW) return;
      lastW = w;
      refit();
    };
    const onTurn = () => {
      lastW = -1;
      window.setTimeout(onResize, 250);
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onTurn);
    if (document.readyState !== "complete") window.addEventListener("load", refit, { once: true });
    document.fonts?.ready.then(refit).catch(() => {});
    document.fonts?.addEventListener?.("loadingdone", refit);
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onTurn);
      window.removeEventListener("load", refit);
      document.fonts?.removeEventListener?.("loadingdone", refit);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [footerRef, lineColor, ...deps]);
}
