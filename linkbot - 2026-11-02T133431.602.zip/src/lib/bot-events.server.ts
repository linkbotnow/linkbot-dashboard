/**
 * Server-only helpers for GoHighLevel bot updates: owner alerts and the one-time links send.
 * Unset webhook addresses are logged and skipped so no page or webhook ever breaks.
 */
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const SITE = "https://linkbot.now";

export function secretMatches(provided: string, expected: string): boolean {
  if (!provided || provided.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < provided.length; i++) diff |= provided.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

export async function sendAlert(event: string, details: { email?: string | null; botId?: string | null; message: string }) {
  const url = process.env["GHL_ALERT_WEBHOOK_URL"];
  const body = { event, email: details.email ?? "", botId: details.botId ?? "", message: details.message, at: new Date().toISOString() };
  if (!url) {
    console.warn("[bot-alert] GHL_ALERT_WEBHOOK_URL not set", body);
    return;
  }
  try {
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    if (!res.ok) console.error("[bot-alert] alert not accepted", res.status, event);
  } catch (err) {
    console.error("[bot-alert] alert failed", event, err);
  }
}

/** Sends a bot's links once, only when it is active and has a widget ID. */
export async function sendLinksIfReady(botId: string): Promise<void> {
  // Claim the send first so two simultaneous updates cannot both send.
  const { data: row } = await supabaseAdmin
    .from("client_slugs")
    .update({ links_sent_at: new Date().toISOString() })
    .eq("id", botId)
    .eq("status", "active")
    .not("ghl_widget_id", "is", null)
    .not("link_code", "is", null)
    .is("links_sent_at", null)
    .select("id, email, slug, link_code, full_name, last_name, phone, ghl_location_id")
    .maybeSingle();
  if (!row) return;

  const release = () => supabaseAdmin.from("client_slugs").update({ links_sent_at: null }).eq("id", row.id);
  const url = process.env["GHL_LINKS_WEBHOOK_URL"];
  if (!url) {
    console.warn("[bot-links] GHL_LINKS_WEBHOOK_URL not set; links will send once it is", { botId: row.id });
    await release();
    return;
  }
  if (!row.ghl_location_id) console.warn("[bot-links] no stored location ID; sending welcome links with empty locationId", { botId: row.id });
  const payload = { email: row.email, botId: row.id, nameLink: `${SITE}/${row.slug}`, realLink: `${SITE}/${row.link_code}`, firstName: row.full_name ?? "", lastName: row.last_name ?? "", phone: row.phone ?? "", locationId: row.ghl_location_id ?? "" };
  let problem = "";
  try {
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    if (!res.ok) problem = `GoHighLevel answered ${res.status}`;
  } catch {
    problem = "GoHighLevel could not be reached";
  }
  if (problem) {
    await release();
    await sendAlert("links_send_failed", { email: row.email, botId: row.id, message: `Sending this bot's links failed: ${problem}.` });
  }
}

/** A link change sends an update only; it never claims or releases the welcome marker. */
export async function sendLinkUpdate(botId: string, reason: "domain_change" | "new_link"): Promise<void> {
  let email = "";
  let problem = "";
  try {
    const { data: row, error } = await supabaseAdmin.from("client_slugs")
      .select("id, email, slug, link_code, full_name, last_name").eq("id", botId).maybeSingle();
    if (error || !row || !row.link_code) throw new Error("Link details unavailable");
    email = row.email ?? "";
    const url = process.env["GHL_LINK_UPDATE_WEBHOOK_URL"];
    if (!url) problem = "GHL_LINK_UPDATE_WEBHOOK_URL not set";
    else {
      const payload = { email, botId: row.id, firstName: row.full_name ?? "", lastName: row.last_name ?? "", nameLink: `${SITE}/${row.slug}`, realLink: `${SITE}/${row.link_code}`, reason };
      const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload), signal: AbortSignal.timeout(10000) });
      if (!res.ok) problem = `GoHighLevel answered ${res.status}`;
    }
  } catch { problem = "Link update could not be delivered"; }
  if (problem) {
    console.warn("[bot-link-update]", problem, { botId, reason });
    try { await sendAlert("link_update_send_failed", { email, botId, message: `Sending this bot's link update failed: ${problem}.` }); }
    catch { console.error("[bot-link-update] alert failed", { botId, reason }); }
  }
}
