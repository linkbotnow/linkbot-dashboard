/** Standalone /legal page: the Legal Terms as a clean document (no header or footer), same dropdown. */
import { LEGAL_SECTIONS } from "@/lib/legal-terms";

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export function legalPage(): Response {
  const links = LEGAL_SECTIONS.map((s) => `<li><button type="button" data-go="${s.id}">${esc(s.label)}</button></li>`).join("");
  const sections = LEGAL_SECTIONS.map(
    (s) =>
      `<section id="${s.id}"><h2>${esc(s.title)}</h2>${s.items
        .map((i) => `<p><strong>${i.n}. ${esc(i.heading)}.</strong> ${esc(i.text)}</p>`)
        .join("")}</section>`,
  ).join("");
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Legal Terms | LinkBot.Now</title>
<meta name="description" content="LinkBot.Now Legal Terms: Terms of Service, Privacy Policy, Refund Policy, AI Disclosure and General terms.">
<meta property="og:title" content="Legal Terms | LinkBot.Now">
<meta property="og:description" content="LinkBot.Now Terms of Service, Privacy Policy, Refund Policy and AI Disclosure.">
<meta property="og:type" content="website"><meta name="twitter:card" content="summary">
<link rel="icon" href="/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap">
<style>
html{--legal-document-ink:#000000;--legal-section-blue:oklch(0.52 0.24 264);background:#f3f4f6;scroll-behavior:smooth}body{margin:0;color:var(--legal-document-ink);font:400 16px/1.75 Inter,ui-sans-serif,system-ui,sans-serif}
.card{--px:clamp(20px,6vw,64px);--g:24px;max-width:816px;margin:32px auto;background:#fff;border:1px solid #e5e7eb;border-radius:16px;box-shadow:0 1px 2px rgba(15,23,42,.04),0 24px 60px -24px rgba(15,23,42,.35)}
header{position:sticky;top:0;z-index:2;display:grid;grid-template-columns:1fr auto 1fr;align-items:center;height:68px;box-sizing:border-box;padding:0 16px;background:#fff;border-bottom:1px solid #e5e7eb;border-radius:16px 16px 0 0}
h1{text-align:center;margin:0;font:700 22px/1.25 Inter,ui-sans-serif,system-ui,sans-serif;color:#111827;white-space:nowrap}
.mb{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:999px;border:1px solid #e5e7eb;background:#fff;color:#374151;cursor:pointer;padding:0}
.mw{position:relative;justify-self:end}.ml{display:none;position:absolute;top:calc(100% + 8px);right:0;min-width:200px;margin:0;padding:6px;list-style:none;background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 12px 32px -12px rgba(15,23,42,.3)}
.mw.o .ml{display:block}.ml button,.c button{appearance:none;border:0;background:none;margin:0;cursor:pointer}.ml button{width:100%;text-align:left}.ml button{display:block;padding:10px 12px;border-radius:8px;font:600 14px/1.2 Inter,ui-sans-serif,system-ui,sans-serif;color:#111827;text-decoration:none}.ml button:hover{background:#f3f4f6}
main{padding:40px var(--px)}
section{scroll-margin-top:92px}section+section{padding-top:var(--g);border-top:1px solid rgba(17,24,39,.06)}
h2{margin:0 0 var(--g);font:800 15px/1.3 Inter,ui-sans-serif,system-ui,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:var(--legal-section-blue)}
p{margin:0 0 var(--g)}strong{font-weight:700;color:var(--legal-document-ink)}main section:last-child p:last-child{margin-bottom:0}
footer{height:68px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;padding:0 var(--px);border-top:1px solid rgba(17,24,39,.06);text-align:center}
.c{display:inline-block;margin:0;white-space:nowrap;font:400 14px/1.5 Inter,ui-sans-serif,system-ui,sans-serif;color:#374151}.c button{padding:0;font:inherit;font-weight:700;color:oklch(0.52 0.24 264);text-decoration:none}
@media(max-width:640px){html{background:#fff}.card{--px:20px;margin:0;border:0;border-radius:0;box-shadow:none}header{border-radius:0;height:60px;padding:0 12px}footer{height:60px}main{padding:24px var(--px)}}
</style></head><body><div class="card"><header><span></span><h1>LinkBot.Now Legal Terms</h1>
<div class="mw" id="mw"><button class="mb" type="button" aria-label="Sections" onclick="document.getElementById('mw').classList.toggle('o')"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button><ul class="ml">${links}</ul></div></header><main>
${sections}
</main><footer><p class="c" id="c">Questions regarding Legal Terms may be directed to <button type="button" onclick="location.href='mailto:support@linkbot.now'">support@linkbot.now</button>.</p></footer>
<script>(function(){var w=document.getElementById('mw');document.addEventListener('click',function(e){if(!w.contains(e.target))w.classList.remove('o')});w.querySelectorAll('button[data-go]').forEach(function(a){a.addEventListener('click',function(){w.classList.remove('o');var t=document.getElementById(a.getAttribute('data-go'));if(t){t.scrollIntoView({behavior:'smooth'});history.replaceState(null,'','#'+t.id);}})});var c=document.getElementById('c');function f(){c.style.fontSize='14px';var m=c.parentNode.clientWidth-parseFloat(getComputedStyle(c.parentNode).paddingLeft)*2;if(c.scrollWidth>m)c.style.fontSize=(14*m/c.scrollWidth)+'px'}f();addEventListener('resize',f);document.fonts&&document.fonts.ready.then(f)})()</script>
</div></body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
}

export function legalRedirect(section: string): Response {
  return new Response(null, { status: 302, headers: { location: `/legal#${section}` } });
}
