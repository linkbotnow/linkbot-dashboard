BEGIN;
DO $$
DECLARE bot_id uuid := gen_random_uuid(); original_code text := public.generate_link_code(); original_marker timestamptz := '2026-10-01T00:00:00Z'; result jsonb; marker timestamptz;
BEGIN
 INSERT INTO public.client_slugs(id,email,slug,status,activated_at,link_code,links_sent_at)
 VALUES(bot_id,'marker-regression@example.invalid','marker-'||substr(bot_id::text,1,8),'active',now(),original_code,original_marker);
 result := public.rename_bot_slug(bot_id,'renamed-'||substr(bot_id::text,1,8));
 IF result->>'changed' <> 'true' THEN RAISE EXCEPTION 'rename did not succeed'; END IF;
 SELECT links_sent_at INTO marker FROM public.client_slugs WHERE id=bot_id;
 IF marker IS DISTINCT FROM original_marker THEN RAISE EXCEPTION 'rename reset welcome marker'; END IF;
 result := public.new_bot_link_code(bot_id);
 IF result->>'changed' <> 'true' OR result->>'link_code'=original_code THEN RAISE EXCEPTION 'new code did not succeed'; END IF;
 SELECT links_sent_at INTO marker FROM public.client_slugs WHERE id=bot_id;
 IF marker IS DISTINCT FROM original_marker THEN RAISE EXCEPTION 'new code reset welcome marker'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.retired_link_codes WHERE link_code=original_code) THEN RAISE EXCEPTION 'old code not retired'; END IF;
END $$;
ROLLBACK;