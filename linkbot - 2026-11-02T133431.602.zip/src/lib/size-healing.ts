/** Width recovery only; existing layout functions retain their own guards. */
export function attachSizeHealing(isSizeWrong: () => boolean, fix: () => void) {
  const pointer = window.matchMedia("(pointer: fine) and (hover: hover)");
  // Touch devices get no listeners, timers, or measurements from this helper.
  if (!pointer.matches) return () => {};
  const desktop = window.matchMedia("(pointer: fine) and (hover: hover) and (min-width: 1024px)");
  const isDesktop = () => pointer.matches && desktop.matches && document.documentElement.clientWidth >= 1024;
  let detach = () => {};
  const activate = () => {
    detach();
    detach = () => {};
    if (!isDesktop()) return;
    let interval = 0;
    let resolution: MediaQueryList | undefined;
    const check = () => {
      if (!isDesktop() || document.visibilityState !== "visible" || (window.visualViewport?.scale ?? 1) !== 1) return;
      if (isSizeWrong()) fix();
    };
    const visibility = () => {
      window.clearInterval(interval);
      interval = 0;
      if (!isDesktop() || document.visibilityState !== "visible") return;
      check();
      interval = window.setInterval(check, 1000);
    };
    const watchResolution = () => {
      resolution?.removeEventListener("change", resolutionChanged);
      if (!isDesktop()) return;
      resolution = window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`);
      resolution.addEventListener("change", resolutionChanged);
    };
    const resolutionChanged = () => { check(); watchResolution(); };
    const windowEvents = ["focus", "pageshow"];
    const documentEvents = ["fullscreenchange", "webkitfullscreenchange"];
    windowEvents.forEach(event => window.addEventListener(event, check));
    documentEvents.forEach(event => document.addEventListener(event, check));
    document.addEventListener("visibilitychange", visibility);
    window.visualViewport?.addEventListener("resize", check);
    watchResolution();
    visibility();
    detach = () => {
      window.clearInterval(interval);
      resolution?.removeEventListener("change", resolutionChanged);
      windowEvents.forEach(event => window.removeEventListener(event, check));
      documentEvents.forEach(event => document.removeEventListener(event, check));
      document.removeEventListener("visibilitychange", visibility);
      window.visualViewport?.removeEventListener("resize", check);
    };
  };
  // Only desktop-capable pointers watch eligibility; narrow windows have no
  // active recovery listeners or timer until the authored breakpoint returns.
  desktop.addEventListener("change", activate);
  activate();
  return () => { desktop.removeEventListener("change", activate); detach(); };
}