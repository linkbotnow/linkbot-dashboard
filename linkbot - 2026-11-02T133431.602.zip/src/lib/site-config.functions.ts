import { createServerFn } from "@tanstack/react-start";

/** Public homepage settings. Only the live demo address is read here. */
export const getCheckoutConfig = createServerFn({ method: "GET" }).handler(async () => {
  const raw = process.env["GHL_DEMO_PUBLIC_URL"];
  const demoPublicUrl = raw && raw.trim().length > 0 ? raw.trim() : null;
  return { demoPublicUrl };
});
