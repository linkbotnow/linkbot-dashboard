// Prompt 138: a new page or full-page step always opens at the very top.
// Re-pins the top for a short settle window (late layout/height changes can
// otherwise leave the page partway down) and stops as soon as the user
// scrolls on purpose.
import { useLayoutEffect, useRef } from "react";

let cancel: (() => void) | null = null;

export function scrollToTopSettled() {
  if (typeof window === "undefined") return;
  cancel?.();
  let stopped = false;
  const timers: number[] = [];
  const top = () => {
    if (stopped) return;
    if (window.scrollX !== 0 || window.scrollY !== 0) window.scrollTo(0, 0);
    document.scrollingElement?.scrollTo?.(0, 0);
  };
  const stop = () => {
    stopped = true;
    timers.forEach((t) => window.clearTimeout(t));
    window.removeEventListener("wheel", stop);
    window.removeEventListener("touchstart", stop);
    window.removeEventListener("keydown", stop);
    if (cancel === stop) cancel = null;
  };
  cancel = stop;
  window.addEventListener("wheel", stop, { passive: true });
  window.addEventListener("touchstart", stop, { passive: true });
  window.addEventListener("keydown", stop);
  top();
  requestAnimationFrame(() => {
    top();
    requestAnimationFrame(top);
  });
  for (const d of [50, 150, 300, 600, 1000]) timers.push(window.setTimeout(top, d));
  timers.push(window.setTimeout(stop, 1050));
}

/** Homepage demo transitions only. Leave ordinary route scrolling unchanged. */
export function pinDemoViewToTop() {
  cancel?.();
  const active = document.activeElement;
  if (active instanceof HTMLElement && active !== document.body) active.blur();
  let stopped = false;
  let frame = 0;
  let showing = false;
  let touch: { id: number; x: number; y: number } | undefined;
  const started = performance.now();
  let stableSince = started;
  let last = "";
  const top = () => {
    if (window.scrollX !== 0 || window.scrollY !== 0) window.scrollTo({ left: 0, top: 0, behavior: "instant" });
    document.scrollingElement?.scrollTo({ left: 0, top: 0, behavior: "instant" });
  };
  const stop = () => {
    stopped = true;
    cancelAnimationFrame(frame);
    window.removeEventListener("wheel", wheel);
    window.removeEventListener("touchstart", touchStart);
    window.removeEventListener("touchmove", touchMove);
    window.removeEventListener("touchend", touchEnd);
    window.removeEventListener("touchcancel", touchEnd);
    window.removeEventListener("keydown", key);
    window.removeEventListener("focusin", focusIn, true);
    window.removeEventListener("mousedown", press, true);
    window.removeEventListener("pointerdown", press, true);
    if (cancel === stop) cancel = null;
  };
  const wheel = (event: WheelEvent) => {
    if (showing && event.isTrusted && !event.ctrlKey && (event.deltaX !== 0 || event.deltaY !== 0)) stop();
  };
  const touchStart = (event: TouchEvent) => {
    // 194: a two-finger touch (pinch zoom) ends the pin at once; no reset during the pinch.
    if (event.isTrusted && event.touches.length >= 2) { stop(); return; }
    // Never adopt a finger already down during the opening tap.
    const finger = event.touches.length === 1 ? event.touches[0] : undefined;
    touch = showing && event.isTrusted && finger ? { id: finger.identifier, x: finger.clientX, y: finger.clientY } : undefined;
  };
  const touchMove = (event: TouchEvent) => {
    if (!touch || event.touches.length !== 1 || !event.isTrusted) return;
    const finger = event.touches[0];
    if (finger && finger.identifier === touch.id && Math.hypot(finger.clientX - touch.x, finger.clientY - touch.y) > 8) stop();
  };
  const touchEnd = () => { touch = undefined; };
  const key = (event: KeyboardEvent) => {
    const target = event.target;
    if (target instanceof HTMLElement && (target.closest("input, textarea, select, button, [contenteditable=true]") || target.isContentEditable)) return;
    if (showing && event.isTrusted && ["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Home", "End", " "].includes(event.key)) stop();
  };
  // 194: focusing a demo form field ends the pin.
  const focusIn = (event: FocusEvent) => {
    const target = event.target;
    if (target instanceof HTMLElement && target.matches("input, textarea, select") && target.closest("form, .demo-form-focus")) stop();
  };
  // 194: any real press after the view is showing (including scrollbar drags) ends the pin.
  const press = (event: Event) => {
    if (showing && event.isTrusted) stop();
  };
  const tick = () => {
    if (stopped) return;
    top();
    const section = document.querySelector(".demo-form-focus-hero, .mh-layer-hero");
    const nodes = [section, ...document.querySelectorAll(".demo-form-focus input, .demo-form-footer, .hero-main-composition, .slide-three-hero-inner, .desktop-scale-frame, .desktop-header-spacer")];
    const signature = nodes.map((node) => {
      if (!node) return "-";
      const rect = node.getBoundingClientRect();
      return `${rect.top.toFixed(2)},${rect.width.toFixed(2)},${rect.height.toFixed(2)}`;
    }).join("|") + `|${document.documentElement.scrollHeight}`;
    if (signature !== last) stableSince = performance.now();
    last = signature;
    const assetsReady = (!document.fonts || document.fonts.status === "loaded") &&
      [...(section?.querySelectorAll("img") ?? [])].every((image) => image.complete);
    // Existing desktop/iPad fits have a final 2600ms checkpoint. Wait beyond
    // that checkpoint AND for stable committed geometry, fonts and images.
    if (assetsReady && performance.now() - started >= 2600 + 200 && performance.now() - stableSince >= 200) {
      stop();
      return;
    }
    showing = true;
    frame = requestAnimationFrame(tick);
  };
  cancel = stop;
  window.addEventListener("wheel", wheel, { passive: true });
  window.addEventListener("touchstart", touchStart, { passive: true });
  window.addEventListener("touchmove", touchMove, { passive: true });
  window.addEventListener("touchend", touchEnd, { passive: true });
  window.addEventListener("touchcancel", touchEnd, { passive: true });
  window.addEventListener("keydown", key);
  window.addEventListener("focusin", focusIn, true);
  window.addEventListener("mousedown", press, true);
  window.addEventListener("pointerdown", press, true);
  top();
  frame = requestAnimationFrame(tick);
  return stop;
}

export function useDemoViewTop(view: "hero" | "form" | "call") {
  const previous = useRef(view);
  useLayoutEffect(() => {
    if (previous.current === view) return;
    previous.current = view;
    return pinDemoViewToTop();
  }, [view]);
}
