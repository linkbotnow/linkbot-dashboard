// Keeps marked message lines on one line: shrinks font-size just enough to fit.
// Shared by React pages (useFitLine) and plain HTML pages (FIT_LINE_SCRIPT).
import { useLayoutEffect, useRef } from "react";

export function fitLine(el: HTMLElement) {
  el.style.whiteSpace = "nowrap";
  el.style.maxWidth = "100%";
  if (el.dataset["fitBase"] === undefined) el.dataset["fitBase"] = el.style.fontSize;
  el.style.fontSize = el.dataset["fitBase"];
  const base = parseFloat(getComputedStyle(el).fontSize);
  const need = el.scrollWidth;
  const have = el.clientWidth;
  if (need <= have || have <= 0) return;
  let size = Math.floor(((base * have) / need) * 100) / 100;
  el.style.fontSize = `${size}px`;
  for (let i = 0; i < 20 && el.scrollWidth > el.clientWidth; i++) el.style.fontSize = `${(size *= 0.98)}px`;
}

export function useFitLine<T extends HTMLElement>(deps: unknown[] = []) {
  const ref = useRef<T>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const run = () => fitLine(el);
    run();
    const ro = new ResizeObserver(run);
    if (el.parentElement) ro.observe(el.parentElement);
    void document.fonts?.ready.then(run);
    window.addEventListener("resize", run);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", run);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return ref;
}

/** Inline script for server-rendered pages: fits every [data-fit-line] element. */
export const FIT_LINE_SCRIPT = `<script>(function(){function f(e){e.style.whiteSpace="nowrap";e.style.maxWidth="100%";e.style.display="block";if(e.dataset.fitBase===undefined)e.dataset.fitBase=e.style.fontSize;e.style.fontSize=e.dataset.fitBase;var b=parseFloat(getComputedStyle(e).fontSize),n=e.scrollWidth,h=e.clientWidth;if(n<=h||h<=0)return;var z=Math.floor(b*h/n*100)/100;e.style.fontSize=z+"px";for(var i=0;i<20&&e.scrollWidth>e.clientWidth;i++){z*=0.98;e.style.fontSize=z+"px";}}function a(){var l=document.querySelectorAll("[data-fit-line]");for(var i=0;i<l.length;i++)f(l[i]);}window.__fitLines=a;a();addEventListener("resize",a);addEventListener("load",a);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(a);if(window.ResizeObserver)new ResizeObserver(a).observe(document.documentElement);})();</script>`;
