import { createHash, createHmac, randomBytes } from 'node:crypto';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';

export const DEVICE_MS = 30 * 24 * 60 * 60 * 1000;
type DeviceDatabase = SupabaseClient<Database>;
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
export function credentialVersion(credential: string, key: string) {
  return createHmac('sha256', key).update(credential).digest('hex');
}
export function deviceCurrent(device: { expires_at: string; revoked_at: string | null; credential_version: string; account_id: string | null }, version: string, owner: string | null, now = Date.now()) {
  return !device.revoked_at && now < Date.parse(device.expires_at) && device.credential_version === version && device.account_id === owner;
}
async function ownerCredential(database: DeviceDatabase, loc: string) {
  const demoLoc = process.env['LIVEDEMO_GHL_LOCATION_ID'];
  if (demoLoc && loc === demoLoc) {
    const credential = process.env['LIVEDEMO_MYLINKS_PASSWORD'];
    return credential ? { owner: null, credential } : null;
  }
  const { data: bots, error } = await database.from('client_slugs').select('owner_account_id').eq('ghl_location_id', loc);
  if (error) return null;
  const owners = [...new Set((bots ?? []).flatMap(bot => bot.owner_account_id ? [bot.owner_account_id] : []))];
  const owner = owners.length === 1 ? owners[0] : undefined;
  if (!owner) return null;
  const { data: account, error: accountError } = await database.from('customer_accounts').select('password_hash').eq('id', owner).maybeSingle();
  return account && !accountError ? { owner, credential: account.password_hash } : null;
}
export async function rememberDevice(database: DeviceDatabase, loc: string, key: string, verifiedCredential: string) {
  const current = await ownerCredential(database, loc);
  if (!current || current.credential !== verifiedCredential) return null;
  const token = `mld_${randomBytes(32).toString('base64url')}`;
  const expiresAt = new Date(Date.now() + DEVICE_MS).toISOString();
  const { error } = await database.from('my_links_devices').insert({ account_id: current.owner, ghl_location_id: loc, token_hash: digest(token), credential_version: credentialVersion(current.credential, key), expires_at: expiresAt });
  return error ? null : { token, expires_at: expiresAt };
}
export async function verifyDevice(database: DeviceDatabase, loc: string, token: string, key: string) {
  if (!/^mld_[A-Za-z0-9_-]{43}$/.test(token)) return false;
  const { data: device, error } = await database.from('my_links_devices').select('account_id,credential_version,expires_at,revoked_at').eq('ghl_location_id', loc).eq('token_hash', digest(token)).maybeSingle();
  if (error || !device) return false;
  const current = await ownerCredential(database, loc);
  return Boolean(current && deviceCurrent(device, credentialVersion(current.credential, key), current.owner));
}