import { FIT_LINE_SCRIPT } from "@/lib/fit-line";
/**
 * Design-only voice page for customer links: a static copy of the homepage
 * live-demo phone (PhoneDemo frame + PhoneCallPreview at its Start Call state),
 * styled by the app's own compiled stylesheet so sizes, fonts and colors match.
 */
import appCss from "@/styles.css?inline";

const MIC =
  '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="CLS" aria-hidden="true"><path d="M12 19v3"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><rect x="9" y="2" width="6" height="13" rx="3"/></svg>';
const mic = (cls: string) => MIC.replace("CLS", cls);

// Same markup/classes as PhoneCallPreview in HeroDemo.tsx (Start Call state).
const SCREEN = `<div class="relative flex h-full flex-col bg-surface px-6 pb-6 pt-16 text-center text-ink">
<div class="text-center">
<span class="relative mx-auto flex h-24 w-24 items-center justify-center">
<span class="absolute h-24 w-24 rounded-full bg-brand/20 animate-pulse-ring"></span>
<span class="relative grid h-20 w-20 place-items-center rounded-full bg-brand text-brand-foreground shadow-brand">${mic("h-8 w-8")}</span>
</span>
<p class="eyebrow mt-7">LIVE RECEPTIONIST</p>
</div>
<h3 class="mt-6 text-3xl font-black text-ink">Hi, let's chat.</h3>
<p class="mt-3 text-base font-medium leading-relaxed text-muted-foreground">I can answer any question and get you to the right person.</p>
<div class="demo-audio-lines demo-audio-lines-active mt-8" aria-hidden="true">${"<span></span>".repeat(17)}</div>
<div class="relative mt-auto w-full">
<button type="button" class="linkbot-button w-full"><span class="flex items-center gap-2">${mic("h-4 w-4")} Start Call</span></button>
</div>
</div>`;

// Paused bots: same screen container, message in the screen's existing paragraph style.
const PAUSED_SCREEN = `<div class="relative flex h-full flex-col items-center justify-center bg-surface px-6 pb-6 pt-16 text-center text-ink">
<p data-fit-line class="whitespace-nowrap text-[13.5px] font-medium leading-relaxed text-muted-foreground">This assistant is temporarily unavailable.</p>
</div>${FIT_LINE_SCRIPT}`;

// Active bots awaiting their widget: same placement and style as the paused message.
const PENDING_SCREEN = `<div class="relative flex h-full flex-col items-center justify-center bg-surface px-6 pb-6 pt-16 text-center text-ink">
<p data-fit-line class="whitespace-nowrap text-[13.5px] font-medium leading-relaxed text-muted-foreground">This assistant will be available shortly.</p>
</div>${FIT_LINE_SCRIPT}`;

const frame = (screen: string) => FRAME.replace(SCREEN, screen);

// Same outer geometry as PhoneDemo in HeroDemo.tsx (316×650, 9px total frame
// thickness, 42px radius), built as three layers: a near-pure-black base
// (never grey), a 4px polished-black rim on the very outside whose shine comes
// only from narrow bright reflection lines along the edges (crisp top/bottom/
// side glints, a 1px bright edge ring, thin diagonal streaks — no wide grey
// gradients), and a 5px black-glass band inside it. The screen area stays
// 298×632 at the same offset, so nothing inside the screen moves; the existing
// shadow is untouched.
const FRAME = `<div id="lb-phone" class="relative h-[650px] w-[316px] overflow-hidden rounded-[42px] shadow-elev-3" style="background:#020304;">
<div class="absolute inset-0 rounded-[42px]" style="background:linear-gradient(115deg,rgba(255,255,255,0) 0%,rgba(255,255,255,0) 8.5%,rgba(255,255,255,0.38) 10.5%,rgba(255,255,255,0) 12.5%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.32) 88.5%,rgba(255,255,255,0) 91%),linear-gradient(180deg,rgba(255,255,255,0.55) 0%,rgba(255,255,255,0.10) 1.5px,rgba(255,255,255,0) 3px),linear-gradient(0deg,rgba(255,255,255,0.45) 0%,rgba(255,255,255,0.08) 1.5px,rgba(255,255,255,0) 3px),linear-gradient(90deg,rgba(255,255,255,0.35) 0%,rgba(255,255,255,0) 2px),linear-gradient(270deg,rgba(255,255,255,0.35) 0%,rgba(255,255,255,0) 2px);box-shadow:inset 0 0 0 1px rgba(255,255,255,0.24),inset 0 0 0 3px rgba(0,0,0,0.85);"></div>
<div class="absolute inset-[4px] rounded-[38px]" style="background:#000;box-shadow:inset 0 0 0 1px rgba(255,255,255,0.06),inset 0 0 3px 1px rgba(255,255,255,0.05);"></div>
<div class="absolute inset-[9px] z-10 overflow-hidden rounded-[33px] bg-surface">
<div class="absolute left-1/2 top-2 z-30 h-6 w-24 -translate-x-1/2 rounded-full bg-night"></div>
<div class="absolute inset-x-0 top-0 z-20 flex h-11 items-center justify-between bg-surface px-6 text-[10px] font-bold text-ink"><span id="lb-time">9:41</span><span>● ● ●</span></div>
<div class="absolute inset-0 z-10 bg-surface">${SCREEN}</div>
</div>
</div>`;

// Phone screen area inside the frame: 316 − 2×9 by 650 − 2×9.
const SCREEN_W = 298;
const SCREEN_H = 632;

export const VOICE_PAGE_HEAD = `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Manrope:wght@400;500;600;700;800&display=swap">
<style id="lb-css">${appCss}
html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#000 !important;font-family:var(--font-sans);}
#lb-stage{position:fixed;inset:0;background:#000;overflow:hidden;}
#lb-fit{position:absolute;left:0;top:0;width:316px;height:650px;transform-origin:center center;}
#lb-mobile{display:none;position:fixed;left:0;top:0;transform-origin:0 0;background:var(--surface);}
html.lb-phone #lb-stage{display:none;}
html.lb-phone #lb-mobile{display:block;}
</style>`;

function pageBody(screen: string, phone: string): string {
  return `<div id="lb-stage"><div id="lb-fit">${phone}</div></div>
<div id="lb-mobile">${screen}</div>
<script>(function(){
var d=document.documentElement,fit=document.getElementById("lb-fit"),mob=document.getElementById("lb-mobile");
function isPhone(){var s=Math.min(screen.width,screen.height);var c=window.matchMedia&&matchMedia("(pointer: coarse)").matches;return c&&s<600;}
function lay(){var w=window.innerWidth,h=window.innerHeight;
if(isPhone()){d.classList.add("lb-phone");var k=Math.min(w/${SCREEN_W},h/${SCREEN_H});mob.style.width=(w/k)+"px";mob.style.height=(h/k)+"px";mob.style.transform="scale("+k+")";}
else{d.classList.remove("lb-phone");var m=16,s=Math.min((w-2*m)/316,(h-2*m)/650);fit.style.transform="translate("+((w-316)/2)+"px,"+((h-650)/2)+"px) scale("+s+")";}}
lay();window.addEventListener("resize",lay);window.addEventListener("orientationchange",function(){setTimeout(lay,250);});
var t=document.getElementById("lb-time");function tick(){var n=new Date();t.textContent=(n.getHours()%12||12)+":"+String(n.getMinutes()).padStart(2,"0");}tick();setInterval(tick,1000);
})();</script>`;
}

export const VOICE_PAGE_BODY = pageBody(SCREEN, FRAME);
export const VOICE_PAGE_PAUSED_BODY = pageBody(PAUSED_SCREEN, frame(PAUSED_SCREEN));
export const VOICE_PAGE_PENDING_BODY = pageBody(PENDING_SCREEN, frame(PENDING_SCREEN));

