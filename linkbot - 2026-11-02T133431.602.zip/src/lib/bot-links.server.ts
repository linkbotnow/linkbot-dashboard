import { createHash, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';

const field = z.string().trim().min(1).max(255);
const inputSchema = z.object({ account: field, button_name: z.string().trim().max(500).optional() });
export const exactName = (value: string) => value.trim().toLowerCase();
export function authorized(supplied: string | null, expected: string | undefined) {
  if (!supplied || !expected) return false;
  return timingSafeEqual(createHash('sha256').update(supplied).digest(), createHash('sha256').update(expected).digest());
}
export const summaryOf = (summary: string | null, details: string) => summary?.trim() || details.match(/^[\s\S]*?[.!?](?:\s|$)/)?.[0].trim() || details.trim();
const reply = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });
export async function botLinks(request: Request, action: 'list' | 'details' | 'share') {
  // Authenticate before parsing input or loading privileged database access.
  if (!authorized(request.headers.get('x-linkbot-key'), process.env['MYLINKS_BOT_KEY'])) return reply({ error: 'Unauthorized' }, 401);
  try {
    const query = new URL(request.url).searchParams;
    let body: Record<string, unknown> = {};
    if (request.method === 'POST') {
      const text = await request.text();
      if (text.length > 20000) return reply({ error: 'Invalid request' }, 400);
      if (text.trim()) body = z.record(z.unknown()).parse(JSON.parse(text));
    }
    const parsed = inputSchema.safeParse({ account: body['account'] ?? query.get('account'), button_name: body['button_name'] ?? query.get('button_name') ?? undefined });
    if (!parsed.success) return reply({ error: 'Invalid request' }, 400);
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data, error } = await supabaseAdmin.from('my_links').select('id,button_name,full_title,who_its_for,details,extra_notes,price,type,ai_summary').eq('ghl_location_id', parsed.data.account).eq('is_on', true).order('created_at', { ascending: false });
    if (error) return reply({ error: 'Unable to read links' }, 503);
    const links = data ?? [];
    if (action === 'list') return reply({
      links: links.map(link => ({ button_name: link.button_name, full_title: link.full_title, who_its_for: link.who_its_for, summary: summaryOf(link.ai_summary, link.details), type: link.type })),
      instructions: links.length ? 'These are the only links you can share. Before describing or sharing any link, run get_link_details with its exact button_name. To share a link, run share_link with its exact button_name. Never say a link was sent unless share_link returned shared: true.' : "There are no links to share. If someone asks for a link, say you don't have one for that.",
    });
    const name = parsed.data.button_name ?? '';
    // Match on the exact button name first, then the exact full title; both case-insensitive.
    const link = name
      ? (links.find(row => exactName(row.button_name) === exactName(name))
        ?? links.find(row => exactName(row.full_title ?? '') === exactName(name)))
      : undefined;
    if (!link) return reply(action === 'details'
      ? { found: false, message: 'No link with that exact name. Use one of these exact names:', available_names: links.map(row => row.button_name) }
      : { shared: false, message: 'No link with that exact name. Nothing was shared. Use one of these exact names:', available_names: links.map(row => row.button_name) });
    if (action === 'share') {
      try {
        const shares = await import('./call-shares.server');
        const callKey = await shares.recordCallShare(request, body, parsed.data.account, link);
        const contactId = query.get('contact_id');
        if (contactId && /^[A-Za-z0-9]{10,40}$/.test(contactId) && callKey) {
          // Delivery is independent of the unchanged share reply and recording result.
          try { shares.queueContactLinks(request, parsed.data.account, contactId, callKey); }
          catch { console.error('LinkBot shared contact links background scheduling failed'); }
        }
      }
      catch { return reply({ error: 'Unable to record shared link' }, 503); }
      return reply({ shared: true, button_name: link.button_name, link_id: link.id, message: "The button is now on the visitor's screen." });
    }
    return reply({ found: true, button_name: link.button_name, full_title: link.full_title, who_its_for: link.who_its_for, details: link.details, extra_notes: link.extra_notes ?? '', price: link.price ?? '', type: link.type });
  } catch { return reply({ error: 'Invalid request' }, 400); }
}

export async function pageLinks(request: Request) {
  const page = field.safeParse(new URL(request.url).searchParams.get('page'));
  if (!page.success) return reply({ links: [] });
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  let account = page.data === 'livedemo' ? process.env['LIVEDEMO_GHL_LOCATION_ID'] : undefined;
  if (page.data !== 'livedemo') {
    // Use equality queries, never interpolate a page key into an OR expression.
    const column = page.data.length === 12 ? 'link_code' : 'slug';
    const { data, error } = await supabaseAdmin.from('client_slugs').select('ghl_location_id').eq(column, page.data).in('status', ['active', 'paused']).not('activated_at', 'is', null).maybeSingle();
    if (error) return reply({ error: 'Unable to read links' }, 503);
    account = data?.ghl_location_id ?? undefined;
  }
  if (!account) return reply({ links: [] });
  const { data, error } = await supabaseAdmin.from('my_links').select('id,button_name,url,type').eq('ghl_location_id', account).eq('is_on', true).order('created_at', { ascending: false });
  if (error) return reply({ error: 'Unable to read links' }, 503);
  return reply({ links: data ?? [] });
}