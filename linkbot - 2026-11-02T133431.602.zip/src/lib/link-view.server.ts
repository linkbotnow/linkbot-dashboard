import { parse, serialize, type DefaultTreeAdapterMap } from 'parse5';
import { publicHttps, publicAddress, allowsFraming, challengeHtml, chooseViewMode, MODE_CACHE_MS, PROXY_CACHE_MS, VIEW_TIMEOUT_MS, MAX_VIEW_BYTES, MAX_VIEW_REDIRECTS, RISKY_LINK, SNAPSHOTS_ENABLED } from './link-view-rules';
type Link = { id: string; url: string; snapshot_path: string | null; snapshot_url_source: string | null; snapshot_blocked_at: string | null };
type Page = { html: string; finalUrl: string; framing: boolean; usable: boolean; expires: number };
const pages = new Map<string, Page>();
const modes = new Map<string, { mode: 'live' | 'proxy' | 'snapshot'; expires: number }>();
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
async function db() { return (await import('@/integrations/supabase/client.server')).supabaseAdmin; }
export async function registeredLink(value: string): Promise<Link | null> {
  if (!value || value.length > 2048) return null;
  const database = await db();
  const query = database.from('my_links').select('id,url,snapshot_path,snapshot_url_source,snapshot_blocked_at');
  const { data, error } = /^[\da-f]{8}-[\da-f-]{27}$/i.test(value) ? await query.eq('id', value).limit(1) : await query.eq('url', value).limit(1);
  if (error) throw new Error('Link lookup failed');
  return data?.[0] ?? null;
}
export async function validatePublicUrl(target: URL, signal: AbortSignal) {
  if (!publicHttps(target)) throw new Error('Public HTTPS required');
  const groups = await Promise.all(['A', 'AAAA'].map(async type => {
    const res = await fetch('https://dns.google/resolve?name=' + encodeURIComponent(target.hostname) + '&type=' + type, { signal });
    if (!res.ok) throw new Error('DNS unavailable');
    const data = await res.json() as { Answer?: { type: number; data: string }[] };
    return (data.Answer ?? []).filter(x => x.type === 1 || x.type === 28).map(x => x.data);
  }));
  const addresses = groups.flat();
  if (!addresses.length || addresses.some(ip => !publicAddress(ip))) throw new Error('Private destination rejected');
}
export async function fetchPage(raw: string, screenshotTarget = false): Promise<Page> {
  const cached = pages.get(raw);
  if (!screenshotTarget && cached && cached.expires > Date.now()) return cached;
  const signal = AbortSignal.timeout(VIEW_TIMEOUT_MS);
  let url = new URL(raw);
  for (let hop = 0; hop <= MAX_VIEW_REDIRECTS; hop++) {
    await validatePublicUrl(url, signal);
    let response: Response;
    try {
      response = await fetch(url, { redirect: 'manual', credentials: 'omit', signal, headers: { 'user-agent': UA, accept: 'text/html,application/xhtml+xml' } });
    } catch (error) {
      // Only transport errors after successful URL/DNS validation may proceed.
      // Unsafe destinations and invalid redirects still throw outside this catch.
      if (screenshotTarget) return { html: '', finalUrl: url.href, framing: false, usable: false, expires: 0 };
      throw error;
    }
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get('location');
      await response.body?.cancel();
      if (!location || hop === MAX_VIEW_REDIRECTS) throw new Error('Redirect limit');
      url = new URL(location, url); continue;
    }
    if (screenshotTarget) {
      await response.body?.cancel();
      return { html: '', finalUrl: url.href, framing: false, usable: false, expires: 0 };
    }
    if ((!screenshotTarget && response.status !== 200) || !/^(text\/html|application\/xhtml\+xml)\b/i.test(response.headers.get('content-type') ?? '')) {
      await response.body?.cancel(); throw new Error('Not usable HTML');
    }
    const bytes = await boundedBody(response, MAX_VIEW_BYTES);
    const html = new TextDecoder().decode(bytes);
    const page = { html, finalUrl: url.href, framing: allowsFraming(response.headers), usable: response.status === 200 && !challengeHtml(html), expires: Date.now() + PROXY_CACHE_MS };
    if (pages.size >= 200) pages.delete(pages.keys().next().value ?? '');
    pages.set(raw, page); return page;
  }
  throw new Error('Redirect limit');
}
export async function boundedBody(response: Response, max: number) {
  if (Number(response.headers.get('content-length') ?? 0) > max) { await response.body?.cancel(); throw new Error('Body too large'); }
  const reader = response.body?.getReader();
  if (!reader) throw new Error('Empty body');
  const chunks: Uint8Array[] = []; let size = 0;
  try { for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.length; if (size > max) throw new Error('Body too large'); chunks.push(part.value); } }
  catch (error) { await reader.cancel(); throw error; }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}
export async function linkMode(link: Link) {
  // A blocked site (bot verification) never opens in the panel during a call: the button holds the link until after the call.
  if (link.snapshot_blocked_at) return { mode: 'snapshot' as const, snapshot_url: null };
  const cached = modes.get(link.url);
  let mode = cached && cached.expires > Date.now() ? cached.mode : undefined;
  if (!mode) {
    mode = 'snapshot';
    if (!RISKY_LINK.test(link.url)) { try { const page = await fetchPage(link.url); mode = chooseViewMode(link.url, page.framing && page.usable, page.usable); } catch { /* snapshot fallback */ } }
    if (modes.size >= 500) modes.delete(modes.keys().next().value ?? '');
    modes.set(link.url, { mode, expires: Date.now() + MODE_CACHE_MS });
  }
  return { mode, snapshot_url: SNAPSHOTS_ENABLED && link.snapshot_path && link.snapshot_url_source === link.url ? '/api/public/link-snapshot?u=' + encodeURIComponent(link.id) : null };
}
// Upstream code must not execute on the app origin or access customer cookies.
// Preserve HTML/styles/images; only our navigation script runs, in an opaque sandbox.
export function proxyHtml(html: string, finalUrl: string, nonce: string, appOrigin = 'https://linkbot.now') {
  const document = parse(html);
  type Node = DefaultTreeAdapterMap['node'];
  const clean = (node: Node) => {
    if ('attrs' in node) node.attrs = node.attrs.filter(a => !/^on/i.test(a.name) && !['srcdoc', 'nonce', 'integrity'].includes(a.name));
    if ('childNodes' in node) {
      node.childNodes = node.childNodes.filter(child => !('tagName' in child) || !['script', 'iframe', 'frame', 'object', 'embed', 'base'].includes(child.tagName) && !(child.tagName === 'meta' && child.attrs.some(a => a.name === 'http-equiv')));
      node.childNodes.forEach(clean);
    }
  };
  clean(document);
  const escaped = finalUrl.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const baseHost = JSON.stringify(new URL(finalUrl).hostname.replace(/^www\./, ''));
  const proxyAddress = JSON.stringify(appOrigin + '/api/public/view?u=');
  const navigation = `<base href="${escaped}"><script nonce="${nonce}">document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a)return;e.preventDefault();e.stopImmediatePropagation();try{var u=new URL(a.getAttribute('href'),document.baseURI);if(u.protocol==='https:'&&u.hostname.replace(/^www\\./,'')===${baseHost})location.href=${proxyAddress}+encodeURIComponent(u.href)}catch(_){}},true);document.addEventListener('submit',function(e){e.preventDefault()},true);</script>`;
  return serialize(document).replace(/<head>/i, '<head>' + navigation);
}
export async function viewResponse(request: Request) {
  try {
    const link = await registeredLink(new URL(request.url).searchParams.get('u') ?? '');
    if (!link) return new Response('Saved link not found', { status: 404 });
    let page: Page;
    try {
      page = await fetchPage(link.url);
      if (!page.usable) return snapshotFallback(link);
    } catch {
      return snapshotFallback(link);
    }
    const nonce = crypto.randomUUID().replace(/-/g, '');
    return new Response(proxyHtml(page.html, page.finalUrl, nonce, new URL(request.url).origin), { headers: {
      'content-type': 'text/html; charset=utf-8', 'cache-control': 'public, max-age=600', 'x-robots-tag': 'noindex, nofollow', 'referrer-policy': 'no-referrer',
      'content-security-policy': `sandbox allow-scripts; default-src https: data:; script-src 'nonce-${nonce}'; connect-src 'none'; frame-src 'none'; object-src 'none'; form-action 'none'; base-uri https:; style-src https: 'unsafe-inline'; frame-ancestors 'self'`,
    } });
  } catch { return new Response('Website unavailable', { status: 502 }); }
}
export function snapshotFallback(link: Link) {
  const image = SNAPSHOTS_ENABLED && link.snapshot_path && link.snapshot_url_source === link.url
    ? '<img alt="" src="/api/public/link-snapshot?u=' + encodeURIComponent(link.id) + '">'
    : '';
  // Upstream rejection is an expected view fallback, not an application failure.
  // A 200 document keeps the existing iframe/panel intact even before capture is configured.
  return new Response('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0}img{display:block;width:100%;height:auto}</style></head><body>' + image + '</body></html>', { headers: {
    'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-linkbot-view-mode': 'snapshot',
    'x-robots-tag': 'noindex, nofollow', 'referrer-policy': 'no-referrer',
    'content-security-policy': "sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'self'",
  } });
}
