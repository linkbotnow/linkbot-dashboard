export function followUpMessage(draft: string, fullName: string) {
  if (!draft.trim()) return '';
  const name = fullName.trim().split(/\s+/)[0] ?? '';
  const text = draft.trimEnd();
  return /Best,$/.test(text) ? `${text}\n${name}` : `${text}\n\nBest,\n${name}`;
}
export function emailHtml(text: string) {
  return text.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] ?? char)).replace(/\r\n|\r|\n/g, '<br>');
}
export function sameLocation(contact: { locationId?: string }, account: string) {
  return contact.locationId === account;
}
export function completeEmail(subject: string, message: string) {
  return Boolean(subject.trim() && message.trim());
}
export function contactField(fields: { id?: string | undefined; key?: string | undefined; fieldKey?: string | undefined; value?: unknown; fieldValue?: unknown }[], key: string, definitions: { id: string; fieldKey: string }[]) {
  const id = definitions.find(field => field.fieldKey === key || field.fieldKey === `contact.${key}`)?.id;
  const field = fields.find(field => field.key === key || field.key === `contact.${key}` || field.fieldKey === key || field.fieldKey === `contact.${key}` || Boolean(id && field.id === id));
  const value = field?.value ?? field?.fieldValue;
  return typeof value === 'string' ? value : '';
}