import { z } from 'zod';
import { onlyWidget } from './settings-rules';
const BASE = 'https://services.leadconnectorhq.com';
const REDIRECT = 'https://linkbot.now/api/public/linkbot/oauth/callback';
const tokens = z.object({ access_token: z.string().min(1), refresh_token: z.string().min(1), expires_in: z.number().positive(), companyId: z.string().min(1) });
async function db() { return (await import('@/integrations/supabase/client.server')).supabaseAdmin; }
function credentials() {
  const client_id = process.env['LINKBOT_APP_CLIENT_ID'], client_secret = process.env['LINKBOT_APP_CLIENT_SECRET'];
  if (!client_id || !client_secret) throw new Error('App credentials unavailable');
  return { client_id, client_secret, user_type: 'Company', redirect_uri: REDIRECT };
}
async function exchange(fields: Record<string,string>) {
  const res = await fetch(`${BASE}/oauth/token`, { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ ...credentials(), ...fields }), signal: AbortSignal.timeout(10000) });
  if (!res.ok) throw new Error(`OAuth request failed (${res.status})`);
  return tokens.parse(await res.json());
}
export async function installApp(code: string) {
  const result = await exchange({ grant_type: 'authorization_code', code });
  const database = await db();
  const { error } = await database.from('linkbot_app_tokens').upsert({ company_id: result.companyId, access_token: result.access_token, refresh_token: result.refresh_token, expires_at: new Date(Date.now()+result.expires_in*1000).toISOString(), updated_at: new Date().toISOString() });
  if (error) throw new Error('App connection could not be stored');
}
function fresh(row: { access_token: string | null; expires_at: string | null } | null, margin = 600000) {
  return Boolean(row?.access_token && row.expires_at && Date.parse(row.expires_at) > Date.now()+margin);
}
export async function getAgencyToken(companyId: string): Promise<string | null> {
  const database = await db();
  for (let attempt=0; attempt<24; attempt++) {
    const { data: row, error } = await database.from('linkbot_app_tokens').select('*').eq('company_id',companyId).maybeSingle();
    if (error) throw new Error('Agency token lookup failed');
    if (!row) return null;
    if (fresh(row)) return row.access_token;
    if (!row.refresh_token) return null;
    // Durable compare-and-swap lease prevents two workers using the rotating refresh token.
    const claim = new Date(Date.now()+20000).toISOString();
    const { data: locked, error: lockError } = await database.rpc('linkbot_claim_token_refresh',{ p_company_id:companyId,p_version:row.updated_at ?? new Date(0).toISOString(),p_claim:claim });
    if (lockError) throw new Error('Agency refresh lock failed');
    if (!locked) { await new Promise(resolve=>setTimeout(resolve,500)); continue; }
    try {
      const result = await exchange({ grant_type:'refresh_token',refresh_token:row.refresh_token });
      const { data: updated, error: updateError } = await database.from('linkbot_app_tokens').update({ access_token:result.access_token, refresh_token:result.refresh_token, expires_at:new Date(Date.now()+result.expires_in*1000).toISOString(),updated_at:new Date().toISOString() }).eq('company_id',companyId).eq('refresh_token',row.refresh_token).eq('updated_at',claim).select('access_token');
      if (updateError) throw new Error('Agency refresh save failed');
      if (updated?.[0]) return updated[0].access_token;
    } catch {
      await database.from('linkbot_app_tokens').update({updated_at:new Date().toISOString()}).eq('company_id',companyId).eq('updated_at',claim);
      console.error('LinkBot agency refresh failed'); return null;
    }
  }
  return null;
}
export async function getLocationToken(locationId: string): Promise<string | null> {
  const database = await db();
  const { data: cached, error } = await database.from('linkbot_location_tokens').select('*').eq('location_id',locationId).maybeSingle();
  if (error) throw new Error('Location token lookup failed');
  if (fresh(cached)) return cached?.access_token ?? null;
  const { data: agencies, error: agencyError } = await database.from('linkbot_app_tokens').select('company_id').limit(2);
  if (agencyError) throw new Error('Agency lookup failed');
  if (!agencies?.length) { console.warn('LinkBot app not installed'); return null; }
  if (agencies.length !== 1) { console.error('LinkBot agency selection is ambiguous'); return null; }
  const companyId = agencies[0]?.company_id;
  if (!companyId) return null;
  const agency = await getAgencyToken(companyId);
  if (!agency) return null;
  const res = await fetch(`${BASE}/oauth/locationToken`, { method:'POST', headers:{Version:'2021-07-28',Authorization:`Bearer ${agency}`,'Content-Type':'application/json'}, body:JSON.stringify({companyId,locationId}),signal:AbortSignal.timeout(10000) });
  if (!res.ok) { console.error('LinkBot location token request failed',res.status); return null; }
  const value = z.object({access_token:z.string().min(1),expires_in:z.number().positive(),locationId:z.string().optional()}).parse(await res.json());
  if (value.locationId && value.locationId !== locationId) throw new Error('Location token mismatch');
  const saved = await database.from('linkbot_location_tokens').upsert({location_id:locationId,access_token:value.access_token,expires_at:new Date(Date.now()+value.expires_in*1000).toISOString(),updated_at:new Date().toISOString()});
  if (saved.error) throw new Error('Location token save failed');
  return value.access_token;
}
export async function findWidgetId(locationId: string) {
  const {sendAlert}=await import('../bot-events.server');
  try {
    const token = await getLocationToken(locationId);
    if (!token) return null;
    const res = await fetch(`${BASE}/chat-widget/list?locationId=${encodeURIComponent(locationId)}&offset=0&limit=100&chatType=voiceAiChat`,{headers:{Version:'v3',Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(10000)});
    if (!res.ok) throw new Error('Widget lookup failed');
    const result = z.object({chatWidgets:z.array(z.object({_id:z.string().min(1)})),totalCount:z.number().optional()}).parse(await res.json());
    const id = onlyWidget(result.chatWidgets,result.totalCount);
    if (!id) await sendAlert('widget_lookup_failed',{message:`Location ${locationId}; widget count ${result.totalCount ?? result.chatWidgets.length}.`});
    return id;
  } catch { await sendAlert('widget_lookup_failed',{message:`Location ${locationId}; widget count unavailable (lookup failed).`});return null; }
}
export async function fillWidgetIds(filter: {botId?:string;locationId?:string} = {}) {
  const database = await db();
  let query = database.from('client_slugs').select('id,ghl_location_id').eq('status','active').not('ghl_location_id','is',null).is('ghl_widget_id',null);
  if (filter.botId) query=query.eq('id',filter.botId);
  if (filter.locationId) query=query.eq('ghl_location_id',filter.locationId);
  const {data:rows,error}=await query;
  if (error) throw new Error('Missing widgets lookup failed');
  const {sendLinksIfReady}=await import('../bot-events.server');
  for (const row of rows ?? []) {
    if (!row.ghl_location_id) continue;
    const widget = await findWidgetId(row.ghl_location_id);
    if (!widget) continue;
    const {data:updated,error:updateError}=await database.from('client_slugs').update({ghl_widget_id:widget}).eq('id',row.id).eq('status','active').eq('ghl_location_id',row.ghl_location_id).is('ghl_widget_id',null).select('id');
    if (updateError) throw new Error('Widget save failed');
    if (updated?.length) await sendLinksIfReady(row.id);
  }
}