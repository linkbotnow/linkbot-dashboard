import { z } from 'zod';
import { decryptContext, issueSettingsAccess, settingsLocation } from './access.server';
import { displayNames, domainProblem, emptySettingsBot, linkedinProfile } from './settings-rules';
import { normalizeClaimSlug } from '../claim-slug';
import { checkSlugAvailability } from '../slug-availability.server';
import { fillWidgetIds, getLocationToken } from './app.server';
import { firstName, greetingProblem } from './greeting-rules';
import { sendGreetingName } from './greeting.server';
import { callScreenProblem } from './call-screen-rules';
const fields='id,slug,link_code,full_name,last_name,company_name,page_title_choice,voice_choice,voice_sent,linkedin_url,greeting_choice,greeting_name_text,greeting_business_text,call_screen_name_text,call_screen_business_text';
async function db(){return (await import('@/integrations/supabase/client.server')).supabaseAdmin;}
async function botFor(loc:string){const database=await db();const {data,error}=await database.from('client_slugs').select(fields).eq('ghl_location_id',loc).eq('status','active').order('created_at',{ascending:true}).limit(1).maybeSingle();if(error)throw new Error('Bot lookup failed');return data;}
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store','referrer-policy':'same-origin'}});
export async function session(request:Request){
  try{
    const input=z.object({encryptedData:z.string().min(24).max(20000)}).parse(await request.json());
    let context:ReturnType<typeof decryptContext>;
    try{context=decryptContext(input.encryptedData);}catch(error){
      const missingLocation=error instanceof z.ZodError&&error.issues.some(issue=>issue.path[0]==='activeLocation');
      console.warn(missingLocation?'no activeLocation':'decrypt failed');
      return reply({error:'Invalid context'},401);
    }
    if(!await botFor(context.activeLocation))console.warn(`no active bot for location ${context.activeLocation.replace(/[\r\n\u0000-\u001f\u007f]/g,'')}`);
    return reply({token:issueSettingsAccess(context.activeLocation)});
  }catch{return reply({error:'Invalid context'},401);}
}
async function applyVoice(loc:string,botId:string,choice:'female'|'male'){
  const {sendAlert}=await import('../bot-events.server');
  try{
    const voiceId=process.env[choice==='female'?'LINKBOT_VOICE_FEMALE_ID':'LINKBOT_VOICE_MALE_ID'];
    if(!voiceId)throw new Error('Voice configuration pending');
    const token=await getLocationToken(loc);if(!token)throw new Error('Location connection pending');
    const headers={Version:'2023-02-21',Authorization:`Bearer ${token}`,'Content-Type':'application/json'};
    const response=await fetch(`https://services.leadconnectorhq.com/voice-ai/agents?locationId=${encodeURIComponent(loc)}`,{headers,signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw new Error('Agent lookup failed');
    const raw=await response.json() as {agents?:{id?:string;_id?:string}[];data?:{id?:string;_id?:string}[];total?:number;totalCount?:number};
    const agents=raw.agents ?? raw.data;
    if(!Array.isArray(agents)||agents.length!==1||(raw.total ?? raw.totalCount ?? agents.length)!==1)throw new Error('Agent selection not unique');
    const id=agents[0]?.id ?? agents[0]?._id;if(!id)throw new Error('Agent ID unavailable');
    const patched=await fetch(`https://services.leadconnectorhq.com/voice-ai/agents/${encodeURIComponent(id)}?locationId=${encodeURIComponent(loc)}`,{method:'PATCH',headers,body:JSON.stringify({voiceId}),signal:AbortSignal.timeout(10000)});
    if(!patched.ok)throw new Error('Voice update failed');
    return true;
  }catch{await sendAlert('voice_update_failed',{botId,message:`Location ${loc}; saved ${choice} voice requires application.`});return false;}
}
export async function settings(request:Request){
  try{
    const input=z.object({action:z.enum(['load','availability','domain','new_link','display','greeting','voice','linkedin']),value:z.union([z.string().max(2000),z.object({choice:z.enum(['name','business']),name:z.string().max(60),business:z.string().max(60)})]).optional()}).parse(await request.json());
    if(!['greeting','display'].includes(input.action)&&input.value!==undefined&&typeof input.value!=='string')return reply({error:'Invalid request'},400);
    const textValue=typeof input.value==='string'?input.value:undefined;
    const token=request.headers.get('authorization')?.replace(/^Bearer /,'') ?? '';
    const loc=settingsLocation(token);if(!loc)return reply({error:'Please open this page from the Account Settings menu in your LinkBot account.'},401);
    let bot=await botFor(loc);
    if(!bot){
      if(input.action==='load')return reply({noBot:true,bot:emptySettingsBot(),pending:false});
      return reply({error:'Nothing to save yet.'},400);
    }
    const database=await db();let pending=false;
    if(input.action==='load')await fillWidgetIds({locationId:loc});
    if(input.action==='availability'||input.action==='domain'){
      const raw=textValue ?? '',problem=domainProblem(raw),slug=normalizeClaimSlug(raw);
      if(problem)return reply({available:false,error:problem},input.action==='domain'?400:200);
      const available=slug===bot.slug || (await checkSlugAvailability(slug)).available;
      if(input.action==='availability')return reply({available,...(!available?{error:'Domain taken. Please try another.'}:{})});
      if(!available)return reply({error:'Domain taken. Please try another.'},400);
      const {data,error}=await database.rpc('rename_bot_slug',{p_bot_id:bot.id,p_new_slug:slug});
      if(error)throw new Error('Domain save failed');
      const result=data as {ok:boolean;changed?:boolean;reason?:string};
      if(!result.ok)return reply({error:'Domain taken. Please try another.'},400);
      if(result.changed)await (await import('../bot-events.server')).sendLinkUpdate(bot.id,'domain_change');
    }
    if(input.action==='new_link'){
      const {data,error}=await database.rpc('new_bot_link_code',{p_bot_id:bot.id});if(error)throw new Error('New link failed');
      const result=data as {ok:boolean;changed?:boolean};if(!result.ok)throw new Error('New link failed');
      if(result.changed)await (await import('../bot-events.server')).sendLinkUpdate(bot.id,'new_link');
    }
    if(input.action==='display'||input.action==='voice'||input.action==='linkedin'){
      let payload:{page_title_choice?:string;call_screen_name_text?:string;call_screen_business_text?:string;voice_choice?:string;linkedin_url?:string};
      if(input.action==='display'){
        if(typeof input.value==='string')payload={page_title_choice:z.enum(['name','business']).parse(input.value)};
        else{
          const value=z.object({choice:z.enum(['name','business']),name:z.string().max(60),business:z.string().max(60)}).parse(input.value);
          const name=value.name.trim(),business=value.business.trim();
          const problem=callScreenProblem(value.choice==='name'?name:business);if(problem)return reply({error:problem},400);
          payload={page_title_choice:value.choice,call_screen_name_text:name,call_screen_business_text:business};
        }
      }
      else if(input.action==='voice')payload={voice_choice:z.enum(['female','male']).parse(input.value)};
      else{const profile=linkedinProfile(textValue ?? '');if(!profile)return reply({error:'Please paste your LinkedIn profile URL, like linkedin.com/in/yourname.'},400);payload={linkedin_url:profile};}
      const {data,error}=await database.from('client_slugs').update(payload).eq('id',bot.id).eq('ghl_location_id',loc).eq('status','active').select('id');
      if(error||!data?.length)throw new Error('Settings save failed');
      if(input.action==='voice')pending=!await applyVoice(loc,bot.id,z.enum(['female','male']).parse(input.value));
    }
    if(input.action==='greeting'){
      const greeting=z.object({choice:z.enum(['name','business']),name:z.string().max(60),business:z.string().max(60)}).parse(input.value);
      const name=greeting.name.trim(),business=greeting.business.trim(),selected=greeting.choice==='name'?name:business;
      const problem=greetingProblem(selected);if(problem)return reply({error:problem},400);
      const {data,error}=await database.from('client_slugs').update({greeting_choice:greeting.choice,greeting_name_text:name,greeting_business_text:business}).eq('id',bot.id).eq('ghl_location_id',loc).eq('status','active').select('id');
      if(error||!data?.length)throw new Error('Settings save failed');
      // A rejected external update is an expected form outcome, not a page/server failure.
      if(!await sendGreetingName(loc,selected))return reply({error:"Couldn't update your greeting. Please try again."});
    }
    bot=await botFor(loc);if(!bot)return reply({error:'Account unavailable'},401);
    return reply({bot:{slug:bot.slug,link_code:bot.link_code,...displayNames(bot),call_screen_name_text:bot.call_screen_name_text,call_screen_business_text:bot.call_screen_business_text,first_name:firstName(bot.full_name),greeting_choice:bot.greeting_choice,greeting_name_text:bot.greeting_name_text,greeting_business_text:bot.greeting_business_text,page_title_choice:bot.page_title_choice,voice_choice:bot.voice_choice || bot.voice_sent,linkedin_url:bot.linkedin_url},pending});
  }catch(error){console.error('LinkBot settings request failed',error instanceof z.ZodError?'invalid input':'operation failed');return reply({error:error instanceof z.ZodError?'Invalid request':'Something went wrong. Please try again.'},error instanceof z.ZodError?400:500);}
}