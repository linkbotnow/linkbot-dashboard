export function callScreenProblem(text: string) {
  if (!text.trim()) return 'Please enter a name.';
  if (text.trim().length > 60) return 'Use no more than 60 characters.';
  return null;
}