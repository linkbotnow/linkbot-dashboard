import { createDecipheriv, createHash, createHmac, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { SETTINGS_ACCESS_MS } from './settings-rules';
function key() { const value=process.env['LINKBOT_SETTINGS_SIGNING_KEY'];if(!value) throw new Error('Settings signing unavailable');return value; }
export function issueSettingsAccess(loc: string, now=Date.now()) {
  const payload=Buffer.from(JSON.stringify({loc,scope:'settings',expires:now+SETTINGS_ACCESS_MS})).toString('base64url');
  return `${payload}.${createHmac('sha256',key()).update(payload).digest('base64url')}`;
}
export function settingsLocation(token: string,now=Date.now()) {
  try {
    const [payload,signature,extra]=token.split('.');if(!payload||!signature||extra)return null;
    const expected=createHmac('sha256',key()).update(payload).digest(),supplied=Buffer.from(signature,'base64url');
    if(expected.length!==supplied.length||!timingSafeEqual(expected,supplied))return null;
    const data=z.object({loc:z.string().min(1).max(255),scope:z.literal('settings'),expires:z.number()}).parse(JSON.parse(Buffer.from(payload,'base64url').toString()));
    return data.expires>now?data.loc:null;
  } catch{return null;}
}
const safeText=(value:unknown)=>typeof value==='string'?value.replace(/[^\w.-]/g,'').slice(0,40):typeof value;
export function decryptContext(encryptedData: string) {
  const secret=process.env['LINKBOT_APP_SHARED_SECRET'];
  const facts:Record<string,unknown>={payloadLength:encryptedData.length,saltedPrefix:encryptedData.startsWith('U2FsdGVkX1'),secretLength:secret?.length??0};
  let step='base64 decode';
  try{
    if(!secret){step='secret missing';throw new Error('Context verification unavailable');}
    const data=Buffer.from(encryptedData,'base64');
    step='missing Salted__ marker';if(data.length<32||data.subarray(0,8).toString()!=='Salted__')throw new Error('Invalid context');
    step='AES unlock (bad decrypt)';
    const salt=data.subarray(8,16),password=Buffer.from(secret);let derived=Buffer.alloc(0),previous=Buffer.alloc(0);
    while(derived.length<48){previous=createHash('md5').update(Buffer.concat([previous,password,salt])).digest();derived=Buffer.concat([derived,previous]);}
    const decipher=createDecipheriv('aes-256-cbc',derived.subarray(0,32),derived.subarray(32,48));
    const plain=Buffer.concat([decipher.update(data.subarray(16)),decipher.final()]).toString('utf8');
    step='text to JSON';const parsed=JSON.parse(plain);
    if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed)){facts['keys']=Object.keys(parsed).map(safeText).slice(0,40);facts['type']=safeText(parsed['type']);}
    step='context check';
    const result=z.object({type:z.enum(['location','agency']),activeLocation:z.string().min(1).max(255)}).parse(parsed);
    console.info('context unlock',JSON.stringify({...facts,result:'ok'}));
    return result;
  }catch(error){console.warn('context unlock',JSON.stringify({...facts,failedStep:step}));throw error;}
}