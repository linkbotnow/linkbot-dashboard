import { claimSlugFormatMessage, normalizeClaimSlug, validateClaimSlug } from '../claim-slug';
export const SETTINGS_ACCESS_MS = 30 * 60 * 1000;
export function domainProblem(raw: string) {
  const format = claimSlugFormatMessage(raw);
  if (format) return format;
  const problem = validateClaimSlug(normalizeClaimSlug(raw));
  if (problem === 'empty' || problem === 'too_short') return 'Use at least 3 characters.';
  if (problem === 'reserved') return 'Domain taken. Please try another.';
  if (problem === 'format') return 'Letters, numbers, periods, underscores and hyphens only. No period at the start or end, or two in a row.';
  return null;
}
export function linkedinProfile(raw: string) {
  try {
    const url = new URL(/^https?:\/\//i.test(raw.trim()) ? raw.trim() : `https://${raw.trim()}`);
    if (url.protocol !== 'https:' || !['linkedin.com','www.linkedin.com'].includes(url.hostname.toLowerCase()) || url.username || url.password || url.port || !/^\/in\/[a-zA-Z0-9_%\-]+\/?$/.test(url.pathname)) return null;
    url.search = ''; url.hash = ''; return url.toString();
  } catch { return null; }
}
export function onlyWidget(widgets: { _id: string }[], total = widgets.length) { return widgets.length === 1 && total === 1 ? widgets[0]?._id ?? null : null; }
export function displayNames(bot: { full_name: string | null; last_name: string | null; company_name: string | null; slug: string }) {
  return { person: [bot.full_name, bot.last_name].filter(Boolean).join(' ').trim() || bot.slug, business: (bot.company_name ?? '').trim() };
}
// Empty values shown when a GoHighLevel sub-account has no active LinkBot yet.
export function emptySettingsBot() {
  return { slug: '', link_code: '', person: '', business: '', first_name: '', greeting_choice: 'name', greeting_name_text: '', greeting_business_text: '', page_title_choice: 'name', voice_choice: 'female', linkedin_url: '' };
}