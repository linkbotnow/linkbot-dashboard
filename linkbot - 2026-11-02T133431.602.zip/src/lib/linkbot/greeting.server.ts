import { getLocationToken } from './app.server';
import { firstName } from './greeting-rules';

/** Uses the same location credentials and custom-value method as Business Info. */
export async function sendGreetingName(loc: string, value: string): Promise<boolean> {
  try {
    const token = loc === process.env['LIVEDEMO_GHL_LOCATION_ID'] ? process.env['GHL_BUSINESS_INFO_TOKEN'] : await getLocationToken(loc);
    if (!token) { console.warn('Greeting Name location token unavailable'); return false; }
    const headers = { authorization: `Bearer ${token}`, version: '2021-07-28', accept: 'application/json', 'content-type': 'application/json' };
    const base = `https://services.leadconnectorhq.com/locations/${encodeURIComponent(loc)}/customValues`;
    const list = await fetch(base, { headers, signal: AbortSignal.timeout(10000) });
    if (!list.ok) throw new Error('Custom values read failed');
    const found = ((await list.json()) as { customValues?: { id: string; name: string }[] }).customValues?.find(x => x.name === 'Greeting Name');
    if (!found) { console.error('Greeting Name custom value not found for location'); return false; }
    const update = await fetch(`${base}/${encodeURIComponent(found.id)}`, { method: 'PUT', headers, body: JSON.stringify({ name: 'Greeting Name', value }), signal: AbortSignal.timeout(10000) });
    if (!update.ok) throw new Error('Custom value update failed');
    return true;
  } catch { console.error('Greeting Name update failed'); return false; }
}

export async function initializeGreetingName(loc: string, fullName: string | null) {
  return sendGreetingName(loc, firstName(fullName));
}

/** 4L27: fills "Owner Email", "Owner First Name" and "Company Name" with the same credentials and
 * error handling as Greeting Name. Only existing values with those exact names are updated. */
export async function sendOwnerValues(loc: string, values: { email: string | null; fullName: string | null; companyName: string | null }): Promise<Record<string, boolean>> {
  const wanted: [string, string][] = [
    ['Owner Email', values.email ?? ''],
    ['Owner First Name', firstName(values.fullName)],
    ['Company Name', values.companyName ?? ''],
  ];
  const result: Record<string, boolean> = Object.fromEntries(wanted.map(([n]) => [n, false]));
  try {
    const token = loc === process.env['LIVEDEMO_GHL_LOCATION_ID'] ? process.env['GHL_BUSINESS_INFO_TOKEN'] : await getLocationToken(loc);
    if (!token) { console.warn('Owner custom values location token unavailable'); return result; }
    const headers = { authorization: `Bearer ${token}`, version: '2021-07-28', accept: 'application/json', 'content-type': 'application/json' };
    const base = `https://services.leadconnectorhq.com/locations/${encodeURIComponent(loc)}/customValues`;
    const list = await fetch(base, { headers, signal: AbortSignal.timeout(10000) });
    if (!list.ok) throw new Error('Custom values read failed');
    const all = ((await list.json()) as { customValues?: { id: string; name: string }[] }).customValues ?? [];
    for (const [name, value] of wanted) {
      try {
        const found = all.find(x => x.name === name);
        if (!found) { console.error(`${name} custom value not found for location`); continue; }
        const update = await fetch(`${base}/${encodeURIComponent(found.id)}`, { method: 'PUT', headers, body: JSON.stringify({ name, value }), signal: AbortSignal.timeout(10000) });
        if (!update.ok) throw new Error('Custom value update failed');
        result[name] = true;
      } catch { console.error(`${name} update failed`); }
    }
  } catch { console.error('Owner custom values update failed'); }
  return result;
}
