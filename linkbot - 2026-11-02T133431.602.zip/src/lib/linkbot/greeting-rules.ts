export type GreetingChoice = 'name' | 'business';
export function firstName(fullName: string | null) {
  return (fullName ?? '').trim().split(/\s+/)[0] ?? '';
}
export function greetingProblem(text: string) {
  const trimmed = text.trim();
  if (!trimmed) return 'Please enter a name.';
  if (trimmed.length > 60) return 'Use no more than 60 characters.';
  if (/['’]s$/i.test(trimmed)) return 'Please remove the ’s. It’s added automatically.';
  return null;
}