// Exact WEBSITE_RE from HeroDemo; claim adds a bare-name check without changing the demo.
const WEBSITE_RE = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d{1,5})?(?:[/?#].*)?$/i;
export function claimWebsiteShape(website: string) {
  return WEBSITE_RE.test(website.trim().replace(/^www\./i, ""));
}

export async function claimWebsiteExists(website: string, lookup: typeof fetch = fetch): Promise<boolean> {
  if (!claimWebsiteShape(website)) return false;
  const host = new URL(`https://${website.trim()}`).hostname.replace(/^www\./i, "");
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<boolean>(resolve => {
    timer = setTimeout(() => { controller.abort(); resolve(true); }, 3000);
  });
  try {
    const queries = [host, `www.${host}`].flatMap(name => ["A", "AAAA", "CNAME"].map(async type => {
      try {
        const response = await lookup(`https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`, { signal: controller.signal });
        if (!response.ok) return "unavailable";
        const result = await response.json() as { Status?: number; Answer?: { type: number; data: string }[] };
        if (result.Status !== 0 && result.Status !== 3) return "unavailable";
        return result.Answer?.some(record => [1, 28, 5].includes(record.type) && !!record.data) ? "exists" : "missing";
      } catch { return "unavailable"; }
    }));
    return await Promise.race([Promise.all(queries).then(results => results.some(result => result !== "missing")), timeout]);
  } finally { clearTimeout(timer); }
}