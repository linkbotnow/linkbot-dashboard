// Full world list of calling codes. Format: "ISO|Country name|dial"
const RAW = `AF|Afghanistan|93
AL|Albania|355
DZ|Algeria|213
AD|Andorra|376
AO|Angola|244
AG|Antigua and Barbuda|1
AR|Argentina|54
AM|Armenia|374
AW|Aruba|297
AU|Australia|61
AT|Austria|43
AZ|Azerbaijan|994
BS|Bahamas|1
BH|Bahrain|973
BD|Bangladesh|880
BB|Barbados|1
BY|Belarus|375
BE|Belgium|32
BZ|Belize|501
BJ|Benin|229
BM|Bermuda|1
BT|Bhutan|975
BO|Bolivia|591
BA|Bosnia and Herzegovina|387
BW|Botswana|267
BR|Brazil|55
BN|Brunei|673
BG|Bulgaria|359
BF|Burkina Faso|226
BI|Burundi|257
KH|Cambodia|855
CM|Cameroon|237
CA|Canada|1
CV|Cape Verde|238
KY|Cayman Islands|1
CF|Central African Republic|236
TD|Chad|235
CL|Chile|56
CN|China|86
CO|Colombia|57
KM|Comoros|269
CG|Congo|242
CD|Congo (DRC)|243
CR|Costa Rica|506
CI|Cote d'Ivoire|225
HR|Croatia|385
CU|Cuba|53
CW|Curacao|599
CY|Cyprus|357
CZ|Czechia|420
DK|Denmark|45
DJ|Djibouti|253
DM|Dominica|1
DO|Dominican Republic|1
EC|Ecuador|593
EG|Egypt|20
SV|El Salvador|503
GQ|Equatorial Guinea|240
ER|Eritrea|291
EE|Estonia|372
SZ|Eswatini|268
ET|Ethiopia|251
FJ|Fiji|679
FI|Finland|358
FR|France|33
GA|Gabon|241
GM|Gambia|220
GE|Georgia|995
DE|Germany|49
GH|Ghana|233
GI|Gibraltar|350
GR|Greece|30
GD|Grenada|1
GT|Guatemala|502
GN|Guinea|224
GW|Guinea-Bissau|245
GY|Guyana|592
HT|Haiti|509
HN|Honduras|504
HK|Hong Kong|852
HU|Hungary|36
IS|Iceland|354
IN|India|91
ID|Indonesia|62
IR|Iran|98
IQ|Iraq|964
IE|Ireland|353
IL|Israel|972
IT|Italy|39
JM|Jamaica|1
JP|Japan|81
JO|Jordan|962
KZ|Kazakhstan|7
KE|Kenya|254
KW|Kuwait|965
KG|Kyrgyzstan|996
LA|Laos|856
LV|Latvia|371
LB|Lebanon|961
LS|Lesotho|266
LR|Liberia|231
LY|Libya|218
LI|Liechtenstein|423
LT|Lithuania|370
LU|Luxembourg|352
MO|Macao|853
MG|Madagascar|261
MW|Malawi|265
MY|Malaysia|60
MV|Maldives|960
ML|Mali|223
MT|Malta|356
MR|Mauritania|222
MU|Mauritius|230
MX|Mexico|52
MD|Moldova|373
MC|Monaco|377
MN|Mongolia|976
ME|Montenegro|382
MA|Morocco|212
MZ|Mozambique|258
MM|Myanmar|95
NA|Namibia|264
NP|Nepal|977
NL|Netherlands|31
NZ|New Zealand|64
NI|Nicaragua|505
NE|Niger|227
NG|Nigeria|234
MK|North Macedonia|389
NO|Norway|47
OM|Oman|968
PK|Pakistan|92
PS|Palestine|970
PA|Panama|507
PG|Papua New Guinea|675
PY|Paraguay|595
PE|Peru|51
PH|Philippines|63
PL|Poland|48
PT|Portugal|351
PR|Puerto Rico|1
QA|Qatar|974
RO|Romania|40
RU|Russia|7
RW|Rwanda|250
KN|Saint Kitts and Nevis|1
LC|Saint Lucia|1
VC|Saint Vincent and the Grenadines|1
WS|Samoa|685
SM|San Marino|378
SA|Saudi Arabia|966
SN|Senegal|221
RS|Serbia|381
SC|Seychelles|248
SL|Sierra Leone|232
SG|Singapore|65
SK|Slovakia|421
SI|Slovenia|386
SB|Solomon Islands|677
SO|Somalia|252
ZA|South Africa|27
KR|South Korea|82
SS|South Sudan|211
ES|Spain|34
LK|Sri Lanka|94
SD|Sudan|249
SR|Suriname|597
SE|Sweden|46
CH|Switzerland|41
SY|Syria|963
TW|Taiwan|886
TJ|Tajikistan|992
TZ|Tanzania|255
TH|Thailand|66
TL|Timor-Leste|670
TG|Togo|228
TO|Tonga|676
TT|Trinidad and Tobago|1
TN|Tunisia|216
TR|Turkiye|90
TM|Turkmenistan|993
TC|Turks and Caicos Islands|1
UG|Uganda|256
UA|Ukraine|380
AE|United Arab Emirates|971
GB|United Kingdom|44
US|United States|1
UY|Uruguay|598
UZ|Uzbekistan|998
VU|Vanuatu|678
VE|Venezuela|58
VN|Vietnam|84
YE|Yemen|967
ZM|Zambia|260
ZW|Zimbabwe|263`;

export type PhoneCountry = {
  code: string;
  name: string;
  flag: string;
  label: string;
  short: string;
  dial: string;
  na: boolean;
};

function flagFor(code: string) {
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

const NORTH_AMERICAN = new Set(["US", "CA"]);

const PARSED: PhoneCountry[] = RAW.split("\n").map((line) => {
  const parts = line.split("|");
  const code = parts[0] ?? "";
  const name = parts[1] ?? "";
  const dial = parts[2] ?? "";
  const flag = flagFor(code);
  return {
    code,
    name,
    flag,
    label: `${flag} ${name}`,
    short: `+${dial}`,
    dial: `+${dial}`,
    na: NORTH_AMERICAN.has(code),
  };
});

// Keep the most common markets at the top, then the rest alphabetically.
const PRIORITY = ["US", "CA", "GB", "AU", "MX", "IN", "DE", "BR"];

export const PHONE_COUNTRIES: PhoneCountry[] = [
  ...PRIORITY.map((code) => PARSED.find((c) => c.code === code)!).filter(Boolean),
  ...PARSED.filter((c) => !PRIORITY.includes(c.code)).sort((a, b) => a.name.localeCompare(b.name)),
];

/** Reads a whole typed, pasted or autofilled phone value (country code included) for the selected country. */
export function parsePhone(raw: string, country: PhoneCountry): { country: PhoneCountry; digits: string } {
  let digits = raw.replace(/\D/g, "");
  let next = country;
  if (raw.trim().startsWith("+")) {
    const byDial = PHONE_COUNTRIES.filter((c) => digits.startsWith(c.dial.slice(1))).sort((x, y) => y.dial.length - x.dial.length);
    const longest = byDial[0];
    if (longest) {
      next = byDial.find((c) => c.code === country.code && c.dial === longest.dial) ?? byDial.find((c) => c.dial === longest.dial)!;
      digits = digits.slice(longest.dial.length - 1);
    }
  } else if (country.na && digits.length === 11 && digits.startsWith("1")) {
    digits = digits.slice(1);
  }
  return { country: next, digits: digits.slice(0, next.na ? 10 : 15) };
}
