// Values remain case-sensitive: an ID is a capability, not a search term.
export const CALL_SHARE_WINDOW_MINUTES = 60;
export const CALL_SHARE_POLL_MS = 2000;
export const isCallShareId = (value: unknown): value is string => typeof value === 'string' && value.length <= 512 && (/^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/.test(value) || /^[A-Za-z0-9_-]{16,}$/.test(value));
const sensitive = (key: string) => /authorization|cookie|password|secret|(?:^|[-_])(?:key|token)(?:$|[-_])|api[-_]?key/i.test(key) || key.toLowerCase() === 'x-linkbot-key';
const staticId = (key: string) => /^(?:account|page|slug|link_?code|link_?id|location_?id|company_?id|agent_?id|bot_?id|widget_?id)$/i.test(key.replace(/-/g, '_'));
const callIdRank = (key: string) => {
  const name = key.replace(/[-_]/g, '').toLowerCase();
  return ['callid', 'voicecallid', 'sessionid', 'conversationid'].indexOf(name);
};
export function sanitizeCallRequest(value: unknown, secrets: string[], depth = 0): unknown {
  if (depth > 30) return '[depth limit]';
  if (typeof value === 'string') {
    let clean = value;
    for (const secret of secrets.filter(Boolean)) clean = clean.split(secret).join('[redacted]');
    try { return sanitizeCallRequest(JSON.parse(clean), secrets, depth + 1); } catch { return clean; }
  }
  if (Array.isArray(value)) return value.map(item => sanitizeCallRequest(item, secrets, depth + 1));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, sensitive(key) ? '[redacted]' : sanitizeCallRequest(item, secrets, depth + 1)]));
  return value;
}
export function callShareIdentity(raw: unknown, excluded: string[]) {
  const ids = new Set<string>(), blocked = new Set(excluded.filter(Boolean));
  const calls: { id: string; rank: number }[] = [];
  const walk = (value: unknown, key = '', depth = 0) => {
    if (depth > 30) return;
    if (typeof value === 'string') {
      try { const nested = JSON.parse(value); if (nested && typeof nested === 'object') { walk(nested, key, depth + 1); return; } } catch {}
      if (!isCallShareId(value)) return;
      ids.add(value);
      if (staticId(key)) blocked.add(value);
      const rank = callIdRank(key);
      if (rank >= 0) calls.push({ id: value, rank });
      return;
    }
    if (Array.isArray(value)) value.forEach(item => walk(item, key, depth + 1));
    else if (value && typeof value === 'object') Object.entries(value).forEach(([name, item]) => walk(item, name, depth + 1));
  };
  walk(raw);
  // Without an explicit call/session/conversation ID, distinct calls cannot be proven.
  // Fail closed rather than treating a contact, bot, fingerprint or request ID as a call.
  const call = calls.filter(item => !blocked.has(item.id)).sort((a, b) => a.rank - b.rank)[0];
  return { ids: [...ids], excluded_ids: [...blocked], call_key: call?.id ?? null };
}