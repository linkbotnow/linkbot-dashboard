/** Shared on/off switch: is /claim currently showing its full-page voice choice? */
import { useSyncExternalStore } from "react";

let active = false;
const listeners = new Set<() => void>();

export function setClaimVoiceStep(next: boolean): void {
  if (active === next) return;
  active = next;
  listeners.forEach((listener) => listener());
}

export function isClaimVoiceStep(): boolean {
  return active;
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useClaimVoiceStep(): boolean {
  return useSyncExternalStore(subscribe, () => active, () => false);
}
