// 196: server error page uses the site's compiled stylesheet (inlined at build time) and real button classes.
import appCss from "@/styles.css?inline";
import { FIT_LINE_SCRIPT } from "@/lib/fit-line";

export function renderErrorPage(): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Manrope:wght@400;500;600;700;800&display=swap">
    <style>${appCss}</style>
  </head>
  <body style="background:#000">
    <div class="lb-message-page"><div class="lb-message-inner"><div class="lb-message-lines"><div class="lb-message-line" data-fit-line>This page didn't load.</div><div class="lb-message-line" data-fit-line>Something went wrong on our end.</div></div><button type="button" class="linkbot-button lb-message-button" onclick="location.reload()"><span>Try Again</span></button></div></div>
    ${FIT_LINE_SCRIPT}
  </body>
</html>`;
}
