export const DESKTOP_CANVAS_WIDTH = 1440;
/** Header height as authored on the 1440px canvas. */
export const DESKTOP_HEADER_HEIGHT = 92;

export function getDesktopScale(viewportWidth: number) {
  return Math.max(1, viewportWidth) / DESKTOP_CANVAS_WIDTH;
}

export function isPhoneLandscapeViewport() {
  const screenWidth = Math.max(window.screen.width, window.screen.height);
  const screenHeight = Math.min(window.screen.width, window.screen.height);
  return window.matchMedia("(orientation: landscape)").matches && screenHeight <= 600 && screenWidth > screenHeight;
}

export function getDesktopViewport() {
  const phoneLandscape = isPhoneLandscapeViewport();
  // A sideways phone always lays out the 1440px canvas. Reading clientWidth
  // there can return a transient value while a reload restores the old zoom
  // or the toolbars animate, which then gets locked in as the page size.
  const layoutWidth = phoneLandscape
    ? DESKTOP_CANVAS_WIDTH
    : Math.max(1, document.documentElement.clientWidth);

  return {
    width: layoutWidth,
    layoutWidth,
    offsetLeft: 0,
    phoneLandscape,
  };
}

export function waitForStableWidth(done: () => void) {
  let last = -1, same = 0, frame = 0;
  const start = performance.now();
  const tick = () => {
    const w = document.documentElement.clientWidth;
    same = w === last ? same + 1 : 0;
    last = w;
    if (same >= 3 || performance.now() - start > 700) { done(); return; }
    frame = requestAnimationFrame(tick);
  };
  frame = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(frame);
}
