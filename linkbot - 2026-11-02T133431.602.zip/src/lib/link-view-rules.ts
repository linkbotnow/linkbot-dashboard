export const MODE_CACHE_MS = 3600000;
export const PROXY_CACHE_MS = 600000;
export const VIEW_TIMEOUT_MS = 8000;
export const MAX_VIEW_BYTES = 5 * 1024 * 1024;
export const MAX_VIEW_REDIRECTS = 5;
export const SNAPSHOT_WIDTH = 390;
export const SNAPSHOTS_ENABLED = false;
export const SNAPSHOT_REFRESH_MS = 86400000;
export const RISKY_LINK = /(?:\/(?:log-?in|sign-?in|sign-?up|register|account|my-account|checkout|cart|pay|payment|payments|billing|portal|dashboard|auth|oauth)(?:[\/?#.]|$))|payment-link|buy\.stripe|checkout\.|^https?:\/\/(?:[^\/]*\.)?(?:linkedin\.com|lnkd\.in|facebook\.com|fb\.com|instagram\.com|twitter\.com|x\.com|tiktok\.com|threads\.net|pinterest\.com|reddit\.com|snapchat\.com|paypal\.com|paypal\.me|stripe\.com|squareup\.com|square\.link|venmo\.com|cash\.app|amazon\.com|amzn\.to|apps\.apple\.com|play\.google\.com|bit\.ly|tinyurl\.com)(?:[\/?#:]|$)/i;
export function publicHttps(url: URL) {
  const host = url.hostname.toLowerCase().replace(/\.$/, '');
  return url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443')
    && host.includes('.') && !/^[\d.]+$/.test(host) && !host.includes(':')
    && !/(?:^|\.)(localhost|local|internal|test|invalid|onion)$/.test(host);
}
export function publicAddress(address: string) {
  if (address.includes(':')) return /^2[0-9a-f]{3}:/i.test(address) && !/^2001:(db8|0):/i.test(address) && !/^2002:/i.test(address);
  const parts = address.split('.').map(Number);
  if (parts.length !== 4 || parts.some(x => !Number.isInteger(x) || x < 0 || x > 255)) return false;
  const [a, b, c] = parts;
  return a !== undefined && b !== undefined && a > 0 && a < 224 && a !== 10 && a !== 127
    && !(a === 169 && b === 254) && !(a === 172 && b >= 16 && b <= 31)
    && !(a === 192 && [0, 168].includes(b)) && !(a === 192 && b === 88 && c === 99)
    && !(a === 100 && b >= 64 && b <= 127) && !(a === 198 && [18, 19].includes(b))
    && !(a === 198 && b === 51 && c === 100) && !(a === 203 && b === 0 && c === 113);
}
export function allowsFraming(headers: Headers) {
  let ancestors = false;
  const allowed = (headers.get('content-security-policy') ?? '').split(',').every(policy => {
    const directive = policy.split(';').map(s => s.trim()).find(s => /^frame-ancestors\b/i.test(s));
    if (!directive) return true;
    ancestors = true;
    return directive.split(/\s+/).slice(1).some(s => ['*', 'https:', 'https://linkbot.now', 'linkbot.now'].includes(s.toLowerCase().replace(/\/$/, '')));
  });
  return allowed && (ancestors || !(headers.get('x-frame-options') ?? '').trim());
}
export function challengeHtml(html: string) {
  return /<title[^>]*>\s*(?:just a moment|attention required|access denied|please wait|verify|robot|security check)|cf-chl-|challenge-platform|captcha-delivery|checking your browser|verify you are human|performing security verification|verifies you are not a bot|incapsula incident|datadome-captcha/i.test(html);
}
export function chooseViewMode(url: string, framing: boolean, usableHtml: boolean): 'live' | 'proxy' | 'snapshot' {
  return RISKY_LINK.test(url) ? 'snapshot' : framing ? 'live' : usableHtml ? 'proxy' : 'snapshot';
}
