import { z } from 'zod';

export const ACCESS_MS = 12 * 60 * 60 * 1000;
export const MAX_FAILURES = 10;
export const LOCK_MINUTES = 15;
export const shouldOpenSetupGuide = (seenAt: string | null | undefined) => !seenAt;
export function privateGuideLink(code: string | null | undefined, status: string, activatedAt: string | null | undefined) {
  return status === 'active' && activatedAt && code && /^[A-Za-z0-9]{12}$/.test(code) ? `https://linkbot.now/${code}` : null;
}
export const LinkInput = z.object({
  id: z.string().uuid().optional(),
  url: z.string().trim().min(1).max(2048),
  full_title: z.string().trim().min(1).max(120),
  button_name: z.string().trim().min(1).max(25),
  who_its_for: z.string().trim().min(1).max(250),
  details: z.string().trim().min(1).max(5000),
  extra_notes: z.string().trim().max(400).nullable(),
  category: z.string().trim().max(30).nullable(),
  price: z.string().trim().max(40).nullable(),
  is_on: z.boolean(),
  is_main_website: z.boolean().default(false),
});
export type LinkValues = z.infer<typeof LinkInput>;
export type MyLink = LinkValues & { id: string; created_at: string; updated_at: string };
export const normalizedName = (name: string) => name.trim().toLowerCase();
export const DUPLICATE_URL_ERROR = 'This link is already saved. Add any extra details to that link instead.';
export function normalizedLinkUrl(raw: string) {
  const value = raw.trim().replace(/^https?:\/\//i, '').replace(/\/$/, '');
  const host = value.match(/^[^/?#]+/)?.[0] ?? '';
  return host.toLowerCase().replace(/^www\./, '') + value.slice(host.length);
}
export function normalizeUrl(raw: string) {
  return /^[a-z][a-z\d+.-]*:/i.test(raw.trim()) ? raw.trim() : `https://${raw.trim()}`;
}
export function categoryOrder(links: MyLink[]) {
  const counts = new Map<string, number>();
  for (const link of links) if (link.category) counts.set(link.category, (counts.get(link.category) ?? 0) + 1);
  return [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
}
export function orderedLinks(links: MyLink[], category = '') {
  const groups = categoryOrder(links).map(([name]) => name);
  return links.filter(link => !category || link.category === category).sort((a, b) => {
    if (a.is_on !== b.is_on) return a.is_on ? 1 : -1;
    if (!category && a.is_on) {
      const ai = a.category ? groups.indexOf(a.category) : groups.length;
      const bi = b.category ? groups.indexOf(b.category) : groups.length;
      if (ai !== bi) return ai - bi;
    }
    return b.created_at.localeCompare(a.created_at);
  });
}
export type BusinessInfoLink = { button_name: string; site_info?: string | null; is_on?: boolean; is_main_website?: boolean };
export function buildBusinessInfo(links: BusinessInfoLink[]) {
  const blocks = links
    .filter(link => link.is_main_website !== false && link.is_on !== false && Boolean(link.site_info?.trim()))
    .map(link => {
      const lines = String(link.site_info).trim().split('\n');
      const first = lines[0] ?? '';
      const named = first.toLowerCase().startsWith('business name:');
      return {
        name: (named ? first.slice(first.indexOf(':') + 1).trim() : '') || link.button_name,
        website: link.button_name,
        rest: (named ? lines.slice(1) : lines).join('\n').trim(),
      };
    });
  if (!blocks.length) return 'No business info has been added yet.';
  const header = blocks.length === 1
    ? 'This person has 1 business. Its information is below.'
    : `This person has ${blocks.length} separate businesses. Each one has its own information below. Never mix details between them.`;
  const render = (items: typeof blocks) => `${header}\n\n${items.map((b, i) => `=== BUSINESS ${i + 1}: ${b.name} ===\nWebsite: ${b.website}${b.rest ? `\n${b.rest}` : ''}\n=== END OF BUSINESS ${i + 1} ===`).join('\n\n')}`;
  return render(blocks);
}