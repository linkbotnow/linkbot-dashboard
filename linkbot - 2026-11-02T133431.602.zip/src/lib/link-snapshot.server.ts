import { boundedBody, fetchPage } from './link-view.server';
import { SNAPSHOT_WIDTH, SNAPSHOTS_ENABLED, challengeHtml } from './link-view-rules';
async function db() { return (await import('@/integrations/supabase/client.server')).supabaseAdmin; }
// At most 90 ScreenshotOne requests per calendar month across all accounts, counted atomically in the database.
const MONTHLY_LIMIT = 90;
// Phrases that appear only on bot-verification pages; the provider fails the capture if any of them shows.
const CHALLENGE_PHRASES = ['just a moment', 'verify you are human', 'checking your browser', 'attention required', 'captcha', 'security check', 'performing security verification', 'verifies you are not a bot', 'performance and security by cloudflare'];
// Full-page height from the PNG header (0 when unreadable).
function pngHeight(bytes: Uint8Array) {
  if (bytes.length < 24 || bytes[0] !== 0x89 || bytes[1] !== 0x50) return 0;
  return (((bytes[20] ?? 0) << 24) | ((bytes[21] ?? 0) << 16) | ((bytes[22] ?? 0) << 8) | (bytes[23] ?? 0)) >>> 0;
}
type LinkRow = { url: string; snapshot_path: string | null };
// A challenged site is marked blocked so calls hold the link until after the call; any saved challenge image is deleted.
async function markBlocked(database: Awaited<ReturnType<typeof db>>, loc: string, id: string, link: LinkRow) {
  await database.from('my_links').update({ snapshot_blocked_at: new Date().toISOString(), snapshot_path: null, snapshot_url_source: null, snapshot_captured_at: null }).eq('id', id).eq('ghl_location_id', loc);
  if (link.snapshot_path) await database.storage.from('link-snapshots').remove([link.snapshot_path]);
}
export async function captureSnapshot(loc: string, id: string, version: string): Promise<{ captured: boolean; reason?: string }> {
  if (!SNAPSHOTS_ENABLED) return { captured: false, reason: 'disabled' };
  let stage = 'key';
  const report = (reason: string) => { console.info('Link snapshot', { id, stage, reason }); return { captured: false, reason }; };
  try {
  const key = process.env['SCREENSHOTONE_ACCESS_KEY'];
  if (!key) return report('key_missing');
  stage = 'lookup';
  const database = await db();
  const { data: link, error } = await database.from('my_links').select('url,snapshot_path').eq('ghl_location_id', loc).eq('id', id).eq('updated_at', version).maybeSingle();
  if (error) throw new Error('Snapshot link lookup failed');
  if (!link) return report('version_changed');
  // Validate DNS and every HTTP redirect ourselves before requesting any capture.
  // A page that answers our probe with a bot-verification challenge is never captured: it is marked blocked instead.
  stage = 'destination_validation';
  let finalUrl: string;
  try {
    const probe = await fetchPage(link.url);
    if (challengeHtml(probe.html)) { stage = 'blocked'; await markBlocked(database, loc, id, link); return report('blocked'); }
    finalUrl = probe.finalUrl;
  } catch {
    // Transport failures and non-HTML answers still let the provider try, with the same destination validation.
    finalUrl = (await fetchPage(link.url, true)).finalUrl;
  }
  stage = 'monthly_cap';
  const { data: allowed, error: capError } = await database.rpc('take_snapshot_request', { p_limit: MONTHLY_LIMIT });
  if (capError) throw new Error('Snapshot usage check failed');
  if (allowed !== true) return report('monthly_cap');
  stage = 'provider';
  const response = await fetch('https://api.screenshotone.com/take', { method: 'POST', signal: AbortSignal.timeout(24000), headers: { 'content-type': 'application/json', 'X-Access-Key': key }, body: JSON.stringify({ url: finalUrl, viewport_width: SNAPSHOT_WIDTH, viewport_height: 844, device_scale_factor: 1, full_page: true, format: 'png', block_ads: true, block_cookie_banners: true, ignore_host_errors: true, timeout: 20, fail_if_content_contains: CHALLENGE_PHRASES }) });
  if (!response.ok) {
    // Never log provider bodies: they can include the access key or request URL.
    console.error('ScreenshotOne failed:', response.status);
    const code = await response.json().then((body) => String((body as { error_code?: string })?.error_code ?? '')).catch(() => '');
    // The provider rendered a challenge page anyway: nothing is saved and the link is marked blocked.
    if (code.includes('content_contains')) { stage = 'blocked'; await markBlocked(database, loc, id, link); return report('blocked'); }
    throw new Error('Snapshot capture failed');
  }
  if (!(response.headers.get('content-type') ?? '').startsWith('image/png')) throw new Error('Invalid snapshot');
  const bytes = await boundedBody(response, 20 * 1024 * 1024);
  const height = pngHeight(bytes);
  if (!height) throw new Error('Invalid snapshot');
  // A full-page capture no taller than one viewport is a challenge or blank page — real pages are taller at 390px wide. Never save it.
  if (height <= 844) { stage = 'blocked'; await markBlocked(database, loc, id, link); return report('blocked'); }
  const path = `${id}/${crypto.randomUUID()}.png`;
  stage = 'storage';
  const upload = await database.storage.from('link-snapshots').upload(path, bytes, { contentType: 'image/png', upsert: false });
  if (upload.error) throw new Error('Snapshot storage failed');
  stage = 'save';
  const result = await database.from('my_links').update({ snapshot_path: path, snapshot_url_source: link.url, snapshot_captured_at: new Date().toISOString(), snapshot_blocked_at: null }).eq('id', id).eq('ghl_location_id', loc).eq('updated_at', version).select('id');
  if (result.error || !result.data?.length) { await database.storage.from('link-snapshots').remove([path]); return report('version_changed'); }
  if (link.snapshot_path) await database.storage.from('link-snapshots').remove([link.snapshot_path]);
  console.info('Link snapshot', { id, stage: 'complete', captured: true });
  return { captured: true };
  } catch (error) { console.error('Link snapshot stopped', { id, stage }); throw error; }
}
// One-time catch-up: every ON link with no saved screenshot and no blocked mark. Never scheduled.
export async function refreshSnapshots() {
  if (!SNAPSHOTS_ENABLED) return { captured: 0, blocked: 0, reason: 'disabled' };
  if (!process.env['SCREENSHOTONE_ACCESS_KEY']) return { captured: 0, blocked: 0, reason: 'key_missing' };
  const database = await db();
  const due: { id: string; ghl_location_id: string; updated_at: string }[] = [];
  for (let offset = 0;; offset += 100) {
    const { data, error } = await database.from('my_links').select('id,ghl_location_id,updated_at').eq('is_on', true).is('snapshot_path', null).is('snapshot_blocked_at', null).order('id').range(offset, offset + 99);
    if (error) throw new Error('Snapshot refresh lookup failed');
    if (!data?.length) break;
    due.push(...data);
    if (data.length < 100) break;
  }
  let captured = 0, blocked = 0;
  for (let i = 0; i < due.length; i += 5) {
    await Promise.all(due.slice(i, i + 5).map(async row => {
      try {
        const result = await captureSnapshot(row.ghl_location_id, row.id, row.updated_at);
        if (result.captured) captured++;
        else if (result.reason === 'blocked') blocked++;
      } catch { console.error('Snapshot refresh failed for link', row.id); }
    }));
  }
  return { captured, blocked };
}
