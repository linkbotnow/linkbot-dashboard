import type { PhoneCountry } from "@/lib/phone-countries";

// 244: phones sign on their own /sign page. The /claim form travels there and back
// in memory only (never sessionStorage), so the password is never stored anywhere.
export type ClaimDraft = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  phoneCountry: PhoneCountry;
  password: string;
  confirmPassword: string;
  companyName: string;
  website: string;
  rawSlug: string;
  slug: string;
};

export type SignHandoff = { kind: "claim"; draft: ClaimDraft; expectedName: string; signatureName?: string };

let current: SignHandoff | null = null;

export const setSignHandoff = (h: SignHandoff | null) => {
  current = h;
};
export const getSignHandoff = () => current;

/** Phones use /sign; iPad and desktop keep the pop-up. */
export function isPhoneSignPage() {
  if (typeof window === "undefined") return false;
  const isIPad = /iPad/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  return !isIPad && window.matchMedia("(max-width: 640px)").matches;
}
