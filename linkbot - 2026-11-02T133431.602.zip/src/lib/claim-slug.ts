/** Client-safe helpers for the personal-link picker. Pure and deterministic. */

export const MAX_SLUG_LENGTH = 30;

/**
 * Letters, numbers, periods, underscores and hyphens; 3–30 characters.
 * No period at the start or end, and never two periods in a row.
 */
export const CLAIM_SLUG_PATTERN = /^(?=.{3,30}$)[a-z0-9_-]+(?:\.[a-z0-9_-]+)*$/;

/** Paths the app itself owns, so they can never be claimed. */
export const RESERVED_CLAIM_SLUGS = new Set([
  "admin",
  "api",
  "app",
  "assets",
  "auth",
  "billing",
  "checkout",
  "claim",
  "dashboard",
  "demo",
  "favicon",
  "help",
  "legal",
  "refund",
  "ai-disclosure",
  "login",
  "logout",
  "onboarding",
  "privacy",
  "linkbot",
  "linkedbot",
  "robots",
  "signup",
  "static",
  "support",
  "terms",
  "test",
  "v",
  "www",
  "welcome",
  "welcome1",
  "welcome2",
  "welcome3",
  "welcome4",
  "welcome5",
  "welcome6",
  "welcome7",
  "welcome8",
  "welcome9",
  "welcome10",
  "sign",
  "forgot-password",
  "reset-password",
  "robots.txt",
  "favicon.ico",
  "favicon.png",
  "apple-touch-icon.png",
  "icon-512.png",
  "linkbot-share.png",
  "sitemap.xml",
]);

/** Lowercase and strip anything that is not a letter, number, period, underscore or hyphen. */
export function normalizeClaimSlug(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, "")
    .slice(0, MAX_SLUG_LENGTH);
}

export type ClaimSlugProblem = "empty" | "too_short" | "format" | "reserved" | null;

export function validateClaimSlug(slug: string): ClaimSlugProblem {
  if (!slug) return "empty";
  if (slug.length < 3) return "too_short";
  if (!CLAIM_SLUG_PATTERN.test(slug)) return "format";
  if (RESERVED_CLAIM_SLUGS.has(slug)) return "reserved";
  return null;
}

/**
 * Points at the exact character that breaks the format rules in the raw typed
 * name (the picker strips bad characters as they are typed, so this must be
 * checked before normalizing). Uppercase letters are allowed — they lowercase.
 */
export function claimSlugFormatMessage(raw: string): string | null {
  const invalid = raw.match(/[^a-zA-Z0-9._-]/);
  if (invalid) return `"${invalid[0]}" is not valid.`;
  if (raw.startsWith(".") || raw.endsWith(".")) {
    return `No period at the start or end.`;
  }
  if (raw.includes("..")) {
    return `No two periods in a row.`;
  }
  return null;
}

/** Details carried over from the landing demo form. */
export interface ClaimContact {
  firstName: string;
  lastName?: string;
  email: string;
  phone?: string;
  companyName?: string;
  website?: string;
}

export const CLAIM_CONTACT_STORAGE_KEY = "linkbot-claim-contact";

export function readStoredClaimContact(): ClaimContact | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(CLAIM_CONTACT_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ClaimContact>;
    if (!parsed || typeof parsed.email !== "string" || !parsed.email.includes("@")) return null;
    return {
      firstName: typeof parsed.firstName === "string" ? parsed.firstName : "",
      ...(typeof parsed.lastName === "string" ? { lastName: parsed.lastName } : {}),
      email: parsed.email,
      ...(typeof parsed.phone === "string" ? { phone: parsed.phone } : {}),
      ...(typeof parsed.companyName === "string" ? { companyName: parsed.companyName } : {}),
      ...(typeof parsed.website === "string" ? { website: parsed.website } : {}),
    };
  } catch {
    return null;
  }
}

export function storeClaimContact(contact: ClaimContact): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(CLAIM_CONTACT_STORAGE_KEY, JSON.stringify(contact));
  } catch {
    /* storage unavailable – the picker asks for the details instead */
  }
}
