// Prompt 41: on real phones the layout width is locked at load. The pre-paint
// script in __root.tsx installs window.__mhLock; this helper lets size
// watchers skip callbacks while iOS reports a transient bad width (wake from
// background / app switcher). Everywhere else it is a no-op.
type MhLock = { bad: () => boolean };

export function phoneLayoutUnstable(): boolean {
  if (typeof window === "undefined") return false;
  const lock = (window as unknown as { __mhLock?: MhLock }).__mhLock;
  try {
    return lock ? lock.bad() : false;
  } catch {
    return false;
  }
}

export function lockedResizeObserver(callback: () => void): ResizeObserver {
  return new ResizeObserver(() => {
    if (phoneLayoutUnstable()) return;
    callback();
  });
}
