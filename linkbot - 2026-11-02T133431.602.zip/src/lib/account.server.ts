/** Customer account helpers: password hashing, sessions. Server only. */
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { getCookie, setCookie } from "@tanstack/react-start/server";

export const SESSION_COOKIE = "lb_session";
const SESSION_DAYS = 30;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  return `scrypt$${salt}$${scryptSync(password, salt, 64).toString("hex")}`;
}

let DUMMY_HASH: string | undefined;
/** Created lazily on first use — module-scope crypto is disallowed in the deployed worker. */
function getDummyHash(): string {
  if (!DUMMY_HASH) DUMMY_HASH = hashPassword(randomBytes(12).toString("hex"));
  return DUMMY_HASH;
}

/** Constant-work check; a missing hash still runs scrypt so timing reveals nothing. */
export function verifyPassword(password: string, stored: string | null | undefined): boolean {
  const [scheme, salt, hex] = (stored ?? getDummyHash()).split("$");
  if (scheme !== "scrypt" || !salt || !hex) return false;
  const expected = Buffer.from(hex, "hex");
  const actual = scryptSync(password, salt, expected.length);
  return timingSafeEqual(actual, expected) && !!stored;
}

export const sha256 = (v: string) => createHash("sha256").update(v).digest("hex");

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

/** persistent=false gives a browser-session cookie that is dropped when the browser closes. */
export async function startSession(accountId: string, persistent = true) {
  const token = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5);
  const db = await admin();
  const { error } = await db.from("customer_sessions").insert({
    account_id: accountId,
    token_hash: sha256(token),
    expires_at: expires.toISOString(),
  });
  if (error) throw new Error("session create failed");
  setCookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    ...(persistent ? { expires } : {}),
  });
}

/** Deletes the visitor's session row and clears the cookie. */
export async function endSession() {
  const token = getCookie(SESSION_COOKIE);
  if (token) {
    const db = await admin();
    await db.from("customer_sessions").delete().eq("token_hash", sha256(token));
  }
  setCookie(SESSION_COOKIE, "", { httpOnly: true, secure: true, sameSite: "lax", path: "/", maxAge: 0 });
}

/** Account id of the signed-in visitor, or null. */
export async function currentAccountId(): Promise<string | null> {
  const token = getCookie(SESSION_COOKIE);
  if (!token) return null;
  const db = await admin();
  const { data } = await db
    .from("customer_sessions")
    .select("account_id, expires_at")
    .eq("token_hash", sha256(token))
    .maybeSingle();
  if (!data || new Date(data.expires_at).getTime() < Date.now()) return null;
  return data.account_id;
}

/** Where to go after sign-in: a same-site "next" or the app. */
export function safeNext(next?: string | null): string {
  const fallback = "https://app.linkbot.now";
  if (!next) return fallback;
  if (next.includes("\\") || [...next].some((c) => c.charCodeAt(0) < 32)) return fallback;
  if (next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\")) return next;
  try {
    const u = new URL(next);
    if (u.protocol === "https:" && (u.hostname === "linkbot.now" || u.hostname.endsWith(".linkbot.now"))) return u.toString();
  } catch { /* ignore */ }
  return fallback;
}
