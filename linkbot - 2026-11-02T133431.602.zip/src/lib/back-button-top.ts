import { isPhoneLandscapeViewport } from "@/lib/desktop-scale";

/** On-screen gap between the header's bottom and the /claim form Back button's
 *  top, as measured on /claim: 4% of the window width, and 63.9 on sideways
 *  phones (which always lay out the 1440 canvas). Used by the demo form and the
 *  voice step so their Back buttons sit at the same height. */
export function claimBackGap(): number {
  if (isPhoneLandscapeViewport()) return 63.9;
  return Math.max(1, document.documentElement.clientWidth) * 0.04;
}

/** Bottom edge of the visible pinned header on screen, or null. */
export function headerBottom(): number | null {
  const rects = [...document.querySelectorAll<HTMLElement>(".desktop-header-frame, header")]
    .map((el) => el.getBoundingClientRect())
    .filter((r) => r.height > 20 && r.top <= 1 && r.width > 0);
  return rects.length ? Math.max(...rects.map((r) => r.bottom)) : null;
}
