/**
 * Site-wide first-paint gate. The head script adds `pg-boot` to <html> before
 * anything is drawn (body hidden). After hydration we wait for fonts, then
 * for the page geometry (header, first heading, canvas size/state) to stay
 * identical for several consecutive frames, and only then reveal. A head
 * script cannot reveal an unmeasured canvas, even on a slow device.
 */
import { useEffect } from "react";
import { DESKTOP_CANVAS_WIDTH, DESKTOP_HEADER_HEIGHT, getDesktopViewport } from "@/lib/desktop-scale";

const STABLE_FRAMES = 4;
let readyPath: string | undefined;

function signature() {
  const parts: string[] = [];
  const header = [...document.querySelectorAll<HTMLElement>(".desktop-header-frame, header")].find(
    (el) => el.getBoundingClientRect().height > 0,
  );
  const h1 = document.querySelector("h1");
  for (const el of [header, h1]) {
    if (!el) { parts.push("-"); continue; }
    const r = el.getBoundingClientRect();
    parts.push(`${r.top.toFixed(1)},${r.height.toFixed(1)},${r.width.toFixed(1)}`);
  }
  const frame = document.querySelector(".desktop-scale-frame");
  parts.push(frame ? String(frame.classList.contains("is-measured")) : "-");
  // Observe the committed sizing, including local tablet/phone fits, rather
  // than treating an unchanged document height as an unchanged composition.
  for (const el of document.querySelectorAll<HTMLElement>(
    ".desktop-scale-canvas, .hero-main-composition, .mobile-home-root, .claim-page-root, .claim-grid, .login-page-root, .login-split, .login-premium-card, .login-card-column",
  )) {
    const style = getComputedStyle(el);
    parts.push(`${el.offsetWidth},${el.offsetHeight},${style.transform},${style.zoom},${el.getAttribute("style") ?? ""}`);
  }
  parts.push(String(document.documentElement.scrollHeight));
  return parts.join("|");
}

/** A stable fallback is not a correctly sized page. Never reveal it. */
export function isPageSized() {
  const frame = document.querySelector(".desktop-scale-frame");
  const header = document.querySelector(".desktop-header-spacer");
  return readyPath === window.location.pathname && Boolean(document.body?.firstElementChild) &&
    (!frame || frame.classList.contains("is-measured")) &&
    (!header || header.classList.contains("is-measured")) &&
    !document.documentElement.classList.contains("mh-boot");
}

let token = 0;
let running = 0; // token of the check currently in progress, 0 if none
let watchdog = 0;
const REVEAL_DEADLINE_MS = 1000;

/** Error-only geometry. Normal deadlines always wait for the page's own fits. */
function applyErrorSizing() {
  const viewport = getDesktopViewport();
  const width = viewport.width;
  const canvas = document.querySelector<HTMLElement>(".desktop-scale-canvas");
  const frame = document.querySelector<HTMLElement>(".desktop-scale-frame");
  if (canvas && frame && !frame.classList.contains("is-measured")) {
    const nativePhone = Boolean(canvas.querySelector(".login-page-root, .claim-page-root, .demo-form-focus, .mobile-home-root, .welcome-page-root, .vc-page"));
    const nativeWide = Boolean(canvas.querySelector(".login-page-root, .welcome-page-root, .vc-page")) || window.location.pathname === "/checkout";
    const native = width < 640 ? nativePhone : nativeWide;
    const scale = native ? 1 : width / DESKTOP_CANVAS_WIDTH;
    const layoutZoom = !native && width < 640 && frame.classList.contains("has-phone-layout-zoom");
    // Use ordinary fallback properties so a recovered measurement can replace
    // them normally; never override the scaler's future committed styles.
    document.documentElement.style.setProperty("--canvas-fallback-scale", String(scale));
    canvas.style.width = `${native ? width : DESKTOP_CANVAS_WIDTH}px`;
    canvas.style.transform = layoutZoom ? "none" : `scale(${scale})`;
    frame.style.height = `${canvas.scrollHeight * scale}px`;
  }
  const spacer = document.querySelector<HTMLElement>(".desktop-header-spacer:not(.is-measured)");
  const header = spacer?.querySelector<HTMLElement>(".desktop-header-frame");
  const inner = header?.firstElementChild as HTMLElement | null;
  if (spacer && header && inner) {
    const scale = width / DESKTOP_CANVAS_WIDTH;
    const height = (width >= 640 && width < 1024 ? 122.297 : DESKTOP_HEADER_HEIGHT) * scale;
    spacer.style.height = header.style.height = `${height}px`;
    inner.style.width = `${DESKTOP_CANVAS_WIDTH}px`;
    inner.style.transform = `scale(${scale})`;
    document.documentElement.style.setProperty("--site-header-height", `${height}px`);
  }
}

/** The deadline requests the real settled sizing; it never substitutes an
 * incomplete width-only calculation. Only a sizing error permits that escape. */
export function forceReveal(sizingFailed = false) {
  if (typeof document === "undefined") return;
  const html = document.documentElement;
  if (!html.classList.contains("pg-boot") && !html.classList.contains("mh-boot")) return;
  if (!sizingFailed) {
    revealWhenSettled();
    return;
  }
  token++;
  running = 0;
  try {
    applyErrorSizing();
  } catch {
    // Keep the pre-paint CSS fallback if even DOM measurement is unavailable.
  }
  html.classList.add("pg-forced");
  const w = window as unknown as { __pgCssReady?: () => boolean; __pgShowOffline?: () => void };
  if (w.__pgCssReady && !w.__pgCssReady()) { w.__pgShowOffline?.(); return; }
  html.classList.remove("pg-boot", "mh-boot");
}

const HARD_LIMIT_MS = 2500;
let hardLimit = 0;
let firstArm = true;

/** 2.5s hard limit: ignore fonts and settling, run the page's real sizing
 * with whatever has loaded, and reveal at that size in the same frame. */
export function hardReveal() {
  const html = document.documentElement;
  if (!html.classList.contains("pg-boot") && !html.classList.contains("mh-boot")) return;
  token++;
  running = 0;
  try {
    // Ask the scaler to re-measure now (its own resize path, unchanged).
    window.dispatchEvent(new Event("resize"));
  } catch {
    // Fall through to the device-aware sizing below.
  }
  const frame = document.querySelector(".desktop-scale-frame");
  const header = document.querySelector(".desktop-header-spacer");
  const committed = (!frame || frame.classList.contains("is-measured")) &&
    (!header || header.classList.contains("is-measured"));
  if (committed) {
    // Real committed sizing (iPad zoom/header, native pages, sideways phones).
    window.clearTimeout(watchdog);
    watchdog = 0;
    const w = window as unknown as { __pgCssReady?: () => boolean; __pgShowOffline?: () => void };
    if (w.__pgCssReady && !w.__pgCssReady()) { w.__pgShowOffline?.(); return; }
    html.classList.remove("pg-boot", "mh-boot");
    return;
  }
  forceReveal(true);
}

/** Arm the 1s deadline and the 2.5s hard limit for a load or page switch. */
export function armRevealWatchdog(resetPage = true) {
  if (typeof window === "undefined") return;
  if (resetPage) {
    readyPath = undefined;
    token++;
    running = 0;
  }
  document.documentElement.classList.remove("pg-forced");
  window.clearTimeout(watchdog);
  watchdog = window.setTimeout(() => forceReveal(), REVEAL_DEADLINE_MS);
  if (resetPage || !hardLimit) {
    window.clearTimeout(hardLimit);
    // A fresh document counts from its own start, not from script arrival.
    const elapsed = firstArm ? performance.now() : 0;
    firstArm = false;
    hardLimit = window.setTimeout(() => {
      hardLimit = 0;
      hardReveal();
    }, Math.max(0, HARD_LIMIT_MS - elapsed));
  }
}

export function revealWhenSettled() {
  if (typeof document === "undefined") return;
  const html = document.documentElement;
  if (!html.classList.contains("pg-boot")) return;
  if (running !== 0 && running === token) return; // a check is already running for this page — let it finish
  const mine = ++token;
  running = mine;
  const done = () => {
    if (mine === token) {
      running = 0;
      window.clearTimeout(watchdog);
      watchdog = 0;
      const w = window as unknown as { __pgCssReady?: () => boolean; __pgShowOffline?: () => void };
      if (w.__pgCssReady && !w.__pgCssReady()) { w.__pgShowOffline?.(); return; }
      html.classList.remove("pg-boot");
    }
  };
  if (!watchdog) armRevealWatchdog(false);
  const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
  const fontsReady = fonts ? fonts.ready.catch(() => undefined) : Promise.resolve();
  void fontsReady.catch(() => undefined).then(() => {
    let last = "";
    let stable = 0;
    let stableSince = 0;
    const tick = () => {
      if (mine !== token) {
        if (running === mine) running = 0;
        return;
      }
      let now: string;
      try {
        now = (!fonts || fonts.status === "loaded") && isPageSized() ? signature() : "";
      } catch {
        running = 0;
        forceReveal(true);
        return;
      }
      stable = now !== "" && now === last ? stable + 1 : 0;
      if (stable === 0) stableSince = performance.now();
      last = now;
      if (stable >= STABLE_FRAMES && performance.now() - stableSince >= 200) {
        done();
        return;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

/** Call once from each page's top-level component (after its own hydration). */
export function useRevealWhenSettled() {
  useEffect(() => {
    readyPath = window.location.pathname;
    revealWhenSettled();
  }, []);
}
