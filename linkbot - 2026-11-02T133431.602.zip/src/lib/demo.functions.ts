/**
 * Public demo-request intake with bot protection.
 *
 * The browser sends the form fields plus two bot signals (hidden trap field,
 * time since the form was shown). Everything sensitive is read from
 * server-side environment variables inside the handler.
 *
 * SECRETS (Lovable Cloud → Secrets), read at request time:
 *   GHL_DEMO_WEBHOOK_URL / GHL_DEMO_API_KEY  lead delivery to HighLevel (optional)
 *   GHL_ALERT_WEBHOOK_URL                    >100 new demo requests/hour alert (optional; logged if unset)
 *   GHL_DEMO_CODE_WEBHOOK_URL                6-digit code delivery when strict mode is on
 *   DEMO_STRICT_MODE                         "on" | "off" (default off) — emergency email-code step
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const ALERT_THRESHOLD = 100;
const CODE_TTL_MS = 10 * 60 * 1000;

const DemoRequestSchema = z.object({
  firstName: z.string().trim().min(1, "Please enter your first name").max(80),
  lastName: z.string().trim().min(1, "Please enter your last name").max(80),
  email: z.string().trim().email("Please enter a valid email address").max(255),
  phone: z
    .string()
    .trim()
    .min(7, "Please enter a valid phone number")
    .max(25)
    .regex(/^[+()\-\s\d.]+$/, "Please enter a valid phone number"),
  companyName: z.string().trim().min(1, "Please enter your company name").max(120),
  website: z
    .string()
    .trim()
    .min(4, "Please enter your website")
    .max(255)
    .regex(/^(https?:\/\/)?[\w-]+(\.[\w-]+)+([/?#][^\s]*)?$/i, "Please enter a valid website address"),
  smsConsent: z.boolean(),
  // Bot signals
  trap: z.string().max(500).optional().default(""),
  // Strict-mode second step
  pendingId: z.string().uuid().optional(),
  code: z.string().trim().max(10).optional(),
});

export type DemoRequestInput = z.input<typeof DemoRequestSchema>;

export type DemoSubmitResult =
  | { status: "ok" }
  | { status: "retry" }
  | { status: "bad_email" }
  | { status: "code_required"; pendingId: string }
  | { status: "bad_code" };

type Lead = {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  company_name: string;
  website: string;
  sms_consent: boolean;
};

function normalizeWebsite(value: string): string {
  return /^https?:\/\//i.test(value) ? value : `https://${value}`;
}

async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function dnsQuery(name: string, type: "MX" | "A" | "AAAA") {
  const res = await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`, {
    headers: { accept: "application/dns-json" },
    signal: AbortSignal.timeout(2500),
  });
  if (!res.ok) throw new Error(`dns ${res.status}`);
  return (await res.json()) as { Status: number; Answer?: { type: number; data: string }[] };
}

/** Returns false only when DNS clearly shows the domain cannot receive email. */
async function domainCanReceiveEmail(email: string): Promise<boolean> {
  const domain = email.split("@")[1]?.toLowerCase();
  if (!domain) return true;
  try {
    const mx = await dnsQuery(domain, "MX");
    if (mx.Status === 3) return false; // NXDOMAIN: domain does not exist
    if (mx.Status !== 0) return true; // resolver unsure
    const records = (mx.Answer ?? []).filter((a) => a.type === 15);
    if (records.length > 0) {
      // RFC 7505 null MX ("0 .") means the domain explicitly accepts no mail.
      const allNull = records.every((r) => /^\s*0\s+\.?\s*$/.test(r.data));
      return !allNull;
    }
    // No MX: mail falls back to the A/AAAA record.
    const [a, aaaa] = await Promise.all([dnsQuery(domain, "A"), dnsQuery(domain, "AAAA")]);
    if (a.Status !== 0 || aaaa.Status !== 0) return true;
    const hasHost = [...(a.Answer ?? []), ...(aaaa.Answer ?? [])].some((r) => r.type === 1 || r.type === 28);
    return hasHost;
  } catch (err) {
    console.warn("[demo-request] email domain check could not complete", err);
    return true;
  }
}

type Admin = (typeof import("@/integrations/supabase/client.server"))["supabaseAdmin"];

async function deliverToGhl(admin: Admin, lead: Lead, requestId: string): Promise<boolean> {
  const endpoint = process.env["GHL_DEMO_WEBHOOK_URL"];
  if (!endpoint) return false;
  const apiKey = process.env["GHL_DEMO_API_KEY"];
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiKey ? { Authorization: `Bearer ${apiKey}`, Version: "2021-07-28" } : {}),
      },
      body: JSON.stringify({ ...lead, source: "linkbot_landing_demo", request_id: requestId }),
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(`HighLevel responded ${response.status}: ${body.slice(0, 500)}`);
    }
    await admin.from("demo_requests").update({ delivered_at: new Date().toISOString(), delivery_error: null }).eq("id", requestId);
    return true;
  } catch (err) {
    console.error("[demo-request] delivery to HighLevel failed", err);
    await admin.from("demo_requests").update({ delivery_error: (err as Error).message.slice(0, 1000) }).eq("id", requestId);
    // 190: a lead that did not reach GoHighLevel is reported to the owner.
    const { sendAlert } = await import("./bot-events.server");
    await sendAlert("demo_lead_not_delivered", { email: lead.email, message: `Demo lead ${lead.email} could not be delivered to GoHighLevel.` });
    return false;
  }
}

/** Alert-only volume check: never blocks. Fires once per hour once >100 new requests. */
async function checkVolumeAlert(admin: Admin) {
  try {
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count } = await admin
      .from("demo_requests")
      .select("id", { count: "exact", head: true })
      .is("repeat_of", null)
      .gte("created_at", since);
    if ((count ?? 0) <= ALERT_THRESHOLD) return;
    const { data: recent } = await admin
      .from("security_audit_log")
      .select("id")
      .eq("event_type", "demo_volume_alert")
      .gte("created_at", since)
      .limit(1);
    if (recent && recent.length > 0) return;
    const details = { time: new Date().toISOString(), requests_last_hour: count };
    await admin.from("security_audit_log").insert({ event_type: "demo_volume_alert", details });
    const url = process.env["GHL_ALERT_WEBHOOK_URL"];
    if (!url) {
      console.warn("[demo-request] volume alert (GHL_ALERT_WEBHOOK_URL not set)", details);
      return;
    }
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ alert: "demo_requests_over_100_per_hour", ...details }),
    });
    if (!res.ok) console.error("[demo-request] volume alert delivery failed", res.status);
  } catch (err) {
    console.error("[demo-request] volume alert check failed", err);
  }
}

/** Stores the lead (or a repeat marker) and forwards new leads to GHL. */
async function acceptLead(admin: Admin, lead: Lead) {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  // 188: exact, case-insensitive equality in the database; no pattern characters at all.
  const { data: earlier } = await admin.rpc("find_recent_demo_request", { p_email: lead.email, p_website: lead.website, p_since: since });
  const original = earlier?.[0] ? (earlier[0].repeat_of ?? earlier[0].id) : null;

  const { data: row, error } = await admin
    .from("demo_requests")
    .insert({ ...lead, source: "landing_hero", repeat_of: original })
    .select("id")
    .single();
  if (error || !row) {
    console.error("[demo-request] failed to store request", error);
    throw new Error("We couldn't start your demo just now. Please try again in a moment.");
  }
  if (original) {
    // 190: a repeat of an original that never reached GoHighLevel is forwarded as a new lead.
    const { data: orig } = await admin.from("demo_requests").select("delivered_at").eq("id", original).maybeSingle();
    if (!orig || orig.delivered_at) return; // Delivered original: no new demo, nothing sent to GHL.
    if (await deliverToGhl(admin, lead, row.id)) {
      await admin.from("demo_requests").update({ delivered_at: new Date().toISOString() }).eq("id", original).is("delivered_at", null);
    }
    return;
  }
  await deliverToGhl(admin, lead, row.id);
  await checkVolumeAlert(admin);
}

export const submitDemoRequest = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => DemoRequestSchema.parse(input))
  .handler(async ({ data }): Promise<DemoSubmitResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Strict-mode second step: verify the emailed code.
    if (data.pendingId) {
      const { data: pending } = await supabaseAdmin
        .from("demo_codes")
        .select("id, code_hash, payload, expires_at, used_at, failed_attempts")
        .eq("id", data.pendingId)
        .maybeSingle();
      const live = !!pending && !pending.used_at && new Date(pending.expires_at).getTime() > Date.now();
      if (!live || !pending) return { status: "bad_code" };
      // 186: take one of the 5 tries atomically before checking, so parallel guesses can't all be checked.
      const { data: attempts } = await supabaseAdmin.rpc("register_demo_code_attempt", { p_id: pending.id, p_max: 5 });
      if (typeof attempts !== "number") return { status: "bad_code" };
      const ok = /^\d{6}$/.test(data.code ?? "") && (await sha256(`${pending.id}:${data.code}`)) === pending.code_hash;
      if (!ok) {
        if (attempts >= 5) {
          await supabaseAdmin.from("demo_codes").update({ used_at: new Date().toISOString() }).eq("id", pending.id).is("used_at", null);
        }
        return { status: "bad_code" };
      }
      const { data: claimed } = await supabaseAdmin
        .from("demo_codes")
        .update({ used_at: new Date().toISOString() })
        .eq("id", pending.id)
        .is("used_at", null)
        .select("id");
      if (!claimed || claimed.length === 0) return { status: "bad_code" };
      await acceptLead(supabaseAdmin, pending.payload as unknown as Lead);
      return { status: "ok" };
    }

    if (data.trap.length > 0) return { status: "retry" };

    const email = data.email.toLowerCase();
    if (!(await domainCanReceiveEmail(email))) return { status: "bad_email" };

    const lead: Lead = {
      first_name: data.firstName,
      last_name: data.lastName,
      email,
      phone: data.phone,
      company_name: data.companyName,
      website: normalizeWebsite(data.website),
      sms_consent: data.smsConsent,
    };

    if ((process.env["DEMO_STRICT_MODE"] ?? "off").trim().toLowerCase() === "on") {
      const code = String(crypto.getRandomValues(new Uint32Array(1))[0]! % 1_000_000).padStart(6, "0");
      const id = crypto.randomUUID();
      const { error } = await supabaseAdmin.from("demo_codes").insert({
        id,
        email,
        code_hash: await sha256(`${id}:${code}`),
        payload: lead,
        expires_at: new Date(Date.now() + CODE_TTL_MS).toISOString(),
      });
      if (error) {
        console.error("[demo-request] failed to store code", error);
        throw new Error("We couldn't start your demo just now. Please try again in a moment.");
      }
      const url = process.env["GHL_DEMO_CODE_WEBHOOK_URL"];
      if (url) {
        try {
          const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, code }),
          });
          if (!res.ok) console.error("[demo-request] code delivery failed", res.status);
        } catch (err) {
          console.error("[demo-request] code delivery failed", err);
        }
      } else {
        console.error("[demo-request] DEMO_STRICT_MODE is on but GHL_DEMO_CODE_WEBHOOK_URL is not set");
      }
      return { status: "code_required", pendingId: id };
    }

    await acceptLead(supabaseAdmin, lead);
    return { status: "ok" };
  });
