import { z } from 'zod';
import { CALL_SHARE_WINDOW_MINUTES, callShareIdentity, isCallShareId, sanitizeCallRequest } from './call-share-rules';

export async function recordCallShare(request: Request, body: Record<string, unknown>, account: string, link: { id: string; button_name: string }) {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const query = Object.fromEntries([...new Set(new URL(request.url).searchParams.keys())].map(key => [key, new URL(request.url).searchParams.getAll(key)]));
  const headers = Object.fromEntries(request.headers.entries());
  const secrets = [process.env['MYLINKS_BOT_KEY'] ?? '', ...Object.entries(headers).filter(([key]) => /authorization|cookie|key|secret|token/i.test(key)).map(([, value]) => value)];
  const raw = sanitizeCallRequest({ headers, query, body }, secrets);
  const { data: bots, error: botError } = await supabaseAdmin.from('client_slugs').select('slug,link_code,ghl_widget_id').eq('ghl_location_id', account);
  if (botError) throw new Error('Unable to scope call share');
  const identity = callShareIdentity(raw, [account, link.id, ...(bots ?? []).flatMap(bot => [bot.slug, bot.link_code ?? '', bot.ghl_widget_id ?? ''])]);
  // LINKS-3L: the call_id query value is the call ID; it ranks first as call_key.
  const callId = new URL(request.url).searchParams.get('call_id');
  if (callId && isCallShareId(callId)) identity.call_key = callId;
  const page = typeof body['page'] === 'string' ? body['page'] : new URL(request.url).searchParams.get('page');
  const { data: share, error } = await supabaseAdmin.from('call_shares').insert({ account, page: page?.slice(0, 255) ?? null, link_id: link.id, button_name: link.button_name, ...identity }).select('id').single();
  if (error || !share) throw new Error('Unable to record call share');
  const { error: debugError } = await supabaseAdmin.from('call_share_debug').insert({ share_id: share.id, raw_request: raw as import('@/integrations/supabase/types').Json });
  if (debugError) throw new Error('Unable to record call diagnostics');
  return identity.call_key;
}

export function sharedContactLines(shares: { link_id: string; button_name: string }[], links: { id: string; url: string }[]) {
  const urls = new Map(links.map(link => [link.id, link.url]));
  const seen = new Set<string>();
  return shares.flatMap(share => {
    const url = urls.get(share.link_id);
    if (!url || seen.has(share.link_id)) return [];
    seen.add(share.link_id);
    return [`${share.button_name} – ${url}`];
  }).join('\n');
}

// Cache only provider field IDs, never caller data or tokens; a miss remains safe after a cold start.
const contactFieldIds = new Map<string, string>();
export async function writeContactLinks(account: string, contactId: string, callKey: string, signal: AbortSignal) {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const { getLocationToken } = await import('./linkbot/app.server');
  const token = await getLocationToken(account);
  signal.throwIfAborted();
  if (!token) throw new Error('Location app token unavailable');
  const { data: shares, error } = await supabaseAdmin.from('call_shares').select('link_id,button_name').eq('account', account).eq('call_key', callKey).order('created_at', { ascending: true }).order('id', { ascending: true }).abortSignal(signal);
  if (error) throw new Error('Shared links lookup failed');
  if (!shares?.length) return;
  const { data: links, error: linkError } = await supabaseAdmin.from('my_links').select('id,url').eq('ghl_location_id', account).in('id', [...new Set(shares.map(share => share.link_id))]).abortSignal(signal);
  if (linkError) throw new Error('Shared link URLs lookup failed');
  const value = sharedContactLines(shares, links ?? []);
  if (!value) return;
  const base = 'https://services.leadconnectorhq.com';
  const headers = { Authorization: `Bearer ${token}`, Version: '2021-07-28', 'Content-Type': 'application/json', Accept: 'application/json' };
  const update = (fieldId?: string) => fetch(`${base}/contacts/${encodeURIComponent(contactId)}`, {
    method: 'PUT', headers, signal,
    // Retain the requested field_value and also supply GHL's documented fieldValue alias.
    body: JSON.stringify({ customFields: [{ ...(fieldId ? { id: fieldId } : { key: 'linkbot_links_shared' }), field_value: value, fieldValue: value }] }),
  });
  let result = await update(contactFieldIds.get(account));
  if ((result.status === 400 || result.status === 422) && !contactFieldIds.has(account)) {
    await result.body?.cancel();
    const lookup = await fetch(`${base}/locations/${encodeURIComponent(account)}/customFields?model=contact`, { headers, signal });
    if (!lookup.ok) { await lookup.body?.cancel(); throw new Error(`Contact field lookup failed (${lookup.status})`); }
    const fields = z.object({ customFields: z.array(z.object({ id: z.string(), fieldKey: z.string() })) }).parse(await lookup.json());
    const field = fields.customFields.find(item => item.fieldKey === 'contact.linkbot_links_shared' || item.fieldKey === 'linkbot_links_shared');
    if (!field) throw new Error('LinkBot Links Shared custom field not found');
    contactFieldIds.set(account, field.id);
    result = await update(field.id);
  }
  await result.body?.cancel();
  if (!result.ok) throw new Error(`Contact links update failed (${result.status})`);
  console.info('LinkBot shared contact links updated');
}

export function queueContactLinks(request: Request, account: string, contactId: string, callKey: string) {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => { controller.abort(); reject(new Error('Contact links update timed out (10000ms)')); }, 10000);
  });
  const task = Promise.race([writeContactLinks(account, contactId, callKey, controller.signal), timeout])
    .catch(error => { console.error('LinkBot shared contact links failed', error instanceof Error ? error.message : 'Request failed'); })
    .finally(() => { clearTimeout(timer); });
  const runtimeRequest = request as Request & { waitUntil?: (task: Promise<unknown>) => void; runtime?: { cloudflare?: { context?: { waitUntil: (task: Promise<unknown>) => void } } } };
  const context = runtimeRequest.runtime?.cloudflare?.context;
  if (context) context.waitUntil(task);
  else if (runtimeRequest.waitUntil) runtimeRequest.waitUntil(task);
  else void task;
}

const pollingInput = z.object({ page: z.string().trim().min(1).max(255), ids: z.array(z.string().refine(isCallShareId)).min(1).max(4000) });
export async function callShares(request: Request) {
  const reply = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store', 'referrer-policy': 'no-referrer' } });
  const query = new URL(request.url).searchParams;
  let page: unknown = query.get('page'), ids: unknown;
  if (request.method === 'POST') {
    let body: unknown;
    try { body = await request.json(); } catch { return reply({ links: [] }, 400); }
    if (!body || typeof body !== 'object' || Array.isArray(body)) return reply({ links: [] }, 400);
    page = (body as Record<string, unknown>)['page'];
    ids = (body as Record<string, unknown>)['ids'];
  } else {
    try { ids = JSON.parse(query.get('ids') ?? '[]'); } catch { return reply({ links: [] }, 400); }
  }
  const parsed = pollingInput.safeParse({ page, ids });
  if (!parsed.success) return reply({ links: [] }, 400);
  // LINKS-3L temporary (remove after 24h): log each page's ID lists to compare with call_share_debug.
  console.log('[call-shares]', new Date().toISOString(), 'page:', parsed.data.page, 'ids:', JSON.stringify(parsed.data.ids));
  // Private share rows are never exposed; exact high-entropy call IDs authorize only minimal buttons.
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  let account = parsed.data.page === 'livedemo' ? process.env['LIVEDEMO_GHL_LOCATION_ID'] : undefined;
  if (parsed.data.page !== 'livedemo') {
    const column = parsed.data.page.length === 12 ? 'link_code' : 'slug';
    const { data, error } = await supabaseAdmin.from('client_slugs').select('ghl_location_id').eq(column, parsed.data.page).eq('status', 'active').not('activated_at', 'is', null).maybeSingle();
    if (error) return reply({ links: [] }, 503);
    account = data?.ghl_location_id ?? undefined;
  }
  if (!account) return reply({ links: [] });
  // LINKS-3L: exact, case-sensitive, full-string call_key match — never shares from any other call.
  const since = new Date(Date.now() - CALL_SHARE_WINDOW_MINUTES * 60 * 1000).toISOString();
  const { data: recent, error } = await supabaseAdmin.from('call_shares').select('link_id,button_name,call_key').eq('account', account).not('call_key', 'is', null).neq('call_key', '').gte('created_at', since);
  if (error) return reply({ links: [] }, 503);
  const submitted = new Set(parsed.data.ids);
  const shares = (recent ?? []).filter(share => share.call_key && submitted.has(share.call_key));
  if (!shares.length) return reply({ links: [] });
  const { data: onLinks, error: linkError } = await supabaseAdmin.from('my_links').select('id,button_name').eq('ghl_location_id', account).eq('is_on', true).in('id', shares.map(share => share.link_id));
  if (linkError) return reply({ links: [] }, 503);
  return reply({ links: (onLinks ?? []).map(link => ({ shared: true, link_id: link.id, button_name: link.button_name })) });
}