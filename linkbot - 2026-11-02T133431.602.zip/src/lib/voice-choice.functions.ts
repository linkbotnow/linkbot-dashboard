/**
 * Voice-choice webhook.
 *
 * The browser never calls the GoHighLevel inbound webhook directly: this server
 * function does, so the webhook URL stays server-side. The submitted account
 * password is never part of the payload and is never accepted here.
 *
 * REQUIRED SECRET:
 *   GHL_VOICE_WEBHOOK_URL  GoHighLevel inbound webhook ("Webhook" workflow action URL).
 *
 * Fails open by design: if the webhook is unreachable the customer still
 * continues to checkout and the error is logged for the operator.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const VoiceChoiceSchema = z.object({
  firstName: z.string().trim().min(1).max(80),
  lastName: z.string().trim().max(80).optional(),
  email: z.string().trim().toLowerCase().email().max(255),
  phone: z.string().trim().max(30).optional(),
  companyName: z.string().trim().max(120).optional(),
  website: z.string().trim().max(255).optional(),
  linkbotLink: z.string().trim().max(255).optional(),
  botId: z.string().trim().max(64).optional(),
  voice: z.enum(["female", "male"]),
});

/** Valid checkout pass for this bot, or signed in as its owner; bot must be held or active. */
async function mayChooseVoice(botId: string, email?: string): Promise<boolean> {
  const { currentAccountId } = await import("./account.server");
  const { hasValidPassFor } = await import("./checkout-pass.server");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  let q = supabaseAdmin
    .from("client_slugs")
    .select("id, owner_account_id")
    .eq("id", botId)
    .in("status", ["reserved", "active"]);
  if (email) q = q.eq("email", email.toLowerCase());
  const { data: bot } = await q.maybeSingle();
  if (!bot) return false;
  if (await hasValidPassFor(botId)) return true;
  const accountId = await currentAccountId();
  return !!accountId && bot.owner_account_id === accountId;
}

/** Whether this browser may still finish the voice step for this bot. */
export const checkVoiceAccess = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ botId: z.string().trim().max(64) }).parse(input))
  .handler(async ({ data }): Promise<{ ok: boolean; paid?: boolean }> => {
    if (!/^[0-9a-f-]{36}$/i.test(data.botId)) return { ok: false };
    // 188: a pass for an already-paid bot goes to /welcome instead of the expired page.
    const { readCheckoutPass } = await import("./checkout-pass.server");
    const pass = await readCheckoutPass();
    if (pass && pass.paid && !pass.statusExpired && pass.botId === data.botId) return { ok: false, paid: true };
    return { ok: await mayChooseVoice(data.botId) };
  });

export type VoiceChoiceResult = { ok: true; delivered: boolean };

export const submitVoiceChoice = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => VoiceChoiceSchema.parse(input))
  .handler(async ({ data }): Promise<VoiceChoiceResult> => {
    // Only the signed-in owner of a held or active bot with this email may send a voice choice.
    if (!data.botId || !/^[0-9a-f-]{36}$/i.test(data.botId)) return { ok: true, delivered: false };
    if (!(await mayChooseVoice(data.botId, data.email))) return { ok: true, delivered: false };

    const payload = {
      firstName: data.firstName,
      lastName: data.lastName ?? "",
      email: data.email,
      phone: data.phone ?? "",
      companyName: data.companyName ?? "",
      website: data.website ?? "",
      linkbotLink: data.linkbotLink ?? "",
      botId: data.botId ?? "",
      voice: data.voice,
      submittedAt: new Date().toISOString(),
    };

    // 185: the same voice already saved and sent for this bot is never sent again.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // 188: skip only when the whole payload matches the last one GoHighLevel confirmed.
    const { submittedAt: _ignored, ...stable } = payload;
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(stable)));
    const sentHash = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
    const { data: saved } = await supabaseAdmin.from("client_slugs").select("voice_sent_hash").eq("id", data.botId).maybeSingle();
    if (saved?.voice_sent_hash === sentHash) return { ok: true, delivered: true };

    const url = process.env["GHL_VOICE_WEBHOOK_URL"];
    if (!url) {
      console.error("[voice-choice] GHL_VOICE_WEBHOOK_URL is not set; voice choice not delivered", {
        voice: payload.voice,
        email: payload.email,
      });
      return { ok: true, delivered: false };
    }

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        console.error(`[voice-choice] webhook responded ${response.status}; continuing anyway`, {
          voice: payload.voice,
        });
        return { ok: true, delivered: false };
      }
      await supabaseAdmin.from("client_slugs").update({ voice_sent: data.voice, voice_sent_hash: sentHash }).eq("id", data.botId);
      return { ok: true, delivered: true };
    } catch (error) {
      console.error("[voice-choice] webhook failed; continuing anyway", error, { voice: payload.voice });
      return { ok: true, delivered: false };
    }
  });
