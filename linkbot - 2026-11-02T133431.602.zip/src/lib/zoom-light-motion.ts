import { useEffect } from "react";
import { MotionGlobalConfig } from "motion/react";

/**
 * 257: while the touch homepage is in pinch light mode (html.home-zoom-light),
 * Motion reveals jump straight to their end state instead of animating. At
 * normal zoom Motion behaves exactly as before.
 * 186: shared by several components — one observer, reference-counted, so an
 * unmount never switches the pause off while zoom light mode is on.
 */
let users = 0;
let observer: MutationObserver | null = null;

function apply() {
  MotionGlobalConfig.skipAnimations = document.documentElement.classList.contains("home-zoom-light");
}

export function useZoomLightMotion() {
  useEffect(() => {
    users += 1;
    if (!observer) {
      observer = new MutationObserver(apply);
      observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    }
    apply();
    return () => {
      users -= 1;
      if (users > 0) return;
      users = 0;
      observer?.disconnect();
      observer = null;
      if (!document.documentElement.classList.contains("home-zoom-light")) MotionGlobalConfig.skipAnimations = false;
    };
  }, []);
}
