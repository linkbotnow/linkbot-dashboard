-- Transactional regression test: all fixture changes are rolled back.
BEGIN;
DO $$
DECLARE abandoned uuid := gen_random_uuid(); paid uuid := gen_random_uuid(); held uuid := gen_random_uuid(); paused uuid := gen_random_uuid(); bot uuid := gen_random_uuid(); sig uuid := gen_random_uuid();
BEGIN
 INSERT INTO public.customer_accounts(id,email,password_hash) VALUES
 (abandoned,'4l21-abandoned@example.invalid','test-only'),(paid,'4l21-paid@example.invalid','test-only'),
 (held,'4l21-held@example.invalid','test-only'),(paused,'4l21-paused@example.invalid','test-only');
 INSERT INTO public.client_slugs(id,email,slug,owner_account_id,status,hold_expires_at,activated_at) VALUES
 (bot,'4l21-abandoned@example.invalid','4l21-expired',abandoned,'reserved',now()-interval '1 minute',NULL),
 (gen_random_uuid(),'4l21-paid@example.invalid','4l21-paid',paid,'reserved',NULL,now()),
 (gen_random_uuid(),'4l21-held@example.invalid','4l21-held',held,'reserved',now()+interval '30 minutes',NULL),
 (gen_random_uuid(),'4l21-paused@example.invalid','4l21-paused',paused,'paused',now()-interval '1 minute',NULL);
 INSERT INTO public.legal_signatures(id,account_id,email,full_name,agreed_sensitive_use,agreed_terms,terms_version)
 VALUES(sig,abandoned,'4l21-abandoned@example.invalid','Test',true,true,'test');
 INSERT INTO public.customer_sessions(account_id,token_hash,expires_at) VALUES(abandoned,'4l21-test',now()+interval '1 hour');
 INSERT INTO public.password_resets(account_id,code_hash,expires_at,type) VALUES(abandoned,'4l21-link',now()+interval '1 hour','link'),(abandoned,'4l21-code',now()+interval '1 hour','code');
 INSERT INTO public.checkout_passes(bot_id,token_hash) VALUES(bot,'4l21-pass');
 IF NOT public.claim_account_is_leftover(abandoned) THEN RAISE EXCEPTION 'Expired unpaid account must be leftover'; END IF;
 IF public.claim_account_is_leftover(paid) THEN RAISE EXCEPTION 'Activated bot must protect paid account'; END IF;
 IF public.claim_account_is_leftover(held) THEN RAISE EXCEPTION '30-minute checkout hold must protect account'; END IF;
 IF public.claim_account_is_leftover(paused) THEN RAISE EXCEPTION 'Paused bot must protect account'; END IF;
 IF public.remove_leftover_accounts(paid) <> 0 OR public.remove_leftover_accounts(held) <> 0 OR public.remove_leftover_accounts(paused) <> 0 THEN RAISE EXCEPTION 'Protected accounts deleted'; END IF;
 IF public.remove_leftover_accounts(abandoned) <> 1 THEN RAISE EXCEPTION 'Expected one leftover deletion'; END IF;
 IF EXISTS(SELECT 1 FROM public.customer_accounts WHERE id=abandoned) OR EXISTS(SELECT 1 FROM public.customer_sessions WHERE account_id=abandoned) OR EXISTS(SELECT 1 FROM public.password_resets WHERE account_id=abandoned) OR EXISTS(SELECT 1 FROM public.checkout_passes WHERE bot_id=bot) THEN RAISE EXCEPTION 'Leftover dependencies retained'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.legal_signatures WHERE id=sig AND account_id IS NULL AND full_name='Test' AND agreed_terms AND agreed_sensitive_use AND terms_version='test') THEN RAISE EXCEPTION 'Legal signature not preserved'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.security_audit_log WHERE event_type='leftover_account_removed' AND details->>'email'='4l21-abandoned@example.invalid') THEN RAISE EXCEPTION 'Missing email audit'; END IF;
END $$;
ROLLBACK;