/** Customer sign-in, forgot password and reset. Passwords are never logged or sent anywhere. */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const PasswordRule = z
  .string()
  .min(8, { message: "Password must be at least 8 characters." })
  .max(128)
  .regex(/[A-Z]/, { message: "Password must include an uppercase letter." })
  .regex(/[0-9]/, { message: "Password must include a number." })
  .regex(/[^A-Za-z0-9]/, { message: "Password must include a special character." });

const MAX_FAILS = 10;
const LOCK_MS = 15 * 60 * 1000;

export async function sendLockAlert(email: string, lockedAt: string) {
  const hook = process.env["GHL_LOCK_ALERT_WEBHOOK_URL"];
  if (!hook) {
    console.warn("[lock-alert] GHL_LOCK_ALERT_WEBHOOK_URL not set; lock alert not sent");
    return;
  }
  try {
    const res = await fetch(hook, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, locked_at: lockedAt }),
    });
    if (!res.ok) console.error("[lock-alert] webhook failed", res.status);
  } catch (e) {
    console.error("[lock-alert] webhook error", e instanceof Error ? e.message : e);
  }
}

export const loginCustomer = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ email: z.string().trim().toLowerCase().max(255), password: z.string().max(128), remember: z.boolean().optional(), next: z.string().max(2000).optional() }).parse(input),
  )
  .handler(async ({ data }): Promise<{ ok: true; redirectTo: string } | { ok: false; locked?: boolean; lockedMinutes?: number }> => {
    const { verifyPassword, startSession, safeNext } = await import("./account.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: acct } = await supabaseAdmin
      .from("customer_accounts")
      .select("id, email, password_hash, failed_attempts, locked_until")
      .eq("email", data.email)
      .maybeSingle();
    const msLeft = acct?.locked_until ? new Date(acct.locked_until).getTime() - Date.now() : 0;
    const locked = msLeft > 0;
    const valid = verifyPassword(data.password, acct?.password_hash);
    if (!acct) return { ok: false };
    if (locked) return { ok: false, locked: true, lockedMinutes: Math.max(1, Math.ceil(msLeft / 60000)) };
    if (!valid) {
      // 451: one atomic count; only the request that locks the account sends the alert.
      const { data: outcome } = await supabaseAdmin.rpc("register_failed_login", { p_account_id: acct.id, p_max: MAX_FAILS, p_lock_minutes: LOCK_MS / 60000 });
      if (outcome === "locked_now") {
        await sendLockAlert(acct.email, new Date().toISOString());
        return { ok: false, locked: true };
      }
      if (outcome === "already_locked") return { ok: false, locked: true };
      return { ok: false };
    }
    await supabaseAdmin.from("customer_accounts").update({ failed_attempts: 0, locked_until: null }).eq("id", acct.id);
    await startSession(acct.id, data.remember === true);
    return { ok: true, redirectTo: safeNext(data.next) };
  });

export const requestPasswordReset = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ email: z.string().trim().toLowerCase().email().max(255) }).parse(input))
  .handler(async ({ data }): Promise<{ sent: boolean }> => {
    const { sha256 } = await import("./account.server");
    const { randomBytes } = await import("crypto");
    const { getRequestUrl } = await import("@tanstack/react-start/server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: acct } = await supabaseAdmin
      .from("customer_accounts")
      .select("id, email")
      .eq("email", data.email)
      .maybeSingle();
    if (!acct) return { sent: true };
    // 451: a fresh unused code from the last 2 minutes means no new code or email.
    const nowIso = new Date().toISOString();
    const { data: recent } = await supabaseAdmin
      .from("password_resets")
      .select("id")
      .eq("account_id", acct.id)
      .is("used_at", null)
      .gt("expires_at", nowIso)
      .gt("created_at", new Date(Date.now() - 2 * 60 * 1000).toISOString())
      .limit(1);
    if (recent && recent.length > 0) return { sent: true };
    const code = randomBytes(32).toString("base64url");
    const { error } = await supabaseAdmin.from("password_resets").insert({
      account_id: acct.id,
      code_hash: sha256(code),
      expires_at: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
    });
    if (error) throw new Error("Could not create reset code");
    const origin = getRequestUrl().origin;
    const resetLink = `${origin}/reset-password?code=${code}`;
    const hook = process.env["GHL_PASSWORD_RESET_WEBHOOK_URL"];
    if (!hook) {
      console.warn("[password-reset] GHL_PASSWORD_RESET_WEBHOOK_URL not set; reset email not sent");
    } else {
      try {
        const res = await fetch(hook, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ email: acct.email, reset_link: resetLink, reset_type: "link" }),
        });
        if (!res.ok) console.error("[password-reset] webhook failed", res.status);
      } catch (e) {
        console.error("[password-reset] webhook error", e instanceof Error ? e.message : e);
      }
    }
    return { sent: true };
  });

export const resetPassword = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ code: z.string().min(10).max(200), password: PasswordRule, next: z.string().max(2000).optional() }).parse(input),
  )
  .handler(async ({ data }): Promise<{ ok: true; redirectTo: string } | { ok: false }> => {
    const { sha256, hashPassword } = await import("./account.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();
    // Mark used atomically so the code works only once.
    const { data: row } = await supabaseAdmin
      .from("password_resets")
      .update({ used_at: now })
      .eq("code_hash", sha256(data.code))
      .is("used_at", null)
      .gt("expires_at", now)
      .select("account_id")
      .maybeSingle();
    if (!row) return { ok: false };
    const { error: updateError } = await supabaseAdmin
      .from("customer_accounts")
      .update({ password_hash: hashPassword(data.password), failed_attempts: 0, locked_until: null })
      .eq("id", row.account_id);
    if (updateError) return { ok: false };
    // 451: any other unused reset codes for this account stop working.
    await supabaseAdmin.from("password_resets").delete().eq("account_id", row.account_id).is("used_at", null);
    // Sign out everywhere: every existing session for this account ends.
    await supabaseAdmin.from("customer_sessions").delete().eq("account_id", row.account_id);
    // No automatic sign-in: the person signs in themselves on /login.
    return { ok: true, redirectTo: "/login?reset=1" };
  });
