/** Phones under 640px: plain jumps to the top that only a real scroll gesture cancels (taps do not). */
export function pinPhoneTop(): () => void {
  if (typeof window === "undefined" || !window.matchMedia("(max-width:639px)").matches) return () => {};
  let cancelled = false;
  let startY = 0;
  const jump = () => {
    if (cancelled) return;
    window.scrollTo(0, 0);
    if (document.scrollingElement) document.scrollingElement.scrollTop = 0;
  };
  const stop = () => { cancelled = true; cleanup(); };
  const onStart = (e: TouchEvent) => { startY = e.touches[0]?.clientY ?? 0; };
  const onMove = (e: TouchEvent) => { if (Math.abs((e.touches[0]?.clientY ?? 0) - startY) > 10) stop(); };
  const timers = [window.setTimeout(jump, 150), window.setTimeout(() => { jump(); cleanup(); }, 400)];
  let f2 = 0;
  const f1 = requestAnimationFrame(() => { jump(); f2 = requestAnimationFrame(jump); });
  function cleanup() {
    window.removeEventListener("wheel", stop);
    window.removeEventListener("touchstart", onStart);
    window.removeEventListener("touchmove", onMove);
  }
  window.addEventListener("wheel", stop, { passive: true });
  window.addEventListener("touchstart", onStart, { passive: true });
  window.addEventListener("touchmove", onMove, { passive: true });
  jump();
  return () => { cancelled = true; cancelAnimationFrame(f1); cancelAnimationFrame(f2); timers.forEach(clearTimeout); cleanup(); };
}
