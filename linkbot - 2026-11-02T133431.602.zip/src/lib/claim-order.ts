/** Client-safe order details carried from /claim to its voice choice, /checkout and the webhook. */

export interface ClaimOrder {
  firstName: string;
  lastName?: string;
  email: string;
  phone?: string;
  companyName?: string;
  website?: string;
  slug: string;
  /** The bot's unique client_slugs ID, sent to GoHighLevel as botId. */
  botId?: string;
  voice?: "female" | "male";
}

export const CLAIM_ORDER_STORAGE_KEY = "linkbot-claim-order";

export function readStoredClaimOrder(): ClaimOrder | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(CLAIM_ORDER_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ClaimOrder>;
    if (!parsed || typeof parsed.email !== "string" || !parsed.email.includes("@")) return null;
    if (typeof parsed.slug !== "string" || !parsed.slug) return null;
    return {
      firstName: typeof parsed.firstName === "string" ? parsed.firstName : "",
      ...(typeof parsed.lastName === "string" && parsed.lastName ? { lastName: parsed.lastName } : {}),
      email: parsed.email,
      ...(typeof parsed.phone === "string" && parsed.phone ? { phone: parsed.phone } : {}),
      ...(typeof parsed.companyName === "string" && parsed.companyName ? { companyName: parsed.companyName } : {}),
      ...(typeof parsed.website === "string" && parsed.website ? { website: parsed.website } : {}),
      slug: parsed.slug,
      ...(typeof parsed.botId === "string" && parsed.botId ? { botId: parsed.botId } : {}),
      ...(parsed.voice === "female" || parsed.voice === "male" ? { voice: parsed.voice } : {}),
    };
  } catch {
    return null;
  }
}

export function storeClaimOrder(order: ClaimOrder): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(CLAIM_ORDER_STORAGE_KEY, JSON.stringify(order));
  } catch {
    /* storage unavailable – voice choice falls back to the form */
  }
}

/** Records the chosen voice on the stored order. */
export function storeClaimVoice(voice: "female" | "male"): void {
  const order = readStoredClaimOrder();
  if (!order) return;
  storeClaimOrder({ ...order, voice });
}
