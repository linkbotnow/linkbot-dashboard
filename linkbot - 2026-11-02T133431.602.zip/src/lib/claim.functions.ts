/**
 * Personal-link picker backend.
 *
 * The browser only ever sends a candidate slug plus the contact details the visitor
 * already typed into the landing demo form. Every database credential is read from
 * server-side environment variables inside the handler and never reaches the browser.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { CLAIM_SLUG_PATTERN, RESERVED_CLAIM_SLUGS, normalizeClaimSlug } from "@/lib/claim-slug";

const DEFAULT_CHECKOUT_URL = "https://checkout.linkbot.now";

/** 194: the one email rule shared by the /claim form and the server. */
export const ClaimEmailRule = z.string().trim().toLowerCase().email().max(255);

const SlugSchema = z.object({
  slug: z.string().trim().toLowerCase().min(3).max(30),
});

const ReserveSchema = SlugSchema.extend({
  firstName: z.string().trim().max(80).default(""),
  lastName: z.string().trim().max(80).optional(),
  email: z.string().trim().toLowerCase().email().max(255),
  // Optional only when a valid unpaid checkout pass already covers this account.
  password: z.string().max(128).optional(),
  phone: z.string().trim().max(30).optional(),
  companyName: z.string().trim().max(120).optional(),
  website: z.string().trim().max(255).optional(),
  // Legal Terms signature (Prompt 205); required unless a valid unpaid checkout pass already covers this bot.
  signature: z
    .object({
      fullName: z.string().trim().min(1).max(120),
      agreedSensitiveUse: z.literal(true),
      agreedTerms: z.literal(true),
    })
    .optional(),
});


function isClaimable(slug: string): boolean {
  return CLAIM_SLUG_PATTERN.test(slug) && !RESERVED_CLAIM_SLUGS.has(slug);
}

/** Hosts allowed to embed this client's widget page, derived from their own website. */
function domainsFromWebsite(website?: string): string[] {
  if (!website) return [];
  let host = website.trim().toLowerCase();
  host = host.replace(/^https?:\/\//, "").split("/")[0] ?? "";
  host = host.replace(/^www\./, "").replace(/:\d+$/, "");
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host)) return [];
  return [host, `www.${host}`];
}

const strongPassword = (p?: string) =>
  !!p && p.length >= 8 && /[A-Z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p);

/** The bot covered by this browser's valid, unpaid checkout pass, or null. */
async function passBot() {
  const { readCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  if (!pass || pass.expired || pass.paid) return null;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("client_slugs")
    .select("id, slug, email, full_name, last_name, phone, company_name, website")
    .eq("id", pass.botId)
    .maybeSingle();
  return data ?? null;
}

export type ClaimPrefill = {
  slug: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  companyName: string;
  website: string;
  botId: string;
} | null;

/** Details for /claim while the browser holds a valid, unpaid checkout pass (never the password or link code). */
export const getClaimPrefill = createServerFn({ method: "GET" }).handler(async (): Promise<ClaimPrefill> => {
  const bot = await passBot();
  if (!bot) return null;
  return {
    slug: bot.slug,
    firstName: bot.full_name ?? "",
    lastName: bot.last_name ?? "",
    email: bot.email,
    phone: bot.phone ?? "",
    companyName: bot.company_name ?? "",
    website: bot.website ?? "",
    botId: bot.id,
  };
});

/** "Not you?" on /claim: switch off this browser's checkout pass. */
export const endClaimPass = createServerFn({ method: "POST" }).handler(async () => {
  const { readCheckoutPass, disableCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  if (pass && !pass.paid) await disableCheckoutPass(pass.passId);
  return { ok: true };
});

/** Existing account the visitor is not already allowed for (same rule reserveClaimSlug uses), or null. */
async function blockedAccount(email: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { currentAccountId } = await import("./account.server");
  const { data: existing } = await supabaseAdmin
    .from("customer_accounts")
    .select("id, email, password_hash, failed_attempts, locked_until")
    .eq("email", email)
    .maybeSingle();
  if (!existing) return null;
  if ((await currentAccountId()) === existing.id) return null;
  const { readCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  if (pass && !pass.expired && !pass.paid) {
    const { data: passBot } = await supabaseAdmin
      .from("client_slugs")
      .select("id")
      .eq("id", pass.botId)
      .eq("owner_account_id", existing.id)
      .eq("email", email)
      .maybeSingle();
    if (passBot) return null;
  }
  const { data: leftover, error } = await supabaseAdmin.rpc("claim_account_is_leftover", { p_account_id: existing.id });
  if (error) throw new Error("Account check unavailable");
  if (leftover) return null;
  return existing;
}

const EmailOnly = z.object({ email: z.string().trim().toLowerCase().email().max(255) });

export const checkClaimWebsite = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ website: z.string().trim().max(255) }).parse(input))
  .handler(async ({ data }) => {
    const { claimWebsiteExists } = await import("./claim-website");
    return { valid: await claimWebsiteExists(data.website) };
  });

export const checkClaimEmail = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => EmailOnly.parse(input))
  .handler(async ({ data }): Promise<{ exists: boolean; hasPaidBot: boolean; signedInOwner?: boolean }> => {
    // 189: the typed email is the signed-in account: no password needed.
    const { currentAccountId } = await import("./account.server");
    const signedIn = await currentAccountId();
    if (signedIn) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { data: me } = await supabaseAdmin.from("customer_accounts").select("id").eq("id", signedIn).eq("email", data.email).maybeSingle();
      if (me) return { exists: false, hasPaidBot: false, signedInOwner: true };
    }
    const existing = await blockedAccount(data.email);
    if (!existing) return { exists: false, hasPaidBot: false };
    // 188: whether this account already owns a paid LinkBot (for the returning note).
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: paidBot } = await supabaseAdmin
      .from("client_slugs")
      .select("id")
      .eq("owner_account_id", existing.id)
      .or("activated_at.not.is.null,status.in.(active,paused)")
      .limit(1);
    return { exists: true, hasPaidBot: !!paidBot && paidBot.length > 0 };
  });

/** 188: whether this browser's checkout pass belongs to an already-paid bot. */
export const getPassPaid = createServerFn({ method: "GET" }).handler(async (): Promise<{ paid: boolean }> => {
  const { readCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  return { paid: !!pass && pass.paid && !pass.statusExpired };
});

/** 185: real minutes left on an account lock (at least 1), read fresh from the database. */
async function lockMinutesLeft(accountId: string): Promise<number> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin.from("customer_accounts").select("locked_until").eq("id", accountId).maybeSingle();
  const ms = data?.locked_until ? new Date(data.locked_until).getTime() - Date.now() : 0;
  return Math.max(1, Math.ceil(ms / 60000));
}

export const checkClaimPassword = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => EmailOnly.extend({ password: z.string().max(128) }).parse(input))
  .handler(async ({ data }): Promise<{ ok: true } | { ok: false; reason: "locked" | "wrong_password"; lockedMinutes?: number }> => {
    const existing = await blockedAccount(data.email);
    if (!existing) return { ok: true };
    if (existing.locked_until && new Date(existing.locked_until).getTime() > Date.now()) return { ok: false, reason: "locked", lockedMinutes: await lockMinutesLeft(existing.id) };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { verifyPassword } = await import("./account.server");
    if (!verifyPassword(data.password, existing.password_hash)) {
      const { data: outcome } = await supabaseAdmin.rpc("register_failed_login", { p_account_id: existing.id, p_max: 10, p_lock_minutes: 15 });
      if (outcome === "locked_now") {
        const { sendLockAlert } = await import("./account.functions");
        await sendLockAlert(existing.email, new Date().toISOString());
        return { ok: false, reason: "locked", lockedMinutes: await lockMinutesLeft(existing.id) };
      }
      if (outcome === "already_locked") return { ok: false, reason: "locked", lockedMinutes: await lockMinutesLeft(existing.id) };
      return { ok: false, reason: "wrong_password" };
    }
    await supabaseAdmin.from("customer_accounts").update({ failed_attempts: 0, locked_until: null }).eq("id", existing.id);
    return { ok: true };
  });

export type SlugCheck = { available: boolean; reason?: "invalid" | "taken" };

export const checkClaimSlug = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SlugSchema.extend({ email: z.string().trim().toLowerCase().email().max(255).optional() }).parse(input))
  .handler(async ({ data }): Promise<SlugCheck> => {
    const { checkSlugAvailability } = await import("@/lib/slug-availability.server");
    const result = await checkSlugAvailability(data.slug);
    if (!result.available && result.reason === "taken") {
      // The pass holder's own held name is available to them.
      const own = await passBot();
      if (own && own.slug === normalizeClaimSlug(data.slug)) return { available: true };
      // 191: an unpaid hold under the typed email is that person's own name.
      if (data.email) {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: hold } = await supabaseAdmin
          .from("client_slugs")
          .select("email")
          .eq("slug", normalizeClaimSlug(data.slug))
          .eq("status", "reserved")
          .is("activated_at", null)
          .maybeSingle();
        if (hold && hold.email.toLowerCase() === data.email) return { available: true };
      }
    }
    return result;
  });

export type ReserveResult =
  | { ok: true; slug: string; checkoutUrl: string; botId: string | null }
  | { ok: false; reason: "invalid" | "invalid_website" | "taken" | "error" | "account_exists" | "wrong_password" | "pass_expired" | "sign_in_needed" }
  | { ok: false; reason: "locked"; lockedMinutes: number };

export const reserveClaimSlug = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ReserveSchema.parse(input))
  .handler(async ({ data }): Promise<ReserveResult> => {
    const slug = normalizeClaimSlug(data.slug);
    if (!isClaimable(slug)) return { ok: false, reason: "invalid" };
    const { claimWebsiteExists } = await import("./claim-website");
    if (!await claimWebsiteExists(data.website ?? "")) return { ok: false, reason: "invalid_website" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { hashPassword, currentAccountId } = await import("./account.server");
    const { readCheckoutPass, issueCheckoutPass } = await import("./checkout-pass.server");
    const startPass = await readCheckoutPass();
    // A checkout pass waives the signature only for the same person: the pass's bot email must match.
    let coveredByPass = false;
    if (startPass && !startPass.expired && !startPass.paid) {
      const { data: passBotRow } = await supabaseAdmin
        .from("client_slugs")
        .select("email")
        .eq("id", startPass.botId)
        .maybeSingle();
      coveredByPass = !!passBotRow && passBotRow.email.toLowerCase() === data.email.toLowerCase();
    }
    // Nobody gets an account, a hold or a pass without signing the Legal Terms first.
    // 189: no signature means the browser relied on its pass, which no longer covers this email.
    if (!coveredByPass && !data.signature) return { ok: false, reason: "pass_expired" };

    // Existing account: signed-in owner, a valid pass for its unpaid hold, or its correct password.
    const { data: found } = await supabaseAdmin
      .from("customer_accounts")
      .select("id, email, password_hash, failed_attempts, locked_until")
      .eq("email", data.email)
      .maybeSingle();
    let existing = found;
    if (existing && (await currentAccountId()) !== existing.id && !coveredByPass) {
      const { data: leftover, error: checkError } = await supabaseAdmin.rpc("claim_account_is_leftover", { p_account_id: existing.id });
      if (checkError) return { ok: false, reason: "error" };
      if (leftover) {
        if (!strongPassword(data.password)) return { ok: false, reason: "invalid" };
        const { data: removed, error: removeError } = await supabaseAdmin.rpc("remove_leftover_accounts", { p_account_id: existing.id });
        if (removeError) return { ok: false, reason: "error" };
        if (removed === 1) existing = null;
      }
    }
    let accountId: string;
    let created = false;
    if (existing) {
      let allowed = (await currentAccountId()) === existing.id;
      if (!allowed) {
        const pass = await readCheckoutPass();
        if (pass && !pass.expired && !pass.paid) {
          const { data: passBot } = await supabaseAdmin
            .from("client_slugs")
            .select("id")
            .eq("id", pass.botId)
            .eq("owner_account_id", existing.id)
            .eq("email", data.email.toLowerCase())
            .maybeSingle();
          allowed = !!passBot;
        }
      }
      if (!allowed) {
        // 190: no password and not the signed-in owner (session ended): ask for sign-in, count nothing.
        if (!data.password) return { ok: false, reason: "sign_in_needed" };
        // Same lockout rules as /login; the password is never changed here.
        const locked = !!existing.locked_until && new Date(existing.locked_until).getTime() > Date.now();
        if (locked) return { ok: false, reason: "locked", lockedMinutes: await lockMinutesLeft(existing.id) };
        const { verifyPassword } = await import("./account.server");
        if (!data.password || !verifyPassword(data.password, existing.password_hash)) {
          const { data: outcome } = await supabaseAdmin.rpc("register_failed_login", { p_account_id: existing.id, p_max: 10, p_lock_minutes: 15 });
          if (outcome === "locked_now") {
            const { sendLockAlert } = await import("./account.functions");
            await sendLockAlert(existing.email, new Date().toISOString());
          }
          if (outcome === "locked_now" || outcome === "already_locked") {
            return { ok: false, reason: "locked", lockedMinutes: await lockMinutesLeft(existing.id) };
          }
          return { ok: false, reason: "wrong_password" };
        }
        await supabaseAdmin.from("customer_accounts").update({ failed_attempts: 0, locked_until: null }).eq("id", existing.id);
      }
      accountId = existing.id;
    } else {
      if (!data.password || !strongPassword(data.password)) return { ok: false, reason: "invalid" };
      const { data: acct, error: acctError } = await supabaseAdmin
        .from("customer_accounts")
        .insert({ email: data.email, password_hash: hashPassword(data.password) })
        .select("id")
        .single();
      if (acctError || !acct) {
        if (acctError?.code === "23505") return { ok: false, reason: "account_exists" };
        console.error("[claim] account create failed", acctError?.code);
        return { ok: false, reason: "error" };
      }
      accountId = acct.id;
      created = true;
    }
    const undo = async () => {
      if (created) await supabaseAdmin.from("customer_accounts").delete().eq("id", accountId);
    };

    // An unpaid hold for this email may only be changed by its signed-in owner.
    const { data: hold } = await supabaseAdmin
      .from("client_slugs")
      .select("owner_account_id")
      .eq("email", data.email.toLowerCase())
      .eq("status", "reserved")
      .maybeSingle();
    if (hold && hold.owner_account_id !== accountId) {
      await undo();
      return { ok: false, reason: "account_exists" };
    }

    // Proof of signing: kept permanently, never removed by any cleanup.
    if (data.signature) {
      const { getRequestHeader } = await import("@tanstack/react-start/server");
      // 185: cf-connecting-ip first; first x-forwarded-for value only if it is missing.
      const fwd = (getRequestHeader("x-forwarded-for") ?? "").split(",")[0]?.trim();
      const ip = getRequestHeader("cf-connecting-ip")?.trim() || fwd || getRequestHeader("x-real-ip") || null;
      const { LEGAL_VERSION } = await import("./legal-terms");
      const { error: sigError } = await supabaseAdmin.from("legal_signatures").insert({
        account_id: accountId,
        email: data.email,
        full_name: data.signature.fullName,
        agreed_sensitive_use: true,
        agreed_terms: true,
        ip_address: ip,
        user_agent: (getRequestHeader("user-agent") ?? "").slice(0, 500) || null,
        terms_version: LEGAL_VERSION,
      });
      if (sigError) {
        console.error("[claim] signature save failed", sigError.code);
        await undo();
        return { ok: false, reason: "error" };
      }
    }

    // Atomic: the database rejects a second simultaneous claim for the same slug.
    const { data: result, error } = await supabaseAdmin.rpc("reserve_client_slug", {
      p_email: data.email,
      p_slug: slug,
      p_domains: domainsFromWebsite(data.website),
      ...(data.firstName ? { p_full_name: data.firstName } : {}),
      ...(data.lastName ? { p_last_name: data.lastName } : {}),
      ...(data.phone ? { p_phone: data.phone } : {}),
      ...(data.companyName ? { p_company: data.companyName } : {}),
      ...(data.website ? { p_website: data.website } : {}),
      p_owner_account_id: accountId,
    });

    if (error) {
      console.error("[claim] reservation failed", error);
      await undo();
      return { ok: false, reason: "error" };
    }
    const payload = (result ?? {}) as { ok?: boolean; reason?: string };
    if (!payload.ok) {
      await undo();
      return { ok: false, reason: payload.reason === "taken" ? "taken" : payload.reason === "invalid" ? "invalid" : "error" };
    }

    // The bot's unique ID, so the voice webhook can tell a customer's bots apart.
    const { data: botRow } = await supabaseAdmin
      .from("client_slugs")
      .select("id")
      .eq("slug", slug)
      .maybeSingle();
    const botId = botRow?.id ?? null;
    // A checkout pass for this bot instead of a sign-in; an existing valid pass keeps its original start time.
    const current = await readCheckoutPass();
    const hasPass = !!current && !current.expired && !current.paid && current.botId === botId;
    if (botId && !hasPass) {
      await issueCheckoutPass(botId);
      // 185: a re-confirmed unpaid hold that gets a fresh pass also restarts its full hold length.
      await supabaseAdmin
        .from("client_slugs")
        .update({ hold_expires_at: new Date(Date.now() + 45 * 60 * 1000).toISOString() })
        .eq("id", botId)
        .eq("status", "reserved")
        .is("activated_at", null);
    }

    const base = DEFAULT_CHECKOUT_URL;
    let checkoutUrl = base;
    try {
      const url = new URL(base);
      url.searchParams.set("email", data.email);
      url.searchParams.set("slug", slug);
      checkoutUrl = url.toString();
    } catch {
      checkoutUrl = base;
    }

    return { ok: true, slug, checkoutUrl, botId };
  });

/** 190: Start Over on the expired voice page releases this pass's own still-unpaid hold. */
export const releasePassHold = createServerFn({ method: "POST" }).handler(async () => {
  const { readCheckoutPass, disableCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  if (!pass || pass.paid) return { ok: true };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: bot } = await supabaseAdmin
    .from("client_slugs")
    .select("*")
    .eq("id", pass.botId)
    .neq("status", "active")
    .is("activated_at", null)
    .maybeSingle();
  if (!bot || bot.status === "paused") return { ok: true };
  await disableCheckoutPass(pass.passId);
  const { error: logErr } = await supabaseAdmin.from("security_audit_log").insert({ event_type: "hold_expired", details: bot });
  if (logErr) return { ok: false };
  await supabaseAdmin.from("client_slugs").delete().eq("id", bot.id).neq("status", "active").is("activated_at", null);
  return { ok: true };
});
