/**
 * Checkout pass: a limited, bot-scoped cookie given after /claim instead of a sign-in.
 * It only allows that bot's checkout steps (hold change, voice choice, /welcome status)
 * and can never sign anyone in. Unpaid: valid 30 minutes. Paid: valid until switched off.
 */
import { randomBytes } from "crypto";
import { getCookie, setCookie } from "@tanstack/react-start/server";
import { sha256 } from "./account.server";

export const PASS_COOKIE = "lb_checkout";
const UNPAID_MS = 30 * 60 * 1000;
// 185: read-only /welcome status may keep checking an unpaid pass for 2 hours.
const UNPAID_STATUS_MS = 2 * 60 * 60 * 1000;
// 185: a paid pass only reads /welcome status, for at most 24 hours after payment.
const PAID_MS = 24 * 60 * 60 * 1000;

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

export async function issueCheckoutPass(botId: string) {
  const token = randomBytes(32).toString("base64url");
  const db = await admin();
  const { error } = await db.from("checkout_passes").insert({ bot_id: botId, token_hash: sha256(token) });
  if (error) throw new Error("checkout pass create failed");
  setCookie(PASS_COOKIE, token, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });
}

export type PassInfo = {
  passId: string;
  botId: string;
  paid: boolean;
  /** Not usable for hold changes or voice choice (paid, or unpaid past 30 minutes). */
  expired: boolean;
  /** Not usable even for the read-only /welcome status check. */
  statusExpired: boolean;
};

/** 188: whether the browser sent an lb_checkout cookie at all. */
export function hasPassCookie(): boolean {
  return !!getCookie(PASS_COOKIE);
}

/** The browser's pass, or null if there is none or it was switched off. */
export async function readCheckoutPass(): Promise<PassInfo | null> {
  const token = getCookie(PASS_COOKIE);
  if (!token) return null;
  const db = await admin();
  const { data } = await db
    .from("checkout_passes")
    .select("id, bot_id, created_at, disabled_at")
    .eq("token_hash", sha256(token))
    .maybeSingle();
  if (!data || data.disabled_at) return null;
  const { data: bot } = await db
    .from("client_slugs")
    .select("status, activated_at")
    .eq("id", data.bot_id)
    .maybeSingle();
  if (!bot) return null;
  const paid = bot.status === "active" || !!bot.activated_at;
  const age = Date.now() - new Date(data.created_at).getTime();
  const expired = paid || age > UNPAID_MS;
  const statusExpired = paid
    ? !!bot.activated_at && Date.now() - new Date(bot.activated_at).getTime() > PAID_MS
    : age > UNPAID_STATUS_MS;
  return { passId: data.id, botId: data.bot_id, paid, expired, statusExpired };
}

/** Valid pass for exactly this bot. */
export async function hasValidPassFor(botId: string): Promise<boolean> {
  const p = await readCheckoutPass();
  return !!p && !p.expired && p.botId === botId;
}

export async function disableCheckoutPass(passId: string) {
  const db = await admin();
  await db.from("checkout_passes").update({ disabled_at: new Date().toISOString() }).eq("id", passId).is("disabled_at", null);
}

/** 194: a switched-off pass whose bot is paid and active, within 24 hours of payment (read-only /welcome status). */
export async function readFinishedPaidPassBot(): Promise<string | null> {
  const token = getCookie(PASS_COOKIE);
  if (!token) return null;
  const db = await admin();
  const { data } = await db
    .from("checkout_passes")
    .select("bot_id, disabled_at")
    .eq("token_hash", sha256(token))
    .maybeSingle();
  if (!data || !data.disabled_at) return null;
  const { data: bot } = await db
    .from("client_slugs")
    .select("status, activated_at")
    .eq("id", data.bot_id)
    .maybeSingle();
  if (!bot || bot.status !== "active" || !bot.activated_at) return null;
  if (Date.now() - new Date(bot.activated_at).getTime() > PAID_MS) return null;
  return data.bot_id;
}
