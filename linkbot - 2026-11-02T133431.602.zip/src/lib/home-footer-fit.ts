import { useLayoutEffect, type RefObject } from "react";

let measureContext: CanvasRenderingContext2D | null | undefined;
function getMeasureContext() {
  if (measureContext === undefined) measureContext = document.createElement("canvas").getContext("2d");
  return measureContext;
}

/**
 * Homepage footer only: keeps the visible space between the bottom of the
 * "Click for answers" tab and the bottom of the footer equal to the on-screen
 * header height, and matches the footer's top line to the header line.
 * Runs on mount, resize and tab/footer size changes — never on scroll.
 */
export function useHomeFooterFit(footerRef: RefObject<HTMLElement | null>, deps: unknown[] = []) {
  useLayoutEffect(() => {
    const footer = footerRef.current;
    if (!footer) return;
    const tag = footer.querySelector<HTMLElement>(".faq-pull-tab"); // resting box; the inner tag animates
    if (!tag) return;

    const findHeader = () =>
      Array.from(document.querySelectorAll<HTMLElement>(".desktop-header-frame, header")).find((el) => {
        if (footer.contains(el)) return false;
        const r = el.getBoundingClientRect();
        return r.height > 0 && r.width > 0 && getComputedStyle(el).position === "fixed";
      }) ??
      Array.from(document.querySelectorAll<HTMLElement>("header")).find((el) => el.getBoundingClientRect().height > 0);

    const lineWidthVisual = (header: HTMLElement) => {
      const els = [header, ...Array.from(header.querySelectorAll<HTMLElement>("*"))];
      for (const el of els) {
        const w = parseFloat(getComputedStyle(el).borderBottomWidth);
        if (w > 0) {
          const r = el.getBoundingClientRect();
          const k = el.offsetHeight > 0 ? r.height / el.offsetHeight : 1;
          return w * k;
        }
      }
      return 1;
    };

    let lastMeasurements = "";
    let good: { top: string; h: string } | null = null; // last fit that looked right
    const measurements = (header: HTMLElement, para: HTMLElement) => {
      const fr = footer.getBoundingClientRect();
      const values = [header.getBoundingClientRect().height, lineWidthVisual(header), footer.offsetHeight, fr.height];
      const fonts: string[] = [];
      for (const el of [para, tag, footer.querySelector<HTMLElement>(".faq-pull-tab__copy strong"), footer.querySelector<HTMLElement>(".faq-pull-tab__tag")]) {
        if (!el) continue;
        const r = el.getBoundingClientRect();
        values.push(r.top - fr.top, r.width, r.height, el.offsetHeight);
        const cs = getComputedStyle(el);
        fonts.push(cs.font, cs.lineHeight);
      }
      return JSON.stringify([values.map((value) => value.toFixed(3)), fonts, document.fonts?.status]);
    };
    const apply = () => {
      const header = findHeader();
      const para = footer.querySelector<HTMLElement>(":scope > p");
      if (!header || !para || footer.offsetHeight === 0) return;
      if (measurements(header, para) === lastMeasurements) return;
      const hr = header.getBoundingClientRect();
      const set = (name: string, v: string) => {
        if (footer.style.getPropertyValue(name) !== v) footer.style.setProperty(name, v);
      };
      footer.classList.add("home-footer-fit");
      // Visual px per footer layout px, read from the footer itself.
      let k = footer.getBoundingClientRect().height / footer.offsetHeight || 1;
      let top = parseFloat(footer.style.getPropertyValue("--hf-top")) || 0;
      let h = parseFloat(footer.style.getPropertyValue("--hf-h")) || hr.height / k;
      set("--hf-line", `${(lineWidthVisual(header) / k).toFixed(4)}px`);
      // Converge on exact on-screen geometry (zoom/scale-safe), a few passes.
      for (let i = 0; i < 4; i++) {
        set("--hf-top", `${top.toFixed(3)}px`);
        set("--hf-h", `${h.toFixed(3)}px`);
        const pr = para.getBoundingClientRect();
        if (pr.height > 0 && h > 0) k = pr.height / h;
        const dTop = tag.getBoundingClientRect().bottom - pr.top;
        const dH = hr.height - pr.height;
        if (Math.abs(dTop) < 0.05 && Math.abs(dH) < 0.05) break;
        top = Math.max(0, top + dTop / k);
        h = Math.max(0, h + dH / k);
      }
      // Never keep a wild result (e.g. measured mid-scroll or mid-animation): go back to the last good fit instead.
      const maxPx = Math.max(600, (hr.height / k) * 6);
      const curTop = parseFloat(footer.style.getPropertyValue("--hf-top"));
      const curH = parseFloat(footer.style.getPropertyValue("--hf-h"));
      if (![top, h, curTop, curH].every((v) => Number.isFinite(v) && v >= 0 && v <= maxPx)) {
        if (good) { set("--hf-top", good.top); set("--hf-h", good.h); }
        else { footer.classList.remove("home-footer-fit"); footer.style.removeProperty("--hf-top"); footer.style.removeProperty("--hf-h"); }
        return;
      }
      good = { top: footer.style.getPropertyValue("--hf-top"), h: footer.style.getPropertyValue("--hf-h") };
      // Dark surface begins level with the top of the white "CLICK FOR ANSWERS"
      // letters; the strip above is painted in the colour directly above.
      const strong = footer.querySelector<HTMLElement>(".faq-pull-tab__copy strong");
      const tagEl = footer.querySelector<HTMLElement>(".faq-pull-tab__tag");
      if (strong && tagEl) {
        const fr = footer.getBoundingClientRect();
        const kf = fr.height / footer.offsetHeight || 1;
        const sr = strong.getBoundingClientRect();
        const ks = strong.offsetHeight ? sr.height / strong.offsetHeight : kf;
        const cs = getComputedStyle(strong);
        const ctx = getMeasureContext();
        let capOffset = 0;
        if (ctx) {
          ctx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
          const m = ctx.measureText("CLICK FOR ANSWERS");
          const fs = parseFloat(cs.fontSize);
          const lh = parseFloat(cs.lineHeight) || fs * 1.2;
          const asc = m.fontBoundingBoxAscent ?? fs * 0.9;
          const desc = m.fontBoundingBoxDescent ?? fs * 0.25;
          capOffset = (lh - (asc + desc)) / 2 + asc - m.actualBoundingBoxAscent;
        }
        const tr = tagEl.getBoundingClientRect();
        const restingTagTop = tag.getBoundingClientRect().bottom - tr.height;
        const textTop = restingTagTop + (sr.top - tr.top) + capOffset * ks;
        const d = (textTop - fr.top) / kf;
        set("--hf-d", `${Math.max(0, d).toFixed(3)}px`);
        set("--hf-ext", `${Math.max(0, -d).toFixed(3)}px`);
        set("--hf-ext-display", d < 0 ? "block" : "none");
        const prevVis = footer.style.visibility;
        const x = fr.left + fr.width * 0.08;
        const y = fr.top - 1;
        let above = "";
        for (const el of document.elementsFromPoint(x, y)) {
          if (footer.contains(el)) continue;
          const bg = getComputedStyle(el).backgroundColor;
          if (bg && bg !== "transparent" && !/rgba\(.*,\s*0\)$/.test(bg)) { above = bg; break; }
        }
        footer.style.visibility = prevVis;
        if (above) set("--hf-above", above);
        set("--hf-seam", d > 0 && above ? above : "transparent");
      }
      // Cache the fitted geometry, not the pre-fit input, so our own size
      // notification does not repeat the convergence or canvas measurement.
      lastMeasurements = measurements(header, para);
    };

    apply();
    let raf = 0;
    let disposed = false;
    let lastW = window.innerWidth;
    const schedule = () => {
      // Pinch-zoom never re-measures.
      if (disposed || raf || (window.visualViewport?.scale ?? 1) > 1.01) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        apply();
      });
    };
    // Re-fit ONLY for real changes: the window gets wider or narrower, the phone is turned, the FAQ opens or closes,
    // the page finishes loading, or the fonts finish loading. Never on a timer, never on scroll, never for a sliding address bar.
    const onResize = () => {
      const w = window.innerWidth;
      if (w === lastW) return;
      lastW = w;
      schedule();
    };
    const onTurn = () => {
      lastW = -1;
      window.setTimeout(onResize, 250);
    };
    const refit = () => {
      lastMeasurements = "";
      schedule();
    };
    const onFaqTransitionEnd = (event: Event) => {
      const target = event.target;
      if (target instanceof Element && target.classList.contains("faq-drawer")) refit();
    };
    document.addEventListener("transitionend", onFaqTransitionEnd);
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onTurn);
    if (document.readyState !== "complete") window.addEventListener("load", refit, { once: true });
    document.fonts?.ready.then(refit).catch(() => {});
    document.fonts?.addEventListener?.("loadingdone", refit);
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      document.removeEventListener("transitionend", onFaqTransitionEnd);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onTurn);
      window.removeEventListener("load", refit);
      document.fonts?.removeEventListener?.("loadingdone", refit);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
