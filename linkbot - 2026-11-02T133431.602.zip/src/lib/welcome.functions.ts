import { createServerFn } from "@tanstack/react-start";

/**
 * Status of the bot this browser's checkout pass belongs to: "active",
 * "waiting" or "signed_out" (no valid pass), plus that bot owner's email.
 */
export const getWelcomeStatus = createServerFn({ method: "GET" }).handler(async () => {
  const { readCheckoutPass, hasPassCookie, readFinishedPaidPassBot } = await import("./checkout-pass.server");
  // 188: only "no cookie at all" is signed_out; a removed or expired pass keeps waiting.
  if (!hasPassCookie()) return { state: "signed_out" as const, email: null as string | null };
  const pass = await readCheckoutPass();
  // 194: a pass switched off at "all set" still shows "all set" on reload while its bot is paid and active (24h).
  const finishedBotId = pass ? null : await readFinishedPaidPassBot();
  if (!finishedBotId && (!pass || pass.statusExpired)) return { state: "waiting" as const, email: null as string | null };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: bot } = await supabaseAdmin
    .from("client_slugs")
    .select("status, owner_account_id")
    .eq("id", finishedBotId ?? pass!.botId)
    .maybeSingle();
  let email: string | null = null;
  if (bot?.owner_account_id) {
    const { data: acct } = await supabaseAdmin
      .from("customer_accounts")
      .select("email")
      .eq("id", bot.owner_account_id)
      .maybeSingle();
    email = acct?.email ?? null;
  }
  return { state: bot?.status === "active" ? ("active" as const) : ("waiting" as const), email };
});

/** Called the moment "Yay. You're all set!" shows: switches the pass off for good. */
export const finishCheckoutPass = createServerFn({ method: "POST" }).handler(async () => {
  const { readCheckoutPass, disableCheckoutPass } = await import("./checkout-pass.server");
  const pass = await readCheckoutPass();
  if (pass && pass.paid) await disableCheckoutPass(pass.passId);
  return { ok: true };
});
