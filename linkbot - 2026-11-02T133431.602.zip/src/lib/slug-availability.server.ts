/** The one name-link availability check, shared by /claim and /api/public/name-available. */
import { CLAIM_SLUG_PATTERN, RESERVED_CLAIM_SLUGS, normalizeClaimSlug } from "@/lib/claim-slug";

export type SlugAvailability = { available: boolean; reason?: "invalid" | "taken" };

export async function checkSlugAvailability(raw: string): Promise<SlugAvailability> {
  const slug = normalizeClaimSlug(String(raw ?? "").trim());
  if (!CLAIM_SLUG_PATTERN.test(slug) || RESERVED_CLAIM_SLUGS.has(slug)) return { available: false, reason: "invalid" };

  // Exactly 12 characters is reserved for private link codes.
  if (slug.length === 12) return { available: false, reason: "taken" };

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const claims = await supabaseAdmin
    .from("client_slugs")
    .select("status, activated_at, hold_expires_at")
    .eq("slug", slug)
    .maybeSingle();
  if (claims.error) {
    console.error("[claim] availability check failed", claims.error);
    throw new Error("availability check failed");
  }
  const row = claims.data;
  if (row) {
    const holdExpired =
      row.status !== "active" &&
      !row.activated_at &&
      !!row.hold_expires_at &&
      new Date(row.hold_expires_at).getTime() < Date.now();
    if (!holdExpired) return { available: false, reason: "taken" };
  }
  return { available: true };
}
