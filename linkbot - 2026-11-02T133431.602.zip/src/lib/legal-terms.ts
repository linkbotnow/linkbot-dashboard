/** The LinkBot.Now Legal Terms, exactly as provided (Prompt 205). Shared by the pop-up, /legal and signing. */
export const LEGAL_TITLE = "LINKBOT.NOW LEGAL TERMS";
export const LEGAL_UPDATED = "Last updated: October 2026";
export const LEGAL_VERSION = "October 2026";

export type LegalItem = { n: number; heading: string; text: string };
export type LegalSection = { id: string; title: string; label: string; items: LegalItem[] };

export const LEGAL_SECTIONS: LegalSection[] = [
  {
    "id": "terms",
    "title": "TERMS OF SERVICE",
    "label": "Terms of Service",
    "items": [
      {
        "n": 1,
        "heading": "Acceptance of Terms",
        "text": "These Legal Terms, including the Terms of Service, Privacy Policy, Refund Policy, and AI Disclosure below, govern your access to and use of LinkBot.Now, including the website located at linkbot.now, your account dashboard, and any AI assistant provided to you. By creating an account, completing a purchase, or otherwise using LinkBot.Now, you agree to be bound by these Legal Terms."
      },
      {
        "n": 2,
        "heading": "Description of the Service",
        "text": "LinkBot.Now provides AI-powered tools for businesses, including AI assistants that interact with visitors on your behalf through a private link. LinkBot.Now reserves the right to add, modify, or discontinue any feature or part of the service at any time."
      },
      {
        "n": 3,
        "heading": "Eligibility and Accounts",
        "text": "You must be at least 18 years of age to use LinkBot.Now. You agree to provide accurate information, to keep your login credentials confidential, and to accept responsibility for all activity under your account."
      },
      {
        "n": 4,
        "heading": "Subscriptions and Billing",
        "text": "Each AI assistant is a separate monthly subscription, billed in advance at the price shown at checkout and renewing automatically until cancelled. LinkBot.Now reserves the right to change subscription pricing at any time, and will notify you by email before any price change takes effect for your subscription. If a payment fails, LinkBot.Now reserves the right to suspend your assistant until payment is received."
      },
      {
        "n": 5,
        "heading": "Your Content",
        "text": "You retain ownership of all content you provide to LinkBot.Now, including websites, documents, and links, and grant LinkBot.Now a limited license to use it solely to operate the service. You represent that you have all rights necessary to provide your content, and that it does not violate any law or the rights of any third party."
      },
      {
        "n": 6,
        "heading": "Acceptable Use",
        "text": "You agree not to use LinkBot.Now to send unsolicited messages, to mislead, harass, or defraud any person, to collect information unlawfully, or to violate any applicable law or the terms of any platform on which you share your link. LinkBot.Now reserves the right to suspend or terminate any account that violates this section, without notice or refund."
      },
      {
        "n": 7,
        "heading": "Prohibited Uses",
        "text": "LinkBot.Now is not designed to provide medical, health, legal, or financial advice, or to receive, store, or process protected health information or other sensitive personal data. You agree not to use LinkBot.Now to share, collect, or store any patient, health, or other legally regulated sensitive information, to provide medical, health, legal, or financial advice, or to promote or sell any product or service in violation of any law, including products such as peptides, supplements, or drugs. You are solely responsible for all content you provide to your AI assistant, all information it shares on your behalf, and your compliance with every law and regulation applicable to your business."
      },
      {
        "n": 8,
        "heading": "Links",
        "text": "Your private link provides access to your AI assistant, and your name link is for display purposes only. You are responsible for keeping your private link confidential, sharing it only where LinkBot.Now instructs, and for any use of the service resulting from its distribution elsewhere. LinkBot.Now reserves the right to modify, disable, or replace any link at any time to protect the service or your account."
      },
      {
        "n": 9,
        "heading": "AI Limitations",
        "text": "Your AI assistant operates automatically and may produce inaccurate or incomplete responses. You are solely responsible for monitoring its activity and for any decisions you make based on its output."
      },
      {
        "n": 10,
        "heading": "Third-Party Providers",
        "text": "LinkBot.Now relies on third-party providers for hosting, artificial intelligence, communications, and payment processing, and is not responsible for any interruption, error, or loss caused by those providers."
      },
      {
        "n": 11,
        "heading": "Disclaimer of Warranties",
        "text": "LinkBot.Now is provided on an \"as is\" and \"as available\" basis, without warranties of any kind, and does not guarantee that the service will be uninterrupted, error free, or produce any particular business result."
      },
      {
        "n": 12,
        "heading": "Limitation of Liability",
        "text": "To the fullest extent permitted by law, LinkBot.Now shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including lost profits, revenue, or data. LinkBot.Now's total liability for any claim shall not exceed the amount of your monthly payment in the one month preceding the claim."
      },
      {
        "n": 13,
        "heading": "Indemnification",
        "text": "You agree to indemnify, defend, and hold harmless LinkBot.Now from any claims, damages, losses, fines, penalties, and expenses, including legal fees, arising from your use of the service, your content, your AI assistant's activity, or your violation of these Legal Terms or any law."
      }
    ]
  },
  {
    "id": "privacy",
    "title": "PRIVACY POLICY",
    "label": "Privacy Policy",
    "items": [
      {
        "n": 1,
        "heading": "Information Collected",
        "text": "When you request a demo or create an account, LinkBot.Now collects your name, email address, phone number, company name, and website. Passwords are stored in encrypted form and are never visible to anyone, including LinkBot.Now. Payments are handled by a third-party payment processor, and LinkBot.Now does not store full payment card numbers."
      },
      {
        "n": 2,
        "heading": "Cookies",
        "text": "LinkBot.Now uses only the cookies necessary to operate the website, such as those that keep you signed in and complete your checkout, and does not use advertising cookies."
      },
      {
        "n": 3,
        "heading": "Use of Information",
        "text": "LinkBot.Now uses information to provide and improve the service, process payments, send account communications, provide support, protect the security of the service, and comply with legal obligations."
      },
      {
        "n": 4,
        "heading": "Sharing of Information",
        "text": "LinkBot.Now does not sell personal information. Information is shared only with the business a visitor interacted with, with third-party providers that support the operation of the service, or as required by law."
      },
      {
        "n": 5,
        "heading": "Data Retention and Requests",
        "text": "LinkBot.Now retains information for as long as necessary to provide the service and comply with legal obligations, and reserves the right to delete a customer's account data after their subscription has been cancelled. Requests to access, correct, or delete personal information may be submitted to support@linkbot.now."
      },
      {
        "n": 6,
        "heading": "Security",
        "text": "LinkBot.Now protects your information with industry standard safeguards, including encrypted connections and encrypted passwords. While no online service can be entirely immune to risk, LinkBot.Now continuously works to keep your information safe."
      }
    ]
  },
  {
    "id": "refund",
    "title": "REFUND POLICY",
    "label": "Refund Policy",
    "items": [
      {
        "n": 1,
        "heading": "No Refunds",
        "text": "All payments are final and non-refundable, including partial billing periods and unused time."
      },
      {
        "n": 2,
        "heading": "Cancellation",
        "text": "You may cancel any subscription at any time from your account. Your AI assistant will remain active through the end of the billing period you have already paid for, and you will not be charged again. To avoid being charged for the next billing period, you must cancel before your renewal date."
      }
    ]
  },
  {
    "id": "ai-disclosure",
    "title": "AI DISCLOSURE",
    "label": "AI Disclosure",
    "items": [
      {
        "n": 1,
        "heading": "Interaction with Artificial Intelligence",
        "text": "LinkBot.Now assistants are automated artificial intelligence voice assistants and are not human. Each assistant speaks on behalf of the business that shared its link, and may share information, links, and resources provided by that business."
      },
      {
        "n": 2,
        "heading": "Transcripts and Consent",
        "text": "Conversations with a LinkBot.Now AI assistant are transcribed. By continuing a conversation, you consent to this transcription, and the transcript and any information you provide are shared with the business you are speaking with."
      }
    ]
  },
  {
    "id": "general",
    "title": "GENERAL",
    "label": "General",
    "items": [
      {
        "n": 1,
        "heading": "Changes",
        "text": "LinkBot.Now reserves the right to update these Legal Terms at any time and will notify customers by email of any material changes. Continued use of LinkBot.Now after any change constitutes acceptance of the updated Legal Terms."
      },
      {
        "n": 2,
        "heading": "Governing Law",
        "text": "These Legal Terms are governed by the laws of the State of Florida."
      }
    ]
  }
];

/** Terms of Service section 7, shown on signing page 1. */
export const SENSITIVE_USE = LEGAL_SECTIONS[0]!.items.find((i) => i.n === 7)!;
