<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Sideways phones use physical orientation and one browser-neutral 1440px auto-fit viewport; clear portrait sizing, reset top and remeasure after rotation settles. Portrait scroll stays separate.
- iPad button sizing stays in `src/styles/ipad-buttons.css`.
- Fit iPad legal portals uniformly in authored coordinates; fit page-1 agreement lines/checkbox together against paragraph font and available label width, preserving shared scaling and scrolling.
- Author portrait-phone pages at a shared 393px layout viewport and let the browser fit that whole composition to the physical screen.
- Keep the portrait-phone homepage hidden until fonts and initial geometry settle to prevent post-reveal shifts.
- Use one shared, full-height desktop-proportioned header treatment across all iPad routes.
- Each route calls `useRevealWhenSettled()` with `pg-boot` hiding to prevent pre-fit paint. Early-script stale CSS reloads are session-guarded; server HTML and Nitro static widget HTML revalidate without changing asset caching.
- Headers fixed except /claim phones (flow). Top-edge pull blocking exempts phone legal touches in root/modal and needs >10px drag elsewhere to preserve taps.

- GHL owns billing/provisioning. Settings use verified context, scoped tokens, independent greetings and local inverse-scale CSS for screen sizes. Renames preserve welcome markers; sends are nonblocking. Refresh uses CAS leases; widget cron verifies auth.
- Customer links: DB-generated private 12-char link_code reaches browsers only after payment; name links require the real-link sessionStorage note. Expired holds are archived to security_audit_log to match late payments.
- Demo protection in demo.functions.ts: trap, DNS mail, 24h repeats, alert-only volume, per-request DEMO_STRICT_MODE.
- Customer sign-in uses our own customer_accounts + httpOnly lb_session cookie (server-only tables, scrypt), not backend auth users; logins belong to the person so one account can own several bots.
- GoHighLevel webhooks: activate deduplicates paymentId; bot-status handles widget/pause/resume/cancel; page-title uses the bot-status secret and a shared title resolver. Cancelled link codes stay retired forever.
- /logout ends the customer session; daily job public.daily_auth_cleanup (migration) deletes only expired sessions, stale reset codes, dead checkout passes and used/expired demo codes, never customer, bot, link or billing data.
- /claim needs permanent legal_signatures before account/hold/pass; /legal has no site chrome.
- Keep footer copy on one centered line ("© year LinkBot · support@linkbot.now · Legal Terms") in the shared FooterLegalLink and footer styles, shrinking only to fit.
- /claim never signs in: customers use /login themselves. Its bot-scoped httpOnly lb_checkout pass allows only hold changes, voice choice and /welcome status, expires before the unpaid name hold, and ends at "all set". Valid unpaid returners get the bot's prefilled form, locked email, no password, and retain their original pass on reconfirmation.
- GoHighLevel link-change accepts rename/new_link for active bots via rename_bot_slug/new_bot_link_code; /claim and name-available share slug-availability.server.ts so rules stay aligned.
- Phones sign the Legal Terms on the standalone /sign route (iPad/desktop keep the pop-up); the /claim form travels via the in-memory src/lib/sign-handoff.ts so passwords are never stored and nothing renders underneath.
- Touch-homepage pinch light mode is `home-zoom-light` on <html>, set by the root zoom effect at the second finger/gesturestart, cleared at normal zoom with no fingers down; CSS pauses all motion, hero timers use a separate zoom pause reason. Why: switching after zoom changes was too late to prevent memory crashes.
- Upright-phone hero uses one portal scale over matching spacers; nested scales crashed pinch.

- Homepage gaps use authored CSS, never runtime sizing, to prevent post-load resizing.
- Share comparison overlap/rotation CSS on desktop and iPad; preserve phone rules.
- Down-only reveals use scroll direction, not positions (zoom skews them).
- Share pricing paint, not geometry. Retained backup chat uses named off switches.
- Website inputs start as editable "www.", strip only leading http(s):// and doubled pasted "www.", and send the trimmed value.
- Homepage demo views share a settled top pin; only deliberate scrolling cancels it. Keep ordinary route scrolling separate.
- Frame checks validate public HTTPS/DNS at every redirect to exclude private destinations.
- Bot tools verify keys; successful shares alone add buttons. Polling exact-matches call IDs; diagnostics expire in seven days. Account/call-scoped contact recap writes use location tokens and an independent 10s deadline, so provider failures never affect sharing.
- My Links: scoped/version-safe access, DNS-safe redirects, bounded AI, unique hosts. Shared URL keys and statement-lock duplicate guards prevent races. Autofill requires verified GHL or owner.
- Honor SNAPSHOTS_ENABLED; preserve scoped writes, DNS checks and data/secrets.
- Call-link views resolve registered IDs/URLs only; HTTPS/DNS checks cover redirects. Proxies strip active content, use opaque sandboxes and reject unsaved navigation to protect cookies.
- Follow-up uses My Links verification; server reservations prevent duplicate emails.
- Fit overlays by settled widths/Range rectangles. My Links uses a fluid unscaled canvas, fixed controls and gap-only compensation; phone actions live on body. Settings keeps static canvas and auto-height/unclipped wrappers; desktop/iPad minimum heights subtract frame/tab offsets to fill the window and preserve bottom padding. Guide footers add flow height; sizing stays separate from spacing.
- Optional My Links remembered devices use location-scoped random bearer tokens, hashed server-side and checked against ownership, expiry, revocation and credential version on every request; password-hash changes revoke all device rows through a database trigger. Browser storage contains only the device token so iframe access does not depend on third-party cookies.
- My Links remembers the checkbox choice separately as a location-scoped noncredential flag; token restoration gates login rendering until verification and initial reads settle, including BFCache returns, so invalidating access does not erase the device's choice.
- My Links category hints occupy a permanently reserved line in the existing tabs wrapper, use scroll-width overflow independent of scroll position and rebound after render; mouse drags suppress only their resulting click so filtering and geometry stay stable.
- Setup Guide preserves authored scaling/native phone sizes. fitGuide measures the phone lane/full-height gradient and fits only the intro via restored font/Range width. Observe popup size changes; track active circles by viewport rectangles against the existing overlay's one-third line so scaled tablet scrolling stays aligned.
- Settings observes box/card widths: fit nonphone notes with a 10px floor; preserve phone notes. Voice layout uses frame viewport width (narrow at ≤450px), never card width; action labels stay measured.
- Stacked settings tabs preserve desktop fitting; phones share a measured width/height-bounded label font and explicit display-only line breaks with fixed label clearance, narrowing uncovered areas only when needed. Offset unselected icons by half the overlap; display names never rename persisted keys.
- Caller edits use nullable bot fields, falling back to signup names. Pass screenName separately from greeting name; never overwrite signup or greeting values.

- Signup voice shares claim grid/ClaimOrderAside scaling; fixed confetti portals to body to escape scaled canvases.
- Claim-only shape/DNS checks fail open on outages; locked service-only leftover cleanup protects paid/live/current holds and preserves signatures, hourly and before reserve.
- Desktop width recovery uses size-healing and existing callbacks; touch, zoom, rotation and scroll guards stay unchanged.
- Claim switches keep settled-top calls, no keyboard correction; phone agreement taps exclude native controls, toggle once and preserve other labels.
